#!/usr/bin/env python3
"""
重新量化模型脚本
使用改进的配置和校准数据重新进行量化
"""

import os
import sys
import torch
import torch.nn as nn
import numpy as np
import json
import copy
from typing import List, Dict

# 添加项目路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from aimet_torch.quantsim import QuantizationSimModel
    from aimet_common.defs import QuantScheme
    from aimet_torch.cross_layer_equalization import equalize_model
    AIMET_AVAILABLE = True
    print("AIMET量化库已加载")
except ImportError as e:
    print(f"AIMET库导入失败: {e}")
    AIMET_AVAILABLE = False

def create_optimized_quantization_config() -> Dict:
    """
    创建优化的量化配置
    使用简化的配置避免冲突
    """
    config = {
        "defaults": {
            "ops": {
                "is_output_quantized": "True",
                "is_symmetric": "True"
            },
            "params": {
                "is_quantized": "True",
                "is_symmetric": "True"
            }
        },
        "params": {
            # 关键参数保持浮点精度
            "bias": {"is_quantized": "False"}
        },
        "op_type": {
            # 对Softmax使用特殊处理
            "Softmax": {
                "is_output_quantized": "True",
                "is_symmetric": "True"
            }
        },
        "supergroups": [
            {"op_list": ["Conv", "Relu"]},
            {"op_list": ["MatMul", "Add"]}
        ],
        "model_input": {
            "is_input_quantized": "True"
        },
        "model_output": {
            "is_output_quantized": "True"
        }
    }
    return config

def load_real_audio_calibration_data(audio_dir: str = "fsmn_model/example", num_samples: int = 200) -> List[torch.Tensor]:
    """
    从真实音频文件加载校准数据
    """
    try:
        import librosa
        from pathlib import Path
        AUDIO_LIBS_AVAILABLE = True
    except ImportError:
        print("音频处理库未安装，使用模拟数据...")
        return create_enhanced_calibration_data(num_samples)

    print(f"从 {audio_dir} 加载真实音频校准数据...")

    features = []
    audio_files = []

    # 查找音频文件
    audio_dir_path = Path(audio_dir)
    if audio_dir_path.exists():
        for ext in ['*.wav', '*.mp3', '*.flac', '*.m4a']:
            audio_files.extend(list(audio_dir_path.glob(ext)))

    if not audio_files:
        print("未找到音频文件，使用模拟数据...")
        return create_enhanced_calibration_data(num_samples)

    print(f"找到 {len(audio_files)} 个音频文件")

    # 音频处理参数
    sample_rate = 16000

    for audio_file in audio_files:
        try:
            print(f"处理音频文件: {audio_file.name}")

            # 加载音频
            audio, _ = librosa.load(str(audio_file), sr=sample_rate)

            # 如果音频太短，跳过
            if len(audio) < sample_rate:
                continue

            # 提取mel频谱特征
            mel_spec = librosa.feature.melspectrogram(
                y=audio,
                sr=sample_rate,
                n_fft=512,
                hop_length=160,  # 10ms
                win_length=400,  # 25ms
                n_mels=80
            )

            # 转换为对数mel频谱
            log_mel = librosa.power_to_db(mel_spec, ref=np.max)
            log_mel = (log_mel + 80) / 80  # 归一化

            # 分割成400帧的段
            n_frames = log_mel.shape[1]
            segment_length = 400

            for start_idx in range(0, n_frames - segment_length + 1, segment_length // 4):
                end_idx = start_idx + segment_length
                segment = log_mel[:, start_idx:end_idx]  # [80, 400]

                # 调整到[400, 400]
                if segment.shape[0] != 400:
                    if segment.shape[0] < 400:
                        repeat_factor = 400 // segment.shape[0] + 1
                        segment = np.tile(segment, (repeat_factor, 1))[:400, :]
                    else:
                        indices = np.linspace(0, segment.shape[0]-1, 400, dtype=int)
                        segment = segment[indices, :]

                feature = torch.tensor(segment.T, dtype=torch.float32)  # [400, 80] -> [400, 400]

                if feature.shape[1] != 400:
                    if feature.shape[1] < 400:
                        padding = torch.zeros(400, 400 - feature.shape[1])
                        feature = torch.cat([feature, padding], dim=1)
                    else:
                        feature = feature[:, :400]

                feature = torch.clamp(feature, -1.0, 1.0)
                features.append(feature)

                if len(features) >= num_samples:
                    break

            if len(features) >= num_samples:
                break

        except Exception as e:
            print(f"处理音频文件失败: {e}")
            continue

    # 如果真实音频特征不够，用模拟特征补充
    if len(features) < num_samples:
        print(f"真实音频特征 {len(features)} 个，用模拟特征补充到 {num_samples} 个")
        simulated_features = create_enhanced_calibration_data(num_samples - len(features))
        features.extend(simulated_features)

    print(f"校准数据加载完成，共 {len(features)} 个样本")
    return features[:num_samples]

def create_enhanced_calibration_data(num_samples: int = 200) -> List[torch.Tensor]:
    """
    创建增强的校准数据（备用方案）
    更好地覆盖VAD模型的输入分布
    """
    print(f"生成 {num_samples} 个增强校准样本...")

    features = []

    for i in range(num_samples):
        sample_type = i % 6

        if sample_type == 0:
            # 纯静音 - 极低能量
            feature = torch.randn(400, 400) * 0.005
        elif sample_type == 1:
            # 低能量语音 - 轻声说话
            feature = torch.randn(400, 400) * 0.03
            # 添加语音的频谱结构
            for f in range(0, 400, 80):
                feature[:, f:f+20] *= 1.2
        elif sample_type == 2:
            # 正常语音 - 正常说话
            feature = torch.randn(400, 400) * 0.08
            # 增强语音频段
            for f in range(0, 400, 60):
                feature[:, f:f+30] *= 1.5
        elif sample_type == 3:
            # 高能量语音 - 大声说话
            feature = torch.randn(400, 400) * 0.12
            # 强化低频和高频
            feature[:, :100] *= 1.3
            feature[:, 300:] *= 1.3
        elif sample_type == 4:
            # 背景噪音
            feature = torch.randn(400, 400) * 0.04
        else:
            # 语音+噪音混合
            speech = torch.randn(400, 400) * 0.06
            noise = torch.randn(400, 400) * 0.02
            feature = speech + noise

        # 添加时间维度的相关性（模拟真实音频的时间连续性）
        for t in range(1, 400):
            feature[t] = 0.7 * feature[t] + 0.3 * feature[t-1]

        # 确保在合理范围内
        feature = torch.clamp(feature, -0.3, 0.3)
        features.append(feature)

    print("增强校准数据生成完成")
    return features

class QuantWrapper(nn.Module):
    """AIMET兼容的模型包装器"""
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, input_tensor, cache_0, cache_1, cache_2, cache_3):
        return self.model(input_tensor, cache_0, cache_1, cache_2, cache_3)

def replace_custom_modules(model):
    """递归替换自定义模块为标准PyTorch模块"""
    for name, module in model.named_children():
        if hasattr(module, '__class__') and 'RectifiedLinearFixed' in str(module.__class__):
            # 替换为标准ReLU
            setattr(model, name, nn.ReLU())
            print(f"替换 {name}: RectifiedLinearFixed -> ReLU")
        else:
            replace_custom_modules(module)

def requantize_model_with_improved_config(model, output_dir: str = "test_cache_model"):
    """
    使用改进的配置重新量化模型
    """
    if not AIMET_AVAILABLE:
        print("AIMET不可用，无法重新量化")
        return None
    
    print("开始使用改进配置重新量化模型...")
    
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. 创建优化的量化配置
    config = create_optimized_quantization_config()
    config_file = os.path.join(output_dir, "optimized_quantization_config.json")
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)
    print(f"优化量化配置已保存: {config_file}")
    
    # 2. 准备模型 - 替换自定义模块
    model_copy = copy.deepcopy(model)
    replace_custom_modules(model_copy)
    wrapper = QuantWrapper(model_copy)
    wrapper.eval()
    print("已替换自定义模块为AIMET兼容模块")
    
    # 3. 创建输入
    dummy_input = torch.randn(1, 400, 400)
    dummy_cache_0 = torch.zeros(1, 128, 19, 1)
    dummy_cache_1 = torch.zeros(1, 128, 19, 1)
    dummy_cache_2 = torch.zeros(1, 128, 19, 1)
    dummy_cache_3 = torch.zeros(1, 128, 19, 1)
    dummy_inputs = (dummy_input, dummy_cache_0, dummy_cache_1, dummy_cache_2, dummy_cache_3)
    
    # 4. 交叉层均衡化
    try:
        equalize_model(model=wrapper,
                       input_shapes=[(1, 400, 400), (1, 128, 19, 1), (1, 128, 19, 1), (1, 128, 19, 1), (1, 128, 19, 1)])
        print("交叉层均衡化完成")
    except Exception as e:
        print(f"交叉层均衡化失败: {e}")
    
    # 5. 创建量化模拟器 - 使用更保守的量化方案
    sim = QuantizationSimModel(
        model=wrapper,
        dummy_input=dummy_inputs,
        quant_scheme=QuantScheme.post_training_tf,  # 使用标准TF方案而不是enhanced
        default_param_bw=8,     # 8bit参数
        default_output_bw=16,   # 16bit激活
        in_place=False,
        config_file=config_file
    )
    print("量化模拟器已创建（使用优化配置）")
    
    # 6. 生成增强校准数据（使用真实音频）
    calibration_features = load_real_audio_calibration_data("fsmn_model/example", 150)
    
    # 7. 校准过程 - 改进的分段处理
    def calibrate(sim_model, _):
        sim_model.eval()
        with torch.no_grad():
            print("开始增强校准过程...")
            
            # 分组处理校准数据，每组模拟一个音频序列
            group_size = 10  # 每组10个段
            num_groups = len(calibration_features) // group_size
            
            for group_idx in range(num_groups):
                # 为每个音频组重置cache
                cache_0 = torch.zeros(1, 128, 19, 1)
                cache_1 = torch.zeros(1, 128, 19, 1)
                cache_2 = torch.zeros(1, 128, 19, 1)
                cache_3 = torch.zeros(1, 128, 19, 1)
                
                # 处理该组的所有段
                start_idx = group_idx * group_size
                end_idx = start_idx + group_size
                group_features = calibration_features[start_idx:end_idx]
                
                for seg_idx, feat in enumerate(group_features):
                    feat_input = feat.unsqueeze(0)
                    
                    try:
                        # 推理并更新cache
                        _, new_cache_0, new_cache_1, new_cache_2, new_cache_3 = sim_model(
                            feat_input, cache_0, cache_1, cache_2, cache_3
                        )
                        
                        # 更新cache状态
                        cache_0, cache_1, cache_2, cache_3 = new_cache_0, new_cache_1, new_cache_2, new_cache_3
                        
                        if (seg_idx + 1) % 5 == 0:
                            print(f"  组 {group_idx + 1}/{num_groups}, 段 {seg_idx + 1}/{group_size}")
                    
                    except Exception as e:
                        print(f"校准失败 - 组 {group_idx + 1}, 段 {seg_idx + 1}: {e}")
                        break
            
            print("增强校准完成")
    
    # 8. 执行校准
    sim.compute_encodings(calibrate, None)
    print("量化校准完成")
    
    # 9. 导出改进的量化模型
    sim.export(
        path=output_dir,
        filename_prefix="quantized_model_improved",
        dummy_input=dummy_inputs
    )
    
    improved_model_path = os.path.join(output_dir, "quantized_model_improved.onnx")
    if os.path.exists(improved_model_path):
        print(f"改进的量化模型已导出: {improved_model_path}")
        
        # 自动修复输入输出名称
        from improve_quantization import fix_quantized_model_names
        fixed_path = fix_quantized_model_names(improved_model_path)
        
        return fixed_path
    else:
        print("改进的量化模型导出失败")
        return None

def main():
    """主函数"""
    print("开始重新量化模型...")
    
    try:
        # 导入原始模型
        from models.fsmn_vad_streaming.encoder_fixed_cache import FSMNFixedCache
        
        model = FSMNFixedCache(
            input_dim=400,
            input_affine_dim=140,
            linear_dim=250,
            proj_dim=128,
            lorder=20,
            output_affine_dim=140,
            output_dim=248,
            fsmn_layers=4,
            use_softmax=True
        )
        model.eval()
        print("原始模型加载完成")
        
        # 重新量化
        improved_model_path = requantize_model_with_improved_config(model)
        
        if improved_model_path:
            print(f"\n重新量化完成!")
            print(f"改进的量化模型: {improved_model_path}")
            
            # 验证改进效果
            from improve_quantization import validate_quantized_model

            print("\n验证改进效果...")
            test_features = load_real_audio_calibration_data("fsmn_model/example", 10)
            results = validate_quantized_model(model, improved_model_path, test_features)
            
            if results:
                print(f"\n改进后的量化质量:")
                print(f"  相对误差: {results['relative_error']*100:.2f}%")
                print(f"  余弦相似度: {results['cosine_similarity']:.6f}")
                
                if results['relative_error'] < 0.1 and results['cosine_similarity'] > 0.9:
                    print("  ✓ 量化质量显著改善!")
                elif results['relative_error'] < 0.2 and results['cosine_similarity'] > 0.8:
                    print("  ✓ 量化质量有所改善")
                else:
                    print("  ⚠ 量化质量仍需进一步优化")
        
    except Exception as e:
        print(f"重新量化失败: {e}")
        import traceback
        print(traceback.format_exc())

if __name__ == "__main__":
    main()
