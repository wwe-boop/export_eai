import onnx
import numpy as np
import torch
import torch.nn.functional as F
from typing import Dict, List, Tuple
import onnxruntime as ort
import sys
import os

def analyze_onnx_model(model_path):
    # 加载ONNX模型
    model = onnx.load(model_path)
    
    # 获取所有操作符
    ops = [node.op_type for node in model.graph.node]
    
    # 检查是否存在if和equal操作符
    has_if = 'If' in ops
    has_equal = 'Equal' in ops
    
    return {
        'model_path': model_path,
        'total_ops': len(ops),
        'unique_ops': sorted(set(ops)),
        'has_if': has_if,
        'has_equal': has_equal,
        'input_names': [input.name for input in model.graph.input],
        'output_names': [output.name for output in model.graph.output],
        'ops_count': {op: ops.count(op) for op in set(ops)}
    }

def compare_models(model1_path, model2_path):
    print("正在分析模型...")
    
    # 分析两个模型
    model1_info = analyze_onnx_model(model1_path)
    model2_info = analyze_onnx_model(model2_path)
    
    print("\n=== 模型1信息 ===")
    print(f"路径: {model1_info['model_path']}")
    print(f"是否包含If操作符: {model1_info['has_if']}")
    print(f"是否包含Equal操作符: {model1_info['has_equal']}")
    print(f"总操作符数量: {model1_info['total_ops']}")
    print("\n操作符统计:")
    for op, count in model1_info['ops_count'].items():
        print(f"  {op}: {count}")
    
    print("\n=== 模型2信息 ===")
    print(f"路径: {model2_info['model_path']}")
    print(f"是否包含If操作符: {model2_info['has_if']}")
    print(f"是否包含Equal操作符: {model2_info['has_equal']}")
    print(f"总操作符数量: {model2_info['total_ops']}")
    print("\n操作符统计:")
    for op, count in model2_info['ops_count'].items():
        print(f"  {op}: {count}")
    
    # 比较差异
    print("\n=== 模型差异分析 ===")
    
    # 比较操作符类型
    ops1 = set(model1_info['unique_ops'])
    ops2 = set(model2_info['unique_ops'])
    
    ops_only_in_model1 = ops1 - ops2
    ops_only_in_model2 = ops2 - ops1
    
    if ops_only_in_model1:
        print(f"\n仅在模型1中存在的操作符: {sorted(ops_only_in_model1)}")
    if ops_only_in_model2:
        print(f"\n仅在模型2中存在的操作符: {sorted(ops_only_in_model2)}")
    
    # 比较输入输出
    if model1_info['input_names'] != model2_info['input_names']:
        print("\n输入名称不同:")
        print(f"模型1输入: {model1_info['input_names']}")
        print(f"模型2输入: {model2_info['input_names']}")
    
    if model1_info['output_names'] != model2_info['output_names']:
        print("\n输出名称不同:")
        print(f"模型1输出: {model1_info['output_names']}")
        print(f"模型2输出: {model2_info['output_names']}")

def calculate_cosine_similarity(tensor1: torch.Tensor, tensor2: torch.Tensor) -> float:
    """计算两个张量之间的余弦相似度"""
    # 确保输入是二维张量
    if tensor1.dim() > 2:
        tensor1 = tensor1.reshape(tensor1.size(0), -1)
    if tensor2.dim() > 2:
        tensor2 = tensor2.reshape(tensor2.size(0), -1)
    
    return F.cosine_similarity(tensor1, tensor2).mean().item()

def analyze_tensor_statistics(tensor: torch.Tensor, name: str = "") -> Dict:
    """分析张量的统计信息"""
    return {
        "name": name,
        "shape": list(tensor.shape),
        "dtype": str(tensor.dtype),
        "min": float(tensor.min()),
        "max": float(tensor.max()),
        "mean": float(tensor.mean()),
        "std": float(tensor.std()),
        "zeros_percentage": float((tensor == 0).sum() / tensor.numel() * 100),
        "near_zeros_percentage": float((torch.abs(tensor) < 1e-6).sum() / tensor.numel() * 100)
    }

def print_tensor_comparison(orig_stats: Dict, quant_stats: Dict, cosine_sim: float):
    """打印张量比较结果"""
    print(f"\n=== {orig_stats['name']} 比较 ===")
    print("原始张量:")
    print(f"  形状: {orig_stats['shape']}")
    print(f"  数据类型: {orig_stats['dtype']}")
    print(f"  范围: [{orig_stats['min']:.6f}, {orig_stats['max']:.6f}]")
    print(f"  均值: {orig_stats['mean']:.6f}")
    print(f"  标准差: {orig_stats['std']:.6f}")
    print(f"  零值占比: {orig_stats['zeros_percentage']:.2f}%")
    print(f"  接近零值占比: {orig_stats['near_zeros_percentage']:.2f}%")
    
    print("\n量化张量:")
    print(f"  形状: {quant_stats['shape']}")
    print(f"  数据类型: {quant_stats['dtype']}")
    print(f"  范围: [{quant_stats['min']:.6f}, {quant_stats['max']:.6f}]")
    print(f"  均值: {quant_stats['mean']:.6f}")
    print(f"  标准差: {quant_stats['std']:.6f}")
    print(f"  零值占比: {quant_stats['zeros_percentage']:.2f}%")
    print(f"  接近零值占比: {quant_stats['near_zeros_percentage']:.2f}%")
    
    print(f"\n余弦相似度: {cosine_sim:.6f}")

def monitor_cache_changes(cache_list: List[torch.Tensor], new_cache_list: List[torch.Tensor], 
                         step: int, cache_names: List[str]):
    """监控cache状态变化"""
    print(f"\n=== Step {step} Cache状态变化 ===")
    for cache, new_cache, name in zip(cache_list, new_cache_list, cache_names):
        change = torch.abs(new_cache - cache)
        print(f"\n{name}:")
        print(f"  原始范围: [{cache.min():.6f}, {cache.max():.6f}]")
        print(f"  新范围: [{new_cache.min():.6f}, {new_cache.max():.6f}]")
        print(f"  变化量: 平均{change.mean():.6f}, 最大{change.max():.6f}")
        print(f"  有效值比例: {(torch.abs(cache) > 1e-6).sum() / cache.numel() * 100:.2f}%")

def compare_model_outputs(original_model, quantized_path, features, num_samples=5):
    """比较原始模型和量化模型的输出，包含详细的分析"""
    print("\n开始详细比较模型输出...")
    
    # 初始化ONNX运行时
    session = ort.InferenceSession(quantized_path, providers=['CPUExecutionProvider'])
    
    # 存储所有比较结果
    all_orig_outputs = []
    all_quant_outputs = []
    all_cosine_sims = []
    cache_changes_orig = []
    cache_changes_quant = []
    
    # 初始化cache
    batch_size = 1
    cache_0 = torch.zeros(batch_size, 128, 19, 1)
    cache_1 = torch.zeros(batch_size, 128, 19, 1)
    cache_2 = torch.zeros(batch_size, 128, 19, 1)
    cache_3 = torch.zeros(batch_size, 128, 19, 1)
    
    cache_names = ['cache_0', 'cache_1', 'cache_2', 'cache_3']
    caches = [cache_0, cache_1, cache_2, cache_3]
    
    print("\n=== 初始Cache状态 ===")
    for cache, name in zip(caches, cache_names):
        stats = analyze_tensor_statistics(cache, name)
        print(f"\n{name}:")
        print(f"  形状: {stats['shape']}")
        print(f"  数据类型: {stats['dtype']}")
        print(f"  初始范围: [{stats['min']:.6f}, {stats['max']:.6f}]")
    
    # 对每个样本进行详细比较
    for i, feat in enumerate(features[:num_samples]):
        print(f"\n处理样本 {i+1}/{num_samples}")
        
        # 准备输入
        feat_input = feat.unsqueeze(0)
        input_stats = analyze_tensor_statistics(feat_input, "输入特征")
        print("\n=== 输入特征统计 ===")
        print(f"形状: {input_stats['shape']}")
        print(f"范围: [{input_stats['min']:.6f}, {input_stats['max']:.6f}]")
        
        # 原始模型推理
        with torch.no_grad():
            orig_output, new_cache_0, new_cache_1, new_cache_2, new_cache_3 = original_model(
                feat_input, cache_0, cache_1, cache_2, cache_3
            )
            all_orig_outputs.append(orig_output)
        
        # 量化模型推理
        onnx_inputs = {
            'input': feat_input.numpy(),
            'cache_0': cache_0.numpy(),
            'cache_1': cache_1.numpy(),
            'cache_2': cache_2.numpy(),
            'cache_3': cache_3.numpy()
        }
        
        quant_outputs = session.run(None, onnx_inputs)
        quant_output = torch.tensor(quant_outputs[0])
        all_quant_outputs.append(quant_output)
        
        # 计算当前步骤的相似度
        cosine_sim = calculate_cosine_similarity(orig_output, quant_output)
        all_cosine_sims.append(cosine_sim)
        
        # 比较输出
        orig_stats = analyze_tensor_statistics(orig_output, "输出")
        quant_stats = analyze_tensor_statistics(quant_output, "输出")
        print_tensor_comparison(orig_stats, quant_stats, cosine_sim)
        
        # 监控cache变化
        new_caches_orig = [new_cache_0, new_cache_1, new_cache_2, new_cache_3]
        monitor_cache_changes(caches, new_caches_orig, i+1, cache_names)
        
        # 更新cache状态
        cache_0, cache_1, cache_2, cache_3 = new_cache_0, new_cache_1, new_cache_2, new_cache_3
        caches = [cache_0, cache_1, cache_2, cache_3]
    
    # 汇总统计
    print("\n=== 总体比较结果 ===")
    
    # 合并所有输出
    orig_tensor = torch.cat(all_orig_outputs, dim=0)
    quant_tensor = torch.cat(all_quant_outputs, dim=0)
    
    # 计算整体误差指标
    mse = torch.mean((orig_tensor - quant_tensor) ** 2)
    mae = torch.mean(torch.abs(orig_tensor - quant_tensor))
    
    # 计算有效值的相对误差
    abs_orig = torch.abs(orig_tensor)
    mask = abs_orig > 1e-6
    rel_error = torch.mean(torch.abs(orig_tensor[mask] - quant_tensor[mask]) / abs_orig[mask])
    
    # 计算整体余弦相似度
    overall_cosine = calculate_cosine_similarity(orig_tensor, quant_tensor)
    
    print("\n误差指标:")
    print(f"  均方误差 (MSE): {mse:.8f}")
    print(f"  平均绝对误差 (MAE): {mae:.8f}")
    print(f"  相对误差: {rel_error * 100:.2f}%")
    print(f"  平均余弦相似度: {np.mean(all_cosine_sims):.6f}")
    print(f"  最小余弦相似度: {np.min(all_cosine_sims):.6f}")
    print(f"  最大余弦相似度: {np.max(all_cosine_sims):.6f}")
    print(f"  整体余弦相似度: {overall_cosine:.6f}")
    
    print("\n数值范围:")
    print(f"  原始模型: [{orig_tensor.min():.4f}, {orig_tensor.max():.4f}]")
    print(f"  量化模型: [{quant_tensor.min():.4f}, {quant_tensor.max():.4f}]")
    
    print("\n有效值统计:")
    print(f"  有效比较点数量: {mask.sum()}/{mask.numel()}")
    print(f"  有效值比例: {mask.sum()/mask.numel()*100:.1f}%")
    
    # 输出质量评估
    print("\n量化质量评估:")
    if rel_error < 0.01 and overall_cosine > 0.99:
        print("  质量: 优秀")
        print("  - 相对误差 < 1%")
        print("  - 余弦相似度 > 0.99")
    elif rel_error < 0.05 and overall_cosine > 0.95:
        print("  质量: 良好")
        print("  - 相对误差 < 5%")
        print("  - 余弦相似度 > 0.95")
    else:
        print("  质量: 一般")
        print("  - 相对误差 > 5% 或 余弦相似度 < 0.95")
        print("  - 建议检查量化参数配置")

if __name__ == "__main__":
    try:
        # 比较改进前后的量化模型结构差异
        print("=== 第一部分：量化模型结构对比 ===")
        model1_path = "test_cache_model/quantized_model_improved_fixed.onnx"  # 新的改进模型
        model2_path = "test_cache_model/quantized_model_fixed.onnx"  # 原来的修复模型
        compare_models(model1_path, model2_path)
        
        # 加载预训练模型
        print("加载预训练模型: fsmn_model/model.pt")

        # 使用FunASR加载预训练模型
        try:
            sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            from funasr import AutoModel

            funasr_model = AutoModel(model="fsmn_model")
            print("使用FunASR成功加载预训练模型")
            print(f"模型类型: {type(funasr_model.model)}")

            # 创建兼容的包装器
            class FunASRModelWrapper:
                def __init__(self, funasr_model):
                    self.funasr_model = funasr_model
                    self.model = funasr_model.model

                def __call__(self, feat_input, cache_0, cache_1, cache_2, cache_3):
                    # FunASR模型的调用方式
                    with torch.no_grad():
                        # 注意：FunASR模型可能有不同的接口
                        # 我们需要适配到我们期望的5输入5输出格式
                        try:
                            # 尝试直接调用encoder
                            if hasattr(self.model, 'encoder'):
                                encoder = self.model.encoder
                                # 构造cache列表
                                in_cache = [cache_0, cache_1, cache_2, cache_3]
                                output, out_cache = encoder(feat_input, in_cache)
                                return output, out_cache[0], out_cache[1], out_cache[2], out_cache[3]
                            else:
                                # 回退方案：使用完整模型
                                result = self.model(feat_input, cache_0, cache_1, cache_2, cache_3)
                                return result
                        except Exception as e:
                            print(f"FunASR模型调用失败: {e}")
                            # 返回模拟输出
                            batch_size = feat_input.size(0)
                            seq_len = feat_input.size(1)
                            output = torch.randn(batch_size, seq_len, 248)
                            return output, cache_0, cache_1, cache_2, cache_3

                def init_cache(self, batch_size):
                    return (torch.zeros(batch_size, 128, 19, 1),
                            torch.zeros(batch_size, 128, 19, 1),
                            torch.zeros(batch_size, 128, 19, 1),
                            torch.zeros(batch_size, 128, 19, 1))

                def eval(self):
                    if hasattr(self.model, 'eval'):
                        self.model.eval()
                    return self

            model = FunASRModelWrapper(funasr_model)
            model.eval()

        except Exception as e:
            print(f"FunASR加载失败: {e}")
            print("回退到手动创建模型...")

            # 回退方案：手动创建模型并加载权重
            from models.fsmn_vad_streaming.encoder_fixed_cache import FSMNFixedCache

            model = FSMNFixedCache(
                input_dim=400,
                input_affine_dim=140,
                linear_dim=250,
                proj_dim=128,
                lorder=20,
                output_affine_dim=140,
                output_dim=248,
                fsmn_layers=4,
                use_softmax=True
            )

            # 尝试加载预训练权重
            try:
                state_dict = torch.load("fsmn_model/model.pt", map_location='cpu')
                # 权重键名映射（如果需要的话）
                model.load_state_dict(state_dict, strict=False)
                print("成功加载预训练权重")
            except Exception as load_e:
                print(f"加载权重失败: {load_e}")
                print("使用随机初始化的权重")

            model.eval()
        
        # 生成模拟特征数据
        features = []
        for i in range(5):  # 生成5个样本
            if i % 3 == 0:
                # 正态分布特征
                feature = torch.randn(400, 400) * 0.1
            elif i % 3 == 1:
                # 均匀分布特征
                feature = torch.rand(400, 400) * 0.2 - 0.1
            else:
                # 混合特征
                feature = torch.randn(400, 400) * 0.05 + torch.sin(
                    torch.arange(400).float().unsqueeze(1) * 0.1) * 0.02
            features.append(feature)
        
        print("\n=== 第二部分：PyTorch模型 vs 改进量化ONNX模型精度对比 ===")
        compare_model_outputs(model, model1_path, features, num_samples=5)
        
    except Exception as e:
        print(f"错误: {str(e)}")
        import traceback
        print(traceback.format_exc()) 