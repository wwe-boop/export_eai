#!/usr/bin/env python3
"""
改进量化质量的独立脚本
主要解决：
1. 校准数据质量问题
2. 量化配置优化
3. 输入输出名称修复
"""

import os
import sys
import torch
import torch.nn as nn
import numpy as np
import json
import onnx
import onnxruntime as ort
from typing import List, Tuple, Dict

# 添加项目路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def load_real_audio_features(audio_dir: str = "fsmn_model/example", num_samples: int = 100) -> List[torch.Tensor]:
    """
    从真实音频文件加载特征用于校准
    """
    try:
        import librosa
        import soundfile as sf
        from pathlib import Path
        AUDIO_LIBS_AVAILABLE = True
    except ImportError as e:
        print(f"音频处理库未安装: {e}")
        print("回退到模拟特征生成...")
        AUDIO_LIBS_AVAILABLE = False

    if not AUDIO_LIBS_AVAILABLE:
        return create_simulated_audio_features(num_samples)

    print(f"从 {audio_dir} 加载真实音频特征...")

    features = []
    audio_files = []

    # 查找音频文件
    audio_dir_path = Path(audio_dir)
    if audio_dir_path.exists():
        # 支持常见音频格式
        for ext in ['*.wav', '*.mp3', '*.flac', '*.m4a']:
            audio_files.extend(list(audio_dir_path.glob(ext)))

    # 如果没有找到音频文件，尝试其他位置
    if not audio_files:
        # 尝试其他可能的目录
        for try_dir in ["example", "audio_samples", "test_audio"]:
            try_path = Path(try_dir)
            if try_path.exists():
                for ext in ['*.wav', '*.mp3', '*.flac', '*.m4a']:
                    audio_files.extend(list(try_path.glob(ext)))

    if not audio_files:
        print("未找到音频文件，回退到模拟特征生成...")
        return create_simulated_audio_features(num_samples)

    print(f"找到 {len(audio_files)} 个音频文件")

    # 音频处理参数（与VAD模型匹配）
    sample_rate = 16000
    frame_length = 25  # ms
    frame_shift = 10   # ms
    n_mels = 80

    frame_length_samples = int(frame_length * sample_rate / 1000)
    frame_shift_samples = int(frame_shift * sample_rate / 1000)

    for audio_file in audio_files[:min(len(audio_files), num_samples // 10)]:
        try:
            print(f"处理音频文件: {audio_file.name}")

            # 加载音频
            audio, sr = librosa.load(str(audio_file), sr=sample_rate)

            # 如果音频太短，跳过
            if len(audio) < sample_rate:  # 至少1秒
                continue

            # 提取mel频谱特征
            mel_spec = librosa.feature.melspectrogram(
                y=audio,
                sr=sample_rate,
                n_fft=512,
                hop_length=frame_shift_samples,
                win_length=frame_length_samples,
                n_mels=n_mels,
                fmin=0,
                fmax=sample_rate//2
            )

            # 转换为对数mel频谱
            log_mel = librosa.power_to_db(mel_spec, ref=np.max)

            # 归一化到合理范围
            log_mel = (log_mel + 80) / 80  # 假设动态范围为80dB

            # 分割成400帧的段
            n_frames = log_mel.shape[1]
            segment_length = 400

            for start_idx in range(0, n_frames - segment_length + 1, segment_length // 2):
                end_idx = start_idx + segment_length
                segment = log_mel[:, start_idx:end_idx]  # [80, 400]

                # 如果mel频谱维度不是400，需要调整
                if segment.shape[0] != 400:
                    # 重复或插值到400维
                    if segment.shape[0] < 400:
                        # 重复特征
                        repeat_factor = 400 // segment.shape[0] + 1
                        segment = np.tile(segment, (repeat_factor, 1))[:400, :]
                    else:
                        # 下采样
                        indices = np.linspace(0, segment.shape[0]-1, 400, dtype=int)
                        segment = segment[indices, :]

                # 转换为torch tensor并调整形状为[400, 400]
                feature = torch.tensor(segment.T, dtype=torch.float32)  # [400, 80] -> [400, 400]

                # 如果特征维度不是400，需要调整
                if feature.shape[1] != 400:
                    if feature.shape[1] < 400:
                        # 零填充
                        padding = torch.zeros(400, 400 - feature.shape[1])
                        feature = torch.cat([feature, padding], dim=1)
                    else:
                        # 截断
                        feature = feature[:, :400]

                # 确保特征在合理范围内
                feature = torch.clamp(feature, -1.0, 1.0)
                features.append(feature)

                if len(features) >= num_samples:
                    break

            if len(features) >= num_samples:
                break

        except Exception as e:
            print(f"处理音频文件 {audio_file} 失败: {e}")
            continue

    # 如果真实音频特征不够，用模拟特征补充
    if len(features) < num_samples:
        print(f"真实音频特征只有 {len(features)} 个，用模拟特征补充到 {num_samples} 个")
        simulated_features = create_simulated_audio_features(num_samples - len(features))
        features.extend(simulated_features)

    print(f"加载完成，共 {len(features)} 个特征样本")
    return features[:num_samples]

def create_simulated_audio_features(num_samples: int = 100) -> List[torch.Tensor]:
    """
    创建模拟音频特征数据作为备用方案
    """
    print(f"生成 {num_samples} 个模拟音频特征样本...")

    features = []

    for i in range(num_samples):
        if i % 4 == 0:
            # 静音段 - 低能量，接近零的特征
            feature = torch.randn(400, 400) * 0.01 + torch.normal(0, 0.005, (400, 400))
        elif i % 4 == 1:
            # 语音段 - 中等能量，有结构的特征
            base = torch.randn(400, 400) * 0.1
            # 添加语音的频谱结构
            for freq_bin in range(0, 400, 50):
                base[:, freq_bin:freq_bin+10] *= 1.5  # 增强某些频率
            feature = base
        elif i % 4 == 2:
            # 噪音段 - 随机但有限的能量
            feature = torch.randn(400, 400) * 0.05
        else:
            # 混合段 - 语音+噪音
            speech = torch.randn(400, 400) * 0.08
            noise = torch.randn(400, 400) * 0.02
            feature = speech + noise

        # 确保特征在合理范围内
        feature = torch.clamp(feature, -0.5, 0.5)
        features.append(feature)

    print("模拟音频特征生成完成")
    return features

def create_improved_quantization_config() -> Dict:
    """
    创建改进的量化配置
    针对VAD模型的特点进行优化
    """
    config = {
        "defaults": {
            "ops": {
                "is_output_quantized": "True",
                "is_symmetric": "True"
            },
            "params": {
                "is_quantized": "True", 
                "is_symmetric": "True"
            }
        },
        "params": {
            # 保持关键参数为浮点
            "bias": {"is_quantized": "False"},
            "scale": {"is_quantized": "False"},
            "mean": {"is_quantized": "False"},
            "var": {"is_quantized": "False"}
        },
        "op_type": {
            # 对关键操作使用更高精度
            "Softmax": {
                "is_output_quantized": "False"  # Softmax输出保持浮点
            },
            "Add": {
                "is_output_quantized": "True",
                "is_symmetric": "True"
            },
            "MatMul": {
                "is_output_quantized": "True", 
                "is_symmetric": "True"
            },
            "Conv": {
                "is_output_quantized": "True",
                "is_symmetric": "True"
            }
        },
        "supergroups": [
            # 定义操作组合，提高量化效率
            {"op_list": ["Conv", "Relu"]},
            {"op_list": ["MatMul", "Add"]},
            {"op_list": ["Add", "Relu"]}
        ],
        "model_input": {
            "is_input_quantized": "False"  # 输入保持float32
        },
        "model_output": {
            "is_output_quantized": "False"  # 输出保持float32
        }
    }
    return config

def fix_quantized_model_names(model_path: str) -> str:
    """
    修复量化模型的输入输出名称
    """
    if not os.path.exists(model_path):
        print(f"模型文件不存在: {model_path}")
        return model_path
    
    fixed_path = model_path.replace('.onnx', '_fixed.onnx')
    
    try:
        # 加载模型
        model = onnx.load(model_path)
        
        # 期望的名称
        expected_input_names = ['input', 'cache_0', 'cache_1', 'cache_2', 'cache_3']
        expected_output_names = ['output', 'new_cache_0', 'new_cache_1', 'new_cache_2', 'new_cache_3']
        
        # 当前名称
        current_input_names = [inp.name for inp in model.graph.input]
        current_output_names = [out.name for out in model.graph.output]
        
        print(f"当前输入名称: {current_input_names}")
        print(f"当前输出名称: {current_output_names}")
        
        # 检查是否需要修复
        if (current_input_names == expected_input_names and 
            current_output_names == expected_output_names):
            print("模型名称已正确，无需修复")
            return model_path
        
        print("开始修复模型名称...")
        
        # 创建映射
        input_mapping = {}
        output_mapping = {}
        
        for i, (current, expected) in enumerate(zip(current_input_names, expected_input_names)):
            if current != expected:
                input_mapping[current] = expected
        
        for i, (current, expected) in enumerate(zip(current_output_names, expected_output_names)):
            if current != expected:
                output_mapping[current] = expected
        
        # 修复输入名称
        for inp in model.graph.input:
            if inp.name in input_mapping:
                old_name = inp.name
                inp.name = input_mapping[old_name]
                print(f"  输入: {old_name} -> {inp.name}")
        
        # 修复输出名称
        for out in model.graph.output:
            if out.name in output_mapping:
                old_name = out.name
                out.name = output_mapping[old_name]
                print(f"  输出: {old_name} -> {out.name}")
        
        # 修复图中的引用
        all_mapping = {**input_mapping, **output_mapping}
        
        for node in model.graph.node:
            # 修复输入引用
            for i, input_name in enumerate(node.input):
                if input_name in all_mapping:
                    node.input[i] = all_mapping[input_name]
            
            # 修复输出引用
            for i, output_name in enumerate(node.output):
                if output_name in all_mapping:
                    node.output[i] = all_mapping[output_name]
        
        # 保存修复后的模型
        onnx.save(model, fixed_path)
        print(f"模型名称修复完成: {fixed_path}")
        
        return fixed_path
        
    except Exception as e:
        print(f"修复模型名称失败: {e}")
        return model_path

def validate_quantized_model(original_model, quantized_path: str, features: List[torch.Tensor]) -> Dict:
    """
    验证量化模型质量
    """
    print("开始验证量化模型质量...")
    
    try:
        # 加载量化模型
        session = ort.InferenceSession(quantized_path, providers=['CPUExecutionProvider'])
        input_names = [inp.name for inp in session.get_inputs()]
        
        print(f"量化模型输入名称: {input_names}")
        
        # 准备测试数据
        test_features = features[:5]  # 使用前5个样本测试
        
        original_outputs = []
        quantized_outputs = []
        
        # 原始模型推理
        original_model.eval()
        with torch.no_grad():
            for feat in test_features:
                feat_input = feat.unsqueeze(0)
                cache_0, cache_1, cache_2, cache_3 = original_model.init_cache(1)
                output, _, _, _, _ = original_model(feat_input, cache_0, cache_1, cache_2, cache_3)
                original_outputs.append(output)
        
        # 量化模型推理
        for feat in test_features:
            feat_input = feat.unsqueeze(0).numpy()
            cache_0 = torch.zeros(1, 128, 19, 1).numpy()
            cache_1 = torch.zeros(1, 128, 19, 1).numpy()
            cache_2 = torch.zeros(1, 128, 19, 1).numpy()
            cache_3 = torch.zeros(1, 128, 19, 1).numpy()
            
            # 构建输入字典
            if len(input_names) == 5:
                onnx_inputs = {
                    input_names[0]: feat_input,
                    input_names[1]: cache_0,
                    input_names[2]: cache_1,
                    input_names[3]: cache_2,
                    input_names[4]: cache_3
                }
            else:
                onnx_inputs = {
                    'input': feat_input,
                    'cache_0': cache_0,
                    'cache_1': cache_1,
                    'cache_2': cache_2,
                    'cache_3': cache_3
                }
            
            outputs = session.run(None, onnx_inputs)
            quantized_outputs.append(torch.tensor(outputs[0]))
        
        # 计算误差指标
        orig_tensor = torch.cat(original_outputs, dim=0)
        quant_tensor = torch.cat(quantized_outputs, dim=0)
        
        mse = torch.mean((orig_tensor - quant_tensor) ** 2).item()
        mae = torch.mean(torch.abs(orig_tensor - quant_tensor)).item()
        
        # 计算相对误差
        abs_orig = torch.abs(orig_tensor)
        mask = abs_orig > 1e-6
        rel_error = torch.mean(torch.abs(orig_tensor[mask] - quant_tensor[mask]) / abs_orig[mask]).item()
        
        # 计算余弦相似度
        cosine_sim = torch.nn.functional.cosine_similarity(
            orig_tensor.flatten(), quant_tensor.flatten(), dim=0
        ).item()
        
        results = {
            'mse': mse,
            'mae': mae,
            'relative_error': rel_error,
            'cosine_similarity': cosine_sim,
            'original_range': [orig_tensor.min().item(), orig_tensor.max().item()],
            'quantized_range': [quant_tensor.min().item(), quant_tensor.max().item()]
        }
        
        print(f"验证结果:")
        print(f"  MSE: {mse:.8f}")
        print(f"  MAE: {mae:.8f}")
        print(f"  相对误差: {rel_error*100:.2f}%")
        print(f"  余弦相似度: {cosine_sim:.6f}")
        print(f"  原始范围: {results['original_range']}")
        print(f"  量化范围: {results['quantized_range']}")
        
        return results
        
    except Exception as e:
        print(f"验证失败: {e}")
        return {}

def main():
    """主函数"""
    print("开始改进量化质量...")
    
    # 检查现有模型
    model_dir = "test_cache_model"
    original_quantized = os.path.join(model_dir, "quantized_model.onnx")
    
    if not os.path.exists(original_quantized):
        print(f"未找到量化模型: {original_quantized}")
        return
    
    # 1. 修复输入输出名称
    print("\n=== 步骤1: 修复输入输出名称 ===")
    fixed_model = fix_quantized_model_names(original_quantized)
    
    # 2. 生成改进的校准数据
    print("\n=== 步骤2: 生成改进的校准数据 ===")
    improved_features = load_real_audio_features("fsmn_model/example", 50)
    
    # 3. 创建改进的量化配置
    print("\n=== 步骤3: 创建改进的量化配置 ===")
    improved_config = create_improved_quantization_config()
    config_path = os.path.join(model_dir, "improved_quantization_config.json")
    with open(config_path, 'w') as f:
        json.dump(improved_config, f, indent=2)
    print(f"改进的量化配置已保存: {config_path}")
    
    # 4. 验证现有量化模型
    print("\n=== 步骤4: 验证量化模型质量 ===")
    try:
        # 导入原始模型
        from models.fsmn_vad_streaming.encoder_fixed_cache import FSMNFixedCache
        
        model = FSMNFixedCache(
            input_dim=400,
            input_affine_dim=140,
            linear_dim=250,
            proj_dim=128,
            lorder=20,
            output_affine_dim=140,
            output_dim=248,
            fsmn_layers=4,
            use_softmax=True
        )
        model.eval()
        
        # 验证原始量化模型
        print("\n--- 原始量化模型 ---")
        original_results = validate_quantized_model(model, original_quantized, improved_features)
        
        # 验证修复后的模型
        if fixed_model != original_quantized:
            print("\n--- 修复后的量化模型 ---")
            fixed_results = validate_quantized_model(model, fixed_model, improved_features)
        
        print("\n=== 改进建议 ===")
        if original_results:
            if original_results['relative_error'] > 0.1:  # 10%
                print("- 相对误差过高，建议使用更多校准数据重新量化")
            if original_results['cosine_similarity'] < 0.9:
                print("- 余弦相似度较低，建议调整量化配置")
            if original_results['relative_error'] < 0.05 and original_results['cosine_similarity'] > 0.95:
                print("- 量化质量良好")
        
    except Exception as e:
        print(f"验证过程出错: {e}")
    
    print("\n量化质量改进完成!")

if __name__ == "__main__":
    main()
