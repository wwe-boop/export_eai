#!/opt/anaconda3/bin/python
"""
核心功能：
1. 导出ONNX模型 - 将PyTorch模型转换为ONNX格式，支持5输入5输出流式接口
2. AIMET量化（真实音频/模拟音频） - 使用AIMET库进行8bit参数+16bit激活量化
3. 模型对比分析 - 对比原始模型和量化模型的输出精度
4. 生成完整EAI转换命令 - 生成Qualcomm EAI硬件加速器的转换命令
"""

# 导入系统库
import sys  # 系统相关功能
import os  # 操作系统接口

# 环境检查
print(f"Python: {sys.version}")
print(f"工作目录: {os.getcwd()}")

import torch
import torch.nn as nn
import argparse
import onnx
from onnxsim import simplify
import yaml
import json

from models.fsmn_vad_streaming.encoder_fixed_cache import FSMNFixedCache, FSMNFixedCacheExport

try:
    from aimet_torch.quantsim import QuantizationSimModel
    from aimet_common.defs import QuantScheme
    from aimet_torch.cross_layer_equalization import equalize_model
    from aimet_torch.meta.connectedgraph import ConnectedGraph
    from aimet_common import quantsim

    quantsim.encoding_version = "0.6.1"
    ConnectedGraph.math_invariant_types.add('zeros')
    ConnectedGraph.math_invariant_types.add('Concat')
    ConnectedGraph.math_invariant_types.add('Add')

    AIMET_AVAILABLE = True
    print("AIMET量化库已加载")
except ImportError as e:
    print(f"AIMET库导入失败: {e}")
    AIMET_AVAILABLE = False
except Exception as e:
    print(f"AIMET库初始化失败: {e}")
    AIMET_AVAILABLE = False


class QuantWrapper(nn.Module):
    def __init__(self, fixed_model):
        super().__init__()
        self.model = fixed_model

    def forward(self, input_tensor, cache_0, cache_1, cache_2, cache_3):
        output, new_cache_0, new_cache_1, new_cache_2, new_cache_3 = self.model(
            input_tensor, cache_0, cache_1, cache_2, cache_3
        )
        return output, new_cache_0, new_cache_1, new_cache_2, new_cache_3


def parse_args():
    # 创建参数解析器
    parser = argparse.ArgumentParser(description='导出固定Cache的FSMN VAD模型')

    # 基础模型参数
    parser.add_argument('--config-file', type=str, default='models/fsmn_vad_streaming/template.yaml',
                        help='模型配置文件路径，包含网络结构参数')
    parser.add_argument('--model-path', type=str, default='fsmn_model/model.pt',
                        help='预训练模型权重文件路径')
    parser.add_argument('--output-dir', type=str, default='test_cache_model',
                        help='输出目录，保存导出的ONNX模型和量化文件')

    # 量化相关参数
    parser.add_argument('--quantize', action='store_true',
                        help='启用AIMET量化功能')
    parser.add_argument('--audio-dir', type=str, default='test_audio',
                        help='音频文件目录或wav.scp文件路径，用于量化校准数据提取')
    parser.add_argument('--calib-samples', type=int, default=50,
                        help='量化校准样本数量，影响量化精度')
    parser.add_argument('--param-bits', type=int, default=8,
                        help='参数量化位宽（权重量化精度）')
    parser.add_argument('--output-bits', type=int, default=16,
                        help='激活量化位宽（特征量化精度）')
    parser.add_argument('--config-json', type=str, default='config_for_eai.json',
                        help='AIMET量化配置JSON文件，定义量化策略')

    # 解析并返回参数
    return parser.parse_args()


def load_config(config_file):
    """
    加载YAML配置文件

    Args:
        config_file: YAML配置文件路径

    Returns:
        dict: 解析后的配置字典，包含模型结构参数
    """
    with open(config_file, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)  # 安全加载YAML文件
    return config


def get_audio_files(audio_dir):
    """
    获取指定目录下的音频文件列表

    支持的音频格式：.wav, .mp3, .flac
    支持递归搜索子目录
    支持wav.scp文件格式

    Args:
        audio_dir: 音频文件目录路径或wav.scp文件路径

    Returns:
        list: 音频文件路径列表
    """
    audio_files = []

    if not audio_dir or not os.path.exists(audio_dir):
        print("音频路径不存在，将使用模拟数据")
        return audio_files

    # 检查是否为wav.scp文件
    if audio_dir.endswith('.scp'):
        print(f"检测到wav.scp文件: {audio_dir}")
        try:
            with open(audio_dir, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line or line.startswith('#'):  # 跳过空行和注释行
                        continue

                    # 解析wav.scp格式: wav_id wav_path
                    parts = line.split(maxsplit=1)
                    if len(parts) >= 2:
                        wav_id, wav_path = parts[0], parts[1]
                        # 支持相对路径（相对于scp文件所在目录）
                        if not os.path.isabs(wav_path):
                            scp_dir = os.path.dirname(audio_dir)
                            wav_path = os.path.join(scp_dir, wav_path)

                        if os.path.exists(wav_path):
                            audio_files.append(wav_path)
                        else:
                            print(f"警告: wav.scp第{line_num}行音频文件不存在: {wav_path}")
                    else:
                        print(f"警告: wav.scp第{line_num}行格式错误: {line}")

        except Exception as e:
            print(f"读取wav.scp文件失败: {e}")
            return audio_files
    else:
        # 原有的目录搜索逻辑
        import glob  # 文件模式匹配库
        # 支持的音频文件扩展名
        extensions = ['*.wav', '*.mp3', '*.flac']
        for ext in extensions:
            # 搜索当前目录
            audio_files.extend(glob.glob(os.path.join(audio_dir, ext)))
            # 递归搜索子目录
            audio_files.extend(glob.glob(os.path.join(audio_dir, '**', ext), recursive=True))

    # 去重并统计
    audio_files = list(set(audio_files))
    if audio_files:
        print(f"找到 {len(audio_files)} 个音频文件")
    else:
        print("未找到音频文件，将使用模拟数据")
    return audio_files


def load_audio(file_path, sample_rate=16000):
    """
    加载音频文件并转换为PyTorch张量

    Args:
        file_path: 音频文件路径
        sample_rate: 目标采样率，默认16kHz

    Returns:
        torch.Tensor: 音频波形张量，形状为[samples]，如果加载失败返回None
    """
    try:
        import librosa  # 音频处理库
        # 加载音频并重采样到指定采样率
        audio, _ = librosa.load(file_path, sr=sample_rate)
        # 转换为PyTorch张量
        return torch.tensor(audio, dtype=torch.float32)
    except Exception as e:
        print(f"加载音频失败 {file_path}: {e}")
        return None


def group_features_by_audio(features):
    """
    将特征按原始音频文件分组
    使用全局变量 _feature_groups 来精确分组
    """
    if not features:
        return []

    # 尝试使用精确的分组信息
    global _feature_groups
    if '_feature_groups' in globals() and _feature_groups:
        audio_groups = []
        for file_segments in _feature_groups:
            group = [features[idx] for idx in file_segments if idx < len(features)]
            if group:  # 只添加非空组
                audio_groups.append(group)

        if audio_groups:
            return audio_groups

    # 回退策略：简单分组（每个特征作为独立组）
    print("使用回退分组策略：每个特征作为独立音频段")
    return [[feature] for feature in features]


def prepare_features(audio_files, calib_samples, seq_length=400, use_real_audio=True):
    """准备量化校准特征"""
    features = []

    # 尝试使用真实音频
    if use_real_audio and audio_files:
        print(f"尝试使用真实音频提取特征...")
        real_features = extract_real_audio_features(audio_files, seq_length, max_samples=calib_samples)
        if real_features:
            features.extend(real_features)
            print(f"成功提取 {len(real_features)} 个真实音频特征")

    # 如果真实音频不够，用增强的模拟数据补充
    remaining = calib_samples - len(features)
    if remaining > 0:
        print(f"生成 {remaining} 个增强模拟特征补充...")
        enhanced_features = create_enhanced_calibration_features(remaining, seq_length)
        features.extend(enhanced_features)

    print(f"准备了 {len(features)} 个特征用于量化校准")
    return features

def create_enhanced_calibration_features(num_samples, seq_length=400):
    """创建增强的校准特征，更好地模拟真实音频特征分布"""
    features = []

    for i in range(num_samples):
        if i % 4 == 0:
            # 语音活动段：较高能量，有结构的特征
            base_feature = torch.randn(seq_length, 400) * 0.15
            # 添加语音特有的频谱结构
            for freq_idx in range(0, 400, 40):  # 模拟共振峰
                base_feature[:, freq_idx:freq_idx+5] *= 1.5
        elif i % 4 == 1:
            # 静音段：低能量，接近零的特征
            base_feature = torch.randn(seq_length, 400) * 0.02
        elif i % 4 == 2:
            # 噪声段：中等能量，随机分布
            base_feature = torch.randn(seq_length, 400) * 0.08
        else:
            # 过渡段：渐变特征
            start_energy = torch.randn(seq_length//2, 400) * 0.02
            end_energy = torch.randn(seq_length//2, 400) * 0.12
            base_feature = torch.cat([start_energy, end_energy], dim=0)

        # 添加时间相关性
        for t in range(1, seq_length):
            base_feature[t] = 0.7 * base_feature[t] + 0.3 * base_feature[t-1]

        features.append(base_feature)

    return features


def extract_real_audio_features(audio_files, seq_length=400, max_samples=None):
    """提取真实音频特征，支持长音频分段处理"""
    features = []
    feature_groups = []  # 记录每个音频文件对应的特征段数

    try:
        # 尝试导入前端处理器
        from funasr.frontends.wav_frontend import WavFrontend

        # 创建前端处理器
        frontend = WavFrontend(
            fs=16000,
            window='hamming',
            n_mels=80,
            frame_length=25,
            frame_shift=10,
            lfr_m=5,
            lfr_n=1,
            dither=0.0
        )
        print("成功加载FunASR前端处理器")

        for file_idx, file_path in enumerate(audio_files):
            try:
                audio = load_audio(file_path)
                if audio is not None:
                    # 使用前端处理器提取特征
                    audio_batch = audio.unsqueeze(0)  # 添加batch维度
                    audio_length = torch.tensor([len(audio)])

                    feats, feats_lens = frontend(audio_batch, audio_length)
                    if feats.size(1) > 0:  # 确保有有效特征
                        feature = feats[0]  # 移除batch维度
                        file_segments = []  # 当前文件的所有段

                        # 分段处理音频特征，丢弃不满400长度的段
                        total_length = feature.size(0)

                        if total_length < seq_length:
                            # 短音频：直接丢弃
                            print(f"音频过短，丢弃: {file_path} -> 长度{total_length} < {seq_length}")
                            continue
                        elif total_length == seq_length:
                            # 正好400长度：直接使用
                            features.append(feature)
                            file_segments.append(len(features) - 1)
                            print(f"FunASR特征提取: {file_path} -> {feature.shape}")
                        else:
                            # 长音频：分段处理，只保留完整的400长度段
                            num_complete_segments = total_length // seq_length  # 完整段数（向下取整）
                            remaining_length = total_length % seq_length

                            print(f"长音频分段处理: {file_path} -> 总长度{total_length}")
                            print(f"  完整段数: {num_complete_segments}, 剩余长度: {remaining_length} (丢弃)")

                            for seg_idx in range(num_complete_segments):
                                start_idx = seg_idx * seq_length
                                end_idx = start_idx + seq_length

                                segment = feature[start_idx:end_idx, :]
                                assert segment.size(0) == seq_length, f"段长度错误: {segment.size(0)} != {seq_length}"

                                features.append(segment)
                                file_segments.append(len(features) - 1)
                                print(f"  段{seg_idx + 1}/{num_complete_segments}: [{start_idx}:{end_idx}] -> {segment.shape}")

                                # 检查是否达到最大样本数
                                if max_samples and len(features) >= max_samples:
                                    print(f"已达到最大样本数 {max_samples}，停止提取")
                                    feature_groups.append(file_segments)
                                    return features

                        feature_groups.append(file_segments)

            except Exception as e:
                print(f"FunASR特征提取失败 {file_path}: {e}")
                continue

    except ImportError as e:
        print(f"无法导入FunASR前端处理器: {e}")

    # 将分组信息存储为全局变量，供后续使用
    global _feature_groups
    _feature_groups = feature_groups

    return features



def copy_weights_from_original(original_state_dict, fixed_model):
    """从原始模型复制权重到固定cache模型"""
    print("复制模型权重...")

    fixed_state = fixed_model.state_dict()
    weight_mapping = {}

    # 输入层
    weight_mapping['encoder.in_linear1.linear.weight'] = 'in_linear1.linear.weight'
    weight_mapping['encoder.in_linear1.linear.bias'] = 'in_linear1.linear.bias'
    weight_mapping['encoder.in_linear2.linear.weight'] = 'in_linear2.linear.weight'
    weight_mapping['encoder.in_linear2.linear.bias'] = 'in_linear2.linear.bias'

    # FSMN层
    for i in range(4):
        orig_prefix = f'encoder.fsmn.{i}'
        fixed_prefix = f'fsmn_layer_{i}'
        weight_mapping[f'{orig_prefix}.linear.linear.weight'] = f'{fixed_prefix}.linear.linear.weight'
        weight_mapping[f'{orig_prefix}.fsmn_block.conv_left.weight'] = f'{fixed_prefix}.fsmn_block.conv_left.weight'
        weight_mapping[f'{orig_prefix}.affine.linear.weight'] = f'{fixed_prefix}.affine.linear.weight'
        weight_mapping[f'{orig_prefix}.affine.linear.bias'] = f'{fixed_prefix}.affine.linear.bias'

    # 输出层
    weight_mapping['encoder.out_linear1.linear.weight'] = 'out_linear1.linear.weight'
    weight_mapping['encoder.out_linear1.linear.bias'] = 'out_linear1.linear.bias'
    weight_mapping['encoder.out_linear2.linear.weight'] = 'out_linear2.linear.weight'

    # 执行复制
    copied = 0
    for orig_key, fixed_key in weight_mapping.items():
        if orig_key in original_state_dict and fixed_key in fixed_state:
            orig_weight = original_state_dict[orig_key]
            if orig_weight.shape == fixed_state[fixed_key].shape:
                fixed_state[fixed_key] = orig_weight.clone()
                copied += 1

    fixed_model.load_state_dict(fixed_state)
    print(f"成功复制 {copied} 个权重")
    return copied > 0


def export_onnx(model, output_path):
    """导出ONNX模型"""
    print(f"导出ONNX模型: {output_path}")

    export_model = FSMNFixedCacheExport(model)
    export_model.eval()

    dummy_input = torch.randn(1, 400, 400)
    cache_0, cache_1, cache_2, cache_3 = model.init_cache(1)

    torch.onnx.export(
        export_model,
        (dummy_input, cache_0, cache_1, cache_2, cache_3),
        output_path,
        export_params=True,
        opset_version=11,
        do_constant_folding=True,
        input_names=['input', 'cache_0', 'cache_1', 'cache_2', 'cache_3'],
        output_names=['output', 'new_cache_0', 'new_cache_1', 'new_cache_2', 'new_cache_3'],
        dynamic_axes={
            'input': {0: 'batch_size', 1: 'sequence_length'},
            'output': {0: 'batch_size', 1: 'sequence_length'},
            'cache_0': {0: 'batch_size'}, 'cache_1': {0: 'batch_size'},
            'cache_2': {0: 'batch_size'}, 'cache_3': {0: 'batch_size'},
            'new_cache_0': {0: 'batch_size'}, 'new_cache_1': {0: 'batch_size'},
            'new_cache_2': {0: 'batch_size'}, 'new_cache_3': {0: 'batch_size'}
        }
    )

    # 验证ONNX模型
    onnx_model = onnx.load(output_path)
    onnx.checker.check_model(onnx_model)
    print("ONNX模型验证通过")

    # 简化模型
    simplified_path = output_path.replace('.onnx', '_simplified.onnx')
    try:
        model_simp, check = simplify(onnx_model)
        if check:
            onnx.save(model_simp, simplified_path)
            print(f"简化模型保存: {simplified_path}")
            return simplified_path
    except Exception as e:
        print(f"模型简化失败: {e}")

    return output_path

def detect_model_type(model):
    """检测模型类型"""
    model_class_name = type(model).__name__
    print(f"检测到模型类型: {model_class_name}")

    # 检查是否为FSMNFixedCache模型
    if 'FSMNFixedCache' in model_class_name:
        return 'FSMNFixedCache'
    elif hasattr(model, 'fsmn_layers') and hasattr(model, 'cache'):
        return 'FSMNOriginal'
    else:
        return 'Unknown'

def create_fixed_cache_eai_config(model):
    """为FSMNFixedCache模型创建专门的EAI量化配置"""
    print("创建FSMNFixedCache专用EAI配置...")

    # 分析模型层结构
    layer_info = {}
    for name, module in model.named_modules():
        if name:  # 跳过根模块
            layer_info[name] = type(module).__name__

    # 使用与requantize_model.py相同的成功量化配置
    config = {
        "defaults": {
            "ops": {
                "is_output_quantized": "True",
                "is_symmetric": "True"
            },
            "params": {
                "is_quantized": "True",
                "is_symmetric": "True"
            }
        },
        "params": {
            # 关键参数保持浮点精度
            "bias": {"is_quantized": "False"}
        },
        "op_type": {
            # 对Softmax使用特殊处理（与requantize_model.py一致）
            "Softmax": {
                "is_output_quantized": "True",  # ✓ 启用Softmax量化
                "is_symmetric": "True"
            }
        },
        "supergroups": [
            {"op_list": ["Conv", "Relu"]},
            {"op_list": ["MatMul", "Add"]}
        ],
        "model_input": {
            "is_input_quantized": "True"
        },
        "model_output": {
            "is_output_quantized": "True"  # ✓ 启用模型输出量化
        }
    }

    # 注意：AIMET不支持op_name字段，所以我们通过op_type来配置
    # 这里主要是确保所有操作都被正确量化

    print(f"为 {len([k for k in layer_info.keys() if 'fsmn_layer_' in k])} 个FSMN层创建了专用配置")
    return config

def create_eai_compatible_config(model=None):
    """
    创建EAI兼容的量化配置文件
    根据模型类型自动选择最佳配置
    """
    if model is not None:
        model_type = detect_model_type(model)
        if model_type == 'FSMNFixedCache':
            return create_fixed_cache_eai_config(model)

    # 默认配置（兼容原始FSMN模型）
    config = {
        "defaults": {
            "ops": {
                "is_output_quantized": "True"
            },
            "params": {
                "is_quantized": "True",
                "is_symmetric": "True"  # 强制对称量化
            },
            "strict_symmetric": "True",      # 严格对称
            "unsigned_symmetric": "False",   # 禁用无符号量化
            "per_channel_quantization": "True"
        },
        "params": {
            # 针对原始FSMN模型的特定层参数设置
            "bias": {"is_quantized": "False"},
            "C": {"is_quantized": "False"},
            "scale": {"is_quantized": "False"},
            "mean": {"is_quantized": "False"},
            "var": {"is_quantized": "False"}
        },
        "op_type": {
            # 禁用可能产生条件操作符的量化类型
            "Relu": {
                "is_output_quantized": "False"  # 避免ReLU量化产生条件操作
            },
            "Add": {
                "is_output_quantized": "True"
            },
            "Conv": {
                "is_output_quantized": "True"
            },
            "MatMul": {
                "is_output_quantized": "True"
            }
        },
        "supergroups": [],
        "model_input": {
            "is_input_quantized": "False"  # 保持输入为float32
        },
        "model_output": {
            "is_output_quantized": "False"  # 保持输出为float32
        }
    }
    return config


def fix_encodings_for_eai(encodings_file, output_file=None):
    """
    修复量化编码文件，确保EAI builder兼容性

    主要修复：
    1. 强制有符号量化 (signed quantization)
    2. 确保对称量化
    3. 修正offset和scale计算
    """
    if output_file is None:
        output_file = encodings_file.replace('.encodings', '_eai_fixed.encodings')

    print(f"修复量化编码文件以兼容EAI: {encodings_file} -> {output_file}")

    try:
        with open(encodings_file, 'r') as f:
            encodings = json.load(f)

        # 修复激活量化编码
        if 'activation_encodings' in encodings:
            for layer_name, encoding_list in encodings['activation_encodings'].items():
                for encoding in encoding_list:
                    # 强制设置为有符号对称量化
                    encoding['is_symmetric'] = "True"
                    encoding['dtype'] = 'int'  # 确保使用int而不是uint

                    # 重新计算对称的min/max
                    max_val = encoding.get('max', 0)
                    min_val = encoding.get('min', 0)
                    abs_max = max(abs(max_val), abs(min_val))
                    encoding['max'] = abs_max
                    encoding['min'] = -abs_max

                    # 根据位宽重新计算offset和scale
                    bitwidth = encoding.get('bitwidth', 16)
                    if bitwidth == 8:
                        encoding['offset'] = -128  # int8: -128 to 127
                        encoding['scale'] = (2 * abs_max) / 255
                    elif bitwidth == 16:
                        encoding['offset'] = -32768  # int16: -32768 to 32767
                        encoding['scale'] = (2 * abs_max) / 65535

        # 修复参数量化编码
        if 'param_encodings' in encodings:
            for layer_name, encoding_list in encodings['param_encodings'].items():
                for encoding in encoding_list:
                    encoding['is_symmetric'] = "True"
                    encoding['dtype'] = 'int'

                    max_val = encoding.get('max', 0)
                    min_val = encoding.get('min', 0)
                    abs_max = max(abs(max_val), abs(min_val))
                    encoding['max'] = abs_max
                    encoding['min'] = -abs_max

                    bitwidth = encoding.get('bitwidth', 8)
                    if bitwidth == 8:
                        encoding['offset'] = -128
                        encoding['scale'] = (2 * abs_max) / 255
                    elif bitwidth == 16:
                        encoding['offset'] = -32768
                        encoding['scale'] = (2 * abs_max) / 65535

        # 保存修复后的编码文件
        with open(output_file, 'w') as f:
            json.dump(encodings, f, indent=2)

        print(f"EAI兼容编码文件已生成: {output_file}")
        return output_file

    except Exception as e:
        print(f"编码文件修复失败: {e}")
        return encodings_file

def enhance_encodings_for_fixed_cache(encodings_file, onnx_model_path, model):
    """为FSMNFixedCache模型增强编码文件，补充缺失的量化信息"""
    if not os.path.exists(encodings_file):
        print(f"原始编码文件不存在: {encodings_file}")
        return encodings_file

    model_type = detect_model_type(model)
    if model_type != 'FSMNFixedCache':
        print(f"模型类型 {model_type} 不需要增强编码")
        return encodings_file

    print(f"为FSMNFixedCache模型增强编码文件: {encodings_file}")

    try:
        # 加载原始编码文件
        with open(encodings_file, 'r') as f:
            original_encodings = json.load(f)

        # 加载ONNX模型分析结构
        onnx_model = onnx.load(onnx_model_path)
        inputs = [inp.name for inp in onnx_model.graph.input]
        outputs = [out.name for out in onnx_model.graph.output]

        # 分析中间张量
        intermediate_tensors = set()
        for node in onnx_model.graph.node:
            for output_name in node.output:
                if output_name not in outputs:
                    intermediate_tensors.add(output_name)

        print(f"ONNX模型分析: {len(inputs)}输入, {len(outputs)}输出, {len(intermediate_tensors)}中间张量")

        # 创建增强编码
        enhanced_encodings = {
            "version": original_encodings.get("version", "0.6.1"),
            "activation_encodings": {},
            "param_encodings": {}
        }

        # 为缺失的输入输出生成量化信息
        for input_name in inputs:
            if input_name not in original_encodings.get("activation_encodings", {}):
                if 'cache' in input_name or any(c.isdigit() for c in input_name):
                    # cache输入使用较小范围
                    enhanced_encodings["activation_encodings"][input_name] = [{
                        "bitwidth": 16,
                        "dtype": "int",
                        "is_symmetric": "True",
                        "max": 2.0,
                        "min": -2.0,
                        "offset": -32768,
                        "scale": 6.103515625e-05
                    }]
                else:
                    # 主输入
                    enhanced_encodings["activation_encodings"][input_name] = [{
                        "bitwidth": 16,
                        "dtype": "int",
                        "is_symmetric": "True",
                        "max": 6.0,
                        "min": -6.0,
                        "offset": -32768,
                        "scale": 0.00018310546875
                    }]

        for output_name in outputs:
            if output_name not in original_encodings.get("activation_encodings", {}):
                if 'cache' in output_name or any(c.isdigit() for c in output_name):
                    # cache输出
                    enhanced_encodings["activation_encodings"][output_name] = [{
                        "bitwidth": 16,
                        "dtype": "int",
                        "is_symmetric": "True",
                        "max": 2.0,
                        "min": -2.0,
                        "offset": -32768,
                        "scale": 6.103515625e-05
                    }]
                else:
                    # 主输出
                    enhanced_encodings["activation_encodings"][output_name] = [{
                        "bitwidth": 16,
                        "dtype": "int",
                        "is_symmetric": "True",
                        "max": 1.0,
                        "min": -1.0,
                        "offset": -32768,
                        "scale": 3.0517578125e-05
                    }]

        # 合并原始编码（优先使用原始编码）
        enhanced_encodings["activation_encodings"].update(original_encodings.get("activation_encodings", {}))
        enhanced_encodings["param_encodings"].update(original_encodings.get("param_encodings", {}))

        # 修复所有编码为EAI兼容格式
        for encoding_dict in [enhanced_encodings["activation_encodings"], enhanced_encodings["param_encodings"]]:
            for layer_name, encoding_list in encoding_dict.items():
                for encoding in encoding_list:
                    encoding["is_symmetric"] = "True"
                    encoding["dtype"] = "int"

                    # 确保对称量化
                    max_val = encoding.get("max", 0)
                    min_val = encoding.get("min", 0)
                    abs_max = max(abs(max_val), abs(min_val))
                    encoding["max"] = abs_max
                    encoding["min"] = -abs_max

                    # 重新计算offset和scale
                    bitwidth = encoding.get("bitwidth", 16)
                    if bitwidth == 8:
                        encoding["offset"] = -128
                        encoding["scale"] = (2 * abs_max) / 255
                    elif bitwidth == 16:
                        encoding["offset"] = -32768
                        encoding["scale"] = (2 * abs_max) / 65535

        # 保存增强编码文件
        enhanced_file = encodings_file.replace('_eai.encodings', '_enhanced_eai.encodings')
        with open(enhanced_file, 'w') as f:
            json.dump(enhanced_encodings, f, indent=2)

        print(f"FSMNFixedCache增强编码文件已生成: {enhanced_file}")

        return enhanced_file

    except Exception as e:
        print(f"增强编码文件失败: {e}")
        return encodings_file


def quantize_model(model, features, args):
    """使用AIMET量化模型，生成EAI兼容的编码文件"""
    # 检查AIMET可用性
    if not AIMET_AVAILABLE:
        print(f"AIMET库不可用，跳过量化")
        return None

    print("开始AIMET量化（EAI兼容模式）...")

    # 使用与requantize_model.py完全相同的简单配置
    print("使用与requantize_model.py相同的优化配置")
    eai_config = {
        "defaults": {
            "ops": {
                "is_output_quantized": "True",
                "is_symmetric": "True"
            },
            "params": {
                "is_quantized": "True",
                "is_symmetric": "True"
            }
        },
        "params": {
            # 关键参数保持浮点精度
            "bias": {"is_quantized": "False"}
        },
        "op_type": {
            # 对Softmax使用特殊处理（与requantize_model.py一致）
            "Softmax": {
                "is_output_quantized": "True",
                "is_symmetric": "True"
            }
        },
        "supergroups": [
            {"op_list": ["Conv", "Relu"]},
            {"op_list": ["MatMul", "Add"]}
        ],
        "model_input": {
            "is_input_quantized": "True"
        },
        "model_output": {
            "is_output_quantized": "True"
        }
    }

    config_file = os.path.join(args.output_dir, "simple_quantization_config.json")
    with open(config_file, 'w') as f:
        json.dump(eai_config, f, indent=2)
    print(f"简化量化配置文件: {config_file}")

    # 替换自定义模块为标准PyTorch模块以兼容AIMET
    def replace_custom_modules(model):
        """递归替换自定义模块为标准PyTorch模块"""
        for name, module in model.named_children():
            if hasattr(module, '__class__') and 'RectifiedLinearFixed' in str(module.__class__):
                # 替换为标准ReLU
                setattr(model, name, nn.ReLU())
                print(f"替换 {name}: RectifiedLinearFixed -> ReLU")
            else:
                replace_custom_modules(module)

    # 创建模型副本并替换自定义模块
    import copy
    model_copy = copy.deepcopy(model)
    replace_custom_modules(model_copy)

    # 使用全局定义的QuantWrapper
    wrapper = QuantWrapper(model_copy)
    wrapper.eval()
    print("已替换自定义模块为AIMET兼容模块")

    # 创建与原始模型相同的5输入dummy_input
    dummy_input = torch.randn(1, 400, 400)
    dummy_cache_0 = torch.zeros(1, 128, 19, 1)
    dummy_cache_1 = torch.zeros(1, 128, 19, 1)
    dummy_cache_2 = torch.zeros(1, 128, 19, 1)
    dummy_cache_3 = torch.zeros(1, 128, 19, 1)
    dummy_inputs = (dummy_input, dummy_cache_0, dummy_cache_1, dummy_cache_2, dummy_cache_3)
    from aimet_torch.cross_layer_equalization import equalize_model
    # 交叉层均衡化
    try:
        equalize_model(model=wrapper,
                       input_shapes=[(1, 400, 400), (1, 128, 19, 1), (1, 128, 19, 1), (1, 128, 19, 1), (1, 128, 19, 1)])
        print("交叉层均衡化完成")
    except Exception as e:
        print(f"交叉层均衡化失败: {e}")

    # 创建量化模拟器（使用改进的稳定配置）
    sim = QuantizationSimModel(
            model=wrapper,
            dummy_input=dummy_inputs,
            quant_scheme=QuantScheme.post_training_tf,  # 使用更稳定的标准TF方案
            default_param_bw=args.param_bits,
            default_output_bw=args.output_bits,
            in_place=False,
            config_file=config_file
        )
    print(f"量化模拟器已创建 (改进的稳定配置: {os.path.basename(config_file)})")



    # 使用与requantize_model.py完全相同的校准过程
    def calibrate(sim_model, _):
        sim_model.eval()
        with torch.no_grad():
            print("开始增强校准过程...")

            # 分组处理校准数据，每组模拟一个音频序列
            group_size = 10  # 每组10个段
            num_groups = len(features) // group_size

            for group_idx in range(num_groups):
                # 为每个音频组重置cache
                cache_0 = torch.zeros(1, 128, 19, 1)
                cache_1 = torch.zeros(1, 128, 19, 1)
                cache_2 = torch.zeros(1, 128, 19, 1)
                cache_3 = torch.zeros(1, 128, 19, 1)

                # 处理该组的所有段
                start_idx = group_idx * group_size
                end_idx = start_idx + group_size
                group_features = features[start_idx:end_idx]

                for seg_idx, feat in enumerate(group_features):
                    feat_input = feat.unsqueeze(0)

                    try:
                        # 推理并更新cache
                        _, new_cache_0, new_cache_1, new_cache_2, new_cache_3 = sim_model(
                            feat_input, cache_0, cache_1, cache_2, cache_3
                        )

                        # 更新cache状态
                        cache_0, cache_1, cache_2, cache_3 = new_cache_0, new_cache_1, new_cache_2, new_cache_3

                        if (seg_idx + 1) % 5 == 0:
                            print(f"  组 {group_idx + 1}/{num_groups}, 段 {seg_idx + 1}/{group_size}")

                    except Exception as e:
                        print(f"校准失败 - 组 {group_idx + 1}, 段 {seg_idx + 1}: {e}")
                        break

            print("增强校准完成")

    sim.compute_encodings(calibrate, None)
    print("量化校准完成")

    # 导出量化模型和编码文件 - 保持5输入5输出接口
    sim.export(
        path=args.output_dir,
        filename_prefix="quantized_model",
        dummy_input=dummy_inputs
    )

    print("量化模型已导出")

    quant_path = os.path.join(args.output_dir, "quantized_model.onnx")
    if os.path.exists(quant_path):
        print(f"量化模型导出: {quant_path}")

        # 检查并修复生成的编码文件以兼容EAI
        original_encoding_file = os.path.join(args.output_dir, "quantized_model.encodings")

        if os.path.exists(original_encoding_file):
            print(f"原始编码文件: {original_encoding_file}")

            # 生成EAI兼容的编码文件
            eai_encoding_file = fix_encodings_for_eai(
                original_encoding_file,
                os.path.join(args.output_dir, "quantized_model_eai.encodings")
            )

            if eai_encoding_file:
                print(f"EAI兼容编码文件已生成: {eai_encoding_file}")

                # 检测模型类型，如果是FSMNFixedCache则进一步增强编码
                model_type = detect_model_type(model)
                if model_type == 'FSMNFixedCache':
                    enhanced_file = enhance_encodings_for_fixed_cache(
                        eai_encoding_file,
                        quant_path,
                        model
                    )
                    if enhanced_file != eai_encoding_file:
                        print(f"FSMNFixedCache增强编码文件已生成: {enhanced_file}")

                print(f"原始编码文件保留为备份: {original_encoding_file}")
        else:
            print("未找到量化编码文件，可能导出失败")

        return quant_path

    return None


def fix_onnx_input_names(input_model_path, output_model_path=None):
    """
    修复ONNX模型的输入输出名称
    解决AIMET量化后输入名称变为t.1, t.3, t.5, t.7, t.9的问题

    Args:
        input_model_path: 输入ONNX模型路径
        output_model_path: 输出ONNX模型路径，如果为None则自动生成

    Returns:
        修复后的模型路径，如果修复失败返回原路径
    """
    if output_model_path is None:
        output_model_path = input_model_path.replace('.onnx', '_fixed.onnx')

    try:
        # 加载模型
        model = onnx.load(input_model_path)

        # 定义期望的输入输出名称
        expected_input_names = ['input', 'cache_0', 'cache_1', 'cache_2', 'cache_3']
        expected_output_names = ['output', 'new_cache_0', 'new_cache_1', 'new_cache_2', 'new_cache_3']

        # 获取当前的输入输出名称
        current_input_names = [inp.name for inp in model.graph.input]
        current_output_names = [out.name for out in model.graph.output]

        # 检查是否需要修复
        if current_input_names == expected_input_names and current_output_names == expected_output_names:
            print("ONNX模型输入输出名称已正确，无需修复")
            return input_model_path

        print(f"检测到ONNX模型名称需要修复:")
        print(f"   当前输入: {current_input_names}")
        print(f"   期望输入: {expected_input_names}")
        print(f"   当前输出: {current_output_names}")
        print(f"   期望输出: {expected_output_names}")

        # 创建名称映射
        input_name_mapping = {}
        output_name_mapping = {}

        # 输入名称映射
        for i, (current, expected) in enumerate(zip(current_input_names, expected_input_names)):
            if current != expected:
                input_name_mapping[current] = expected

        # 输出名称映射
        for i, (current, expected) in enumerate(zip(current_output_names, expected_output_names)):
            if current != expected:
                output_name_mapping[current] = expected

        # 修改输入名称
        for inp in model.graph.input:
            if inp.name in input_name_mapping:
                old_name = inp.name
                inp.name = input_name_mapping[old_name]
                print(f"   修复输入: {old_name} -> {inp.name}")

        # 修改输出名称
        for out in model.graph.output:
            if out.name in output_name_mapping:
                old_name = out.name
                out.name = output_name_mapping[old_name]
                print(f"   修复输出: {old_name} -> {out.name}")

        # 修改图中节点的输入输出引用
        all_name_mapping = {**input_name_mapping, **output_name_mapping}

        for node in model.graph.node:
            # 修改节点输入引用
            for i, input_name in enumerate(node.input):
                if input_name in all_name_mapping:
                    node.input[i] = all_name_mapping[input_name]

            # 修改节点输出引用
            for i, output_name in enumerate(node.output):
                if output_name in all_name_mapping:
                    node.output[i] = all_name_mapping[output_name]

        # 保存修复后的模型
        onnx.save(model, output_model_path)
        print(f"ONNX模型名称修复完成: {output_model_path}")

        return output_model_path

    except Exception as e:
        print(f"ONNX模型名称修复失败: {e}")
        print(f"   将使用原始模型: {input_model_path}")
        return input_model_path


def compare_models(original_model, quantized_path, features):
    """对比原始模型和量化模型输出"""
    if not quantized_path or not os.path.exists(quantized_path):
        return

    print("对比模型输出...")

    try:
        import onnxruntime as ort

        # 检查并修复ONNX模型输入输出名称
        try:
            # 先尝试加载模型检查输入名称
            session = ort.InferenceSession(quantized_path, providers=['CPUExecutionProvider'])
            input_names = [inp.name for inp in session.get_inputs()]
            expected_names = ['input', 'cache_0', 'cache_1', 'cache_2', 'cache_3']

            if input_names != expected_names:
                print("检测到输入名称不匹配，正在自动修复...")
                fixed_path = fix_onnx_input_names(quantized_path)
                if fixed_path != quantized_path:
                    quantized_path = fixed_path
                    print(f"使用修复后的模型进行对比: {quantized_path}")
            else:
                print("ONNX模型输入输出名称正确")

        except Exception as fix_e:
            print(f"自动修复过程出现问题: {fix_e}")
            print("   继续使用原始模型进行对比...")

        # 原始模型输出
        original_model.eval()
        original_outputs = []
        with torch.no_grad():
            for feat in features[:5]:
                feat_input = feat.unsqueeze(0)
                cache_0, cache_1, cache_2, cache_3 = original_model.init_cache(1)
                output, _, _, _, _ = original_model(feat_input, cache_0, cache_1, cache_2, cache_3)
                original_outputs.append(output)

        # 量化模型输出
        session = ort.InferenceSession(quantized_path, providers=['CPUExecutionProvider'])

        # 动态获取输入名称，支持修复前后的模型
        input_names = [inp.name for inp in session.get_inputs()]

        quantized_outputs = []
        for feat in features[:5]:
            feat_input = feat.unsqueeze(0).numpy()
            cache_0 = torch.zeros(1, 128, 19, 1).numpy()
            cache_1 = torch.zeros(1, 128, 19, 1).numpy()
            cache_2 = torch.zeros(1, 128, 19, 1).numpy()
            cache_3 = torch.zeros(1, 128, 19, 1).numpy()

            # 根据实际输入名称构建输入字典
            if len(input_names) == 5:
                onnx_inputs = {
                    input_names[0]: feat_input,
                    input_names[1]: cache_0,
                    input_names[2]: cache_1,
                    input_names[3]: cache_2,
                    input_names[4]: cache_3
                }
            else:
                # 回退到标准名称
                onnx_inputs = {
                    'input': feat_input,
                    'cache_0': cache_0, 'cache_1': cache_1,
                    'cache_2': cache_2, 'cache_3': cache_3
                }

            outputs = session.run(None, onnx_inputs)
            quantized_outputs.append(torch.tensor(outputs[0]))

        # 计算差异
        if original_outputs and quantized_outputs:
            orig_tensor = torch.cat(original_outputs, dim=0)
            quant_tensor = torch.cat(quantized_outputs, dim=0)

            mse = torch.mean((orig_tensor - quant_tensor) ** 2)
            mae = torch.mean(torch.abs(orig_tensor - quant_tensor))
            rel_error = torch.mean(torch.abs(orig_tensor - quant_tensor) / (torch.abs(orig_tensor) + 1e-8))

            print(f"模型对比结果:")
            print(f"  均方误差: {mse:.8f}")
            print(f"  平均绝对误差: {mae:.8f}")
            print(f"  相对误差: {rel_error * 100:.2f}%")

            if rel_error < 0.01:
                print("  量化质量: 优秀")
            elif rel_error < 0.05:
                print("  量化质量: 良好")
            else:
                print("  量化质量: 一般")

    except Exception as e:
        print(f"模型对比失败: {e}")


def generate_eai_commands(onnx_path, quantized_path, output_dir):
    """生成EAI转换命令"""
    print(f"\n" + "=" * 60)
    print("EAI转换命令")
    print("=" * 60)

    sdk_path = "/local/mnt/workspace/Qualcomm/Hexagon_SDK/6.2.0.1/addons/LPAI/eNPU6/5.7.0/eai_builder/eai_builder"

    if quantized_path:

        # 检查量化编码文件（优先使用增强版本）
        encoding_files = [
            (os.path.join(output_dir, "quantized_model_enhanced_eai.encodings"), "FSMNFixedCache增强编码文件"),
            (os.path.join(output_dir, "quantized_model_eai.encodings"), "EAI兼容编码文件"),
            (os.path.join(output_dir, "quantized_model.encodings"), "原始编码文件")
        ]

        found_encoding = None
        for encoding_file, _ in encoding_files:
            if os.path.exists(encoding_file):
                found_encoding = encoding_file
                break

        if found_encoding:
            if "enhanced" in found_encoding:
                output_name = "vad_fixed_cache_enhanced.eai"
            elif "eai" in found_encoding:
                output_name = "vad_quantized_with_encodings.eai"
            else:
                output_name = "vad_quantized_original.eai"

            print(f"使用量化编码文件构建EAI模型:")
            print(f"{sdk_path} --onnx {quantized_path} \\")
            print(f"           --quant_json {found_encoding} \\")
            print(f"           --output {os.path.join(output_dir, output_name)} \\")
            print(f"           --enable_enpu_ver v6 \\")
            print(f"           --enable_hw_cfg 1")
        else:
            print(f"未找到量化编码文件")


def main():
    """主函数"""
    args = parse_args()

    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)
    print(f"输出目录: {args.output_dir}")

    # 加载配置
    config = load_config(args.config_file)
    encoder_conf = config.get('encoder_conf', {})

    # 创建模型
    print("创建固定Cache FSMN模型...")
    model = FSMNFixedCache(
        input_dim=encoder_conf.get('input_dim', 400),
        input_affine_dim=encoder_conf.get('input_affine_dim', 140),
        linear_dim=encoder_conf.get('linear_dim', 250),
        proj_dim=encoder_conf.get('proj_dim', 128),
        lorder=encoder_conf.get('lorder', 20),
        output_affine_dim=encoder_conf.get('output_affine_dim', 140),
        output_dim=encoder_conf.get('output_dim', 248),
        fsmn_layers=encoder_conf.get('fsmn_layers', 4),
        use_softmax=True
    )
    model.eval()

    # 加载权重
    if args.model_path and os.path.exists(args.model_path):
        print(f"加载预训练权重: {args.model_path}")
        checkpoint = torch.load(args.model_path, map_location='cpu')
        if isinstance(checkpoint, dict):
            state_dict = checkpoint.get('model', checkpoint.get('state_dict', checkpoint))
        else:
            state_dict = checkpoint

        copy_weights_from_original(state_dict, model)

    # 导出ONNX
    onnx_path = os.path.join(args.output_dir, "fixed_cache_model.onnx")
    final_onnx_path = export_onnx(model, onnx_path)

    # 量化流程
    quantized_path = None
    if args.quantize:
        # 使用与requantize_model.py相同的校准数据
        print("使用与requantize_model.py相同的校准数据源")
        from requantize_model import load_real_audio_calibration_data
        features = load_real_audio_calibration_data("fsmn_model/example", 150)

        # 执行量化
        quantized_path = quantize_model(model, features, args)

        # 模型对比
        if quantized_path:
            compare_models(model, quantized_path, features)
            print("===========")
            print(quantized_path)
    # 生成EAI转换命令
    generate_eai_commands(final_onnx_path, quantized_path, args.output_dir)

    print(f"\n  导出完成!")
    print(f"ONNX模型: {final_onnx_path}")
    if quantized_path:
        print(f"量化模型: {quantized_path}")
        print(f"量化配置: {args.param_bits}bit参数 + {args.output_bits}bit激活")

        # 检查生成的量化相关文件
        print("量化相关文件:")

        print("导出完成")


if __name__ == "__main__":
    main()