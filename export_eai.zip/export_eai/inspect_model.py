#!/usr/bin/env python3
"""
检查预训练模型文件的结构
"""

import torch
import sys
import os

def inspect_model_file(model_path):
    """检查模型文件的内容和结构"""
    print(f"检查模型文件: {model_path}")
    
    try:
        # 加载模型文件
        model_data = torch.load(model_path, map_location='cpu')
        
        print(f"模型数据类型: {type(model_data)}")
        
        if isinstance(model_data, dict):
            print("模型是字典格式，包含以下键:")
            for key in model_data.keys():
                print(f"  - {key}: {type(model_data[key])}")
                
                # 如果是state_dict，显示一些层的信息
                if 'state_dict' in key.lower() or key == 'model':
                    if isinstance(model_data[key], dict):
                        print(f"    {key} 包含 {len(model_data[key])} 个参数:")
                        for i, (param_name, param_tensor) in enumerate(model_data[key].items()):
                            if i < 5:  # 只显示前5个
                                print(f"      {param_name}: {param_tensor.shape}")
                            elif i == 5:
                                print(f"      ... 还有 {len(model_data[key]) - 5} 个参数")
                                break
        
        elif hasattr(model_data, '__class__'):
            print(f"模型类: {model_data.__class__}")
            if hasattr(model_data, 'state_dict'):
                state_dict = model_data.state_dict()
                print(f"模型包含 {len(state_dict)} 个参数")
                for i, (name, param) in enumerate(state_dict.items()):
                    if i < 5:
                        print(f"  {name}: {param.shape}")
                    elif i == 5:
                        print(f"  ... 还有 {len(state_dict) - 5} 个参数")
                        break
        
        return model_data
        
    except Exception as e:
        print(f"加载模型失败: {e}")
        return None

def try_load_with_funasr(model_dir):
    """尝试使用FunASR加载模型"""
    try:
        sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from funasr import AutoModel
        
        print(f"\n尝试使用FunASR加载: {model_dir}")
        model = AutoModel(model=model_dir)
        print(f"FunASR加载成功，模型类型: {type(model)}")
        
        # 检查模型是否有我们需要的方法
        if hasattr(model, 'model'):
            print(f"模型内部结构: {type(model.model)}")
            if hasattr(model.model, 'encoder'):
                print(f"编码器类型: {type(model.model.encoder)}")
        
        return model
        
    except Exception as e:
        print(f"FunASR加载失败: {e}")
        return None

def main():
    # 检查模型文件
    model_data = inspect_model_file("fsmn_model/model.pt")
    
    # 尝试FunASR加载
    funasr_model = try_load_with_funasr("fsmn_model")
    
    # 如果是state_dict，尝试创建模型并加载权重
    if isinstance(model_data, dict) and ('state_dict' in model_data or 'model' in model_data):
        print("\n尝试创建模型并加载权重...")
        try:
            from models.fsmn_vad_streaming.encoder_fixed_cache import FSMNFixedCache
            
            # 创建模型
            model = FSMNFixedCache(
                input_dim=400,
                input_affine_dim=140,
                linear_dim=250,
                proj_dim=128,
                lorder=20,
                output_affine_dim=140,
                output_dim=248,
                fsmn_layers=4,
                use_softmax=True
            )
            
            # 尝试加载权重
            if 'state_dict' in model_data:
                state_dict = model_data['state_dict']
            elif 'model' in model_data:
                state_dict = model_data['model']
            else:
                state_dict = model_data
            
            # 检查权重键名是否匹配
            model_keys = set(model.state_dict().keys())
            loaded_keys = set(state_dict.keys())
            
            print(f"模型参数数量: {len(model_keys)}")
            print(f"加载的参数数量: {len(loaded_keys)}")
            
            common_keys = model_keys & loaded_keys
            missing_keys = model_keys - loaded_keys
            unexpected_keys = loaded_keys - model_keys
            
            print(f"匹配的参数: {len(common_keys)}")
            if missing_keys:
                print(f"缺失的参数: {list(missing_keys)[:5]}...")
            if unexpected_keys:
                print(f"多余的参数: {list(unexpected_keys)[:5]}...")
            
            if len(common_keys) > 0:
                # 尝试加载匹配的权重
                filtered_state_dict = {k: v for k, v in state_dict.items() if k in model_keys}
                model.load_state_dict(filtered_state_dict, strict=False)
                print("权重加载成功（部分匹配）")
                
                # 测试模型
                test_input = torch.randn(1, 400, 400)
                cache_0, cache_1, cache_2, cache_3 = model.init_cache(1)
                
                with torch.no_grad():
                    output = model(test_input, cache_0, cache_1, cache_2, cache_3)
                    print(f"模型测试成功，输出形状: {[o.shape if torch.is_tensor(o) else type(o) for o in output]}")
            
        except Exception as e:
            print(f"创建和加载模型失败: {e}")
            import traceback
            print(traceback.format_exc())

if __name__ == "__main__":
    main()
