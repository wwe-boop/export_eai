import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple, Optional

# ========== 基础变换层 ==========

class LinearTransform(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(LinearTransform, self).__init__()
        self.linear = nn.Linear(input_dim, output_dim, bias=False)

    def forward(self, input):
        return self.linear(input)


class AffineTransform(nn.Module):
    def __init__(self, input_dim: int, output_dim: int):
        super().__init__()
        self.linear = nn.Linear(input_dim, output_dim)
        self.relu = nn.ReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.relu(self.linear(x))


class RectifiedLinear(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(RectifiedLinear, self).__init__()
        self.dim = input_dim
        self.relu = nn.ReLU()

    def forward(self, input):
        return self.relu(input)


# ========== FSMN核心组件 ==========

class FSMNBlock(nn.Module):
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        lorder: int = 20,
        rorder: int = 0,
        lstride: int = 1,
        rstride: int = 1,
    ):
        super(FSMNBlock, self).__init__()

        self.dim = input_dim
        self.lorder = lorder
        self.rorder = rorder
        self.lstride = lstride
        self.rstride = rstride

        kernel_size_left = (int(lorder), 1)
        stride_size = (1, 1)
        dilation_left = (int(lstride), 1)

        self.conv_left = nn.Conv2d(
            in_channels=self.dim,
            out_channels=self.dim,
            kernel_size=kernel_size_left,
            stride=stride_size,
            dilation=dilation_left,
            groups=self.dim,
            bias=False
        )

        if self.rorder > 0:
            kernel_size_right = (int(rorder), 1)
            dilation_right = (int(rstride), 1)
            self.conv_right = nn.Conv2d(
                in_channels=self.dim,
                out_channels=self.dim,
                kernel_size=kernel_size_right,
                stride=stride_size,
                dilation=dilation_right,
                groups=self.dim,
                bias=False
            )
        else:
            self.conv_right = None

    def forward(self, input: torch.Tensor, cache: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = torch.unsqueeze(input, 1)
        x_per = x.permute(0, 3, 2, 1)  # B, D, T, C

        # Concatenate cache and input
        y_left = torch.cat((cache, x_per), dim=2)
        new_cache = y_left[:, :, -(self.lorder - 1) * self.lstride:, :]

        y_left = self.conv_left(y_left)
        out = x_per + y_left

        if self.conv_right is not None:
            y_right = F.pad(x_per, [0, 0, 0, self.rorder * self.rstride])
            y_right = y_right[:, :, self.rstride:, :]
            y_right = self.conv_right(y_right)
            out += y_right

        out_per = out.permute(0, 3, 2, 1)  # B, T, D, C
        output = out_per.squeeze(1)  # B, T, D

        return output, new_cache


class FSMNLayer(nn.Module):
    def __init__(self, linear_dim: int, proj_dim: int, lorder: int, rorder: int, lstride: int, rstride: int):
        super().__init__()
        self.linear = AffineTransform(linear_dim, linear_dim)
        self.fsmn_block = FSMNBlock(
            input_dim=linear_dim,
            output_dim=linear_dim,
            lorder=lorder,
            rorder=rorder,
            lstride=lstride,
            rstride=rstride
        )
        self.affine = AffineTransform(linear_dim, proj_dim)
        self.relu = RectifiedLinear(proj_dim, linear_dim)

    def forward(self, x: torch.Tensor, cache: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        identity = x
        out = self.linear(x)
        out, new_cache = self.fsmn_block(out, cache)
        out = self.affine(out)
        out = self.relu(out)
        return out + identity, new_cache


# ========== 主模型类 ==========

class FSMNModel(nn.Module):
    def __init__(
        self,
        input_dim: int = 400,
        input_affine_dim: int = 140,
        linear_dim: int = 250,
        proj_dim: int = 128,
        lorder: int = 20,
        rorder: int = 0,
        lstride: int = 1,
        rstride: int = 1,
        output_affine_dim: int = 140,
        output_dim: int = 248,
        fsmn_layers: int = 4,
    ):
        super().__init__()

        # 输入层
        self.in_linear1 = AffineTransform(input_dim, input_affine_dim)
        self.in_linear2 = AffineTransform(input_affine_dim, linear_dim)

        # FSMN 层
        self.fsmn_layers = nn.ModuleList([
            FSMNLayer(
                linear_dim=linear_dim,
                proj_dim=proj_dim,
                lorder=lorder,
                rorder=rorder,
                lstride=lstride,
                rstride=rstride
            ) for _ in range(fsmn_layers)
        ])

        # 输出层
        self.out_linear1 = AffineTransform(proj_dim, output_affine_dim)
        self.out_linear2 = AffineTransform(output_affine_dim, output_dim)

        # 静态缓存
        self.cache = nn.ParameterList([
            nn.Parameter(torch.zeros(1, lorder - 1, linear_dim), requires_grad=False)
            for _ in range(fsmn_layers)
        ])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size = x.size(0)

        # 初始化缓存
        caches = [cache.expand(batch_size, -1, -1) for cache in self.cache]

        out = self.in_linear1(x)
        out = self.in_linear2(out)

        for i, layer in enumerate(self.fsmn_layers):
            out, new_cache = layer(out, caches[i])
            caches[i] = new_cache  # 更新缓存

        out = self.out_linear1(out)
        out = self.out_linear2(out)

        return out


# ========== 流式推理封装类（可选） ==========

class FSMNInferencer:
    def __init__(self, model: FSMNModel):
        self.model = model.eval()
        self.cache = [cache.clone() for cache in model.cache]  # 初始化静态缓存

    def step(self, x: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            output, *new_cache = self.model(x)
        self.cache = new_cache
        return output