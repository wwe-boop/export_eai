

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple
import importlib

# 导入tables模块
try:
    from funasr.register import tables
except ImportError:
    # 创建简单的注册器
    class SimpleRegister:
        def __init__(self):
            self.classes = {}

        def register(self, table_name, class_name):
            def decorator(cls):
                if table_name not in self.classes:
                    self.classes[table_name] = {}
                self.classes[table_name][class_name] = cls
                return cls
            return decorator

    tables = SimpleRegister()


class LinearTransformFixed(nn.Module):
    """固定的线性变换层，无bias"""
    def __init__(self, input_dim, output_dim):
        super(LinearTransformFixed, self).__init__()
        self.linear = nn.Linear(input_dim, output_dim, bias=False)

    def forward(self, input):
        return self.linear(input)


class AffineTransformFixed(nn.Module):
    """固定的仿射变换层，带bias和ReLU"""
    def __init__(self, input_dim: int, output_dim: int):
        super().__init__()
        self.linear = nn.Linear(input_dim, output_dim, bias=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.relu(self.linear(x))


class RectifiedLinearFixed(nn.Module):
    """固定的修正线性层（ReLU）"""
    def __init__(self, input_dim, output_dim):
        super(RectifiedLinearFixed, self).__init__()
        assert input_dim == output_dim

    def forward(self, input):
        return F.relu(input)


class FSMNBlockFixed(nn.Module):
    """
    使用2D卷积实现，与原始实现保持一致
    """
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        lorder: int = 20,
        rorder: int = 0,
        lstride: int = 1,
        rstride: int = 1,
    ):
        super(FSMNBlockFixed, self).__init__()

        self.dim = input_dim
        self.lorder = lorder
        self.rorder = rorder
        self.lstride = lstride
        self.rstride = rstride

        # 左侧卷积：处理历史信息，与原始FSMN完全一致
        kernel_size_left: Tuple[int, int] = (int(lorder), 1)
        stride_size: Tuple[int, int] = (1, 1)
        dilation_left: Tuple[int, int] = (int(lstride), 1)

        self.conv_left = nn.Conv2d(
            in_channels=self.dim,
            out_channels=self.dim,
            kernel_size=kernel_size_left,
            stride=stride_size,
            dilation=dilation_left,
            groups=self.dim,
            bias=False
        )

        if self.rorder > 0:
            kernel_size_right: Tuple[int, int] = (int(rorder), 1)
            dilation_right: Tuple[int, int] = (int(rstride), 1)

            self.conv_right = nn.Conv2d(
                in_channels=self.dim,
                out_channels=self.dim,
                kernel_size=kernel_size_right,
                stride=stride_size,
                dilation=dilation_right,
                groups=self.dim,
                bias=False
            )
        else:
            self.conv_right = None

    def forward(self, input: torch.Tensor, cache: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        完全保持原始FSMN的前向传播逻辑
        Args:
            input: [B, T, D] 输入特征
            cache: [B, D, history_length, 1] 历史cache，与原始格式一致
        Returns:
            output: [B, T, D] 输出特征
            new_cache: [B, D, history_length, 1] 更新的cache
        """
        # 完全按照原始FSMN的维度变换逻辑
        x = torch.unsqueeze(input, 1)  # [B, T, D] -> [B, 1, T, D]
        x_per = x.permute(0, 3, 2, 1)  # [B, 1, T, D] -> [B, D, T, 1]

        # 确保cache在正确的设备上
        cache = cache.to(x_per.device)

        # 拼接cache和当前输入，完全按照原始逻辑
        y_left = torch.cat((cache, x_per), dim=2)  # [B, D, history_length + T, 1]

        # 更新cache：保留最后的(lorder-1)*lstride帧
        cache_new = y_left[:, :, -(self.lorder - 1) * self.lstride :, :]

        # 应用左侧卷积
        y_left = self.conv_left(y_left)  # [B, D, T, 1]

        # 残差连接
        out = x_per + y_left

        # 右侧卷积（如果存在）
        if self.conv_right is not None:
            y_right = F.pad(x_per, [0, 0, 0, self.rorder * self.rstride])
            y_right = y_right[:, :, self.rstride :, :]
            y_right = self.conv_right(y_right)
            out += y_right

        # 恢复原始维度
        out_per = out.permute(0, 3, 2, 1)  # [B, D, T, 1] -> [B, 1, T, D]
        output = out_per.squeeze(1)  # [B, 1, T, D] -> [B, T, D]

        return output, cache_new


class FSMNLayerFixed(nn.Module):
    def __init__(self, linear_dim: int, proj_dim: int, lorder: int, rorder: int, lstride: int, rstride: int, stack_layer: int):
        super().__init__()
        self.stack_layer = stack_layer
        # 线性投影层：linear_dim -> proj_dim，无bias（对应原始BasicBlock.linear）
        self.linear = LinearTransformFixed(linear_dim, proj_dim)
        self.fsmn_block = FSMNBlockFixed(
            input_dim=proj_dim,
            output_dim=proj_dim,
            lorder=lorder,
            rorder=rorder,
            lstride=lstride,
            rstride=rstride
        )
        # 仿射变换：proj_dim -> linear_dim，有bias+ReLU
        self.affine = AffineTransformFixed(proj_dim, linear_dim)
        # 额外的ReLU层
        self.relu = RectifiedLinearFixed(linear_dim, linear_dim)

    def forward(self, x: torch.Tensor, cache: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        完全按照原始BasicBlock的逻辑：linear -> fsmn_block -> affine -> relu
        Args:
            x: [B, T, linear_dim] 输入特征
            cache: [B, proj_dim, history_length, 1] 层cache（注意：cache维度是proj_dim）
        Returns:
            output: [B, T, linear_dim] 输出特征
            new_cache: [B, proj_dim, history_length, 1] 更新的cache
        """
        # 步骤1：线性投影 linear_dim -> proj_dim
        x = self.linear(x)  # [B, T, proj_dim]

        # 步骤2：FSMN记忆块处理（在proj_dim空间）
        x, new_cache = self.fsmn_block(x, cache)  # [B, T, proj_dim]

        # 步骤3：仿射变换 proj_dim -> linear_dim
        x = self.affine(x)  # [B, T, linear_dim]

        # 步骤4：ReLU激活
        x = self.relu(x)  # [B, T, linear_dim]

        return x, new_cache


@tables.register("encoder_classes", "FSMNFixedCache")
class FSMNFixedCache(nn.Module):

    def __init__(
        self,
        input_dim: int = 400,
        input_affine_dim: int = 140,
        linear_dim: int = 250,
        proj_dim: int = 128,
        lorder: int = 20,
        rorder: int = 0,
        lstride: int = 1,
        rstride: int = 1,
        output_affine_dim: int = 140,
        output_dim: int = 248,
        fsmn_layers: int = 4,
        use_softmax: bool = True,
    ):
        super().__init__()

        # 保存参数用于cache初始化
        self.proj_dim = proj_dim
        self.lorder = lorder
        self.fsmn_layers = fsmn_layers
        self.use_softmax = use_softmax

        # 输入层
        self.in_linear1 = AffineTransformFixed(input_dim, input_affine_dim)
        self.in_linear2 = AffineTransformFixed(input_affine_dim, linear_dim)

        # 固定四层FSMN
        self.fsmn_layer_0 = FSMNLayerFixed(linear_dim, proj_dim, lorder, rorder, lstride, rstride, 0)
        self.fsmn_layer_1 = FSMNLayerFixed(linear_dim, proj_dim, lorder, rorder, lstride, rstride, 1)
        self.fsmn_layer_2 = FSMNLayerFixed(linear_dim, proj_dim, lorder, rorder, lstride, rstride, 2)
        self.fsmn_layer_3 = FSMNLayerFixed(linear_dim, proj_dim, lorder, rorder, lstride, rstride, 3)

        # 输出层
        self.out_linear1 = AffineTransformFixed(linear_dim, output_affine_dim)
        self.out_linear2 = AffineTransformFixed(output_affine_dim, output_dim)

        # 激活函数
        if use_softmax:
            self.softmax = nn.Softmax(dim=-1)

    def forward(
        self,
        input: torch.Tensor,
        cache_0: torch.Tensor,
        cache_1: torch.Tensor,
        cache_2: torch.Tensor,
        cache_3: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        固定四个cache参数的前向传播
        Args:
            input: [B, T, input_dim] 输入特征
            cache_0: [B, proj_dim, history_length, 1] 第0层cache
            cache_1: [B, proj_dim, history_length, 1] 第1层cache
            cache_2: [B, proj_dim, history_length, 1] 第2层cache
            cache_3: [B, proj_dim, history_length, 1] 第3层cache
        Returns:
            output: [B, T, output_dim] 输出特征
            new_cache_0: [B, proj_dim, history_length, 1] 更新的第0层cache
            new_cache_1: [B, proj_dim, history_length, 1] 更新的第1层cache
            new_cache_2: [B, proj_dim, history_length, 1] 更新的第2层cache
            new_cache_3: [B, proj_dim, history_length, 1] 更新的第3层cache
        """
        # 输入层处理
        x = self.in_linear1(input)  # [B, T, input_affine_dim]
        x = self.in_linear2(x)      # [B, T, linear_dim]

        # 逐层处理FSMN，每层都有独立的cache
        x, new_cache_0 = self.fsmn_layer_0(x, cache_0)
        x, new_cache_1 = self.fsmn_layer_1(x, cache_1)
        x, new_cache_2 = self.fsmn_layer_2(x, cache_2)
        x, new_cache_3 = self.fsmn_layer_3(x, cache_3)

        # 输出层处理
        x = self.out_linear1(x)  # [B, T, output_affine_dim]
        x = self.out_linear2(x)  # [B, T, output_dim]

        # 应用softmax
        if self.use_softmax:
            x = self.softmax(x)

        return x, new_cache_0, new_cache_1, new_cache_2, new_cache_3

    def init_cache(self, batch_size=1, device='cpu'):
        """
        初始化四个cache张量，修复为正确的4维形状
        Returns:
            tuple: (cache_0, cache_1, cache_2, cache_3)
        """
        history_length = (self.lorder - 1)  # 历史长度
        cache_shape = (batch_size, self.proj_dim, history_length, 1)  # 修复：4维形状

        cache_0 = torch.zeros(cache_shape, device=device, dtype=torch.float32)
        cache_1 = torch.zeros(cache_shape, device=device, dtype=torch.float32)
        cache_2 = torch.zeros(cache_shape, device=device, dtype=torch.float32)
        cache_3 = torch.zeros(cache_shape, device=device, dtype=torch.float32)

        return cache_0, cache_1, cache_2, cache_3


class FSMNFixedCacheExport(nn.Module):
    """
    专门用于ONNX导出的FSMN模型包装器
    提供更好的ONNX兼容性和导出支持
    """
    def __init__(self, model: FSMNFixedCache):
        super().__init__()
        self.model = model

    def forward(
        self,
        input: torch.Tensor,
        cache_0: torch.Tensor,
        cache_1: torch.Tensor,
        cache_2: torch.Tensor,
        cache_3: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """ONNX导出专用的前向传播"""
        return self.model(input, cache_0, cache_1, cache_2, cache_3)

        #return input, cache_0, cache_1, cache_2, cache_3


def copy_weights_from_original_fsmn(original_model, fixed_cache_model):
    """
    从原始FSMN模型复制权重到固定cache模型
    Args:
        original_model: 原始FSMN模型实例
        fixed_cache_model: 固定cache的FSMN模型实例
    """
    print("开始复制权重...")

    # 获取两个模型的state_dict
    orig_state = original_model.state_dict()
    fixed_state = fixed_cache_model.state_dict()

    # 权重映射规则
    weight_mapping = {
        # 输入层映射
        'in_linear1.linear.weight': 'in_linear1.linear.weight',
        'in_linear1.linear.bias': 'in_linear1.linear.bias',
        'in_linear2.linear.weight': 'in_linear2.linear.weight',
        'in_linear2.linear.bias': 'in_linear2.linear.bias',

        # 输出层映射
        'out_linear1.linear.weight': 'out_linear1.linear.weight',
        'out_linear1.linear.bias': 'out_linear1.linear.bias',
        'out_linear2.linear.weight': 'out_linear2.linear.weight',
    }

    # FSMN层映射（4层）
    for i in range(4):
        # 原始模型使用fsmn列表，固定cache模型使用独立层
        orig_prefix = f'fsmn.{i}'
        fixed_prefix = f'fsmn_layer_{i}'

        weight_mapping.update({
            f'{orig_prefix}.linear.linear.weight': f'{fixed_prefix}.linear.linear.weight',
            f'{orig_prefix}.fsmn_block.conv_left.weight': f'{fixed_prefix}.fsmn_block.conv_left.weight',  # 修复：使用正确的名称
            f'{orig_prefix}.affine.linear.weight': f'{fixed_prefix}.affine.linear.weight',
            f'{orig_prefix}.affine.linear.bias': f'{fixed_prefix}.affine.linear.bias',
        })

    # 执行权重复制
    copied_count = 0
    failed_count = 0

    for orig_key, fixed_key in weight_mapping.items():
        if orig_key in orig_state and fixed_key in fixed_state:
            orig_weight = orig_state[orig_key]
            fixed_weight = fixed_state[fixed_key]

            if orig_weight.shape == fixed_weight.shape:
                # 直接复制
                fixed_state[fixed_key] = orig_weight.clone()
                print(f"  {orig_key} -> {fixed_key} (形状: {orig_weight.shape})")
                copied_count += 1
            else:
                print(f"  形状不匹配: {orig_key} {orig_weight.shape} -> {fixed_key} {fixed_weight.shape}")
                failed_count += 1
        else:
            if orig_key not in orig_state:
                print(f"  原始模型中未找到: {orig_key}")
            if fixed_key not in fixed_state:
                print(f"  固定cache模型中未找到: {fixed_key}")
            failed_count += 1

    # 加载更新后的权重
    fixed_cache_model.load_state_dict(fixed_state)

    print(f"\n权重复制完成:")
    print(f"  成功复制: {copied_count} 个")
    print(f"  复制失败: {failed_count} 个")
    print(f"  成功率: {copied_count/(copied_count+failed_count)*100:.1f}%")

    return copied_count > 0


def export_fixed_cache_onnx(model, output_path, opset_version=11):
    """
    导出固定cache的ONNX模型
    Args:
        model: FSMNFixedCache模型实例
        output_path: 输出路径
        opset_version: ONNX操作集版本
    """
    print(f"导出固定cache ONNX模型到: {output_path}")

    # 创建导出包装器
    export_model = FSMNFixedCacheExport(model)
    export_model.eval()

    # 准备输入
    batch_size = 1
    seq_len = 400
    input_dim = 400

    dummy_input = torch.randn(batch_size, seq_len, input_dim)
    cache_0, cache_1, cache_2, cache_3 = model.init_cache(batch_size)

    # 定义输入输出名称
    input_names = ['input', 'cache_0', 'cache_1', 'cache_2', 'cache_3']
    output_names = ['output', 'new_cache_0', 'new_cache_1', 'new_cache_2', 'new_cache_3']

    # 定义动态轴
    dynamic_axes = {
        'input': {0: 'batch_size', 1: 'sequence_length'},
        'output': {0: 'batch_size', 1: 'sequence_length'},
        'cache_0': {0: 'batch_size'},
        'cache_1': {0: 'batch_size'},
        'cache_2': {0: 'batch_size'},
        'cache_3': {0: 'batch_size'},
        'new_cache_0': {0: 'batch_size'},
        'new_cache_1': {0: 'batch_size'},
        'new_cache_2': {0: 'batch_size'},
        'new_cache_3': {0: 'batch_size'},
    }

    # 执行ONNX导出
    torch.onnx.export(
        export_model,
        (dummy_input, cache_0, cache_1, cache_2, cache_3),
        output_path,
        export_params=True,
        opset_version=opset_version,
        do_constant_folding=True,
        input_names=input_names,
        output_names=output_names,
        dynamic_axes=dynamic_axes,
        verbose=False
    )

    print("ONNX导出完成")
    return output_path


