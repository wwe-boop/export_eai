#!/usr/bin/env python3
"""
比较原始PyTorch模型和量化ONNX模型
支持多种模型对比和详细的精度分析
"""

import os
import sys
import torch
import torch.nn as nn
import numpy as np
import onnxruntime as ort
import argparse
import yaml
from typing import List, Dict, Tuple

# 添加项目路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def create_test_features(num_samples: int = 5) -> List[torch.Tensor]:
    """创建测试特征"""
    features = []
    for i in range(num_samples):
        if i % 3 == 0:
            feature = torch.randn(400, 400) * 0.1
        elif i % 3 == 1:
            feature = torch.rand(400, 400) * 0.2 - 0.1
        else:
            feature = torch.randn(400, 400) * 0.05 + torch.sin(
                torch.arange(400).float().unsqueeze(1) * 0.1) * 0.02
        features.append(feature)
    return features

def calculate_cosine_similarity(tensor1: torch.Tensor, tensor2: torch.Tensor) -> float:
    """计算余弦相似度"""
    if tensor1.dim() > 2:
        tensor1 = tensor1.reshape(tensor1.size(0), -1)
    if tensor2.dim() > 2:
        tensor2 = tensor2.reshape(tensor2.size(0), -1)
    
    return torch.nn.functional.cosine_similarity(tensor1, tensor2).mean().item()

def analyze_tensor_statistics(tensor: torch.Tensor, name: str = "") -> Dict:
    """分析张量统计信息"""
    return {
        "name": name,
        "shape": list(tensor.shape),
        "dtype": str(tensor.dtype),
        "min": float(tensor.min()),
        "max": float(tensor.max()),
        "mean": float(tensor.mean()),
        "std": float(tensor.std()),
        "zeros_percentage": float((tensor == 0).sum() / tensor.numel() * 100),
        "near_zeros_percentage": float((torch.abs(tensor) < 1e-6).sum() / tensor.numel() * 100)
    }

def compare_pytorch_vs_onnx(pytorch_model, onnx_path: str, features: List[torch.Tensor]):
    """比较PyTorch模型和ONNX模型的输出"""
    print("=== PyTorch模型 vs ONNX模型精度对比 ===")
    
    # 加载ONNX模型
    try:
        session = ort.InferenceSession(onnx_path, providers=['CPUExecutionProvider'])
        input_names = [inp.name for inp in session.get_inputs()]
        print(f"ONNX模型输入名称: {input_names}")
    except Exception as e:
        print(f"加载ONNX模型失败: {e}")
        return
    
    pytorch_outputs = []
    onnx_outputs = []
    cosine_similarities = []
    
    # 初始化cache
    batch_size = 1
    cache_0 = torch.zeros(batch_size, 128, 19, 1)
    cache_1 = torch.zeros(batch_size, 128, 19, 1)
    cache_2 = torch.zeros(batch_size, 128, 19, 1)
    cache_3 = torch.zeros(batch_size, 128, 19, 1)
    
    pytorch_model.eval()
    
    for i, feat in enumerate(features):
        print(f"\n处理样本 {i+1}/{len(features)}")
        
        feat_input = feat.unsqueeze(0)  # [1, 400, 400]
        
        # PyTorch模型推理
        with torch.no_grad():
            pt_output, pt_cache_0, pt_cache_1, pt_cache_2, pt_cache_3 = pytorch_model(
                feat_input, cache_0, cache_1, cache_2, cache_3
            )
            pytorch_outputs.append(pt_output)
        
        # ONNX模型推理
        onnx_inputs = {
            input_names[0]: feat_input.numpy(),
            input_names[1]: cache_0.numpy(),
            input_names[2]: cache_1.numpy(),
            input_names[3]: cache_2.numpy(),
            input_names[4]: cache_3.numpy()
        }
        
        onnx_result = session.run(None, onnx_inputs)
        onnx_output = torch.tensor(onnx_result[0])
        onnx_outputs.append(onnx_output)
        
        # 计算相似度
        cosine_sim = calculate_cosine_similarity(pt_output, onnx_output)
        cosine_similarities.append(cosine_sim)
        
        # 分析当前样本
        pt_stats = analyze_tensor_statistics(pt_output, "PyTorch输出")
        onnx_stats = analyze_tensor_statistics(onnx_output, "ONNX输出")
        
        print(f"PyTorch输出范围: [{pt_stats['min']:.6f}, {pt_stats['max']:.6f}]")
        print(f"ONNX输出范围: [{onnx_stats['min']:.6f}, {onnx_stats['max']:.6f}]")
        print(f"余弦相似度: {cosine_sim:.6f}")
        
        # 更新cache（使用PyTorch模型的cache）
        cache_0, cache_1, cache_2, cache_3 = pt_cache_0, pt_cache_1, pt_cache_2, pt_cache_3
    
    # 总体分析
    print(f"\n=== 总体分析结果 ===")
    
    # 合并所有输出
    pt_all = torch.cat(pytorch_outputs, dim=0)
    onnx_all = torch.cat(onnx_outputs, dim=0)
    
    # 计算误差指标
    mse = torch.mean((pt_all - onnx_all) ** 2).item()
    mae = torch.mean(torch.abs(pt_all - onnx_all)).item()
    
    # 相对误差
    abs_pt = torch.abs(pt_all)
    mask = abs_pt > 1e-6
    if mask.sum() > 0:
        rel_error = torch.mean(torch.abs(pt_all[mask] - onnx_all[mask]) / abs_pt[mask]).item()
    else:
        rel_error = 0.0
    
    # 整体余弦相似度
    overall_cosine = calculate_cosine_similarity(pt_all, onnx_all)
    
    print(f"误差指标:")
    print(f"  均方误差 (MSE): {mse:.8f}")
    print(f"  平均绝对误差 (MAE): {mae:.8f}")
    print(f"  相对误差: {rel_error*100:.2f}%")
    print(f"  平均余弦相似度: {np.mean(cosine_similarities):.6f}")
    print(f"  最小余弦相似度: {np.min(cosine_similarities):.6f}")
    print(f"  最大余弦相似度: {np.max(cosine_similarities):.6f}")
    print(f"  整体余弦相似度: {overall_cosine:.6f}")
    
    print(f"\n数值范围:")
    print(f"  PyTorch模型: [{pt_all.min():.6f}, {pt_all.max():.6f}]")
    print(f"  ONNX模型: [{onnx_all.min():.6f}, {onnx_all.max():.6f}]")
    
    # 质量评估
    print(f"\n量化质量评估:")
    if rel_error < 0.01 and overall_cosine > 0.99:
        print("  质量: 优秀")
        print("  - 相对误差 < 1%")
        print("  - 余弦相似度 > 0.99")
    elif rel_error < 0.05 and overall_cosine > 0.95:
        print("  质量: 良好")
        print("  - 相对误差 < 5%")
        print("  - 余弦相似度 > 0.95")
    else:
        print("  质量: 一般")
        print("  - 相对误差 > 5% 或 余弦相似度 < 0.95")
        print("  - 建议检查量化参数配置")

def main():
    """主函数"""
    print("比较我们自己的PyTorch模型和量化ONNX模型")
    
    try:
        # 创建PyTorch模型
        from models.fsmn_vad_streaming.encoder_fixed_cache import FSMNFixedCache
        
        pytorch_model = FSMNFixedCache(
            input_dim=400,
            input_affine_dim=140,
            linear_dim=250,
            proj_dim=128,
            lorder=20,
            output_affine_dim=140,
            output_dim=248,
            fsmn_layers=4,
            use_softmax=True
        )

        # 加载预训练权重
        model_path = "fsmn_model/model.pt"
        if os.path.exists(model_path):
            print(f"加载预训练权重: {model_path}")
            checkpoint = torch.load(model_path, map_location='cpu')
            if isinstance(checkpoint, dict):
                state_dict = checkpoint.get('model', checkpoint.get('state_dict', checkpoint))
            else:
                state_dict = checkpoint

            # 使用export_onnx.py中的权重复制函数
            from export_onnx import copy_weights_from_original
            copy_weights_from_original(state_dict, pytorch_model)
            print("权重加载完成")

        pytorch_model.eval()
        print("PyTorch模型创建成功")
        
        # 使用与export_onnx.py相同的校准数据进行比较
        print("使用真实音频校准数据进行比较...")
        from requantize_model import load_real_audio_calibration_data
        features = load_real_audio_calibration_data("fsmn_model/example", 5)
        print("真实音频特征加载完成")
        
        # 比较准备转EAI的ONNX模型
        onnx_models = [
            ("准备转EAI的量化ONNX模型", "test_perfect_export/quantized_model_fixed.onnx"),
            ("原始量化ONNX模型(未修复名称)", "test_perfect_export/quantized_model.onnx")
        ]
        
        for model_name, onnx_path in onnx_models:
            if os.path.exists(onnx_path):
                print(f"\n{'='*60}")
                print(f"比较 {model_name}: {onnx_path}")
                print('='*60)
                compare_pytorch_vs_onnx(pytorch_model, onnx_path, features)
            else:
                print(f"\n模型文件不存在: {onnx_path}")
        
    except Exception as e:
        print(f"比较过程出错: {e}")
        import traceback
        print(traceback.format_exc())

if __name__ == "__main__":
    main()
