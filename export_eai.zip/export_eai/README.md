# FSMNFixedCache EAI 导出工具

自动检测FSMNFixedCache模型并生成EAI兼容的量化文件。

## 使用方法

```bash
python export_onnx.py --quantize --audio-dir test_audio --calib-samples 2 --output-dir output
```

## 自动功能

1. **模型类型检测**: 自动识别FSMNFixedCache模型
2. **专用配置生成**: 为FSMNFixedCache生成专门的量化配置
3. **编码文件增强**: 自动补充缺失的量化信息
4. **ONNX模型修复**: 自动修复输入输出名称

## 生成文件

- `quantized_model.onnx` - 量化ONNX模型
- `quantized_model_fixed.onnx` - 修复后的ONNX模型
- `quantized_model_eai_enhanced_eai.encodings` - 增强编码文件（推荐）
- `aimet_eai_config_fsmnfixedcache.json` - FSMNFixedCache专用配置

## EAI构建命令

```bash
/path/to/eai_builder --onnx output/quantized_model_fixed.onnx \
                     --quant_json output/quantized_model_eai_enhanced_eai.encodings \
                     --output output/vad_model.eai \
                     --enable_enpu_ver v6 \
                     --enable_hw_cfg 1
```

## 解决的问题

- 层名结构差异 (fsmn.{i} -> fsmn_layer_{i})
- AIMET量化配置无法正确匹配层名
- 缺少cache和output量化信息
- 条件操作符问题
- ONNX模型输入输出名称问题
