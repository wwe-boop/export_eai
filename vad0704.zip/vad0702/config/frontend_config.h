/**
 * @file frontend_config.h
 * @brief 前端处理配置参数定义
 * @details 定义前端处理的所有配置参数和常量
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#ifndef FRONTEND_CONFIG_H
#define FRONTEND_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

// 音频参数定义
#define SAMPLE_RATE             16000   // 采样率
#define FRAME_LENGTH_MS         25      // 帧长(ms)
#define FRAME_SHIFT_MS         10      // 帧移(ms)
#define N_MELS                 80      // Mel滤波器数
#define FRAME_LENGTH           (SAMPLE_RATE * FRAME_LENGTH_MS / 1000)  // 帧长(采样点)
#define FRAME_SHIFT           (SAMPLE_RATE * FRAME_SHIFT_MS / 1000)   // 帧移(采样点)
#define N_FFT                 400     // FFT点数
#define N_FFT_OUT             (N_FFT / 2 + 1)  // FFT输出长度
#define MIN_FREQ              20.0    // 最小频率(Hz)
#define MAX_FREQ              8000.0  // 最大频率(Hz)
#define LFR_M                 5       // LFR参数m
#define LFR_N                 1       // LFR参数n

// 处理参数定义
#define PREEMPH_COEFF         0.97f   // 预加重系数
#define MAX_LINE_LENGTH       8192    // 最大行长度
#define MAX_MEANS_VARS        512     // 最大均值方差数量
#define EPSILON               1.1920928955078125e-07f  // 浮点数精度

/**
 * @brief 前端处理配置结构体
 */
typedef struct {
    int fs;                 /**< 采样率 */
    int frame_length;       /**< 帧长（采样点数） */
    int frame_shift;        /**< 帧移（采样点数） */
    int n_mels;            /**< Mel滤波器组数量 */
    int n_fft;             /**< FFT点数 */
    char window[32];       /**< 窗函数类型 */
    int lfr_m;             /**< LFR合并帧数 */
    int lfr_n;             /**< LFR跳帧数 */
    float fmin;            /**< 最小频率（Hz） */
    float fmax;            /**< 最大频率（Hz） */
    float dither;          /**< 抖动系数 */
    int snip_edges;        /**< 是否裁剪边缘 */
} FrontendConfig;

/**
 * @brief 前端处理通道结构体
 */
typedef struct {
    FrontendConfig config; /**< 配置参数 */
} FrontendChannel;

#ifdef __cplusplus
}
#endif

#endif // FRONTEND_CONFIG_H
