import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import os

def compare_outputs():
    """
    加载C和Python的输出，并计算余弦相似度。
    """
    repo_root = '/local/vad0702'
    
    c_output_path = os.path.join(repo_root, 'build/c_frontend_output.txt')
    py_output_path = os.path.join(repo_root, 'python/ref_result/py_frontend_output.npy')

    # 1. 加载数据
    try:
        c_data = np.loadtxt(c_output_path)
        print(f"Successfully loaded C output from: {c_output_path}")
        print(f"C data shape: {c_data.shape}")
    except Exception as e:
        print(f"Error loading C output from {c_output_path}: {e}")
        return

    try:
        py_data = np.load(py_output_path)
        print(f"Successfully loaded Python output from: {py_output_path}")
        print(f"Python data shape: {py_data.shape}")
    except Exception as e:
        print(f"Error loading Python output from {py_output_path}: {e}")
        return

    # 2. 展平为一维向量
    c_vector = c_data.flatten()
    py_vector = py_data.flatten()
    
    # 3. 计算余弦相似度
    # Scikit-learn的cosine_similarity需要2D输入
    similarity = cosine_similarity(c_vector.reshape(1, -1), py_vector.reshape(1, -1))
    
    # 4. 打印结果
    print(f"\nCosine Similarity: {similarity[0][0]}")

if __name__ == '__main__':
    compare_outputs() 