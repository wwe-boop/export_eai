#!/usr/bin/env python3
"""
导出EAI兼容的VAD编码器模型
"""

import os
import sys
import torch
import argparse
import onnx
from onnxsim import simplify
from models.fsmn_vad_streaming.encoder_eai import EAICompatibleFSMN

# 导入AIMET库
try:
    from aimet_torch.quantsim import QuantizationSimModel
    from aimet_common.defs import QuantScheme
    from aimet_torch.cross_layer_equalization import equalize_model
    from aimet_torch.meta.connectedgraph import ConnectedGraph
    # 设置AIMET编码版本以解决兼容性问题
    from aimet_common import quantsim
    quantsim.encoding_version = "0.6.1"
    
    # 添加数学不变量类型
    ConnectedGraph.math_invariant_types.add('zeros')
    ConnectedGraph.math_invariant_types.add('Concat')
    ConnectedGraph.math_invariant_types.add('Add')
    
    AIMET_AVAILABLE = True
except ImportError:
    print("警告: AIMET库未安装，无法进行量化")
    AIMET_AVAILABLE = False

def copy_weights_from_original_to_eai(original_state_dict, eai_model):
    """
    将原始FSMN模型的权重复制到EAI兼容模型
    
    Args:
        original_state_dict: 原始模型的state_dict
        eai_model: EAI兼容模型
    """
    
    # 获取EAI模型的state_dict
    eai_state_dict = eai_model.state_dict()
    
    # 权重映射规则
    weight_mapping = {}
    
    # 映射输入层
    weight_mapping['encoder.in_linear1.linear.weight'] = 'in_linear1.linear.weight'
    weight_mapping['encoder.in_linear1.linear.bias'] = 'in_linear1.linear.bias'
    weight_mapping['encoder.in_linear2.linear.weight'] = 'in_linear2.linear.weight'
    weight_mapping['encoder.in_linear2.linear.bias'] = 'in_linear2.linear.bias'
    
    # 映射FSMN层
    for i in range(4):  # 假设有4层FSMN
        # linear层
        weight_mapping[f'encoder.fsmn.{i}.linear.linear.weight'] = f'fsmn.layers.{i}.linear.weight'
        # FSMN的conv_left对应memory_block
        weight_mapping[f'encoder.fsmn.{i}.fsmn_block.conv_left.weight'] = f'fsmn.layers.{i}.memory_block.weight'
        # affine层
        weight_mapping[f'encoder.fsmn.{i}.affine.linear.weight'] = f'fsmn.layers.{i}.affine.weight'
        weight_mapping[f'encoder.fsmn.{i}.affine.linear.bias'] = f'fsmn.layers.{i}.affine.bias'
    
    # 映射输出层
    weight_mapping['encoder.out_linear1.linear.weight'] = 'out_linear1.linear.weight'
    weight_mapping['encoder.out_linear1.linear.bias'] = 'out_linear1.linear.bias'
    weight_mapping['encoder.out_linear2.linear.weight'] = 'out_linear2.linear.weight'
    weight_mapping['encoder.out_linear2.linear.bias'] = 'out_linear2.linear.bias'
    
    # 执行权重复制
    copied_count = 0
    for original_key, eai_key in weight_mapping.items():
        if original_key in original_state_dict and eai_key in eai_state_dict:
            original_weight = original_state_dict[original_key]
            eai_weight = eai_state_dict[eai_key]
            
            # 检查形状是否匹配
            if original_weight.shape == eai_weight.shape:
                eai_state_dict[eai_key] = original_weight.clone()
                copied_count += 1
                print(f"   {original_key} -> {eai_key} (形状: {original_weight.shape})")
            elif 'memory_block' in eai_key and len(original_weight.shape) == 4 and len(eai_weight.shape) == 3:
                # 特殊处理卷积权重：从[C, 1, K, 1]转换为[C, 1, K]
                if (original_weight.shape[0] == eai_weight.shape[0] and 
                    original_weight.shape[1] == eai_weight.shape[1] and
                    original_weight.shape[2] == eai_weight.shape[2] and
                    original_weight.shape[3] == 1):
                    converted_weight = original_weight.squeeze(-1) 
                    eai_state_dict[eai_key] = converted_weight.clone()
                    copied_count += 1
                    print(f"   {original_key} -> {eai_key} (形状转换: {original_weight.shape} -> {converted_weight.shape})")
                else:
                    print(f"   卷积形状不匹配: {original_key} {original_weight.shape} -> {eai_key} {eai_weight.shape}")
            else:
                print(f"   形状不匹配: {original_key} {original_weight.shape} -> {eai_key} {eai_weight.shape}")
        else:
            if original_key not in original_state_dict:
                print(f"   原始模型中未找到: {original_key}")
            if eai_key not in eai_state_dict:
                print(f"   EAI模型中未找到: {eai_key}")
    
    # 特殊处理: 如果线性层缺少bias，添加零偏置
    for eai_key in eai_state_dict.keys():
        if eai_key.endswith('.linear.bias') and eai_key.startswith('fsmn.layers.'):
            # 检查对应的线性层是否有bias
            layer_prefix = eai_key.replace('.linear.bias', '.linear.weight')
            if layer_prefix in eai_state_dict:
                weight_shape = eai_state_dict[layer_prefix].shape
                if weight_shape[0] != eai_state_dict[eai_key].shape[0]:
                    # 重新初始化为正确大小的零向量
                    eai_state_dict[eai_key] = torch.zeros(weight_shape[0])
                    print(f"  + 初始化零偏置: {eai_key} (形状: {weight_shape[0]})")
    
    # 加载修改后的权重
    eai_model.load_state_dict(eai_state_dict)
    
    print(f"权重复制完成，成功复制 {copied_count} 个权重")
    return copied_count > 0

def parse_args():
    parser = argparse.ArgumentParser(description='导出EAI兼容的VAD编码器模型')
    parser.add_argument('--config-file', type=str, default='models/fsmn_vad_streaming/template.yaml',
                        help='模型配置文件')
    parser.add_argument('--model-path', type=str, default='fsmn_model/model.pt',
                        help='预训练模型(.pt)文件路径')
    parser.add_argument('--audio-dir', type=str, default='test_audio',
                        help='包含音频文件的目录路径(用于量化评估)')
    parser.add_argument('--audio-files', type=str, nargs='+',
                        help='音频文件路径列表(用于量化评估)')
    parser.add_argument('--calib-samples', type=int, default=50,
                        help='用于量化校准的音频样本数量')
    parser.add_argument('--eval-samples', type=int, default=100,
                        help='用于量化评估的音频样本数量')
    parser.add_argument('--output-dir', type=str, default='eai_model',
                        help='输出目录')
    parser.add_argument('--opset-version', type=int, default=11,
                        help='ONNX操作集版本')
    parser.add_argument('--config-json', type=str, default='config_for_eai.json',
                        help='AIMET量化配置文件')
    parser.add_argument('--param-bits', type=int, default=8,
                        help='参数位宽')
    parser.add_argument('--output-bits', type=int, default=16,
                        help='激活值位宽')
    parser.add_argument('--skip-evaluation', action='store_true',
                        help='跳过量化评估步骤')
    parser.add_argument('--use-softmax', action='store_true', default=True,
                        help='在模型输出中使用softmax')
    parser.add_argument('--export-logits', action='store_true',
                        help='同时导出logits版本(无softmax)用于量化')
    return parser.parse_args()

def load_config(config_file):
    """加载YAML配置文件"""
    import yaml
    with open(config_file, 'r') as f:
        config = yaml.safe_load(f)
    return config

def get_audio_files(args):
    """获取音频文件列表"""
    audio_files = []
    
    # 从目录中获取音频文件
    if args.audio_dir and os.path.exists(args.audio_dir):
        import glob
        audio_extensions = ['*.wav', '*.mp3', '*.flac', '*.m4a', '*.aac']
        for ext in audio_extensions:
            audio_files.extend(glob.glob(os.path.join(args.audio_dir, ext)))
            audio_files.extend(glob.glob(os.path.join(args.audio_dir, '**', ext), recursive=True))
    
    # 从命令行参数获取音频文件
    if args.audio_files:
        for file_path in args.audio_files:
            if os.path.exists(file_path):
                audio_files.append(file_path)
            else:
                print(f"警告: 音频文件不存在: {file_path}")
    
    # 去重并限制数量
    audio_files = list(set(audio_files))
    if audio_files:
        print(f"找到 {len(audio_files)} 个音频文件")
        return audio_files
    else:
        print("警告: 未找到音频文件，将使用随机数据进行评估")
        return []

def load_audio(file_path, sample_rate=16000):
    """加载音频文件"""
    try:
        import librosa
        audio, sr = librosa.load(file_path, sr=sample_rate)
        return torch.tensor(audio, dtype=torch.float32)
    except Exception as e:
        print(f"加载音频文件失败 {file_path}: {e}")
        return None

def preprocess_audio_batch(audio_files, frontend, sample_rate=16000, max_duration=30):
    """批量预处理音频文件"""
    features = []
    feature_lengths = []
    
    for file_path in audio_files:
        audio = load_audio(file_path, sample_rate)
        if audio is None:
            continue
            
        # 限制音频长度
        max_samples = int(max_duration * sample_rate)
        if len(audio) > max_samples:
            audio = audio[:max_samples]
        
        # 添加batch维度
        audio = audio.unsqueeze(0)
        audio_length = torch.tensor([len(audio[0])])
        
        try:
            # 使用前端处理器提取特征
            feats, feats_lens = frontend(audio, audio_length)
            if feats.size(1) > 0:  # 确保有有效特征
                features.append(feats[0])  # 移除batch维度
                feature_lengths.append(feats_lens[0])
        except Exception as e:
            print(f"特征提取失败 {file_path}: {e}")
            continue
    
    if not features:
        print("警告: 没有成功提取的特征，使用随机数据")
        # 生成随机特征数据
        dummy_feat = torch.randn(1, 400, 400)
        features.append(dummy_feat[0])
        feature_lengths.append(torch.tensor(400))
    
    return features, feature_lengths

def evaluate_model_accuracy(model, features, feature_lengths, desc="模型"):
    """评估模型精度"""
    model.eval()
    outputs = []
    
    print(f"评估{desc}...")
    with torch.no_grad():
        for feat, feat_len in zip(features, feature_lengths):
            # 调整特征形状以匹配模型输入
            if feat.dim() == 2:
                # 确保特征形状为 [batch, time, feature_dim]
                if feat.size(1) == 400:  # [time, feature_dim] -> [batch, time, feature_dim]
                    feat_input = feat.unsqueeze(0)
                else:  # [feature_dim, time] -> [batch, time, feature_dim]
                    feat_input = feat.transpose(0, 1).unsqueeze(0)
            else:
                feat_input = feat.unsqueeze(0)
            
            # 如果特征长度不匹配，进行调整
            target_len = 400
            if feat_input.size(1) != target_len:
                if feat_input.size(1) < target_len:
                    # 零填充
                    padding = torch.zeros(feat_input.size(0), target_len - feat_input.size(1), feat_input.size(2))
                    feat_input = torch.cat([feat_input, padding], dim=1)
                else:
                    # 截断
                    feat_input = feat_input[:, :target_len, :]
            
            try:
                output = model(feat_input)
                outputs.append(output.cpu())
            except Exception as e:
                print(f"模型推理失败: {e}")
                continue
    
    if outputs:
        # 计算一些基础统计信息
        all_outputs = torch.cat(outputs, dim=0)
        mean_output = torch.mean(all_outputs)
        std_output = torch.std(all_outputs)
        print(f"{desc}输出统计 - 均值: {mean_output:.6f}, 标准差: {std_output:.6f}")
        return all_outputs
    else:
        print(f"警告: {desc}没有有效输出")
        return None

def compare_model_outputs(original_outputs, quantized_outputs):
    """比较原始模型和量化模型的输出"""
    if original_outputs is None or quantized_outputs is None:
        print("无法比较模型输出：缺少输出数据")
        return
    
    print("\n" + "=" * 50)
    print("量化精度分析")
    print("=" * 50)
    
    # 确保输出形状匹配
    min_samples = min(original_outputs.size(0), quantized_outputs.size(0))
    orig_out = original_outputs[:min_samples]
    quant_out = quantized_outputs[:min_samples]
    
    # 计算差异
    diff = torch.abs(orig_out - quant_out)
    relative_diff = diff / (torch.abs(orig_out) + 1e-8)
    
    # 统计信息
    mse = torch.mean((orig_out - quant_out) ** 2)
    mae = torch.mean(diff)
    max_diff = torch.max(diff)
    mean_rel_diff = torch.mean(relative_diff)
    
    print(f"均方误差 (MSE): {mse:.8f}")
    print(f"平均绝对误差 (MAE): {mae:.8f}")
    print(f"最大绝对误差: {max_diff:.8f}")
    print(f"平均相对误差: {mean_rel_diff:.6f} ({mean_rel_diff*100:.2f}%)")
    
    # 相似度分析
    cosine_sim = torch.nn.functional.cosine_similarity(
        orig_out.flatten().unsqueeze(0), 
        quant_out.flatten().unsqueeze(0)
    )
    print(f"余弦相似度: {cosine_sim.item():.6f}")
    
    # 信噪比
    signal_power = torch.mean(orig_out ** 2)
    noise_power = torch.mean((orig_out - quant_out) ** 2)
    snr_db = 10 * torch.log10(signal_power / (noise_power + 1e-8))
    print(f"信噪比 (SNR): {snr_db:.2f} dB")
    
    return {
        'mse': mse.item(),
        'mae': mae.item(),
        'max_diff': max_diff.item(),
        'mean_rel_diff': mean_rel_diff.item(),
        'cosine_sim': cosine_sim.item(),
        'snr_db': snr_db.item()
    }

def export_to_onnx(model, output_path, opset_version=11):
    """导出模型为ONNX格式"""
    print(f"导出ONNX模型到: {output_path}")
    
    # 准备输入
    dummy_input = torch.randn(1, 400, 400)
    
    # 导出模型
    torch.onnx.export(
        model,
        dummy_input,
        output_path,
        export_params=True,
        opset_version=opset_version,
        do_constant_folding=True,
        input_names=['input'],
        output_names=['output'],
        dynamic_axes={
            'input': {0: 'batch_size', 1: 'sequence_length'},
            'output': {0: 'batch_size', 1: 'sequence_length'}
        }
    )
    
    # 验证模型
    onnx_model = onnx.load(output_path)
    onnx.checker.check_model(onnx_model)
    print("ONNX模型验证通过")
    
    return output_path

def simplify_onnx_model(input_path, output_path):
    """简化ONNX模型"""
    print(f"简化ONNX模型: {input_path} -> {output_path}")
    
    try:
        onnx_model = onnx.load(input_path)
        model_simp, check = simplify(onnx_model)
        
        if check:
            onnx.save(model_simp, output_path)
            print(f"简化模型保存到: {output_path}")
            return True
        else:
            print("简化失败")
            return False
    except Exception as e:
        print(f"简化模型失败: {e}")
        return False

def analyze_onnx_operators(model_path):
    """分析ONNX模型中使用的操作符"""
    print(f"\n分析ONNX模型: {model_path}")
    
    try:
        model = onnx.load(model_path)
        ops = {}
        
        for node in model.graph.node:
            op_type = node.op_type
            if op_type in ops:
                ops[op_type] += 1
            else:
                ops[op_type] = 1
        
        print("模型中使用的操作符:")
        for op, count in sorted(ops.items()):
            print(f" OP {op}, count = {count}")
        
        return ops
    except Exception as e:
        print(f"分析模型失败: {e}")
        return {}

def quantize_model(model, args, features=None, feature_lengths=None):
    """使用AIMET进行模型量化"""
    if not AIMET_AVAILABLE:
        print("错误: AIMET库未安装，无法进行量化")
        return None
    
    print("\n" + "=" * 60)
    print("使用AIMET进行模型量化")
    print("=" * 60)
    
    # 准备输入
    dummy_input = torch.randn(1, 400, 400)
    
    # 验证模型
    try:
        from aimet_torch.model_validator.model_validator import ModelValidator
        flag = ModelValidator.validate_model(model, model_input=dummy_input)
        print(f"模型验证结果: {flag}")
    except Exception as e:
        print(f"模型验证失败: {e}")
    
    # 应用交叉层均衡化
    print("应用交叉层均衡化...")
    try:
        equalize_model(model=model, input_shapes=[(1, 400, 400)])
        print("交叉层均衡化应用成功")
    except Exception as e:
        print(f"交叉层均衡化应用失败: {e}")
    
    # 创建量化模拟模型
    print("创建量化模拟模型...")
    sim = QuantizationSimModel(
        model=model,
        dummy_input=dummy_input,
        quant_scheme=QuantScheme.post_training_tf_enhanced,
        default_param_bw=args.param_bits,
        default_output_bw=args.output_bits,
        in_place=False,
        config_file=args.config_json
    )
    
    # 计算编码
    print("计算量化编码...")
    def calibration_forward_pass(sim_model, args_calib):
        """使用真实数据进行校准"""
        sim_model.eval()
        with torch.no_grad():
            if features and feature_lengths:
                print(f"使用 {len(features)} 个音频样本进行量化校准...")
                calib_samples = min(args.calib_samples, len(features))
                for i in range(calib_samples):
                    feat = features[i]
                    feat_len = feature_lengths[i]
                    
                    # 调整特征形状
                    if feat.dim() == 2:
                        if feat.size(1) == 400:
                            feat_input = feat.unsqueeze(0)
                        else:
                            feat_input = feat.transpose(0, 1).unsqueeze(0)
                    else:
                        feat_input = feat.unsqueeze(0)
                    
                    # 调整长度
                    target_len = 400
                    if feat_input.size(1) != target_len:
                        if feat_input.size(1) < target_len:
                            padding = torch.zeros(feat_input.size(0), target_len - feat_input.size(1), feat_input.size(2))
                            feat_input = torch.cat([feat_input, padding], dim=1)
                        else:
                            feat_input = feat_input[:, :target_len, :]
                    
                    try:
                        _ = sim_model(feat_input)
                    except Exception as e:
                        print(f"校准样本 {i} 失败: {e}")
                        continue
                print("使用真实音频数据校准完成")
            else:
                print("使用随机数据进行校准...")
                for i in range(10):  # 使用多个随机样本
                    random_input = torch.randn(1, 400, 400)
                    _ = sim_model(random_input)
                print("随机数据校准完成")
        return None
    
    sim.compute_encodings(calibration_forward_pass, args)
    
    # 导出量化模型
    print("导出量化模型...")
    os.makedirs(args.output_dir, exist_ok=True)
    
    # 导出ONNX模型
    dummy_input = torch.randn(1, 400, 400)  # 确保使用相同的输入尺寸
    
    # 使用正确的参数调用export
    sim.export(
        path=args.output_dir,
        filename_prefix="quantized_vad_encoder",
        dummy_input=dummy_input  # 使用dummy_input替代input_shape
    )
    
    onnx_path = os.path.join(args.output_dir, "quantized_vad_encoder.onnx")
    
    # 简化ONNX模型
    simplified_path = os.path.join(args.output_dir, "quantized_vad_encoder_simplified.onnx")
    if simplify_onnx_model(onnx_path, simplified_path):
        return simplified_path
    else:
        return onnx_path

def main():
    args = parse_args()
    
    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)
    
    # 加载配置
    config = load_config(args.config_file)
    encoder_conf = config.get('encoder_conf', {})

    # 创建EAI兼容模型
    print("创建EAI兼容模型...")
    model = EAICompatibleFSMN(
        input_dim=encoder_conf.get('input_dim', 400),
        input_affine_dim=encoder_conf.get('input_affine_dim', 140),
        linear_dim=encoder_conf.get('linear_dim', 250),
        proj_dim=encoder_conf.get('proj_dim', 128),
        lorder=encoder_conf.get('lorder', 20),
        output_affine_dim=encoder_conf.get('output_affine_dim', 140),
        output_dim=encoder_conf.get('output_dim', 248),
        num_layers=encoder_conf.get('fsmn_layers', 4),
        use_softmax=args.use_softmax
    )
    model.eval()
    
    logits_model = None
    if args.export_logits or not args.use_softmax:
        print("创建logits版本模型用于量化...")
        logits_model = EAICompatibleFSMN(
            input_dim=encoder_conf.get('input_dim', 400),
            input_affine_dim=encoder_conf.get('input_affine_dim', 140),
            linear_dim=encoder_conf.get('linear_dim', 250),
            proj_dim=encoder_conf.get('proj_dim', 128),
            lorder=encoder_conf.get('lorder', 20),
            output_affine_dim=encoder_conf.get('output_affine_dim', 140),
            output_dim=encoder_conf.get('output_dim', 248),
            num_layers=encoder_conf.get('fsmn_layers', 4),
            use_softmax=False  # 强制不使用softmax
        )
        logits_model.eval()

    # 加载预训练权重
    model_path = None
    if args.model_path and os.path.exists(args.model_path):
        model_path = args.model_path
        print(f"使用命令行指定的模型: {model_path}")
    elif 'init_param' in config:
        model_path = config['init_param']
        print(f"使用配置文件中的模型: {model_path}")
    
    if model_path:
        if model_path.endswith('.pt') or model_path.endswith('.pth'):
            # 直接加载PyTorch模型权重
            print(f"加载PyTorch模型权重: {model_path}")
            try:
                checkpoint = torch.load(model_path, map_location='cpu')
                if isinstance(checkpoint, dict):
                    # 如果是checkpoint字典，尝试获取model state_dict
                    if 'model' in checkpoint:
                        state_dict = checkpoint['model']
                    elif 'state_dict' in checkpoint:
                        state_dict = checkpoint['state_dict']
                    else:
                        state_dict = checkpoint
                else:
                    # 直接是state_dict
                    state_dict = checkpoint
                
                # 使用权重映射函数复制权重
                weight_copy_success = copy_weights_from_original_to_eai(state_dict, model)
                if weight_copy_success:
                    print("模型权重加载成功")
                else:
                    print("警告: 权重复制失败，使用随机初始化权重")
                
                # 如果有logits模型，也加载相同的权重
                if logits_model is not None:
                    weight_copy_success_logits = copy_weights_from_original_to_eai(state_dict, logits_model)
                    if weight_copy_success_logits:
                        print("logits模型权重加载成功")
                    else:
                        print("警告: logits模型权重复制失败")
            except Exception as e:
                print(f"PyTorch模型加载失败: {e}")
        else:
            # 使用funasr的加载方法
            try:
                from funasr.train_utils.load_pretrained_model import load_pretrained_model
                load_pretrained_model(
                    model=model,
                    path=model_path,
                    ignore_init_mismatch=True
                )
                print("funasr模型加载成功")
            except Exception as e:
                print(f"funasr模型加载失败: {e}")
    else:
        print("警告: 未指定预训练模型，使用随机初始化权重")

    # 测试模型
    print("测试模型...")
    dummy_input = torch.randn(1, 400, 400)
    with torch.no_grad():
        output = model(dummy_input)
        print(f"输出形状: {output.shape}")

    # 导出原始ONNX模型
    base_path = os.path.join(args.output_dir, "vad_encoder_eai")
    onnx_path = f"{base_path}.onnx"
    export_to_onnx(model, onnx_path, args.opset_version)

    # 分析原始模型
    ops = analyze_onnx_operators(onnx_path)

    simplified_path = f"{base_path}_simplified.onnx"
    if simplify_onnx_model(onnx_path, simplified_path):
        print("\n分析简化后的模型:")
        analyze_onnx_operators(simplified_path)

    # 准备音频数据用于量化评估
    features = None
    feature_lengths = None
    original_outputs = None
    quantized_outputs = None
    
    if not args.skip_evaluation:
        print("\n" + "=" * 60)
        print("准备量化评估数据")
        print("=" * 60)
        
        # 获取音频文件
        audio_files = get_audio_files(args)
        
        if audio_files:
            # 创建前端处理器
            from funasr.frontends.wav_frontend import WavFrontend
            frontend_conf = config.get('frontend_conf', {})
            frontend = WavFrontend(
                fs=frontend_conf.get('fs', 16000),
                window=frontend_conf.get('window', 'hamming'),
                n_mels=frontend_conf.get('n_mels', 80),
                frame_length=frontend_conf.get('frame_length', 25),
                frame_shift=frontend_conf.get('frame_shift', 10),
                lfr_m=frontend_conf.get('lfr_m', 5),
                lfr_n=frontend_conf.get('lfr_n', 1),
                dither=frontend_conf.get('dither', 0.0)
            )
            
            print("提取音频特征...")
            # 限制用于评估的音频数量
            eval_audio_files = audio_files[:args.eval_samples]
            features, feature_lengths = preprocess_audio_batch(
                eval_audio_files, frontend, 
                sample_rate=frontend_conf.get('fs', 16000)
            )
            
            if features:
                print(f"成功提取 {len(features)} 个音频特征")
                # 评估原始模型
                original_outputs = evaluate_model_accuracy(
                    model, features, feature_lengths, "原始模型"
                )
            else:
                print("警告: 特征提取失败")

    quantization_model = logits_model if logits_model is not None else model
    quantized_model_path = quantize_model(quantization_model, args, features, feature_lengths)
    
    if args.export_logits and logits_model is not None:
        logits_onnx_path = os.path.join(args.output_dir, "vad_encoder_logits.onnx")
        export_to_onnx(logits_model, logits_onnx_path, args.opset_version)
        
        logits_simplified_path = os.path.join(args.output_dir, "vad_encoder_logits_simplified.onnx")
        if simplify_onnx_model(logits_onnx_path, logits_simplified_path):
            analyze_onnx_operators(logits_simplified_path)

    if quantized_model_path:
        # 分析量化模型
        print("\n分析量化模型:")
        analyze_onnx_operators(quantized_model_path)
        
        # 如果有评估数据，进行量化后评估
        if not args.skip_evaluation and features and feature_lengths:
            try:
                # 加载量化后的PyTorch模型进行评估
                quantized_pth_path = os.path.join(args.output_dir, "quantized_vad_encoder.pth")
                if os.path.exists(quantized_pth_path):
                    print("\n加载量化模型进行精度评估...")
                    quantized_model = torch.load(quantized_pth_path, map_location='cpu')
                    quantized_model.eval()
                    
                    # 评估量化模型
                    quantized_outputs = evaluate_model_accuracy(
                        quantized_model, features, feature_lengths, "量化模型"
                    )
                    
                    # 比较原始模型和量化模型的输出
                    if original_outputs is not None and quantized_outputs is not None:
                        accuracy_metrics = compare_model_outputs(original_outputs, quantized_outputs)
                        
                        # 保存评估结果
                        import json
                        eval_results = {
                            'accuracy_metrics': accuracy_metrics,
                            'num_samples': len(features),
                            'model_config': {
                                'param_bits': args.param_bits,
                                'output_bits': args.output_bits,
                                'calib_samples': args.calib_samples
                            }
                        }
                        
                        eval_file = os.path.join(args.output_dir, "quantization_evaluation.json")
                        with open(eval_file, 'w') as f:
                            json.dump(eval_results, f, indent=2)
                        print(f"\n评估结果已保存到: {eval_file}")
                        
            except Exception as e:
                print(f"量化评估失败: {e}")
        
        print("\n" + "=" * 60)
        print("量化模型导出完成!")
        print("=" * 60)
        print(f"量化模型: {quantized_model_path}")
        
        # 提供EAI转换命令
        print("\nEAI转换命令示例:")
        print("-" * 40)
        # 检查文件是否存在
        encoding_file_new = os.path.join(args.output_dir, "quantized_vad_encoder_new.json")
        encoding_file_old = os.path.join(args.output_dir, "quantized_vad_encoder.encodings")

        if os.path.exists(encoding_file_new):
            encoding_file = encoding_file_new
        elif os.path.exists(encoding_file_old):
            encoding_file = encoding_file_old
        else:
            encoding_file = encoding_file_new
            print("警告: 未找到编码文件，请确保量化过程正确完成")

        print(f"/local/mnt/workspace/Qualcomm/Hexagon_SDK/6.2.0.1/addons/LPAI/eNPU6/5.7.0/eai_builder/eai_builder --onnx {quantized_model_path} \\")
        print(f"           --quant_json {encoding_file} \\")
        print(f"           --output vad_encoder_eai.eai \\")
        print(f"           --enable_enpu_ver v6 \\")
        print(f"           --enable_hw_cfg 1")
    else:
        print("\n警告: 量化失败，无法生成EAI转换命令")
        print("请确保已安装AIMET库，或使用其他量化方法")

if __name__ == "__main__":
    main()





