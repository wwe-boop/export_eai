#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
验证正确的VAD数据格式理解
248维输出: 第一维=静音概率, 语音概率=1-第一维, 阈值=0.6
"""

import numpy as np

def verify_correct_format():
    """验证正确的数据格式理解"""
    print("🔍 验证正确的VAD数据格式")
    print("=" * 80)
    print("根据提示：")
    print("- 248维输出的第一维是静音概率")
    print("- 语音概率 = 1 - 第一维")
    print("- 阈值直接是0.6")
    print()
    
    # 加载数据
    raw_path = "data/encoder_output.raw"
    meta_path = "data/encoder_output.meta"
    
    try:
        # 读取元数据
        with open(meta_path, 'r') as f:
            lines = f.readlines()
            
        # 解析shape信息
        shape_line = [line for line in lines if line.startswith('shape =')][0]
        shape_str = shape_line.split('=')[1].strip()
        shape_str = shape_str.strip('()')
        shape_parts = [int(x.strip()) for x in shape_str.split(',')]
        
        batch_size, num_frames, output_dim = shape_parts
        print(f"数据形状: {batch_size} × {num_frames} × {output_dim}")
        
        # 读取原始数据
        data = np.fromfile(raw_path, dtype=np.float32)
        data = data.reshape(batch_size, num_frames, output_dim)
        encoder_output = data[0]  # [num_frames, output_dim]
        
        print(f"编码器输出形状: {encoder_output.shape}")
        print(f"数值范围: [{encoder_output.min():.6f}, {encoder_output.max():.6f}]")
        print()
        
        # 按照正确的格式提取概率
        print("=== 正确格式提取概率 ===")
        sil_probs = encoder_output[:, 0]  # 第一维直接是静音概率
        speech_probs = 1.0 - sil_probs   # 语音概率 = 1 - 静音概率
        
        print(f"静音概率范围: [{sil_probs.min():.6f}, {sil_probs.max():.6f}]")
        print(f"语音概率范围: [{speech_probs.min():.6f}, {speech_probs.max():.6f}]")
        print(f"静音概率均值: {sil_probs.mean():.6f}")
        print(f"语音概率均值: {speech_probs.mean():.6f}")
        print()
        
        # 阈值分类
        threshold = 0.6
        speech_frames = speech_probs > threshold
        speech_count = speech_frames.sum()
        
        print(f"=== 阈值分类 (阈值={threshold}) ===")
        print(f"语音帧数: {speech_count}/{num_frames} ({speech_count/num_frames*100:.1f}%)")
        print()
        
        # 显示前20帧和关键帧
        print("前20帧详细信息:")
        for i in range(min(20, num_frames)):
            sil_prob = sil_probs[i]
            speech_prob = speech_probs[i]
            is_speech = speech_prob > threshold
            print(f"  帧{i:3d} ({i*10:4d}ms): 静音={sil_prob:.4f}, 语音={speech_prob:.4f}, "
                  f"判断={'语音' if is_speech else '静音'}")
        
        print()
        print("关键帧分析:")
        key_frames = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600]
        for frame_idx in key_frames:
            if frame_idx < num_frames:
                sil_prob = sil_probs[frame_idx]
                speech_prob = speech_probs[frame_idx]
                is_speech = speech_prob > threshold
                print(f"  帧{frame_idx:3d} ({frame_idx*10:4d}ms): 静音={sil_prob:.4f}, 语音={speech_prob:.4f}, "
                      f"判断={'语音' if is_speech else '静音'}")
        
        # 找到语音段
        print()
        print("=== 语音段检测 ===")
        if speech_count > 0:
            # 找到所有语音帧的位置
            speech_indices = np.where(speech_frames)[0]
            print(f"语音帧位置: {speech_indices[:10]}..." if len(speech_indices) > 10 else f"语音帧位置: {speech_indices}")
            
            # 简单的段合并
            segments = []
            if len(speech_indices) > 0:
                start_frame = speech_indices[0]
                end_frame = speech_indices[0]
                
                for i in range(1, len(speech_indices)):
                    if speech_indices[i] == speech_indices[i-1] + 1:
                        # 连续帧
                        end_frame = speech_indices[i]
                    else:
                        # 不连续，保存当前段
                        segments.append((start_frame, end_frame))
                        start_frame = speech_indices[i]
                        end_frame = speech_indices[i]
                
                # 保存最后一段
                segments.append((start_frame, end_frame))
            
            print(f"检测到 {len(segments)} 个原始语音段:")
            for i, (start, end) in enumerate(segments):
                start_ms = start * 10
                end_ms = (end + 1) * 10  # +1因为end是包含的
                duration_ms = end_ms - start_ms
                print(f"  段{i+1}: {start_ms}ms - {end_ms}ms (时长: {duration_ms}ms)")
        else:
            print("未检测到语音帧")
        
        print()
        print("📊 与期望结果对比:")
        print("期望: 1个语音段 [780ms, 4470ms] (时长3690ms)")
        if speech_count > 0:
            print("✅ 现在有语音检测结果了！")
        else:
            print("❌ 仍然没有检测到语音")
            
    except Exception as e:
        print(f"❌ 验证失败: {e}")

if __name__ == "__main__":
    verify_correct_format() 