#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试FunASR兼容的VAD后处理算法
基于model.py中的标准实现
"""

import numpy as np
import torch
import math

def test_funasr_postprocess():
    """测试FunASR兼容的后处理算法"""
    print("🔍 测试FunASR兼容的VAD后处理算法")
    print("=" * 80)
    
    # 1. 加载编码器输出
    ref_file = "ref_result/sa1_eai_encoder_output.npz"
    data = np.load(ref_file)
    encoder_output = data['encoder_output']  # [1, 644, 248]
    
    print(f"编码器输出形状: {encoder_output.shape}")
    
    # 2. 提取VAD logits (前2维)
    vad_logits = encoder_output[0, :, :2]  # [644, 2]
    print(f"VAD logits形状: {vad_logits.shape}")
    print(f"VAD logits范围: [{vad_logits.min():.6f}, {vad_logits.max():.6f}]")
    
    # 3. FunASR标准参数
    speech_noise_thres = 0.6  # 来自model.py第77行
    speech_2_noise_ratio = 1.0  # 来自model.py第67行
    frame_in_ms = 10  # 每帧10ms
    
    # 4. 模拟FunASR的概率计算
    print(f"\n🔍 FunASR标准概率计算")
    
    frame_states = []
    speech_probs = []
    noise_probs = []
    
    for t in range(len(vad_logits)):
        # FunASR使用的是静音概率在第0维，语音概率在第1维
        sil_score = vad_logits[t, 0]  # 静音分数
        speech_score = vad_logits[t, 1]  # 语音分数
        
        # FunASR的概率计算方式 (参考model.py第529-536行)
        # 假设这是softmax后的概率
        total_score = 1.0
        sum_score = sil_score  # 静音概率
        noise_prob = math.log(sum_score) * speech_2_noise_ratio
        
        sum_score = total_score - sil_score  # 语音概率
        speech_prob = math.log(sum_score)
        
        speech_probs.append(speech_prob)
        noise_probs.append(noise_prob)
        
        # FunASR的判断逻辑 (参考model.py第549行)
        if math.exp(speech_prob) >= math.exp(noise_prob) + speech_noise_thres:
            frame_state = 1  # 语音
        else:
            frame_state = 0  # 静音
            
        frame_states.append(frame_state)
        
        # 打印前10帧的详细信息
        if t < 10:
            print(f"帧{t:3d}: 静音分数={sil_score:.6f}, 语音分数={speech_score:.6f}")
            print(f"      静音概率={noise_prob:.6f}, 语音概率={speech_prob:.6f}")
            print(f"      exp(语音)={math.exp(speech_prob):.6f}, exp(静音)+阈值={math.exp(noise_prob) + speech_noise_thres:.6f}")
            print(f"      判断: {'语音' if frame_state == 1 else '静音'}")
    
    # 5. 统计结果
    speech_frames = sum(frame_states)
    total_frames = len(frame_states)
    speech_ratio = speech_frames / total_frames
    
    print(f"\n📊 FunASR标准算法结果:")
    print(f"语音帧数: {speech_frames}/{total_frames} ({speech_ratio*100:.1f}%)")
    
    # 6. 简单的语音段提取 (不使用复杂的状态机)
    segments = extract_simple_segments(frame_states, frame_in_ms)
    
    print(f"检测到语音段: {len(segments)}个")
    for i, (start, end) in enumerate(segments):
        duration = end - start
        print(f"  语音段{i+1}: {start}-{end}ms (时长: {duration}ms)")
    
    # 7. 与Python参考对比
    print(f"\n🔍 与参考结果对比:")
    print(f"Python参考: 1个语音段 1150-4390ms (3240ms)")
    print(f"FunASR算法: {len(segments)}个语音段")
    
    return {
        'frame_states': frame_states,
        'speech_probs': speech_probs,
        'noise_probs': noise_probs,
        'segments': segments,
        'speech_ratio': speech_ratio
    }

def extract_simple_segments(frame_states, frame_in_ms, min_duration=100):
    """简单的语音段提取"""
    segments = []
    start_frame = None
    min_frames = min_duration // frame_in_ms
    
    for i, is_speech in enumerate(frame_states):
        if is_speech and start_frame is None:
            # 语音段开始
            start_frame = i
        elif not is_speech and start_frame is not None:
            # 语音段结束
            if i - start_frame >= min_frames:
                start_ms = start_frame * frame_in_ms
                end_ms = i * frame_in_ms
                segments.append((start_ms, end_ms))
            start_frame = None
    
    # 处理最后一个语音段
    if start_frame is not None:
        if len(frame_states) - start_frame >= min_frames:
            start_ms = start_frame * frame_in_ms
            end_ms = len(frame_states) * frame_in_ms
            segments.append((start_ms, end_ms))
    
    return segments

def test_different_thresholds():
    """测试不同阈值的效果"""
    print(f"\n🔍 测试不同speech_noise_thres阈值的效果")
    
    thresholds = [0.3, 0.4, 0.5, 0.6, 0.7, 0.8]
    
    for threshold in thresholds:
        # 这里需要重新实现，但为了简化，我们先用固定的结果
        print(f"阈值{threshold}: 待实现")

if __name__ == "__main__":
    result = test_funasr_postprocess()
    test_different_thresholds()
