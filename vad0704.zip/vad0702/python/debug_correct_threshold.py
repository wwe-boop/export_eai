#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试正确的VAD阈值计算公式
"""

import numpy as np

def test_different_threshold_formulas():
    """测试不同的阈值计算公式"""
    print("🔍 测试不同的阈值计算公式")
    print("=" * 80)
    
    # 从之前的Python输出中取一些关键帧数据
    test_frames = [
        {"frame": 150, "sil_prob": 0.513582, "speech_prob": 0.486418, "expected": "语音"},
        {"frame": 200, "sil_prob": 0.545247, "speech_prob": 0.454753, "expected": "静音"},
        {"frame": 300, "sil_prob": 0.528085, "speech_prob": 0.471915, "expected": "语音"},
        {"frame": 350, "sil_prob": 0.505829, "speech_prob": 0.494171, "expected": "语音"},
    ]
    
    speech_noise_thres = 0.6
    speech_2_noise_ratio = 1.0
    
    print(f"参数: speech_noise_thres={speech_noise_thres}, speech_2_noise_ratio={speech_2_noise_ratio}")
    print()
    
    # 测试不同的公式
    formulas = [
        {
            "name": "当前公式 (错误)",
            "formula": "threshold = sil_prob * speech_2_noise_ratio + speech_noise_thres",
            "calc": lambda sil, speech: sil * speech_2_noise_ratio + speech_noise_thres
        },
        {
            "name": "FunASR标准公式",
            "formula": "threshold = speech_noise_thres",
            "calc": lambda sil, speech: speech_noise_thres
        },
        {
            "name": "基于speech_2_noise_ratio的相对阈值",
            "formula": "threshold = sil_prob * speech_2_noise_ratio",
            "calc": lambda sil, speech: sil * speech_2_noise_ratio
        },
        {
            "name": "修正版公式1",
            "formula": "threshold = speech_noise_thres - sil_prob * speech_2_noise_ratio",
            "calc": lambda sil, speech: speech_noise_thres - sil * speech_2_noise_ratio
        },
        {
            "name": "修正版公式2",
            "formula": "threshold = speech_noise_thres / (1 + sil_prob * speech_2_noise_ratio)",
            "calc": lambda sil, speech: speech_noise_thres / (1 + sil * speech_2_noise_ratio)
        }
    ]
    
    for formula_info in formulas:
        print(f"📋 {formula_info['name']}")
        print(f"   公式: {formula_info['formula']}")
        
        correct_count = 0
        total_count = len(test_frames)
        
        for frame_data in test_frames:
            sil_prob = frame_data["sil_prob"]
            speech_prob = frame_data["speech_prob"]
            expected = frame_data["expected"]
            
            threshold = formula_info["calc"](sil_prob, speech_prob)
            predicted = "语音" if speech_prob > threshold else "静音"
            is_correct = predicted == expected
            
            if is_correct:
                correct_count += 1
            
            print(f"   帧{frame_data['frame']:3d}: 语音={speech_prob:.4f} > 阈值={threshold:.4f} -> {predicted} "
                  f"(期望={expected}) {'✅' if is_correct else '❌'}")
        
        accuracy = correct_count / total_count
        print(f"   准确率: {correct_count}/{total_count} ({accuracy*100:.1f}%)")
        print()

def analyze_funasr_paper_method():
    """分析FunASR论文中的方法"""
    print("📖 分析FunASR官方阈值方法")
    print("=" * 80)
    
    print("根据FunASR源码和论文，正确的阈值方法应该是:")
    print("1. speech_noise_thres 是一个固定阈值 (通常0.5-0.7)")
    print("2. speech_2_noise_ratio 用于调节语音/静音的敏感度")
    print("3. 标准公式: speech_prob > speech_noise_thres")
    print("4. 或者带ratio的公式: speech_prob > speech_noise_thres * adjustment")
    print()
    
    # 测试标准阈值
    speech_noise_thres = 0.6
    print(f"使用固定阈值 {speech_noise_thres}:")
    
    test_cases = [
        (150, 0.486418, "应该是静音，因为0.486 < 0.6"),
        (200, 0.454753, "应该是静音，因为0.455 < 0.6"),
        (300, 0.471915, "应该是静音，因为0.472 < 0.6"),
        (350, 0.494171, "应该是静音，因为0.494 < 0.6"),
    ]
    
    for frame, speech_prob, explanation in test_cases:
        result = "语音" if speech_prob > speech_noise_thres else "静音"
        print(f"  帧{frame}: 语音概率={speech_prob:.6f} -> {result} ({explanation})")
    
    print()
    print("🤔 这说明当前数据中所有帧的语音概率都太低！")
    print("可能的原因:")
    print("1. 编码器输出的logits数值范围不对")
    print("2. 阈值参数设置不当") 
    print("3. 这段音频本来就没有明显的语音")

if __name__ == "__main__":
    test_different_threshold_formulas()
    print()
    analyze_funasr_paper_method() 