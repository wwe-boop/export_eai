import torch
import torch.nn as nn
from typing import Tuple

class AffineTransformEAI(nn.Module):
    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.linear = nn.Linear(input_dim, output_dim, bias=True)
    
    def forward(self, input):
        return self.linear(input)

class RectifiedLinearEAI(nn.Module):
    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.relu = nn.ReLU()
    
    def forward(self, input):
        return self.relu(input)

class BasicBlockEAI(nn.Module):
    def __init__(self, linear_dim, proj_dim, lorder, stack_layer=0):
        super().__init__()
        # 线性层：从linear_dim投影到proj_dim
        self.linear = nn.Linear(linear_dim, proj_dim)
        self.lorder = lorder
        self.stack_layer = stack_layer
        
        # 使用1D卷积替代FSMN的记忆块，使用proj_dim维度
        self.memory_block = nn.Conv1d(
            proj_dim, 
            proj_dim,
            kernel_size=lorder,
            padding=0,
            groups=proj_dim,
            bias=False
        )
        
        # 仿射层：从proj_dim投影回linear_dim
        self.affine = nn.Linear(proj_dim, linear_dim)
        self.relu = nn.ReLU()
    
    def forward(self, input):
        """静态前向传播，无条件分支"""
        # 投影到低维空间
        x = self.linear(input)  # [B, T, linear_dim] -> [B, T, proj_dim]
        
        # 转换为卷积格式 [B, D, T]
        x_conv = x.transpose(1, 2)
        
        # 填充以匹配原始实现
        padding = torch.zeros(
            x_conv.shape[0], 
            x_conv.shape[1], 
            self.lorder-1,
            device=x_conv.device,
            dtype=x_conv.dtype
        )
        x_padded = torch.cat([padding, x_conv], dim=2)
        
        # 应用卷积记忆块
        x_mem = self.memory_block(x_padded)
        
        # 转回原始格式并添加残差连接
        x_mem = x_mem.transpose(1, 2)
        x = x + x_mem
        
        # 投影回高维空间
        x = self.affine(x)  # [B, T, proj_dim] -> [B, T, linear_dim]
        x = self.relu(x)
        return x

class FsmnStackEAI(nn.Module):
    def __init__(self, num_layers, linear_dim, proj_dim, lorder):
        super().__init__()
        self.layers = nn.ModuleList([
            BasicBlockEAI(linear_dim, proj_dim, lorder, i)
            for i in range(num_layers)
        ])
    
    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x

class EAICompatibleFSMN(nn.Module):
    def __init__(
        self,
        input_dim,
        input_affine_dim,
        linear_dim,
        proj_dim,
        lorder,
        output_affine_dim,
        output_dim,
        num_layers,
        use_softmax=True
    ):
        super().__init__()
        
        self.use_softmax = use_softmax
        self.in_linear1 = AffineTransformEAI(input_dim, input_affine_dim)
        self.in_linear2 = AffineTransformEAI(input_affine_dim, linear_dim)
        self.relu = RectifiedLinearEAI(linear_dim, linear_dim)
        self.fsmn = FsmnStackEAI(num_layers, linear_dim, proj_dim, lorder)
        self.out_linear1 = AffineTransformEAI(linear_dim, output_affine_dim)
        self.out_linear2 = AffineTransformEAI(output_affine_dim, output_dim)
        
        # 只在需要时添加softmax
        if self.use_softmax:
            self.softmax = nn.Softmax(dim=-1)
    
    def forward(self, input):
        """静态前向传播，无条件分支"""
        x = self.in_linear1(input)
        x = self.in_linear2(x)
        x = self.relu(x)
        x = self.fsmn(x)
        x = self.out_linear1(x)
        x = self.out_linear2(x)
        
        # 根据设置决定是否应用softmax
        if self.use_softmax and hasattr(self, 'softmax'):
            x = self.softmax(x)
        
        return x
    
    def get_logits(self, input):
        """获取未经softmax的logits"""
        x = self.in_linear1(input)
        x = self.in_linear2(x)
        x = self.relu(x)
        x = self.fsmn(x)
        x = self.out_linear1(x)
        x = self.out_linear2(x)
        return x


# ========== EAI编码器推理模型类 ==========

class EAIVADModel(nn.Module):
    """使用EAI兼容编码器的VAD模型"""
    
    def __init__(
        self,
        input_dim: int = 400,           # 输入特征维度 (例如: 80 * 5 LFR)
        input_affine_dim: int = 512,    # 第一个仿射层输出维度
        linear_dim: int = 512,          # 线性层维度
        proj_dim: int = 128,            # FSMN投影维度
        lorder: int = 20,               # FSMN左侧阶数
        output_affine_dim: int = 512,   # 输出仿射层维度
        output_dim: int = 248,          # 编码器输出维度 (标准248维)
        num_layers: int = 4,            # FSMN层数
        **kwargs
    ):
        super().__init__()
        
        # EAI兼容的FSMN编码器
        self.encoder = EAICompatibleFSMN(
            input_dim=input_dim,
            input_affine_dim=input_affine_dim,
            linear_dim=linear_dim,
            proj_dim=proj_dim,
            lorder=lorder,
            output_affine_dim=output_affine_dim,
            output_dim=output_dim,
            num_layers=num_layers,
            use_softmax=True  # 使用softmax激活，与原版FSMN保持一致
        )
        
        # 推理阈值参数
        self.speech_threshold = 0.5  # 语音检测阈值
        
    def forward(self, input: torch.Tensor) -> torch.Tensor:
        """
        前向传播
        Args:
            input: [batch_size, time_steps, feature_dim] 输入特征
        Returns:
            encoder_output: [batch_size, time_steps, 248] 编码器完整输出
        """
        # 编码器推理
        encoder_output = self.encoder(input)  # [B, T, 248]
        return encoder_output
    
    def extract_vad_probs(self, encoder_output: torch.Tensor) -> torch.Tensor:
        """
        从编码器输出中提取VAD概率
        Args:
            encoder_output: [batch_size, time_steps, 248] 编码器输出
        Returns:
            vad_probs: [batch_size, time_steps, 2] VAD概率 (静音, 语音)
        """
        # 提取前两维作为VAD logits
        vad_logits = encoder_output[:, :, :2]  # [B, T, 2]
        
        # 应用softmax确保输出概率分布
        vad_probs = torch.softmax(vad_logits, dim=-1)  # [B, T, 2]
        
        return vad_probs
    
    def inference(self, features: torch.Tensor, **kwargs) -> dict:
        """
        推理接口
        Args:
            features: [batch_size, time_steps, feature_dim] 输入特征
        Returns:
            dict: 包含VAD结果的字典
        """
        self.eval()
        
        with torch.no_grad():
            # 编码器前向传播
            encoder_output = self.forward(features)  # [B, T, 248]
            
            # 提取VAD概率
            vad_probs = self.extract_vad_probs(encoder_output)  # [B, T, 2]
            
            # 提取语音概率 (第二维)
            speech_probs = vad_probs[:, :, 1]  # [B, T] 语音概率
            
            # 应用阈值检测
            speech_frames = (speech_probs > self.speech_threshold).float()
            
            # 统计信息
            batch_size, time_steps = speech_frames.shape
            speech_ratio = speech_frames.mean(dim=1)  # 每个样本的语音比例
            
            results = {
                'encoder_output': encoder_output.cpu().numpy(),    # 完整248维编码器输出
                'vad_probs': vad_probs.cpu().numpy(),             # VAD概率(前2维)
                'speech_probs': speech_probs.cpu().numpy(),       # 语音概率
                'speech_frames': speech_frames.cpu().numpy(),     # 语音帧标记
                'speech_ratio': speech_ratio.cpu().numpy(),       # 语音比例
                'batch_size': batch_size,
                'time_steps': time_steps
            }
            
        return results
    
    def extract_speech_segments(self, features: torch.Tensor, min_duration: int = 10) -> list:
        """
        提取语音段
        Args:
            features: [batch_size, time_steps, feature_dim] 输入特征
            min_duration: 最小语音段长度(帧数)
        Returns:
            list: 语音段列表，每个元素为 (start_frame, end_frame)
        """
        inference_result = self.inference(features)
        speech_frames = inference_result['speech_frames'][0]  # 假设batch_size=1
        
        segments = []
        start_frame = None
        
        for i, is_speech in enumerate(speech_frames):
            if is_speech and start_frame is None:
                # 语音段开始
                start_frame = i
            elif not is_speech and start_frame is not None:
                # 语音段结束
                if i - start_frame >= min_duration:
                    segments.append((start_frame, i))
                start_frame = None
        
        # 处理最后一个语音段
        if start_frame is not None:
            if len(speech_frames) - start_frame >= min_duration:
                segments.append((start_frame, len(speech_frames)))
        
        return segments


# ========== 推理工具函数 ==========

def create_eai_vad_model(config: dict = None) -> EAIVADModel:
    """
    创建EAI VAD模型
    Args:
        config: 模型配置字典
    Returns:
        EAIVADModel: 初始化的模型
    """
    if config is None:
        config = {
            'input_dim': 400,          # 80 mel * 5 LFR
            'input_affine_dim': 512,
            'linear_dim': 512,
            'proj_dim': 128,
            'lorder': 20,
            'output_affine_dim': 512,
            'output_dim': 248,         # 标准248维输出
            'num_layers': 4
        }
    
    model = EAIVADModel(**config)
    return model


def load_eai_model_weights(model: EAIVADModel, weight_path: str) -> EAIVADModel:
    """
    加载模型权重 - 精确映射版本
    Args:
        model: EAI VAD模型
        weight_path: 权重文件路径
    Returns:
        EAIVADModel: 加载权重后的模型
    """
    checkpoint = torch.load(weight_path, map_location='cpu')
    
    # 处理不同的权重格式
    if 'state_dict' in checkpoint:
        state_dict = checkpoint['state_dict']
    elif 'model' in checkpoint:
        state_dict = checkpoint['model']
    else:
        state_dict = checkpoint
    
    # 手动映射权重
    eai_state_dict = model.state_dict()
    loaded_count = 0
    failed_count = 0
    
    # 权重映射规则
    weight_mapping = {
        # 输入层
        'encoder.in_linear1.linear.weight': 'encoder.in_linear1.linear.weight',
        'encoder.in_linear1.linear.bias': 'encoder.in_linear1.linear.bias',
        'encoder.in_linear2.linear.weight': 'encoder.in_linear2.linear.weight',
        'encoder.in_linear2.linear.bias': 'encoder.in_linear2.linear.bias',
        
        # 输出层
        'encoder.out_linear1.linear.weight': 'encoder.out_linear1.linear.weight',
        'encoder.out_linear1.linear.bias': 'encoder.out_linear1.linear.bias',
        'encoder.out_linear2.linear.weight': 'encoder.out_linear2.linear.weight',
        'encoder.out_linear2.linear.bias': 'encoder.out_linear2.linear.bias',
    }
    
    # FSMN层权重映射 (4层)
    for layer_id in range(4):
        # 线性层权重
        weight_mapping[f'encoder.fsmn.layers.{layer_id}.linear.weight'] = f'encoder.fsmn.{layer_id}.linear.linear.weight'
        # 仿射层权重
        weight_mapping[f'encoder.fsmn.layers.{layer_id}.affine.weight'] = f'encoder.fsmn.{layer_id}.affine.linear.weight'
        weight_mapping[f'encoder.fsmn.layers.{layer_id}.affine.bias'] = f'encoder.fsmn.{layer_id}.affine.linear.bias'
    
    print(f"开始精确权重映射...")
    
    # 执行直接映射
    for eai_key, std_key in weight_mapping.items():
        if std_key in state_dict and eai_key in eai_state_dict:
            std_weight = state_dict[std_key]
            eai_weight = eai_state_dict[eai_key]
            
            if std_weight.shape == eai_weight.shape:
                eai_weight.data.copy_(std_weight.data)
                print(f"  ✅ {eai_key:<45} <- {std_key}")
                loaded_count += 1
            else:
                print(f"  ❌ {eai_key:<45} 形状不匹配: {eai_weight.shape} vs {std_weight.shape}")
                failed_count += 1
        else:
            print(f"  ❌ {eai_key:<45} 未找到源权重: {std_key}")
            failed_count += 1
    
    # 特殊处理：FSMN记忆块权重 (形状转换)
    print(f"\n处理FSMN记忆块权重...")
    for layer_id in range(4):
        eai_key = f'encoder.fsmn.layers.{layer_id}.memory_block.weight'
        std_key = f'encoder.fsmn.{layer_id}.fsmn_block.conv_left.weight'
        
        if std_key in state_dict and eai_key in eai_state_dict:
            std_weight = state_dict[std_key]  # [128, 1, 20, 1]
            eai_weight = eai_state_dict[eai_key]  # [128, 1, 20]
            
            # 去掉最后一维，从 [128, 1, 20, 1] -> [128, 1, 20]
            converted_weight = std_weight.squeeze(-1)
            
            if converted_weight.shape == eai_weight.shape:
                eai_weight.data.copy_(converted_weight.data)
                print(f"  ✅ {eai_key:<45} <- {std_key} (形状转换)")
                loaded_count += 1
            else:
                print(f"  ❌ {eai_key:<45} 转换后形状仍不匹配: {eai_weight.shape} vs {converted_weight.shape}")
                failed_count += 1
        else:
            print(f"  ❌ {eai_key:<45} 未找到源权重: {std_key}")
            failed_count += 1
    
    # 处理线性层bias (原版FSMN的linear层没有bias，我们初始化为0)
    print(f"\n初始化缺失的bias...")
    for layer_id in range(4):
        eai_key = f'encoder.fsmn.layers.{layer_id}.linear.bias'
        if eai_key in eai_state_dict:
            eai_state_dict[eai_key].data.zero_()
            print(f"  ✅ {eai_key:<45} 初始化为0")
            loaded_count += 1
    
    print(f"\n权重加载统计:")
    print(f"  成功加载/初始化: {loaded_count} 个")
    print(f"  加载失败: {failed_count} 个")
    print(f"  总体成功率: {loaded_count/(loaded_count+failed_count)*100:.1f}%")
    
    return model


def batch_inference(model: EAIVADModel, feature_list: list, device: str = 'cpu') -> list:
    """
    批量推理
    Args:
        model: EAI VAD模型
        feature_list: 特征列表，每个元素为 [time_steps, feature_dim]
        device: 推理设备
    Returns:
        list: 推理结果列表
    """
    model.to(device)
    model.eval()
    
    results = []
    
    with torch.no_grad():
        for features in feature_list:
            # 转换为torch tensor并添加batch维度
            if isinstance(features, torch.Tensor):
                feat_tensor = features.unsqueeze(0)  # [1, T, D]
            else:
                feat_tensor = torch.from_numpy(features).float().unsqueeze(0)
            
            feat_tensor = feat_tensor.to(device)
            
            # 推理
            result = model.inference(feat_tensor)
            results.append(result)
    
    return results


# ========== 使用示例 ==========

def example_usage():
    """EAI编码器推理使用示例"""
    
    # 1. 创建模型
    model = create_eai_vad_model()
    print(f"模型参数量: {sum(p.numel() for p in model.parameters()):,}")
    
    # 2. 模拟输入特征 (batch_size=1, time_steps=100, feature_dim=400)
    batch_size, time_steps, feature_dim = 1, 100, 400
    dummy_features = torch.randn(batch_size, time_steps, feature_dim)
    
    # 3. 推理
    print("\n=== 开始推理 ===")
    result = model.inference(dummy_features)
    
    print(f"输入形状: {dummy_features.shape}")
    print(f"编码器输出形状: {result['encoder_output'].shape}")  # [1, 100, 248]
    print(f"VAD概率形状: {result['vad_probs'].shape}")          # [1, 100, 2]
    print(f"语音比例: {result['speech_ratio'][0]:.3f}")
    
    # 4. 提取语音段
    segments = model.extract_speech_segments(dummy_features, min_duration=5)
    print(f"检测到 {len(segments)} 个语音段:")
    for i, (start, end) in enumerate(segments):
        print(f"  段{i+1}: 帧{start}-{end} (时长: {end-start}帧)")
    
    # 5. 展示编码器单独推理
    print("\n=== 编码器单独推理 ===")
    with torch.no_grad():
        encoder_output = model.forward(dummy_features)  # 完整248维输出
        print(f"编码器输出形状: {encoder_output.shape}")
        print(f"编码器输出范围: [{encoder_output.min():.3f}, {encoder_output.max():.3f}]")
        
        # VAD分数提取
        vad_probs = model.extract_vad_probs(encoder_output)
        print(f"VAD分数形状: {vad_probs.shape}")
        print(f"静音概率均值: {vad_probs[:, :, 0].mean():.3f}")
        print(f"语音概率均值: {vad_probs[:, :, 1].mean():.3f}")


if __name__ == "__main__":
    example_usage()