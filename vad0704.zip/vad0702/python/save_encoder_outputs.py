# !/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import json
# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import librosa
import numpy as np
from pathlib import Path

from models.fsmn_vad_streaming.model import FsmnVADStreaming
from models.fsmn_vad_streaming.encoder_eai import create_eai_vad_model, load_eai_model_weights
from frontends.wav_frontend import WavFrontend


def save_encoder_outputs():
    """保存编码器输出到文件"""
    import json  # 在函数开始处导入json模块
    
    # 测试音频路径
    audio_path = r"/data4/l50011968/workspace/compare_python/sa1.wav"

    if not os.path.exists(audio_path):
        print(f"❌ 音频文件不存在: {audio_path}")
        return

    print(f"🎵 处理音频: {os.path.basename(audio_path)}")

    # 初始化前端
    frontend = WavFrontend(
        cmvn_file="../fsmn_model/am.mvn",
        fs=16000,
        window='hamming',
        n_mels=80,
        frame_length=25,
        frame_shift=10,
        lfr_m=5,
        lfr_n=1
    )

    # 加载音频并提取特征
    waveform, sample_rate = librosa.load(audio_path, sr=16000, mono=True)
    waveform_tensor = torch.from_numpy(waveform).unsqueeze(0).float()

    frontend.eval()
    with torch.no_grad():
        input_lengths = torch.tensor([waveform_tensor.shape[1]], dtype=torch.long)
        features, feature_lengths = frontend(waveform_tensor, input_lengths)

    # 保存Fbank特征到二进制文件，供C语言测试使用
    features_np = features.cpu().numpy()
    features_path = "fbank_features.bin"
    features_np.tofile(features_path)
    print(f"💾 Fbank特征已保存到: {features_path} (形状: {features_np.shape})")

    print(f"音频时长: {len(waveform) / sample_rate:.2f}秒")
    print(f"特征形状: {features.shape}")
    
    # 输出特征的详细信息
    feature_info = {
        "shape": list(features.shape[1:]),  # 去掉batch维度
        "数据类型": str(features.dtype),
        "数值范围": {
            "最小值": float(features.min()),
            "最大值": float(features.max()),
            "平均值": float(features.mean())
        },
        "第一帧前5个数值": [float(x) for x in features[0, 0, :5].tolist()]
    }
    
    print("\n特征详细信息:")
    print(json.dumps({
        "输出": feature_info
    }, indent=2, ensure_ascii=False))

    # 初始化标准FSMN模型
    encoder_conf = {
        'input_dim': 400,
        'input_affine_dim': 140,
        'fsmn_layers': 4,
        'linear_dim': 250,
        'proj_dim': 128,
        'lorder': 20,
        'rorder': 0,
        'lstride': 1,
        'rstride': 0,
        'output_affine_dim': 140,
        'output_dim': 248
    }

    vad_post_args = {
        'sample_rate': 16000,
        'detect_mode': 1,
        'max_end_silence_time': 800,
        'max_start_silence_time': 3000,
        'speech_noise_thres': 0.6,
        'speech_2_noise_ratio': 1.0
    }

    std_model = FsmnVADStreaming(
        encoder="FSMN",
        encoder_conf=encoder_conf,
        vad_post_args=vad_post_args,
        **vad_post_args
    )

    # 加载权重
    checkpoint = torch.load("../fsmn_model/model.pt", map_location='cpu')
    std_model.load_state_dict(checkpoint, strict=False)

    # 初始化EAI模型
    eai_config = {
        'input_dim': 400,
        'input_affine_dim': 140,
        'linear_dim': 250,
        'proj_dim': 128,
        'lorder': 20,
        'output_affine_dim': 140,
        'output_dim': 248,
        'num_layers': 4
    }
    eai_model = create_eai_vad_model(eai_config)
    load_eai_model_weights(eai_model, "../fsmn_model/model.pt")

    print("✅ 模型初始化完成")

    # 获取编码器输出
    print("🔄 获取标准FSMN编码器输出...")
    std_model.eval()
    with torch.no_grad():
        encoder_cache = {}
        std_output = std_model.encoder(features, encoder_cache)

    print("🔄 获取EAI编码器输出...")
    eai_model.eval()
    with torch.no_grad():
        eai_output = eai_model.encoder(features)

    print(f"标准FSMN输出形状: {std_output.shape}")
    print(f"EAI输出形状: {eai_output.shape}")

    # 验证一致性
    difference = torch.abs(std_output - eai_output).max().item()
    print(f"编码器输出最大差异: {difference}")

    if difference < 1e-6:
        print("✅ 编码器输出完全一致")
    else:
        print("❌ 编码器输出存在差异")

    # 保存输出到文件
    output_dir = Path("encoder_outputs")
    output_dir.mkdir(exist_ok=True)

    audio_name = os.path.splitext(os.path.basename(audio_path))[0]

    # 转换为numpy数组以便计算统计信息
    std_output_np = std_output.cpu().numpy()
    eai_output_np = eai_output.cpu().numpy()

    # 保存NPZ格式文件（原始完整数据）
    std_output_npz = output_dir / f"{audio_name}_std_encoder_output.npz"
    eai_output_npz = output_dir / f"{audio_name}_eai_encoder_output.npz"
    
    np.savez_compressed(
        std_output_npz,
        encoder_output=std_output_np,
        method="standard_fsmn"
    )
    
    np.savez_compressed(
        eai_output_npz,
        encoder_output=eai_output_np,
        method="eai_fsmn"
    )

    # 只保留前10个值，并添加统计信息（JSON格式）
    std_output_data = {
        'encoder_output_first10': std_output_np[0, :10, :5].tolist(),  # 只保留前10帧的前5个特征
        'stats': {
            'max': float(std_output_np.max()),
            'min': float(std_output_np.min()),
            'mean': float(std_output_np.mean()),
            'shape': list(std_output_np.shape)
        },
        'method': "standard_fsmn"
    }

    eai_output_data = {
        'encoder_output_first10': eai_output_np[0, :10, :5].tolist(),  # 只保留前10帧的前5个特征
        'stats': {
            'max': float(eai_output_np.max()),
            'min': float(eai_output_np.min()),
            'mean': float(eai_output_np.mean()),
            'shape': list(eai_output_np.shape)
        },
        'method': "eai_fsmn"
    }

    std_output_file = output_dir / f"{audio_name}_std_encoder_output.json"
    eai_output_file = output_dir / f"{audio_name}_eai_encoder_output.json"
    metadata_file = output_dir / f"{audio_name}_metadata.json"

    with open(std_output_file, 'w', encoding='utf-8') as f:
        json.dump(std_output_data, f, indent=2, ensure_ascii=False)

    with open(eai_output_file, 'w', encoding='utf-8') as f:
        json.dump(eai_output_data, f, indent=2, ensure_ascii=False)

    # 保存元数据

    metadata = {
        'audio_path': str(audio_path),
        'audio_duration': float(len(waveform) / sample_rate),
        'sample_rate': int(sample_rate),
        'features_shape': list(features.shape),
        'frame_shift_ms': 10,
        'vad_post_args': vad_post_args
    }

    with open(metadata_file, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)

    print(f"💾 已保存文件:")
    print(f"  标准FSMN输出 (NPZ): {std_output_npz}")
    print(f"  EAI输出 (NPZ): {eai_output_npz}")
    print(f"  标准FSMN输出 (JSON): {std_output_file}")
    print(f"  EAI输出 (JSON): {eai_output_file}")
    print(f"  元数据: {metadata_file}")

    return std_output_file, eai_output_file, metadata_file


if __name__ == "__main__":
    save_encoder_outputs() 







