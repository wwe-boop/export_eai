#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
验证编码器输出数据格式的理解
"""

import numpy as np
import torch

def verify_encoder_output_format():
    """验证编码器输出数据格式"""
    print("🔍 验证编码器输出数据格式")
    print("=" * 80)
    
    # 1. 加载编码器输出
    data = np.load('python/ref_result/sa1_eai_encoder_output.npz')
    encoder_output = data['encoder_output']  # [1, 644, 248]
    print(f"编码器输出形状: {encoder_output.shape}")
    print(f"数值范围: [{encoder_output.min():.6f}, {encoder_output.max():.6f}]")
    
    # 2. 检查前几维的数据
    print(f"\n=== 前几维数据分析 ===")
    for dim in range(min(10, encoder_output.shape[2])):
        dim_data = encoder_output[0, :, dim]
        print(f"第{dim}维: 范围[{dim_data.min():.6f}, {dim_data.max():.6f}], 均值{dim_data.mean():.6f}")
    
    # 3. 检查前几帧的前几维数据
    print(f"\n=== 前5帧的前10维数据 ===")
    for frame in range(5):
        frame_data = encoder_output[0, frame, :10]
        print(f"帧{frame}: {frame_data}")
    
    # 4. 测试不同的概率计算方式
    print(f"\n=== 测试不同的概率计算方式 ===")
    
    # 方式1: 前2维做softmax (当前方式)
    print(f"\n方式1: 前2维做softmax")
    vad_logits = encoder_output[0, :, :2]
    probs1 = torch.softmax(torch.from_numpy(vad_logits), dim=1).numpy()
    print(f"前5帧概率:")
    for i in range(5):
        print(f"  帧{i}: 静音={probs1[i,0]:.6f}, 语音={probs1[i,1]:.6f}")
    
    # 方式2: 第1维直接作为静音概率，语音概率=1-静音概率
    print(f"\n方式2: 第1维直接作为静音概率")
    sil_probs2 = encoder_output[0, :, 0]
    speech_probs2 = 1.0 - sil_probs2
    print(f"前5帧概率:")
    for i in range(5):
        print(f"  帧{i}: 静音={sil_probs2[i]:.6f}, 语音={speech_probs2[i]:.6f}")
    
    # 方式3: 第2维直接作为语音概率，静音概率=1-语音概率
    print(f"\n方式3: 第2维直接作为语音概率")
    speech_probs3 = encoder_output[0, :, 1]
    sil_probs3 = 1.0 - speech_probs3
    print(f"前5帧概率:")
    for i in range(5):
        print(f"  帧{i}: 静音={sil_probs3[i]:.6f}, 语音={speech_probs3[i]:.6f}")
    
    # 5. 对比Python基准的期望值
    print(f"\n=== 对比Python基准期望值 ===")
    expected_frames = [
        {"frame": 0, "sil": 0.6033, "speech": 0.3967},
        {"frame": 50, "sil": 0.2029, "speech": 0.7971},
        {"frame": 150, "sil": 0.0551, "speech": 0.9449},
        {"frame": 200, "sil": 0.1816, "speech": 0.8184},
        {"frame": 300, "sil": 0.1125, "speech": 0.8875},
    ]
    
    print(f"Python基准 vs 我们的计算:")
    for exp in expected_frames:
        frame_idx = exp["frame"]
        exp_sil = exp["sil"]
        exp_speech = exp["speech"]
        
        # 我们的方式1结果
        our_sil1 = probs1[frame_idx, 0]
        our_speech1 = probs1[frame_idx, 1]
        
        # 我们的方式2结果
        our_sil2 = sil_probs2[frame_idx]
        our_speech2 = speech_probs2[frame_idx]
        
        print(f"帧{frame_idx:3d}:")
        print(f"  期望: 静音={exp_sil:.4f}, 语音={exp_speech:.4f}")
        print(f"  方式1: 静音={our_sil1:.4f}, 语音={our_speech1:.4f} (差异: {abs(our_sil1-exp_sil):.4f})")
        print(f"  方式2: 静音={our_sil2:.4f}, 语音={our_speech2:.4f} (差异: {abs(our_sil2-exp_sil):.4f})")
        print()
    
    # 6. 检查是否有其他可能的数据格式
    print(f"=== 检查其他可能的数据格式 ===")
    
    # 检查是否需要归一化
    print(f"检查前2维的和:")
    for i in range(5):
        sum_val = encoder_output[0, i, 0] + encoder_output[0, i, 1]
        print(f"  帧{i}: 前2维和 = {sum_val:.6f}")
    
    # 检查是否有特殊的维度包含概率
    print(f"\n检查特殊维度:")
    for dim in [0, 1, 2, 246, 247]:  # 检查开头、结尾的维度
        dim_data = encoder_output[0, :5, dim]
        print(f"  第{dim}维前5帧: {dim_data}")

if __name__ == "__main__":
    verify_encoder_output_format()
