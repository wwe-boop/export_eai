#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
修正版后处理对比分析
比较标准FSMN和EAI模型的后处理结果
"""

import os
import sys
import numpy as np
import torch
import librosa
import json
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.fsmn_vad_streaming.model import FsmnVADStreaming
from frontends.wav_frontend import WavFrontend
from enhanced_vad_postprocessing import enhanced_funasr_vad_postprocessing


def corrected_manual_postprocessing(encoder_output, model_name, vad_post_args):
    """
    修正版手动后处理算法
    """
    # 提取VAD logits（前2维）
    vad_logits = encoder_output[0, :, :2].cpu()
    
    # 计算概率
    speech_2_noise_ratio = vad_post_args.get('speech_2_noise_ratio', 1.0)
    
    # 使用softmax获取概率
    probs = torch.softmax(vad_logits, dim=1)
    speech_probs = probs[:, 1]
    sil_probs = probs[:, 0]
    
    # 转换为numpy数组
    speech_probs_np = speech_probs.numpy()
    sil_probs_np = sil_probs.numpy()
    
    # 运行增强算法
    result = enhanced_funasr_vad_postprocessing(
        speech_probs_np, 
        sil_probs_np,
        **vad_post_args
    )
    
    return result


def main():
    """主函数"""
    print("🔍 修正版后处理对比分析")
    print("=" * 80)

    # 1. 加载编码器输出和元数据
    print(f"🔄 加载编码器输出和元数据...")

    # 文件路径
    std_file = 'encoder_outputs/si491_std_encoder_output.npz'
    eai_file = 'encoder_outputs/si491_eai_encoder_output.npz'
    metadata_file = 'encoder_outputs/si491_metadata.json'

    if not os.path.exists(std_file) or not os.path.exists(eai_file) or not os.path.exists(metadata_file):
        print(f"❌ 找不到必要的文件，请先运行save_encoder_outputs.py生成编码器输出")
        return

    std_data = np.load(std_file)
    eai_data = np.load(eai_file)

    # 从JSON文件读取元数据
    with open(metadata_file, 'r') as f:
        metadata = json.load(f)

    std_output = torch.from_numpy(std_data['encoder_output'])
    eai_output = torch.from_numpy(eai_data['encoder_output'])

    print(f"✅ 加载编码器输出:")
    print(f"  标准FSMN: {std_output.shape}")
    print(f"  EAI: {eai_output.shape}")
    print(f"  音频: {metadata['audio_path']}")
    print(f"  时长: {metadata['audio_duration']:.2f}秒")

    # 2. 获取原版FunASR结果作为参考
    print(f"\n🔄 获取原版FunASR参考结果...")
    audio_path = metadata['audio_path']
    original_segments = get_original_funasr_result(audio_path)
    
    print(f"  原版FunASR结果: {len(original_segments)} 个语音段")
    for i, segment in enumerate(original_segments):
        print(f"    段{i + 1}: {segment[0]}ms - {segment[1]}ms (时长: {segment[1] - segment[0]}ms)")

    # 3. 应用修正版后处理算法
    vad_post_args = metadata['vad_post_args']

    std_corrected_result = corrected_manual_postprocessing(std_output, "标准FSMN", vad_post_args)
    eai_corrected_result = corrected_manual_postprocessing(eai_output, "EAI", vad_post_args)

    # 4. 对比结果
    print(f"\n{'=' * 80}")
    print(f"📊 修正版后处理结果对比")
    print(f"{'=' * 80}")

    print(f"\n🔍 FSMN模型后处理结果:")
    print(f"  检测到语音段: {len(std_corrected_result)} 个")
    for i, (start_frame, end_frame) in enumerate(std_corrected_result):
        start_ms = start_frame * 10
        end_ms = end_frame * 10
        print(f"    段{i + 1}: {start_ms}ms - {end_ms}ms (时长: {end_ms - start_ms}ms)")

    print(f"\n🔍 EAI模型后处理结果:")
    print(f"  检测到语音段: {len(eai_corrected_result)} 个")
    for i, (start_frame, end_frame) in enumerate(eai_corrected_result):
        start_ms = start_frame * 10
        end_ms = end_frame * 10
        print(f"    段{i + 1}: {start_ms}ms - {end_ms}ms (时长: {end_ms - start_ms}ms)")

    # 一致性分析
    std_frames = std_corrected_result['speech_frames']
    eai_frames = eai_corrected_result['speech_frames']
    frame_agreement = (std_frames == eai_frames).sum() / len(std_frames)
    print(f"\n  标准FSMN vs EAI帧级一致性: {frame_agreement:.3f} ({frame_agreement * 100:.1f}%)")

    if frame_agreement == 1.0:
        print("  ✅ 修正版后处理结果完全一致")
    else:
        print("  ❌ 修正版后处理结果存在差异")


def get_original_funasr_result(audio_path):
    """获取原版FunASR的VAD结果"""
    # 加载音频并提取特征
    waveform, sample_rate = librosa.load(audio_path, sr=16000, mono=True)
    waveform_tensor = torch.from_numpy(waveform).unsqueeze(0).float()

    # 初始化前端
    frontend = WavFrontend(
        cmvn_file="../fsmn_model/am.mvn",
        fs=16000,
        window='hamming',
        n_mels=80,
        frame_length=25,
        frame_shift=10,
        lfr_m=5,
        lfr_n=1
    )

    # 初始化VAD模型
    encoder_conf = {
        'input_dim': 400,
        'input_affine_dim': 140,
        'fsmn_layers': 4,
        'linear_dim': 250,
        'proj_dim': 128,
        'lorder': 20,
        'rorder': 0,
        'lstride': 1,
        'rstride': 0,
        'output_affine_dim': 140,
        'output_dim': 248
    }
    
    vad_post_args = {
        'sample_rate': 16000,
        'detect_mode': 1,
        'max_end_silence_time': 800,
        'max_start_silence_time': 3000,
        'speech_noise_thres': 0.6,
        'speech_2_noise_ratio': 1.0
    }
    
    model = FsmnVADStreaming(
        encoder="FSMN",
        encoder_conf=encoder_conf,
        vad_post_args=vad_post_args,
        **vad_post_args
    )

    # 加载权重
    checkpoint = torch.load("../fsmn_model/model.pt", map_location='cpu')
    model.load_state_dict(checkpoint, strict=False)

    # 提取特征
    frontend.eval()
    with torch.no_grad():
        input_lengths = torch.tensor([waveform_tensor.shape[1]], dtype=torch.long)
        features, feature_lengths = frontend(waveform_tensor, input_lengths)

    # 初始化cache并完整推理
    cache = {}
    model.init_cache(cache)

    model.eval()
    with torch.no_grad():
        segments = model.forward(
            feats=features,
            waveform=waveform_tensor,
            cache=cache,
            is_final=True
        )

    # 提取原版结果
    if segments:
        flat_segments = []
        for segment_list in segments:
            if isinstance(segment_list, list):
                for segment in segment_list:
                    if isinstance(segment, list) and len(segment) >= 2:
                        flat_segments.append(segment)
        return flat_segments
    else:
        return []


if __name__ == "__main__":
    main()

