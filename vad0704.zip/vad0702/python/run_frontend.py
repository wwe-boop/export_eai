import torch
import numpy as np
import librosa
from frontend_core import AudioFrontend
import os

def run_python_frontend(wav_path, cmvn_path, output_path):
    """
    运行Python前端并保存输出。
    """
    # 1. 初始化前端
    frontend = AudioFrontend(cmvn_file=cmvn_path, lfr_m=5, lfr_n=1)
    
    # 2. 加载音频
    waveform, sr = librosa.load(wav_path, sr=16000)
    waveform = torch.from_numpy(waveform).float().unsqueeze(0)
    input_lengths = torch.LongTensor([waveform.shape[1]])

    # 3. 运行前端处理
    # 确保模型在评估模式
    frontend.eval()
    with torch.no_grad():
        # frontend_core.py的forward函数返回 (feats, feats_lens)
        # 其中feats是一个包含张量的列表，我们需要第一个元素
        feats_list, _ = frontend(waveform, input_lengths)
        final_feats = feats_list[0]

    # 4. 保存输出
    output_dir = os.path.dirname(output_path)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        
    np.save(output_path, final_feats.numpy())
    print(f"Python frontend output saved to: {output_path}")
    print(f"Shape: {final_feats.numpy().shape}")

if __name__ == '__main__':
    # 使用相对路径，以便可以在项目的任何位置运行此脚本
    repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    wav_file = os.path.join(repo_root, 'testsrc/sa1.wav')
    cmvn_file = os.path.join(repo_root, 'models/am.mvn')
    output_file = os.path.join(repo_root, 'python/ref_result/py_frontend_output.npy')
    
    run_python_frontend(wav_file, cmvn_file, output_file) 