#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eAI推理结果相似度对比分析
比较C实现的eAI推理结果与Python参考结果的相似度
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import json
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics import mean_squared_error, mean_absolute_error
import pandas as pd

def load_c_implementation_output():
    """加载C实现的eAI推理输出"""
    print("🔄 加载C实现输出数据...")
    
    c_output_file = "../build/eai_encoder_test_output.txt"
    
    if not Path(c_output_file).exists():
        print(f"❌ C输出文件不存在: {c_output_file}")
        return None
    
    # 解析C输出文件
    data_lines = []
    with open(c_output_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) >= 249:  # frame_index + 248 features
                    frame_idx = int(parts[0])
                    features = [float(x) for x in parts[1:249]]
                    data_lines.append(features)
    
    if not data_lines:
        print("❌ 未找到有效的数据行")
        return None
    
    # 转换为numpy数组
    c_output = np.array(data_lines)
    c_output = c_output[np.newaxis, :]  # 添加batch维度 [1, frames, 248]
    
    print(f"✅ C实现输出数据:")
    print(f"   形状: {c_output.shape}")
    print(f"   数值范围: [{c_output.min():.6f}, {c_output.max():.6f}]")
    print(f"   平均值: {c_output.mean():.6f}")
    print(f"   标准差: {c_output.std():.6f}")
    
    return c_output

def load_python_reference():
    """加载Python参考数据"""
    print("\n🔄 加载Python参考数据...")
    
    ref_file = "ref_result/sa1_eai_encoder_output.npz"
    if not Path(ref_file).exists():
        print(f"❌ 参考文件不存在: {ref_file}")
        return None
    
    data = np.load(ref_file)
    python_ref = data['encoder_output']
    
    print(f"✅ Python参考数据:")
    print(f"   形状: {python_ref.shape}")
    print(f"   数值范围: [{python_ref.min():.6f}, {python_ref.max():.6f}]")
    print(f"   平均值: {python_ref.mean():.6f}")
    print(f"   标准差: {python_ref.std():.6f}")
    
    return python_ref

def compute_similarity_metrics(c_output, python_ref):
    """计算相似度指标"""
    print("\n📊 计算相似度指标...")
    
    # 确保形状一致
    if c_output.shape != python_ref.shape:
        print(f"⚠️  形状不匹配: C={c_output.shape}, Python={python_ref.shape}")
        # 取较小的维度
        min_frames = min(c_output.shape[1], python_ref.shape[1])
        min_features = min(c_output.shape[2], python_ref.shape[2])
        c_output = c_output[:, :min_frames, :min_features]
        python_ref = python_ref[:, :min_frames, :min_features]
        print(f"   调整后形状: {c_output.shape}")
    
    # 展平数据进行整体分析
    c_flat = c_output.flatten()
    py_flat = python_ref.flatten()
    
    # 基本统计指标
    mse = mean_squared_error(py_flat, c_flat)
    mae = mean_absolute_error(py_flat, c_flat)
    rmse = np.sqrt(mse)
    
    # 相对误差
    relative_error = np.abs(py_flat - c_flat) / (np.abs(py_flat) + 1e-10)
    mean_relative_error = np.mean(relative_error)
    max_relative_error = np.max(relative_error)
    
    # 相关系数
    pearson_corr, pearson_p = pearsonr(py_flat, c_flat)
    spearman_corr, spearman_p = spearmanr(py_flat, c_flat)
    
    # 余弦相似度
    dot_product = np.dot(py_flat, c_flat)
    norm_py = np.linalg.norm(py_flat)
    norm_c = np.linalg.norm(c_flat)
    cosine_similarity = dot_product / (norm_py * norm_c)
    
    # 数值范围对比
    py_range = python_ref.max() - python_ref.min()
    c_range = c_output.max() - c_output.min()
    range_ratio = c_range / py_range if py_range > 0 else float('inf')
    
    metrics = {
        'MSE': mse,
        'MAE': mae,
        'RMSE': rmse,
        'Mean Relative Error': mean_relative_error,
        'Max Relative Error': max_relative_error,
        'Pearson Correlation': pearson_corr,
        'Spearman Correlation': spearman_corr,
        'Cosine Similarity': cosine_similarity,
        'Range Ratio (C/Python)': range_ratio
    }
    
    print("📈 相似度指标:")
    for metric, value in metrics.items():
        if 'Correlation' in metric or 'Similarity' in metric:
            print(f"   {metric}: {value:.6f}")
        elif 'Error' in metric:
            print(f"   {metric}: {value:.6f} ({value*100:.2f}%)")
        else:
            print(f"   {metric}: {value:.6f}")
    
    return metrics

def analyze_frame_by_frame(c_output, python_ref):
    """逐帧分析差异"""
    print("\n🔍 逐帧差异分析...")
    
    num_frames = min(c_output.shape[1], python_ref.shape[1])
    frame_errors = []
    frame_correlations = []
    
    for i in range(num_frames):
        c_frame = c_output[0, i, :]
        py_frame = python_ref[0, i, :]
        
        # 计算帧级别的误差
        frame_mse = mean_squared_error(py_frame, c_frame)
        frame_mae = mean_absolute_error(py_frame, c_frame)
        
        # 计算帧级别的相关性
        if np.std(c_frame) > 1e-10 and np.std(py_frame) > 1e-10:
            frame_corr, _ = pearsonr(py_frame, c_frame)
        else:
            frame_corr = 0.0
        
        frame_errors.append(frame_mae)
        frame_correlations.append(frame_corr)
    
    frame_errors = np.array(frame_errors)
    frame_correlations = np.array(frame_correlations)
    
    print(f"   帧级MAE统计:")
    print(f"     平均: {frame_errors.mean():.6f}")
    print(f"     标准差: {frame_errors.std():.6f}")
    print(f"     最大: {frame_errors.max():.6f} (帧{frame_errors.argmax()})")
    print(f"     最小: {frame_errors.min():.6f} (帧{frame_errors.argmin()})")
    
    print(f"   帧级相关性统计:")
    print(f"     平均: {frame_correlations.mean():.6f}")
    print(f"     标准差: {frame_correlations.std():.6f}")
    print(f"     最大: {frame_correlations.max():.6f} (帧{frame_correlations.argmax()})")
    print(f"     最小: {frame_correlations.min():.6f} (帧{frame_correlations.argmin()})")
    
    return frame_errors, frame_correlations

def analyze_feature_dimensions(c_output, python_ref):
    """分析不同特征维度的差异"""
    print("\n🔍 特征维度差异分析...")
    
    num_features = min(c_output.shape[2], python_ref.shape[2])
    feature_errors = []
    feature_correlations = []
    
    for i in range(num_features):
        c_feature = c_output[0, :, i]
        py_feature = python_ref[0, :, i]
        
        # 计算特征维度的误差
        feature_mae = mean_absolute_error(py_feature, c_feature)
        
        # 计算特征维度的相关性
        if np.std(c_feature) > 1e-10 and np.std(py_feature) > 1e-10:
            feature_corr, _ = pearsonr(py_feature, c_feature)
        else:
            feature_corr = 0.0
        
        feature_errors.append(feature_mae)
        feature_correlations.append(feature_corr)
    
    feature_errors = np.array(feature_errors)
    feature_correlations = np.array(feature_correlations)
    
    print(f"   特征维度MAE统计:")
    print(f"     平均: {feature_errors.mean():.6f}")
    print(f"     最大: {feature_errors.max():.6f} (维度{feature_errors.argmax()})")
    print(f"     最小: {feature_errors.min():.6f} (维度{feature_errors.argmin()})")
    
    print(f"   特征维度相关性统计:")
    print(f"     平均: {feature_correlations.mean():.6f}")
    print(f"     最大: {feature_correlations.max():.6f} (维度{feature_correlations.argmax()})")
    print(f"     最小: {feature_correlations.min():.6f} (维度{feature_correlations.argmin()})")
    
    return feature_errors, feature_correlations

def analyze_vad_logits_specifically(c_output, python_ref):
    """专门分析VAD logits（前2维）的差异"""
    print("\n🎯 VAD Logits专项分析...")
    
    # 提取前2维（VAD logits）
    c_vad = c_output[0, :, :2]
    py_vad = python_ref[0, :, :2]
    
    print(f"VAD logits形状: {c_vad.shape}")
    
    # 分别分析静音和语音logits
    for i, label in enumerate(['静音logit', '语音logit']):
        c_logit = c_vad[:, i]
        py_logit = py_vad[:, i]
        
        mae = mean_absolute_error(py_logit, c_logit)
        corr, _ = pearsonr(py_logit, c_logit) if np.std(c_logit) > 1e-10 and np.std(py_logit) > 1e-10 else (0.0, 1.0)
        
        print(f"   {label}:")
        print(f"     C实现范围: [{c_logit.min():.6f}, {c_logit.max():.6f}]")
        print(f"     Python范围: [{py_logit.min():.6f}, {py_logit.max():.6f}]")
        print(f"     MAE: {mae:.6f}")
        print(f"     相关性: {corr:.6f}")
    
    # 计算softmax概率并比较
    def softmax(logits):
        exp_logits = np.exp(logits)
        return exp_logits / np.sum(exp_logits, axis=1, keepdims=True)
    
    c_probs = softmax(c_vad)
    py_probs = softmax(py_vad)
    
    print(f"\n   Softmax概率对比:")
    for i, label in enumerate(['静音概率', '语音概率']):
        c_prob = c_probs[:, i]
        py_prob = py_probs[:, i]
        
        mae = mean_absolute_error(py_prob, c_prob)
        corr, _ = pearsonr(py_prob, c_prob) if np.std(c_prob) > 1e-10 and np.std(py_prob) > 1e-10 else (0.0, 1.0)
        
        print(f"     {label}:")
        print(f"       C实现范围: [{c_prob.min():.6f}, {c_prob.max():.6f}]")
        print(f"       Python范围: [{py_prob.min():.6f}, {py_prob.max():.6f}]")
        print(f"       MAE: {mae:.6f}")
        print(f"       相关性: {corr:.6f}")

def save_detailed_report(metrics, frame_errors, frame_correlations, feature_errors, feature_correlations):
    """保存详细报告"""
    print("\n💾 保存详细报告...")
    
    report = {
        'overall_metrics': metrics,
        'frame_analysis': {
            'mean_mae': float(frame_errors.mean()),
            'std_mae': float(frame_errors.std()),
            'max_mae': float(frame_errors.max()),
            'min_mae': float(frame_errors.min()),
            'mean_correlation': float(frame_correlations.mean()),
            'std_correlation': float(frame_correlations.std())
        },
        'feature_analysis': {
            'mean_mae': float(feature_errors.mean()),
            'max_mae': float(feature_errors.max()),
            'min_mae': float(feature_errors.min()),
            'mean_correlation': float(feature_correlations.mean())
        }
    }
    
    with open('../build/eai_inference_similarity_report.json', 'w') as f:
        json.dump(report, f, indent=2)
    
    print("✅ 报告已保存到: ../build/eai_inference_similarity_report.json")

def main():
    """主函数"""
    print("🔍 eAI推理结果相似度对比分析")
    print("=" * 80)
    
    # 加载数据
    c_output = load_c_implementation_output()
    python_ref = load_python_reference()
    
    if c_output is None or python_ref is None:
        print("❌ 数据加载失败，退出分析")
        return
    
    # 计算整体相似度指标
    metrics = compute_similarity_metrics(c_output, python_ref)
    
    # 逐帧分析
    frame_errors, frame_correlations = analyze_frame_by_frame(c_output, python_ref)
    
    # 特征维度分析
    feature_errors, feature_correlations = analyze_feature_dimensions(c_output, python_ref)
    
    # VAD logits专项分析
    analyze_vad_logits_specifically(c_output, python_ref)
    
    # 保存详细报告
    save_detailed_report(metrics, frame_errors, frame_correlations, feature_errors, feature_correlations)
    
    # 总结
    print("\n" + "=" * 80)
    print("📋 分析总结:")
    print(f"   整体相关性: {metrics['Pearson Correlation']:.4f}")
    print(f"   余弦相似度: {metrics['Cosine Similarity']:.4f}")
    print(f"   平均相对误差: {metrics['Mean Relative Error']*100:.2f}%")
    print(f"   数值范围比例: {metrics['Range Ratio (C/Python)']:.4f}")
    
    if metrics['Pearson Correlation'] > 0.95:
        print("✅ 相似度很高，C实现基本正确")
    elif metrics['Pearson Correlation'] > 0.8:
        print("⚠️  相似度中等，存在一些差异")
    else:
        print("❌ 相似度较低，需要进一步调试")

if __name__ == "__main__":
    main()
