#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
后处理调试脚本 - 逐步输出中间结果与C语言对比
"""

import numpy as np
import torch

def debug_postprocess_step_by_step():
    """逐步调试后处理过程"""
    print("🔍 后处理逐步调试")
    print("=" * 60)
    
    # 1. 加载编码器输出
    print("\n=== 步骤1: 加载编码器输出 ===")
    data = np.load('ref_result/sa1_eai_encoder_output.npz')
    encoder_output = data['encoder_output']
    print(f"编码器输出形状: {encoder_output.shape}")
    print(f"数值范围: [{encoder_output.min():.6f}, {encoder_output.max():.6f}]")
    print(f"平均值: {encoder_output.mean():.6f}")
    
    # 2. 提取VAD logits (前2维)
    print("\n=== 步骤2: 提取VAD Logits ===")
    vad_logits = encoder_output[0, :, :2]  # [644, 2]
    print(f"VAD logits形状: {vad_logits.shape}")
    print(f"前5帧的原始logits:")
    for i in range(5):
        print(f"  帧{i}: sil_logit={vad_logits[i,0]:.6f}, speech_logit={vad_logits[i,1]:.6f}")
    
    # 3. 计算softmax概率
    print("\n=== 步骤3: 计算Softmax概率 ===")
    vad_logits_tensor = torch.from_numpy(vad_logits)
    probs = torch.softmax(vad_logits_tensor, dim=1)
    sil_probs = probs[:, 0].numpy()
    speech_probs = probs[:, 1].numpy()
    
    print(f"静音概率范围: [{sil_probs.min():.6f}, {sil_probs.max():.6f}]")
    print(f"静音概率均值: {sil_probs.mean():.6f}")
    print(f"语音概率范围: [{speech_probs.min():.6f}, {speech_probs.max():.6f}]")
    print(f"语音概率均值: {speech_probs.mean():.6f}")
    
    print(f"前5帧的softmax概率:")
    for i in range(5):
        print(f"  帧{i}: 静音={sil_probs[i]:.6f}, 语音={speech_probs[i]:.6f}")
    
    # 4. 阈值判断
    print("\n=== 步骤4: 阈值判断 ===")
    speech_noise_thres = 0.6
    print(f"speech_noise_thres = {speech_noise_thres}")
    
    # 统计语音帧
    speech_frames = speech_probs > speech_noise_thres
    speech_count = speech_frames.sum()
    print(f"检测到语音帧: {speech_count}/{len(speech_frames)} ({speech_count/len(speech_frames)*100:.1f}%)")
    
    # 输出前20帧和关键帧的判断结果
    print(f"前20帧的判断结果:")
    for i in range(20):
        is_speech = speech_probs[i] > speech_noise_thres
        print(f"  帧{i:2d} ({i*10:3d}ms): 静音={sil_probs[i]:.4f}, 语音={speech_probs[i]:.4f}, 阈值={speech_noise_thres:.1f}, 判断={'语音' if is_speech else '静音'}")
    
    # 输出一些关键帧
    key_frames = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600]
    print(f"关键帧的判断结果:")
    for i in key_frames:
        if i < len(speech_probs):
            is_speech = speech_probs[i] > speech_noise_thres
            print(f"  帧{i:3d} ({i*10:4d}ms): 静音={sil_probs[i]:.4f}, 语音={speech_probs[i]:.4f}, 阈值={speech_noise_thres:.1f}, 判断={'语音' if is_speech else '静音'}")
    
    # 5. 保存调试数据供C语言对比
    print("\n=== 步骤5: 保存调试数据 ===")
    debug_data = {
        'vad_logits': vad_logits,
        'sil_probs': sil_probs,
        'speech_probs': speech_probs,
        'speech_frames': speech_frames.astype(np.int32),
        'speech_count': speech_count
    }
    
    np.savez('ref_result/debug_postprocess.npz', **debug_data)
    print("调试数据已保存到: ref_result/debug_postprocess.npz")
    
    # 6. 输出原始二进制数据供C语言直接读取
    print("\n=== 步骤6: 输出原始数据 ===")
    
    # 保存VAD logits为二进制文件
    vad_logits.astype(np.float32).tofile('ref_result/debug_vad_logits.raw')
    print(f"VAD logits已保存: ref_result/debug_vad_logits.raw ({vad_logits.nbytes} bytes)")

    # 保存概率为二进制文件
    probs_combined = np.column_stack([sil_probs, speech_probs]).astype(np.float32)
    probs_combined.tofile('ref_result/debug_probs.raw')
    print(f"概率数据已保存: ref_result/debug_probs.raw ({probs_combined.nbytes} bytes)")
    
    print("\n✅ 调试数据准备完成，可以与C语言实现对比")
    
    return {
        'vad_logits': vad_logits,
        'sil_probs': sil_probs,
        'speech_probs': speech_probs,
        'speech_frames': speech_frames,
        'speech_count': speech_count
    }

if __name__ == "__main__":
    debug_postprocess_step_by_step()
