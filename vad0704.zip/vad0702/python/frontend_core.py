import torch
import torch.nn as nn
import numpy as np
import librosa
import torchaudio.compliance.kaldi as kaldi
from torch.nn.utils.rnn import pad_sequence
from typing import Tuple, Optional, Union, List
import json
import os

class AudioFrontend(nn.Module):
    """音频前端处理基类"""
    
    def __init__(
        self,
        cmvn_file: str = None,
        fs: int = 16000,
        window: str = "hamming",
        n_mels: int = 80,
        frame_length: int = 25,
        frame_shift: int = 10,
        lfr_m: int = 1,
        lfr_n: int = 1,
        dither: float = 1.0,
        snip_edges: bool = True,
        log_file: str = None,
        n_fft: int = None,  # 添加n_fft参数
        fmin: int = None,   # 添加fmin参数
        fmax: int = None,   # 添加fmax参数
        **kwargs,
    ):
        super().__init__()
        self.fs = fs
        self.n_mels = n_mels
        self.frame_length = frame_length
        self.frame_shift = frame_shift
        self.window = window
        self.n_fft = n_fft or int(frame_length * fs / 1000)
        self.fmin = fmin or 0
        self.fmax = fmax or fs / 2
        self.lfr_m = lfr_m
        self.lfr_n = lfr_n
        self.dither = dither
        self.snip_edges = snip_edges
        self.log_file = log_file
        
        # 初始化日志字典
        self.step_logs = {
            "处理步骤说明": {
                "1.输入波形": "原始音频波形数据",
                "2.音量放大": "将音频数据放大2^15倍",
                "3.Fbank特征": "使用Kaldi风格提取的Fbank特征",
                "4.LFR输入": "送入LFR处理的特征",
                "5.LFR输出": "LFR处理后的特征",
                "6.CMVN输入": "送入CMVN归一化的特征",
                "7.CMVN输出": "CMVN归一化后的特征",
                "8.最终输出": "最终处理完成的特征"
            },
            "参数配置": {
                "采样率": fs,
                "Mel滤波器数": n_mels,
                "帧长(ms)": frame_length,
                "帧移(ms)": frame_shift,
                "窗函数": window,
                "FFT点数": self.n_fft,
                "最小频率": self.fmin,
                "最大频率": self.fmax,
                "LFR_m": lfr_m,
                "LFR_n": lfr_n,
                "抖动系数": dither
            },
            "处理步骤": {}
        }
        
        # 加载CMVN参数
        self.cmvn = None
        if cmvn_file is not None:
            self.cmvn = self.load_cmvn(cmvn_file)
            
        # 初始化Mel滤波器组
        self.mel_basis = librosa.filters.mel(
            sr=fs,
            n_fft=self.n_fft,
            n_mels=n_mels,
            fmin=self.fmin,
            fmax=self.fmax
        )
        self.register_buffer("mel_basis_tensor", torch.from_numpy(self.mel_basis).float())

    def _log_step(self, step_name: str, data: torch.Tensor, additional_info: dict = None):
        """记录处理步骤的详细信息"""
        # 确保数据是2D的
        if data.dim() == 1:
            data = data.unsqueeze(0)
        elif data.dim() > 2:
            # 如果维度大于2，取第一个样本
            data = data[0]
            
        log_data = {
            "shape": list(data.shape),
            "数据类型": str(data.dtype),
            "数值范围": {
                "最小值": float(data.min()),
                "最大值": float(data.max()),
                "平均值": float(data.mean())
            }
        }
        
        # 只记录第一帧的前5个数值
        if data.shape[0] > 0:
            first_frame = data[0]
            num_values = min(5, first_frame.shape[0])
            log_data["第一帧前5个数值"] = first_frame[:num_values].tolist()
            
        if additional_info:
            log_data.update(additional_info)
            
        self.step_logs["处理步骤"][step_name] = log_data

    def load_cmvn(self, cmvn_file: str) -> torch.Tensor:
        """加载CMVN参数"""
        with open(cmvn_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
            
        means_list = []
        vars_list = []
        for i in range(len(lines)):
            line_item = lines[i].split()
            if line_item[0] == "<AddShift>":
                line_item = lines[i + 1].split()
                if line_item[0] == "<LearnRateCoef>":
                    means_list = list(map(float, line_item[3:-1]))
            elif line_item[0] == "<Rescale>":
                line_item = lines[i + 1].split()
                if line_item[0] == "<LearnRateCoef>":
                    vars_list = list(map(float, line_item[3:-1]))
                    
        means = np.array(means_list, dtype=np.float32)
        vars = np.array(vars_list, dtype=np.float32)
        return torch.from_numpy(np.stack([means, vars]))

    def apply_cmvn(self, inputs: torch.Tensor) -> torch.Tensor:
        """应用CMVN归一化"""
        if self.cmvn is None:
            return inputs
            
        self._log_step("6.CMVN输入", inputs)
        
        device = inputs.device
        frame, dim = inputs.shape
        means = self.cmvn[0:1, :dim]
        vars = self.cmvn[1:2, :dim]
        
        inputs = inputs + means.to(device)
        inputs = inputs * vars.to(device)
        
        self._log_step("7.CMVN输出", inputs)
        
        return inputs.float()

    def apply_lfr(self, inputs: torch.Tensor) -> torch.Tensor:
        """应用LFR(Low Frame Rate)处理"""
        if self.lfr_m == 1 and self.lfr_n == 1:
            return inputs
            
        self._log_step("4.LFR输入", inputs)
        
        T = inputs.shape[0]
        T_lfr = int(np.ceil(T / self.lfr_n))
        
        lfr_outputs = []
        for i in range(T_lfr):
            if self.lfr_m <= T - i * self.lfr_n:
                lfr_outputs.append(
                    inputs[i * self.lfr_n : i * self.lfr_n + self.lfr_m].reshape(1, -1)
                )
            else:
                # 处理最后一帧
                num_padding = self.lfr_m - (T - i * self.lfr_n)
                frame = inputs[i * self.lfr_n :].reshape(-1)
                for _ in range(num_padding):
                    frame = torch.cat([frame, inputs[-1]])
                lfr_outputs.append(frame)
                
        result = torch.vstack(lfr_outputs).float()
        
        self._log_step("5.LFR输出", result)
        
        return result

    def extract_fbank(self, waveform: torch.Tensor) -> torch.Tensor:
        """提取Fbank特征"""
        # 记录输入波形
        self._log_step("1.输入波形", waveform)
        
        # 确保输入是2D张量 [channels, samples]
        if waveform.dim() == 1:
            waveform = waveform.unsqueeze(0)
            
        # 应用音量放大
        waveform = waveform * (1 << 15)
        self._log_step("2.音量放大", waveform)
        
        # 使用Kaldi风格的Fbank提取
        mat = kaldi.fbank(
            waveform,
            num_mel_bins=self.n_mels,
            frame_length=self.frame_length,
            frame_shift=self.frame_shift,
            dither=self.dither,
            energy_floor=0.0,
            window_type=self.window,
            sample_frequency=self.fs,
            snip_edges=self.snip_edges
        )
        
        self._log_step("3.Fbank特征", mat)
        
        return mat

    def forward(
        self, 
        input: torch.Tensor,
        input_lengths: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """前向处理流程"""
        batch_size = input.size(0)
        feats = []
        feats_lens = []
        
        # 逐条处理音频
        for i in range(batch_size):
            # 1. 提取当前音频
            waveform_length = input_lengths[i]
            waveform = input[i][:waveform_length]
            
            # 2. 提取Fbank特征
            mat = self.extract_fbank(waveform)
            
            # 3. 应用LFR
            if self.lfr_m != 1 or self.lfr_n != 1:
                mat = self.apply_lfr(mat)
                
            # 4. 应用CMVN
            if self.cmvn is not None:
                mat = self.apply_cmvn(mat)
                
            # 5. 记录特征和长度
            feat_length = mat.size(0)
            feats.append(mat)
            feats_lens.append(feat_length)
        
        # 6. 打包特征
        feats_lens = torch.as_tensor(feats_lens)
        if batch_size == 1:
            feats_pad = feats[0].unsqueeze(0)
        else:
            feats_pad = pad_sequence(feats, batch_first=True, padding_value=0.0)
            
        # 记录最终输出
        self._log_step("8.最终输出", feats_pad[0])
        
        # 将日志保存到文件
        if self.log_file:
            log_path = self.log_file
        else:
            log_path = 'frontend_steps.json'
            
        with open(log_path, 'w', encoding='utf-8') as f:
            json.dump(self.step_logs, f, ensure_ascii=False, indent=2)
            
        return feats_pad, feats_lens

class StreamingAudioFrontend(AudioFrontend):
    """流式音频前端处理"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.frame_sample_length = int(self.frame_length * self.fs / 1000)
        self.frame_shift_sample_length = int(self.frame_shift * self.fs / 1000)

    def init_cache(self) -> dict:
        """初始化缓存"""
        return {
            "input_cache": torch.empty(0),
            "lfr_splice_cache": [],
            "waveforms": None,
            "fbanks": None,
            "fbanks_lens": None
        }

    def compute_frame_num(self, sample_length: int) -> int:
        """计算可以提取的帧数"""
        frame_num = (sample_length - self.frame_sample_length) // self.frame_shift_sample_length + 1
        return max(0, frame_num)

    def forward(
        self,
        input: torch.Tensor,
        input_lengths: torch.Tensor,
        cache: dict,
        is_final: bool = False
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """流式前向处理"""
        batch_size = input.size(0)
        
        # 1. 合并输入缓存
        input = torch.cat((cache["input_cache"], input), dim=1)
        
        # 2. 计算可处理的帧数
        frame_num = self.compute_frame_num(input.shape[-1])
        
        # 3. 更新输入缓存
        cache["input_cache"] = input[:, -(input.shape[-1] - frame_num * self.frame_shift_sample_length):]
        
        # 4. 如果没有足够的帧数且不是最终处理
        if frame_num == 0 and not is_final:
            return torch.empty(0), torch.zeros(batch_size, dtype=torch.long)
            
        # 5. 特征提取
        feats = []
        feats_lens = []
        
        for i in range(batch_size):
            # 提取波形
            waveform = input[i]
            if frame_num > 0:
                waveform = waveform[:(frame_num - 1) * self.frame_shift_sample_length + self.frame_sample_length]
            
            # 提取特征
            mat = self.extract_fbank(waveform)
            
            # 合并LFR缓存
            if len(cache["lfr_splice_cache"]) > i:
                mat = torch.cat([cache["lfr_splice_cache"][i], mat], dim=0)
            
            # 应用LFR
            if self.lfr_m != 1 or self.lfr_n != 1:
                if is_final:
                    mat = self.apply_lfr(mat)
                    cache["lfr_splice_cache"] = []
                else:
                    # 计算可以处理的完整帧数
                    complete_frames = (mat.shape[0] - self.lfr_m) // self.lfr_n
                    if complete_frames > 0:
                        processed_mat = self.apply_lfr(mat[:complete_frames * self.lfr_n + self.lfr_m])
                        cache["lfr_splice_cache"].append(mat[complete_frames * self.lfr_n:])
                        mat = processed_mat
                    else:
                        cache["lfr_splice_cache"].append(mat)
                        continue
            
            # 应用CMVN
            if self.cmvn is not None:
                mat = self.apply_cmvn(mat)
            
            feat_length = mat.size(0)
            feats.append(mat)
            feats_lens.append(feat_length)
        
        # 6. 打包特征
        if not feats:
            return torch.empty(0), torch.zeros(batch_size, dtype=torch.long)
            
        feats_lens = torch.as_tensor(feats_lens)
        feats_pad = pad_sequence(feats, batch_first=True, padding_value=0.0)
        
        return feats_pad, feats_lens 
import torchaudio
def process_wav_with_logs(wav_path):
    # 获取文件名（不含路径和扩展名）
    import os
    filename = os.path.splitext(os.path.basename(wav_path))[0]
    log_file = f"{filename}_frontend_steps.json"
    
    # 初始化前端处理器
    frontend = AudioFrontend(
        cmvn_file="../models/am.mvn",
        fs=16000,
        window='hamming',
        n_mels=80,
        frame_length=25,
        frame_shift=10,
        lfr_m=5,
        lfr_n=1,
        dither=0.0,  # 与C实现保持一致
        log_file=log_file  # 指定日志文件
    )
    
    # 加载音频
    waveform, sample_rate = torchaudio.load(wav_path)
    
    # 处理音频
    with torch.no_grad():
        input_lengths = torch.tensor([waveform.shape[1]])
        waveform = waveform.unsqueeze(0)  # 添加batch维度
        features, features_lengths = frontend(waveform, input_lengths)
    
    print(f"特征处理完成，日志已保存至: {log_file}")
    return features, features_lengths

wav_file = "../testsrc/sa1.wav"
process_wav_with_logs(wav_file)
