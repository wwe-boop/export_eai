#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
验证eAI推理结果的正确性
分析sa1_eai_encoder_output.npz参考数据并与C实现对比
"""

import sys
import os
import json
import numpy as np
from pathlib import Path


def load_reference_data():
    """加载参考数据"""
    print("🔄 加载参考数据...")
    
    # 加载编码器输出
    encoder_data = np.load('python/ref_result/sa1_eai_encoder_output.npz')
    encoder_output = encoder_data['encoder_output']  # [1, 644, 248]
    
    # 加载元数据
    with open('python/ref_result/sa1_metadata.json', 'r', encoding='utf-8') as f:
        metadata = json.load(f)
    
    # 加载前端步骤信息
    with open('python/ref_result/sa1_frontend_steps.json', 'r', encoding='utf-8') as f:
        frontend_steps = json.load(f)
    
    print(f"✅ 参考编码器输出形状: {encoder_output.shape}")
    print(f"✅ 音频时长: {metadata['audio_duration']:.2f}秒")
    print(f"✅ 特征形状: {metadata['features_shape']}")
    
    return {
        'encoder_output': encoder_output,
        'metadata': metadata,
        'frontend_steps': frontend_steps
    }


def load_c_inference_result():
    """加载C实现的推理结果"""
    print("\n🔄 加载C实现推理结果...")

    # 检查C实现的输出文件
    c_output_files = [
        "build/eai_encoder_test_output.txt",
        "build/inference_test_results.txt",
        "data/encoder_output.raw"
    ]

    for output_file in c_output_files:
        if os.path.exists(output_file):
            print(f"✅ 找到C输出文件: {output_file}")

            if output_file.endswith('.raw'):
                # 加载原始二进制数据
                return load_raw_binary_data(output_file)
            else:
                # 加载文本格式数据
                return load_text_output_data(output_file)

    print("❌ 未找到C实现的输出文件")
    print("请先运行C程序生成推理结果:")
    print("  cd build && ./bin/test_eai_encoder")
    return None


def load_raw_binary_data(raw_file_path):
    """加载原始二进制数据"""
    print(f"🔄 加载原始二进制文件: {raw_file_path}")

    try:
        # 根据已知形状 [644, 248] 加载数据
        expected_frames = 644
        expected_dim = 248
        expected_size = expected_frames * expected_dim * 4  # float32

        with open(raw_file_path, 'rb') as f:
            data = np.frombuffer(f.read(), dtype=np.float32)

        if len(data) != expected_frames * expected_dim:
            print(f"⚠️  数据大小不匹配: 期望{expected_frames * expected_dim}, 实际{len(data)}")
            # 尝试重新调整形状
            if len(data) % expected_dim == 0:
                actual_frames = len(data) // expected_dim
                data = data.reshape(actual_frames, expected_dim)
                print(f"✅ 重新调整为形状: [{actual_frames}, {expected_dim}]")
            else:
                print("❌ 无法重新调整数据形状")
                return None
        else:
            data = data.reshape(expected_frames, expected_dim)

        # 添加batch维度以匹配参考数据格式 [1, frames, dim]
        data = data[np.newaxis, :]

        print(f"✅ C推理数据加载完成，形状: {data.shape}")
        return {'eai_output': data}

    except Exception as e:
        print(f"❌ 加载原始数据失败: {e}")
        return None


def load_text_output_data(text_file_path):
    """加载文本格式的输出数据"""
    print(f"🔄 解析文本输出文件: {text_file_path}")

    # 这里可以根据实际的文本格式进行解析
    # 目前返回None，提示用户检查文件格式
    print("⚠️  文本格式解析功能待实现")
    print("建议使用原始二进制文件进行对比")
    return None


def compare_results(reference_data, inference_data):
    """对比推理结果"""
    print("\n🔍 对比推理结果...")

    ref_output = reference_data['encoder_output']
    inf_output = inference_data['eai_output']

    print(f"参考输出形状: {ref_output.shape}")
    print(f"推理输出形状: {inf_output.shape}")

    # 检查形状是否一致
    if ref_output.shape != inf_output.shape:
        print("❌ 输出形状不一致!")

        # 尝试调整形状匹配
        if ref_output.shape[1:] == inf_output.shape[1:]:
            print("⚠️  只有batch维度不同，尝试调整...")
            if ref_output.shape[0] == 1 and len(inf_output.shape) == 2:
                inf_output = inf_output[np.newaxis, :]
                print(f"✅ 调整后推理输出形状: {inf_output.shape}")
            elif inf_output.shape[0] == 1 and len(ref_output.shape) == 2:
                ref_output = ref_output[np.newaxis, :]
                print(f"✅ 调整后参考输出形状: {ref_output.shape}")

        if ref_output.shape != inf_output.shape:
            print(f"❌ 形状仍不匹配: {ref_output.shape} vs {inf_output.shape}")
            return False

    # 计算差异
    abs_diff = np.abs(ref_output - inf_output)
    max_diff = abs_diff.max()
    mean_diff = abs_diff.mean()

    print(f"\n差异统计:")
    print(f"  最大绝对差异: {max_diff:.8f}")
    print(f"  平均绝对差异: {mean_diff:.8f}")

    # 检查精度
    tolerance = 1e-5  # 放宽容差，考虑到C实现可能的精度差异
    if max_diff < tolerance:
        print(f"✅ 推理结果一致 (差异 < {tolerance})")
        return True
    else:
        print(f"❌ 推理结果不一致 (差异 >= {tolerance})")

        # 分析差异分布
        print(f"\n差异分析:")
        print(f"  差异 > 1e-6 的元素数量: {np.sum(abs_diff > 1e-6)}")
        print(f"  差异 > 1e-5 的元素数量: {np.sum(abs_diff > 1e-5)}")
        print(f"  差异 > 1e-4 的元素数量: {np.sum(abs_diff > 1e-4)}")
        print(f"  差异 > 1e-3 的元素数量: {np.sum(abs_diff > 1e-3)}")

        # 找出最大差异的位置
        max_diff_idx = np.unravel_index(abs_diff.argmax(), abs_diff.shape)
        print(f"  最大差异位置: {max_diff_idx}")
        print(f"  参考值: {ref_output[max_diff_idx]:.8f}")
        print(f"  推理值: {inf_output[max_diff_idx]:.8f}")

        return False


def analyze_data_statistics(reference_data, inference_data):
    """分析数据统计信息"""
    print("\n📊 数据统计分析...")
    
    ref_output = reference_data['encoder_output']
    inf_output = inference_data['eai_output']
    
    print(f"\n参考数据统计:")
    print(f"  形状: {ref_output.shape}")
    print(f"  数值范围: [{ref_output.min():.6f}, {ref_output.max():.6f}]")
    print(f"  平均值: {ref_output.mean():.6f}")
    print(f"  标准差: {ref_output.std():.6f}")
    
    print(f"\n推理数据统计:")
    print(f"  形状: {inf_output.shape}")
    print(f"  数值范围: [{inf_output.min():.6f}, {inf_output.max():.6f}]")
    print(f"  平均值: {inf_output.mean():.6f}")
    print(f"  标准差: {inf_output.std():.6f}")
    
    # 检查前几帧的前几维
    print(f"\n前5帧的前10维对比:")
    for frame in range(min(5, ref_output.shape[1])):
        ref_frame = ref_output[0, frame, :10]
        inf_frame = inf_output[0, frame, :10]
        diff_frame = np.abs(ref_frame - inf_frame)
        
        print(f"  帧{frame}:")
        print(f"    参考: {ref_frame}")
        print(f"    推理: {inf_frame}")
        print(f"    差异: {diff_frame} (最大: {diff_frame.max():.8f})")


def save_comparison_results(reference_data, inference_data, is_consistent):
    """保存对比结果"""
    print("\n💾 保存对比结果...")
    
    output_dir = Path("python/debug_results")
    output_dir.mkdir(exist_ok=True)
    
    # 保存详细对比结果
    comparison_result = {
        'is_consistent': is_consistent,
        'tolerance': 1e-6,
        'reference_stats': {
            'shape': list(reference_data['encoder_output'].shape),
            'min': float(reference_data['encoder_output'].min()),
            'max': float(reference_data['encoder_output'].max()),
            'mean': float(reference_data['encoder_output'].mean()),
            'std': float(reference_data['encoder_output'].std())
        },
        'inference_stats': {
            'shape': list(inference_data['eai_output'].shape),
            'min': float(inference_data['eai_output'].min()),
            'max': float(inference_data['eai_output'].max()),
            'mean': float(inference_data['eai_output'].mean()),
            'std': float(inference_data['eai_output'].std())
        }
    }
    
    if reference_data['encoder_output'].shape == inference_data['eai_output'].shape:
        abs_diff = np.abs(reference_data['encoder_output'] - inference_data['eai_output'])
        comparison_result['difference_stats'] = {
            'max_abs_diff': float(abs_diff.max()),
            'mean_abs_diff': float(abs_diff.mean()),
            'elements_gt_1e6': int(np.sum(abs_diff > 1e-6)),
            'elements_gt_1e5': int(np.sum(abs_diff > 1e-5)),
            'elements_gt_1e4': int(np.sum(abs_diff > 1e-4))
        }
    
    result_file = output_dir / "eai_inference_comparison.json"
    with open(result_file, 'w', encoding='utf-8') as f:
        json.dump(comparison_result, f, indent=2, ensure_ascii=False)
    
    print(f"✅ 对比结果已保存: {result_file}")


def analyze_reference_data_only():
    """仅分析参考数据"""
    print("\n📊 分析参考数据...")

    try:
        reference_data = load_reference_data()
        ref_output = reference_data['encoder_output']

        print(f"\n参考数据详细分析:")
        print(f"  形状: {ref_output.shape}")
        print(f"  数值范围: [{ref_output.min():.6f}, {ref_output.max():.6f}]")
        print(f"  平均值: {ref_output.mean():.6f}")
        print(f"  标准差: {ref_output.std():.6f}")

        # 检查前几帧的前几维
        print(f"\n前5帧的前10维数据:")
        for frame in range(min(5, ref_output.shape[1])):
            frame_data = ref_output[0, frame, :10]
            print(f"  帧{frame}: {frame_data}")

        # 检查数据分布
        print(f"\n数据分布分析:")
        print(f"  零值数量: {np.sum(ref_output == 0)}")
        print(f"  负值数量: {np.sum(ref_output < 0)}")
        print(f"  大于1的值数量: {np.sum(ref_output > 1)}")

        # 保存分析结果
        output_dir = Path("python/debug_results")
        output_dir.mkdir(exist_ok=True)

        analysis_result = {
            'shape': list(ref_output.shape),
            'stats': {
                'min': float(ref_output.min()),
                'max': float(ref_output.max()),
                'mean': float(ref_output.mean()),
                'std': float(ref_output.std())
            },
            'distribution': {
                'zero_count': int(np.sum(ref_output == 0)),
                'negative_count': int(np.sum(ref_output < 0)),
                'gt_one_count': int(np.sum(ref_output > 1))
            },
            'first_5_frames_10_dims': ref_output[0, :5, :10].tolist()
        }

        result_file = output_dir / "reference_data_analysis.json"
        with open(result_file, 'w', encoding='utf-8') as f:
            json.dump(analysis_result, f, indent=2, ensure_ascii=False)

        print(f"\n✅ 参考数据分析完成，结果保存至: {result_file}")
        return True

    except Exception as e:
        print(f"❌ 参考数据分析失败: {e}")
        return False


def main():
    """主函数"""
    print("🚀 开始验证eAI推理结果")
    print("=" * 80)

    try:
        # 1. 加载参考数据
        reference_data = load_reference_data()

        # 2. 尝试加载C实现推理结果
        inference_data = load_c_inference_result()

        if inference_data is None:
            print("\n⚠️  未找到C实现推理结果，仅分析参考数据")
            return 0 if analyze_reference_data_only() else -1

        # 3. 对比结果
        is_consistent = compare_results(reference_data, inference_data)

        # 4. 分析统计信息
        analyze_data_statistics(reference_data, inference_data)

        # 5. 保存对比结果
        save_comparison_results(reference_data, inference_data, is_consistent)

        # 6. 总结
        print("\n" + "=" * 80)
        if is_consistent:
            print("✅ eAI推理结果验证通过!")
            print("   C实现输出与参考数据一致")
        else:
            print("❌ eAI推理结果验证失败!")
            print("   C实现输出与参考数据存在差异")
            print("   建议检查:")
            print("   - 模型文件是否正确加载")
            print("   - 输入数据预处理是否一致")
            print("   - 量化/反量化精度")
            print("   - eAI推理配置参数")

        return 0 if is_consistent else -1

    except Exception as e:
        print(f"❌ 验证过程出错: {e}")
        import traceback
        traceback.print_exc()
        return -1


if __name__ == "__main__":
    exit(main())
