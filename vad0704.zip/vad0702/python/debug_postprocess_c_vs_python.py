#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
VAD后处理详细调试脚本
逐步分析encoder_output数据，输出详细调试信息，与C语言版本对比
"""

import numpy as np
import math

def load_encoder_output(npz_path):
    """加载编码器输出数据"""
    print(f"🔄 加载编码器输出: {npz_path}")
    
    # 直接加载对应的.raw文件
    raw_path = npz_path.replace('.npz', '.raw')
    meta_path = npz_path.replace('.npz', '.meta')
    
    try:
        # 读取元数据 (格式: shape = (1, 644, 248))
        with open(meta_path, 'r') as f:
            lines = f.readlines()
            
        # 解析shape信息
        shape_line = [line for line in lines if line.startswith('shape =')][0]
        shape_str = shape_line.split('=')[1].strip()
        # 移除括号并解析
        shape_str = shape_str.strip('()')
        shape_parts = [int(x.strip()) for x in shape_str.split(',')]
        
        batch_size, num_frames, output_dim = shape_parts
        print(f"  元数据: {batch_size} × {num_frames}帧 × {output_dim}维")
        
        # 读取原始数据
        data = np.fromfile(raw_path, dtype=np.float32)
        data = data.reshape(batch_size, num_frames, output_dim)
        # 取第一个batch
        data = data[0]  # [num_frames, output_dim]
        
        print(f"  数据形状: {data.shape}")
        print(f"  数值范围: [{data.min():.6f}, {data.max():.6f}]")
        print(f"  平均值: {data.mean():.6f}")
        
        return data
        
    except Exception as e:
        print(f"❌ 加载失败: {e}")
        return None

def extract_vad_logits_debug(encoder_output):
    """提取VAD logits并详细调试输出"""
    print(f"\n=== 步骤1: 提取VAD Logits ===")
    
    # 提取前2维
    vad_logits = encoder_output[:, :2]  # [num_frames, 2]
    num_frames = vad_logits.shape[0]
    
    print(f"VAD logits形状: {vad_logits.shape}")
    print(f"前5帧原始logits:")
    for i in range(min(5, num_frames)):
        sil_logit = vad_logits[i, 0]
        speech_logit = vad_logits[i, 1]
        print(f"  帧{i:3d}: 静音logit={sil_logit:.6f}, 语音logit={speech_logit:.6f}")
    
    return vad_logits

def compute_probabilities_debug(vad_logits):
    """计算概率并详细调试输出"""
    print(f"\n=== 步骤2: 计算概率 (Softmax) ===")
    
    num_frames = vad_logits.shape[0]
    sil_probs = np.zeros(num_frames)
    speech_probs = np.zeros(num_frames)
    
    print(f"Softmax计算过程:")
    print(f"  公式: softmax(x_i) = exp(x_i) / sum(exp(x_j))")
    
    for i in range(num_frames):
        sil_logit = vad_logits[i, 0]
        speech_logit = vad_logits[i, 1]
        
        # Softmax计算
        exp_sil = np.exp(sil_logit)
        exp_speech = np.exp(speech_logit)
        sum_exp = exp_sil + exp_speech
        
        sil_prob = exp_sil / sum_exp
        speech_prob = exp_speech / sum_exp
        
        sil_probs[i] = sil_prob
        speech_probs[i] = speech_prob
        
        # 打印前20帧和关键帧的详细信息
        if i < 20 or i == 150 or i % 50 == 0:
            print(f"  帧{i:3d}: logit[{sil_logit:.6f}, {speech_logit:.6f}] -> "
                  f"exp[{exp_sil:.6f}, {exp_speech:.6f}] -> "
                  f"prob[{sil_prob:.6f}, {speech_prob:.6f}] (sum={sil_prob+speech_prob:.6f})")
    
    # 统计信息
    print(f"\n概率统计:")
    print(f"  静音概率范围: [{sil_probs.min():.6f}, {sil_probs.max():.6f}]")
    print(f"  语音概率范围: [{speech_probs.min():.6f}, {speech_probs.max():.6f}]")
    print(f"  静音概率均值: {sil_probs.mean():.6f}")
    print(f"  语音概率均值: {speech_probs.mean():.6f}")
    
    return sil_probs, speech_probs

def classify_frames_debug(sil_probs, speech_probs, speech_noise_thres=0.6, speech_2_noise_ratio=1.0):
    """阈值分类并详细调试输出"""
    print(f"\n=== 步骤3: 阈值分类 ===")
    print(f"参数: speech_noise_thres={speech_noise_thres}, speech_2_noise_ratio={speech_2_noise_ratio}")
    
    num_frames = len(sil_probs)
    frame_states = np.zeros(num_frames, dtype=int)  # 0=静音, 1=语音
    speech_count = 0
    
    print(f"阈值计算公式: threshold = sil_prob * speech_2_noise_ratio + speech_noise_thres")
    print(f"判断条件: speech_prob > threshold 则为语音")
    print(f"\n详细分类过程:")
    
    for i in range(num_frames):
        sil_prob = sil_probs[i]
        speech_prob = speech_probs[i]
        
        # 阈值计算
        threshold = sil_prob * speech_2_noise_ratio + speech_noise_thres
        
        # 判断
        is_speech = speech_prob > threshold
        frame_states[i] = 1 if is_speech else 0
        
        if is_speech:
            speech_count += 1
        
        # 打印前20帧和关键帧
        if i < 20 or i == 150 or i % 50 == 0:
            print(f"  帧{i:3d} ({i*10:4d}ms): 静音={sil_prob:.4f}, 语音={speech_prob:.4f}, "
                  f"阈值={threshold:.4f}, 判断={'语音' if is_speech else '静音'}")
    
    speech_ratio = speech_count / num_frames
    print(f"\n分类结果:")
    print(f"  语音帧数: {speech_count}/{num_frames} ({speech_ratio*100:.1f}%)")
    
    return frame_states, speech_count

def analyze_critical_frames(sil_probs, speech_probs, frame_states, critical_frames=[150, 200, 250, 300]):
    """分析关键帧的详细信息"""
    print(f"\n=== 关键帧详细分析 ===")
    
    for frame_idx in critical_frames:
        if frame_idx < len(sil_probs):
            sil_prob = sil_probs[frame_idx]
            speech_prob = speech_probs[frame_idx]
            threshold = sil_prob * 1.0 + 0.6  # 使用默认参数
            state = frame_states[frame_idx]
            
            print(f"帧{frame_idx} ({frame_idx*10}ms):")
            print(f"  静音概率: {sil_prob:.6f}")
            print(f"  语音概率: {speech_prob:.6f}")
            print(f"  阈值: {threshold:.6f}")
            print(f"  speech_prob > threshold: {speech_prob:.6f} > {threshold:.6f} = {speech_prob > threshold}")
            print(f"  分类结果: {'语音' if state == 1 else '静音'}")
            print()

def debug_c_vs_python_comparison():
    """C语言版本 vs Python版本对比调试"""
    print("🔍 C语言 vs Python版本逐步对比")
    print("=" * 80)
    
    # 加载数据
    encoder_output = load_encoder_output("data/encoder_output.npz")
    if encoder_output is None:
        return
    
    # 步骤1: 提取VAD logits
    vad_logits = extract_vad_logits_debug(encoder_output)
    
    # 步骤2: 计算概率
    sil_probs, speech_probs = compute_probabilities_debug(vad_logits)
    
    # 步骤3: 阈值分类
    frame_states, speech_count = classify_frames_debug(sil_probs, speech_probs)
    
    # 步骤4: 关键帧分析
    analyze_critical_frames(sil_probs, speech_probs, frame_states)
    
    # 与C语言输出对比
    print(f"=" * 80)
    print(f"📊 Python版本结果总结:")
    print(f"  总帧数: {len(sil_probs)}")
    print(f"  语音帧数: {speech_count}")
    print(f"  语音比例: {speech_count/len(sil_probs)*100:.1f}%")
    print(f"  静音概率范围: [{sil_probs.min():.6f}, {sil_probs.max():.6f}]")
    print(f"  语音概率范围: [{speech_probs.min():.6f}, {speech_probs.max():.6f}]")
    
    print(f"\n🔍 C语言版本问题分析:")
    print(f"根据C语言输出，发现以下问题:")
    print(f"1. 静音概率范围: [0.501926, 0.704964] - 看起来正常")
    print(f"2. 阈值计算: 帧150阈值=1.1136 - 这不对！应该远小于1.0")
    print(f"3. 语音帧数: 0/644 - 完全错误")
    
    print(f"\n💡 问题可能在于:")
    print(f"1. Softmax计算错误")
    print(f"2. 阈值计算公式错误")
    print(f"3. 概率数值范围不对")

if __name__ == "__main__":
    debug_c_vs_python_comparison() 