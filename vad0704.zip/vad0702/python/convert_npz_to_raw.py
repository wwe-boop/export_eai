#!/usr/bin/env python3
"""
NPZ转原始二进制数据转换器
将sa1_eai_encoder_output.npz转换为C语言可以直接读取的原始二进制文件
"""

import numpy as np
import sys
import os

def convert_npz_to_raw(npz_file, output_file):
    """
    将NPZ文件转换为原始二进制文件
    """
    print(f"🔄 转换NPZ文件: {npz_file} -> {output_file}")
    
    # 加载NPZ文件
    try:
        data = np.load(npz_file)
        print(f"NPZ文件包含键: {list(data.files)}")
        
        # 获取encoder_output数据
        if 'encoder_output' not in data.files:
            print("❌ NPZ文件中未找到encoder_output数据")
            return False
            
        encoder_output = data['encoder_output']
        print(f"encoder_output形状: {encoder_output.shape}")
        print(f"encoder_output数据类型: {encoder_output.dtype}")
        print(f"encoder_output数据大小: {encoder_output.nbytes} 字节")
        print(f"数值范围: [{encoder_output.min():.6f}, {encoder_output.max():.6f}]")
        
        # 确保是float32类型
        if encoder_output.dtype != np.float32:
            print(f"⚠️  转换数据类型从 {encoder_output.dtype} 到 float32")
            encoder_output = encoder_output.astype(np.float32)
        
        # 保存为原始二进制文件
        encoder_output.tofile(output_file)
        
        # 验证文件大小
        file_size = os.path.getsize(output_file)
        expected_size = encoder_output.nbytes
        
        print(f"✅ 转换完成")
        print(f"  输出文件: {output_file}")
        print(f"  文件大小: {file_size} 字节")
        print(f"  期望大小: {expected_size} 字节")
        
        if file_size != expected_size:
            print("❌ 文件大小不匹配!")
            return False
            
        return True
        
    except Exception as e:
        print(f"❌ 转换失败: {e}")
        return False

def create_metadata_file(npz_file, metadata_file):
    """
    创建元数据文件，包含数组的维度信息
    """
    try:
        data = np.load(npz_file)
        encoder_output = data['encoder_output']
        
        metadata = {
            'shape': encoder_output.shape,
            'dtype': str(encoder_output.dtype),
            'nbytes': encoder_output.nbytes,
            'min_val': float(encoder_output.min()),
            'max_val': float(encoder_output.max()),
            'mean_val': float(encoder_output.mean())
        }
        
        with open(metadata_file, 'w') as f:
            f.write("# encoder_output元数据\n")
            f.write(f"shape = {metadata['shape']}\n")
            f.write(f"dtype = {metadata['dtype']}\n")
            f.write(f"nbytes = {metadata['nbytes']}\n")
            f.write(f"min_val = {metadata['min_val']:.6f}\n")
            f.write(f"max_val = {metadata['max_val']:.6f}\n")
            f.write(f"mean_val = {metadata['mean_val']:.6f}\n")
        
        print(f"✅ 元数据文件创建: {metadata_file}")
        return True
        
    except Exception as e:
        print(f"❌ 创建元数据失败: {e}")
        return False

def main():
    # 文件路径
    npz_file = "python/ref_result/sa1_eai_encoder_output.npz"
    raw_file = "python/ref_result/sa1_eai_encoder_output.raw"
    metadata_file = "python/ref_result/sa1_eai_encoder_output.meta"
    
    print("🚀 NPZ转原始二进制数据转换器")
    print("=" * 50)
    
    # 检查输入文件
    if not os.path.exists(npz_file):
        print(f"❌ 输入文件不存在: {npz_file}")
        return 1
    
    # 转换NPZ到原始二进制
    if not convert_npz_to_raw(npz_file, raw_file):
        return 1
    
    # 创建元数据文件
    if not create_metadata_file(npz_file, metadata_file):
        return 1
    
    print("\n🎉 转换完成!")
    print(f"原始数据文件: {raw_file}")
    print(f"元数据文件: {metadata_file}")
    print("\nC代码现在可以直接读取 .raw 文件")
    
    return 0

if __name__ == "__main__":
    sys.exit(main()) 