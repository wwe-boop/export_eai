#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
详细对比C实现eAI编码器输出与Python参考结果
"""

import numpy as np
import json
from pathlib import Path

def load_python_reference():
    """加载Python参考数据"""
    print("🔄 加载Python参考数据...")
    
    data = np.load('python/ref_result/sa1_eai_encoder_output.npz')
    encoder_output = data['encoder_output']  # [1, 644, 248]
    
    print(f"✅ Python参考数据:")
    print(f"   形状: {encoder_output.shape}")
    print(f"   数值范围: [{encoder_output.min():.6f}, {encoder_output.max():.6f}]")
    print(f"   平均值: {encoder_output.mean():.6f}")
    print(f"   标准差: {encoder_output.std():.6f}")
    
    return encoder_output

def load_c_implementation_output():
    """加载C实现输出数据"""
    print("\n🔄 加载C实现输出数据...")
    
    c_output_file = "build/eai_encoder_test_output.txt"
    
    if not Path(c_output_file).exists():
        print(f"❌ C输出文件不存在: {c_output_file}")
        return None
    
    # 解析C输出文件
    data_lines = []
    with open(c_output_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) >= 249:  # frame_index + 248 features
                    frame_idx = int(parts[0])
                    features = [float(x) for x in parts[1:249]]
                    data_lines.append(features)
    
    if not data_lines:
        print("❌ 未找到有效的数据行")
        return None
    
    # 转换为numpy数组
    c_output = np.array(data_lines)
    c_output = c_output[np.newaxis, :]  # 添加batch维度 [1, frames, 248]
    
    print(f"✅ C实现输出数据:")
    print(f"   形状: {c_output.shape}")
    print(f"   数值范围: [{c_output.min():.6f}, {c_output.max():.6f}]")
    print(f"   平均值: {c_output.mean():.6f}")
    print(f"   标准差: {c_output.std():.6f}")
    
    return c_output

def analyze_data_issues(c_output):
    """分析C输出数据的问题"""
    print("\n🔍 分析C输出数据问题...")
    
    # 检查异常值
    inf_count = np.sum(np.isinf(c_output))
    nan_count = np.sum(np.isnan(c_output))
    large_values = np.sum(np.abs(c_output) > 1e6)
    zero_count = np.sum(c_output == 0.0)
    
    print(f"   无穷大值数量: {inf_count}")
    print(f"   NaN值数量: {nan_count}")
    print(f"   大于1e6的值数量: {large_values}")
    print(f"   零值数量: {zero_count} / {c_output.size} ({zero_count/c_output.size*100:.1f}%)")
    
    # 找出最大值的位置
    max_val = c_output.max()
    max_pos = np.unravel_index(c_output.argmax(), c_output.shape)
    print(f"   最大值: {max_val:.2e} 位置: {max_pos}")
    
    # 检查前几帧的数据
    print(f"\n   前5帧的前10维数据:")
    for i in range(min(5, c_output.shape[1])):
        frame_data = c_output[0, i, :10]
        print(f"     帧{i}: {frame_data}")
        
        # 检查是否有异常值
        if np.any(np.abs(frame_data) > 1e6):
            print(f"       ⚠️  帧{i}包含异常大值!")

def compare_with_reference(python_ref, c_output):
    """与参考数据对比"""
    print("\n📊 与Python参考数据对比...")
    
    if python_ref.shape != c_output.shape:
        print(f"❌ 形状不匹配: Python{python_ref.shape} vs C{c_output.shape}")
        return False
    
    # 计算差异
    abs_diff = np.abs(python_ref - c_output)
    max_diff = abs_diff.max()
    mean_diff = abs_diff.mean()
    
    print(f"   最大绝对差异: {max_diff:.2e}")
    print(f"   平均绝对差异: {mean_diff:.2e}")
    
    # 检查差异分布
    large_diff_count = np.sum(abs_diff > 1.0)
    print(f"   差异>1.0的元素数量: {large_diff_count} / {abs_diff.size}")
    
    # 相对误差分析
    # 避免除零，只对非零参考值计算相对误差
    nonzero_mask = python_ref != 0
    if np.any(nonzero_mask):
        rel_error = abs_diff[nonzero_mask] / np.abs(python_ref[nonzero_mask])
        max_rel_error = rel_error.max()
        mean_rel_error = rel_error.mean()
        print(f"   最大相对误差: {max_rel_error:.2e}")
        print(f"   平均相对误差: {mean_rel_error:.2e}")
    
    return max_diff < 1e-3  # 设置一个宽松的阈值

def diagnose_c_implementation():
    """诊断C实现问题"""
    print("\n🔧 C实现问题诊断...")
    
    print("可能的问题原因:")
    print("1. 🔴 量化/反量化错误")
    print("   - eAI推理输出的量化数据未正确反量化")
    print("   - 量化scale参数错误")
    
    print("2. 🔴 数据类型转换错误")
    print("   - int8/int16到float32转换问题")
    print("   - 字节序问题")
    
    print("3. 🔴 内存访问错误")
    print("   - 缓冲区越界")
    print("   - 未初始化的内存")
    
    print("4. 🔴 eAI推理配置错误")
    print("   - 输入数据格式不正确")
    print("   - 模型加载问题")
    
    print("\n建议的调试步骤:")
    print("1. 检查量化参数设置")
    print("2. 验证eAI推理的原始输出（量化前）")
    print("3. 检查数据类型转换代码")
    print("4. 添加更多调试输出")

def save_comparison_report(python_ref, c_output, is_consistent):
    """保存对比报告"""
    print("\n💾 保存对比报告...")
    
    output_dir = Path("python/debug_results")
    output_dir.mkdir(exist_ok=True)
    
    report = {
        "comparison_summary": {
            "is_consistent": bool(is_consistent),
            "python_reference": {
                "shape": list(python_ref.shape),
                "min": float(python_ref.min()),
                "max": float(python_ref.max()),
                "mean": float(python_ref.mean()),
                "std": float(python_ref.std())
            },
            "c_implementation": {
                "shape": list(c_output.shape),
                "min": float(c_output.min()),
                "max": float(c_output.max()),
                "mean": float(c_output.mean()),
                "std": float(c_output.std())
            }
        },
        "data_quality_issues": {
            "inf_count": int(np.sum(np.isinf(c_output))),
            "nan_count": int(np.sum(np.isnan(c_output))),
            "large_values_count": int(np.sum(np.abs(c_output) > 1e6)),
            "zero_count": int(np.sum(c_output == 0.0)),
            "total_elements": int(c_output.size)
        }
    }
    
    if python_ref.shape == c_output.shape:
        abs_diff = np.abs(python_ref - c_output)
        report["difference_analysis"] = {
            "max_abs_diff": float(abs_diff.max()),
            "mean_abs_diff": float(abs_diff.mean()),
            "large_diff_count": int(np.sum(abs_diff > 1.0))
        }
    
    report_file = output_dir / "detailed_comparison_report.json"
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    print(f"✅ 对比报告已保存: {report_file}")

def main():
    """主函数"""
    print("🚀 详细对比分析：C实现 vs Python参考")
    print("=" * 80)
    
    try:
        # 1. 加载Python参考数据
        python_ref = load_python_reference()
        
        # 2. 加载C实现输出
        c_output = load_c_implementation_output()
        if c_output is None:
            return -1
        
        # 3. 分析C输出数据问题
        analyze_data_issues(c_output)
        
        # 4. 与参考数据对比
        is_consistent = compare_with_reference(python_ref, c_output)
        
        # 5. 诊断问题
        diagnose_c_implementation()
        
        # 6. 保存报告
        save_comparison_report(python_ref, c_output, is_consistent)
        
        # 7. 总结
        print("\n" + "=" * 80)
        print("📋 对比分析总结:")
        if is_consistent:
            print("✅ C实现与Python参考数据一致")
        else:
            print("❌ C实现与Python参考数据存在重大差异")
            print("🔧 需要修复C实现中的量化/反量化或数据转换问题")
        
        return 0 if is_consistent else -1
        
    except Exception as e:
        print(f"❌ 对比分析出错: {e}")
        import traceback
        traceback.print_exc()
        return -1

if __name__ == "__main__":
    exit(main())
