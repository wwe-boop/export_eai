#!/usr/bin/env python3
"""
统一的Python测试文件
整合了所有Python测试功能，用于验证C语言实现的正确性
"""
import torch
import torchaudio
import torchaudio.compliance.kaldi as kaldi
import numpy as np
import json
import os
from frontend_core import AudioFrontend

def test_basic_fbank():
    """基础Fbank特征提取测试"""
    print("=== 基础Fbank特征提取测试 ===")
    
    # 加载音频
    waveform, sample_rate = torchaudio.load("../testsrc/sa1.wav")
    waveform_scaled = waveform * (1 << 15)
    
    # 参数设置（与C语言一致）
    params = {
        'num_mel_bins': 80,
        'frame_length': 25.0,
        'frame_shift': 10.0,
        'dither': 0.0,
        'energy_floor': 0.0,
        'window_type': 'hamming',
        'sample_frequency': 16000.0,
        'snip_edges': True,
        'low_freq': 20.0,
        'high_freq': 8000.0,
        'use_log_fbank': True,
        'use_power': True,
        'preemphasis_coefficient': 0.97,
        'remove_dc_offset': True
    }
    
    # 提取Fbank特征
    fbank_features = kaldi.fbank(waveform_scaled, **params)
    
    print(f"Fbank特征: shape={fbank_features.shape}")
    print(f"  范围: min={fbank_features.min():.6f}, max={fbank_features.max():.6f}")
    print(f"  均值: {fbank_features.mean():.6f}")
    print(f"  前5个值: {fbank_features[0, :5].tolist()}")
    
    return fbank_features, params

def test_lfr_processing():
    """LFR处理测试"""
    print("\n=== LFR处理测试 ===")
    
    # 获取基础Fbank特征
    fbank_features, params = test_basic_fbank()
    
    # LFR参数
    lfr_m = 5
    lfr_n = 1
    
    # 执行LFR处理
    num_frames = fbank_features.shape[0]
    num_features = fbank_features.shape[1]
    
    # 计算LFR输出帧数
    lfr_frames = (num_frames - lfr_m + lfr_n) // lfr_n
    lfr_features = torch.zeros(lfr_frames, num_features * lfr_m)
    
    for i in range(lfr_frames):
        start_frame = i * lfr_n
        for j in range(lfr_m):
            frame_idx = start_frame + j
            if frame_idx < num_frames:
                lfr_features[i, j*num_features:(j+1)*num_features] = fbank_features[frame_idx]
    
    print(f"LFR特征: shape={lfr_features.shape}")
    print(f"  范围: min={lfr_features.min():.6f}, max={lfr_features.max():.6f}")
    print(f"  均值: {lfr_features.mean():.6f}")
    
    return lfr_features

def test_cmvn_processing():
    """CMVN处理测试"""
    print("\n=== CMVN处理测试 ===")
    
    # 获取LFR特征
    lfr_features = test_lfr_processing()
    
    # 模拟CMVN参数（实际应该从am.mvn文件加载）
    mean = torch.zeros(lfr_features.shape[1])
    var = torch.ones(lfr_features.shape[1])
    
    # 执行CMVN归一化
    cmvn_features = (lfr_features - mean) / torch.sqrt(var)
    
    print(f"CMVN特征: shape={cmvn_features.shape}")
    print(f"  范围: min={cmvn_features.min():.6f}, max={cmvn_features.max():.6f}")
    print(f"  均值: {cmvn_features.mean():.6f}")
    
    return cmvn_features

def test_frontend_core():
    """测试完整的前端处理流程"""
    print("\n=== 完整前端处理流程测试 ===")
    
    # 初始化前端处理器
    frontend = AudioFrontend(
        cmvn_file="../models/am.mvn",
        fs=16000,
        window='hamming',
        n_mels=80,
        frame_length=25,
        frame_shift=10,
        lfr_m=5,
        lfr_n=1,
        log_file="ref_result/sa1_frontend_steps.json"
    )
    
    # 加载音频
    waveform, sample_rate = torchaudio.load("../testsrc/sa1.wav")
    
    # 处理音频
    with torch.no_grad():
        input_lengths = torch.tensor([waveform.shape[1]])
        waveform = waveform.unsqueeze(0)  # 添加batch维度
        features, features_lengths = frontend(waveform, input_lengths)
    
    print(f"前端处理完成:")
    print(f"  输出特征: shape={features.shape}")
    print(f"  特征长度: {features_lengths}")
    print(f"  范围: min={features.min():.6f}, max={features.max():.6f}")
    print(f"  均值: {features.mean():.6f}")
    
    return features, features_lengths

def save_unified_results():
    """保存统一的测试结果"""
    print("\n=== 保存统一测试结果 ===")
    
    # 执行所有测试
    fbank_features, params = test_basic_fbank()
    lfr_features = test_lfr_processing()
    cmvn_features = test_cmvn_processing()
    
    try:
        frontend_features, frontend_lengths = test_frontend_core()
    except Exception as e:
        print(f"前端处理器测试失败: {e}")
        frontend_features = None
        frontend_lengths = None
    
    # 保存结果
    results = {
        'fbank_features': fbank_features,
        'lfr_features': lfr_features,
        'cmvn_features': cmvn_features,
        'frontend_features': frontend_features,
        'frontend_lengths': frontend_lengths,
        'parameters': params
    }
    
    torch.save(results, 'unified_test_results.pt')
    print("统一测试结果已保存到 unified_test_results.pt")
    
    return results

def main():
    """主测试函数"""
    print("开始统一Python测试...")
    
    # 确保输出目录存在
    os.makedirs("ref_result", exist_ok=True)
    
    # 执行所有测试并保存结果
    results = save_unified_results()
    
    print("\n=== 测试总结 ===")
    print("所有Python测试已完成，结果已保存")
    print("可用于与C语言实现进行对比验证")

if __name__ == "__main__":
    main()
