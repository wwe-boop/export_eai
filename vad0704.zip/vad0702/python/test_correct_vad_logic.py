#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试正确的VAD后处理逻辑
基于encoder_eai.py的标准实现
"""

import numpy as np
import torch
import torch.nn.functional as F

def load_c_encoder_output():
    """加载C实现的编码器输出"""
    print("🔄 加载C实现的编码器输出...")
    
    # 从main程序的输出中我们知道正确的数值范围
    # 但文件可能还是旧的，我们需要重新生成
    
    # 先尝试加载Python参考数据作为测试
    ref_file = "ref_result/sa1_eai_encoder_output.npz"
    data = np.load(ref_file)
    encoder_output = data['encoder_output']  # [1, 644, 248]
    
    print(f"✅ 编码器输出形状: {encoder_output.shape}")
    print(f"   数值范围: [{encoder_output.min():.6f}, {encoder_output.max():.6f}]")
    print(f"   平均值: {encoder_output.mean():.6f}")
    
    return encoder_output

def test_standard_vad_logic(encoder_output, speech_threshold=0.5):
    """测试标准VAD逻辑（基于encoder_eai.py）"""
    print(f"\n🔍 测试标准VAD逻辑 (阈值={speech_threshold})")
    
    # 转换为torch tensor
    if isinstance(encoder_output, np.ndarray):
        encoder_tensor = torch.from_numpy(encoder_output).float()
    else:
        encoder_tensor = encoder_output
    
    # 1. 提取前2维作为VAD logits
    vad_logits = encoder_tensor[:, :, :2]  # [1, 644, 2]
    print(f"VAD logits形状: {vad_logits.shape}")
    print(f"VAD logits范围: [{vad_logits.min():.6f}, {vad_logits.max():.6f}]")
    
    # 2. 应用softmax获取概率
    vad_probs = torch.softmax(vad_logits, dim=-1)  # [1, 644, 2]
    sil_probs = vad_probs[:, :, 0]  # 静音概率
    speech_probs = vad_probs[:, :, 1]  # 语音概率
    
    print(f"静音概率范围: [{sil_probs.min():.6f}, {sil_probs.max():.6f}]")
    print(f"语音概率范围: [{speech_probs.min():.6f}, {speech_probs.max():.6f}]")
    print(f"语音概率均值: {speech_probs.mean():.6f}")
    
    # 3. 应用阈值检测
    speech_frames = (speech_probs > speech_threshold).float()
    speech_count = speech_frames.sum().item()
    total_frames = speech_frames.numel()
    speech_ratio = speech_count / total_frames
    
    print(f"语音帧数: {speech_count}/{total_frames} ({speech_ratio*100:.1f}%)")
    
    # 4. 提取语音段
    speech_frames_1d = speech_frames[0].numpy()  # [644]
    segments = extract_speech_segments(speech_frames_1d)
    
    print(f"检测到语音段: {len(segments)}个")
    for i, (start, end) in enumerate(segments):
        duration_ms = (end - start) * 10  # 每帧10ms
        print(f"  语音段{i+1}: {start*10}-{end*10}ms (时长: {duration_ms}ms)")
    
    return {
        'vad_logits': vad_logits.numpy(),
        'vad_probs': vad_probs.numpy(),
        'speech_probs': speech_probs.numpy(),
        'speech_frames': speech_frames.numpy(),
        'speech_ratio': speech_ratio,
        'segments': segments
    }

def extract_speech_segments(speech_frames, min_duration=10):
    """提取语音段"""
    segments = []
    start_frame = None
    
    for i, is_speech in enumerate(speech_frames):
        if is_speech and start_frame is None:
            # 语音段开始
            start_frame = i
        elif not is_speech and start_frame is not None:
            # 语音段结束
            if i - start_frame >= min_duration:
                segments.append((start_frame, i))
            start_frame = None
    
    # 处理最后一个语音段
    if start_frame is not None:
        if len(speech_frames) - start_frame >= min_duration:
            segments.append((start_frame, len(speech_frames)))
    
    return segments

def test_different_thresholds(encoder_output):
    """测试不同阈值的效果"""
    print(f"\n🔍 测试不同阈值的效果")
    
    thresholds = [0.3, 0.4, 0.5, 0.6, 0.7]
    
    for threshold in thresholds:
        result = test_standard_vad_logic(encoder_output, threshold)
        print(f"阈值{threshold}: {len(result['segments'])}个语音段, 语音比例{result['speech_ratio']*100:.1f}%")

def compare_with_python_reference():
    """与Python参考结果对比"""
    print(f"\n🔍 与Python参考结果对比")
    
    # 加载Python参考的后处理结果
    try:
        with open("ref_result/post_process.txt.txt", 'r') as f:
            lines = f.readlines()
        
        # 查找语音段信息
        for line in lines:
            if "检测到语音段" in line:
                print(f"Python参考: {line.strip()}")
                break
    except:
        print("无法加载Python参考结果")

def main():
    """主函数"""
    print("🔍 测试正确的VAD后处理逻辑")
    print("=" * 80)
    
    # 1. 加载编码器输出
    encoder_output = load_c_encoder_output()
    
    # 2. 测试标准VAD逻辑
    result = test_standard_vad_logic(encoder_output, speech_threshold=0.5)
    
    # 3. 测试不同阈值
    test_different_thresholds(encoder_output)
    
    # 4. 与Python参考对比
    compare_with_python_reference()
    
    # 5. 总结
    print("\n" + "=" * 80)
    print("📋 分析总结:")
    print(f"   使用标准逻辑(阈值0.5): {len(result['segments'])}个语音段")
    print(f"   语音比例: {result['speech_ratio']*100:.1f}%")
    
    if len(result['segments']) > 0:
        print("✅ 检测到语音段，逻辑正确")
    else:
        print("❌ 未检测到语音段，需要调整阈值或检查数据")

if __name__ == "__main__":
    main()
