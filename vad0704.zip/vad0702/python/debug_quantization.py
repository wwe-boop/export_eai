#!/usr/bin/env python3
"""
量化参数调试脚本
分析C实现和Python参考之间的差异，重点关注量化/反量化问题
"""

import numpy as np
import json
from pathlib import Path

def load_c_implementation_output():
    """加载C实现输出数据"""
    print("\n🔄 加载C实现输出数据...")
    
    c_output_file = "build/eai_encoder_test_output.txt"
    
    if not Path(c_output_file).exists():
        print(f"❌ C输出文件不存在: {c_output_file}")
        return None
    
    # 解析C输出文件
    data_lines = []
    with open(c_output_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) >= 249:  # frame_index + 248 features
                    frame_idx = int(parts[0])
                    features = [float(x) for x in parts[1:249]]
                    data_lines.append(features)
    
    if not data_lines:
        print("❌ 未找到有效的数据行")
        return None
    
    # 转换为numpy数组
    c_output = np.array(data_lines)
    c_output = c_output[np.newaxis, :]  # 添加batch维度 [1, frames, 248]
    
    print(f"✅ C实现输出数据:")
    print(f"   形状: {c_output.shape}")
    print(f"   数值范围: [{c_output.min():.6f}, {c_output.max():.6f}]")
    print(f"   平均值: {c_output.mean():.6f}")
    print(f"   标准差: {c_output.std():.6f}")
    
    return c_output

def load_python_reference():
    """加载Python参考数据"""
    print("\n🔄 加载Python参考数据...")
    
    ref_file = "python/ref_result/sa1_eai_encoder_output.npz"
    if not Path(ref_file).exists():
        print(f"❌ 参考文件不存在: {ref_file}")
        return None
    
    data = np.load(ref_file)
    python_ref = data['encoder_output']
    
    print(f"✅ Python参考数据:")
    print(f"   形状: {python_ref.shape}")
    print(f"   数值范围: [{python_ref.min():.6f}, {python_ref.max():.6f}]")
    print(f"   平均值: {python_ref.mean():.6f}")
    print(f"   标准差: {python_ref.std():.6f}")
    
    return python_ref

def analyze_quantization_scale():
    """分析量化scale参数"""
    print("\n🔍 分析量化scale参数...")
    
    # 从C代码中使用的默认scale
    default_scale = 0.0004765573082753644
    print(f"C实现使用的默认scale: {default_scale}")
    
    # 加载数据
    c_output = load_c_implementation_output()
    python_ref = load_python_reference()
    
    if c_output is None or python_ref is None:
        return
    
    # 分析第一帧的数据
    print(f"\n📊 第一帧数据对比:")
    c_frame0 = c_output[0, 0, :10]
    py_frame0 = python_ref[0, 0, :10]
    
    print(f"C实现前10个值: {c_frame0}")
    print(f"Python前10个值: {py_frame0}")
    
    # 计算可能的scale因子
    ratios = []
    for i in range(10):
        if c_frame0[i] != 0 and py_frame0[i] != 0:
            ratio = py_frame0[i] / c_frame0[i]
            ratios.append(ratio)
            print(f"  维度{i}: C={c_frame0[i]:.6f}, Py={py_frame0[i]:.6f}, 比值={ratio:.6f}")
    
    if ratios:
        avg_ratio = np.mean(ratios)
        print(f"\n平均比值: {avg_ratio:.6f}")
        print(f"建议的scale修正因子: {avg_ratio:.10f}")
        
        # 尝试用修正因子调整C输出
        corrected_c = c_output * avg_ratio
        
        print(f"\n修正后的C输出:")
        print(f"   数值范围: [{corrected_c.min():.6f}, {corrected_c.max():.6f}]")
        print(f"   平均值: {corrected_c.mean():.6f}")
        
        # 计算修正后的差异
        diff = np.abs(corrected_c - python_ref)
        print(f"   与Python的最大差异: {diff.max():.6f}")
        print(f"   与Python的平均差异: {diff.mean():.6f}")

def analyze_specific_frames():
    """分析特定帧的数据"""
    print("\n🔍 分析特定帧数据...")
    
    c_output = load_c_implementation_output()
    python_ref = load_python_reference()
    
    if c_output is None or python_ref is None:
        return
    
    # 分析几个关键帧
    key_frames = [0, 100, 300, 500, 640, 643]
    
    for frame_idx in key_frames:
        if frame_idx >= c_output.shape[1]:
            continue
            
        print(f"\n帧 {frame_idx}:")
        c_frame = c_output[0, frame_idx, :5]
        py_frame = python_ref[0, frame_idx, :5]
        
        print(f"  C实现: {c_frame}")
        print(f"  Python: {py_frame}")
        
        # 计算差异
        diff = np.abs(c_frame - py_frame)
        rel_diff = diff / (np.abs(py_frame) + 1e-10)
        
        print(f"  绝对差异: {diff}")
        print(f"  相对差异: {rel_diff}")

def main():
    print("🚀 量化参数调试分析")
    print("=" * 80)
    
    analyze_quantization_scale()
    analyze_specific_frames()
    
    print("\n" + "=" * 80)
    print("📋 调试分析完成")

if __name__ == "__main__":
    main()
