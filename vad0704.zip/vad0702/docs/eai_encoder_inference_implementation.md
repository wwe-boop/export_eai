# eAI编码器推理实现方案

## 1. Python参考流程分析

### 1.1 Python实现核心步骤
```python
# 1. 前端特征提取 (已完成的C语言实现)
features = frontend(waveform)  # [1, 644, 400] float32

# 2. EAI编码器推理 (需要实现的部分)
eai_model = create_eai_vad_model(eai_config)
load_eai_model_weights(eai_model, "../fsmn_model/model.pt")
eai_output = eai_model.encoder(features)  # [1, 644, 248] float32
```

### 1.2 关键配置参数
```python
eai_config = {
    'input_dim': 400,      # 输入特征维度
    'output_dim': 248,     # 输出特征维度
    'num_layers': 4,       # FSMN网络层数
    'input_affine_dim': 140,
    'linear_dim': 250,
    'proj_dim': 128,
    'lorder': 20,
    'output_affine_dim': 140
}
```

### 1.3 推理特点
- **直接推理**: 无需上下文缓存，不使用context_frames
- **输入格式**: [时间步, 特征维度] = [644, 400]
- **输出格式**: [时间步, 输出维度] = [644, 248]
- **数据类型**: float32输入，float32输出

## 2. C语言实现方案

### 2.1 实现架构
```
前端特征[644,400] → 量化 → eAI推理 → 反量化 → 编码器输出[644,248]
                   float32  int16    int16   float32
```

### 2.2 核心组件设计

#### 2.2.1 EaiEncoderContext结构体
```c
typedef struct EaiEncoderContext {
    // eAI核心组件
    EaiVadContext* eai_context;         // 复用eai_interfence实现
    
    // 配置参数
    EaiEncoderConfig config;
    
    // 输入输出缓冲区
    float* input_buffer;                // [time_steps, 400]
    float* output_buffer;               // [time_steps, 248]
    int16_t* quantized_input_buffer;    // 量化输入
    int16_t* quantized_output_buffer;   // 量化输出
    
    // 状态管理
    int is_initialized;
    EaiEncoderPerfStats perf_stats;
} EaiEncoderContext;
```

#### 2.2.2 推理接口函数
```c
// 初始化
EaiEncoderContext* eai_encoder_init(const EaiEncoderConfig* config);

// 推理执行
EaiEncoderResult eai_encoder_inference(
    EaiEncoderContext* context,
    const float* features,     // [time_steps, 400]
    int time_steps,
    EaiEncoderInferenceResult* result
);

// 资源释放
void eai_encoder_destroy(EaiEncoderContext* context);
```

### 2.3 实现步骤详解

#### 步骤1: 模型初始化
```c
// 1. 加载eAI模型文件 (.eai格式)
// 2. 初始化eAI运行时环境
// 3. 配置张量信息和内存缓冲区
// 4. 设置量化参数
```

#### 步骤2: 特征预处理
```c
// 1. 验证输入特征格式 [time_steps, 400]
// 2. float32 → int16量化
//    量化公式: int16_value = (int16_t)(float_value / scale)
//    scale = 从模型配置中获取或使用默认值
```

#### 步骤3: eAI推理执行
```c
// 1. 设置输入张量数据
// 2. 调用eai_execute()执行推理
// 3. 获取输出张量数据
```

#### 步骤4: 输出后处理
```c
// 1. int16 → float32反量化
//    反量化公式: float_value = int16_value * scale
// 2. 验证输出格式 [time_steps, 248]
// 3. 返回结果
```

## 3. 数据流验证

### 3.1 输入数据验证
- 特征数据范围: Python参考 [-1.04, 1.10]
- 量化后范围: int16 [-32768, 32767]
- 量化精度要求: 与Python输出差异 < 1e-3

### 3.2 输出数据验证
- 对比基准: `/local/vad0702/python/ref_result/sa1_eai_encoder_output.npz`
- 精度要求: 与Python输出最大差异 < 1e-6
- 输出保存: `build/inference_test_results.txt`

## 4. 复用eai_interfence实现

### 4.1 复用组件
- `EaiVadContext`: eAI推理上下文管理
- `eai_vad_init()`: 模型加载和初始化
- `eai_vad_inference()`: 核心推理执行
- 量化/反量化工具函数

### 4.2 适配修改
- 去除上下文处理逻辑 (无需context_frames)
- 简化输入数据准备流程
- 适配新的接口函数签名

## 5. 测试验证方案

### 5.1 单元测试
- 模型加载测试
- 量化/反量化精度测试
- 推理结果验证

### 5.2 集成测试
- 前端+推理完整流程测试
- 与Python基准结果对比
- 性能测试

### 5.3 测试数据
- 输入: testsrc/sa1.wav 前端特征
- 基准: python/ref_result/sa1_eai_encoder_output.npz
- 输出: build/eai_encoder_test_output.txt 