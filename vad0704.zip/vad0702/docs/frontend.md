# 前端组件实现文档

## 1. 组件概述

前端组件主要负责音频数据的预处理，将原始音频转换为模型所需的特征输入。主要包含以下处理步骤：
1. 音频数据读取和音量放大
2. Fbank特征提取
3. LFR(Low Frame Rate)处理
4. CMVN归一化

## 2. Python实现分析

### 2.1 关键参数
```python
fs = 16000                # 采样率
n_mels = 80              # Mel滤波器数
frame_length = 25        # 帧长(ms)
frame_shift = 10         # 帧移(ms)
window = "hamming"       # 窗函数
n_fft = frame_length * fs / 1000  # FFT点数
dither = 1.0            # 抖动系数
```

### 2.2 处理流程详解

#### 2.2.1 音频数据预处理
```python
# 1. 确保输入是2D张量 [channels, samples]
if waveform.dim() == 1:
    waveform = waveform.unsqueeze(0)
    
# 2. 音量放大
waveform = waveform * (1 << 15)
```

#### 2.2.2 Fbank特征提取
Python使用torchaudio.compliance.kaldi实现Fbank特征提取：
```python
mat = kaldi.fbank(
    waveform,
    num_mel_bins=self.n_mels,
    frame_length=self.frame_length,
    frame_shift=self.frame_shift,
    dither=self.dither,
    energy_floor=0.0,
    window_type=self.window,
    sample_frequency=self.fs,
    snip_edges=self.snip_edges
)
```

#### 2.2.3 LFR处理
LFR(Low Frame Rate)处理用于降低帧率，将连续m帧合并为一帧，每n帧进行一次处理：
```python
T = inputs.shape[0]
T_lfr = int(np.ceil(T / self.lfr_n))
# 处理每一帧
for i in range(T_lfr):
    if self.lfr_m <= T - i * self.lfr_n:
        lfr_outputs.append(
            inputs[i * self.lfr_n : i * self.lfr_n + self.lfr_m].reshape(1, -1)
        )
```

#### 2.2.4 CMVN归一化
CMVN(Cepstral Mean and Variance Normalization)用于特征归一化：
```python
means = self.cmvn[0:1, :dim]  # 均值
vars = self.cmvn[1:2, :dim]   # 方差
inputs = inputs + means
inputs = inputs * vars
```

## 3. C语言实现方案

### 3.1 数据结构设计
```c
typedef struct {
    float *waveform;      // 音频波形数据
    int length;           // 数据长度
    int channels;         // 通道数
} AudioData;

typedef struct {
    int fs;              // 采样率
    int n_mels;          // Mel滤波器数
    int frame_length;    // 帧长
    int frame_shift;     // 帧移
    char *window;        // 窗函数类型
    int n_fft;          // FFT点数
    float dither;       // 抖动系数
    float *cmvn_means;  // CMVN均值
    float *cmvn_vars;   // CMVN方差
} FrontendConfig;
```

### 3.2 关键函数设计
```c
// 1. 初始化前端配置
FrontendConfig* frontend_init(const char* cmvn_file);

// 2. 音频数据预处理
void preprocess_audio(AudioData* audio);

// 3. Fbank特征提取
float* extract_fbank(const AudioData* audio, const FrontendConfig* config);

// 4. LFR处理
float* apply_lfr(const float* features, int m, int n);

// 5. CMVN归一化
void apply_cmvn(float* features, const FrontendConfig* config);

// 6. 资源释放
void frontend_free(FrontendConfig* config);
```

### 3.3 替代方案说明

1. **Fbank特征提取**:
   - 使用FFTW库替代torch的FFT实现
   - 自实现Mel滤波器组
   - 使用查表法优化三角函数计算

2. **内存管理**:
   - 使用内存池管理临时数组
   - 预分配固定大小缓冲区
   - 避免频繁malloc/free

3. **优化策略**:
   - 使用SIMD指令优化向量运算
   - 循环展开提高计算效率
   - 减少不必要的数据拷贝

## 4. 测试验证方案

1. **单元测试**:
   - 每个处理步骤的输入输出验证
   - 边界条件测试
   - 内存泄漏检测

2. **对比测试**:
   - 与Python版本结果对比
   - 误差范围控制
   - 性能测试

3. **测试数据**:
   - 使用sa1.wav作为基准测试音频
   - 记录每个步骤的数值范围
   - 保存中间结果进行对比

## 5. 注意事项

1. 严格按照Python版本的参数设置
2. 确保数值计算精度
3. 做好内存管理
4. 添加详细的日志记录
5. 保持代码可维护性 