#!/bin/bash

# @file build.sh
# @brief eAI模型推理VAD项目构建脚本
# @details 支持清理构建、Linux平台构建等功能
# @author l50011968
# @date 2025.7.2
# @version 1.0.0
# Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.

# 设置错误时退出
set -e

# 默认参数
CLEAN_BUILD=false
BUILD_LINUX=true
BUILD_ENPU_VER=""

# 解析命令行参数
while [[ $# -gt 0 ]]; do
    case $1 in
        --clean_build)
            CLEAN_BUILD=true
            shift
            ;;
        --build_linux)
            BUILD_LINUX=true
            shift
            ;;
        --build_enpu_ver)
            BUILD_ENPU_VER="$2"
            shift 2
            ;;
        *)
            echo "未知参数: $1"
            exit 1
            ;;
    esac
done

# 清理构建目录
if [ "$CLEAN_BUILD" = true ]; then
    echo "清理构建目录..."
    rm -rf build/*
    echo "构建目录已清理"
fi

# 创建构建目录
mkdir -p build

# Linux构建
if [ "$BUILD_LINUX" = true ]; then
    echo "开始Linux构建..."
    echo "ENPU版本: $BUILD_ENPU_VER"
    
    cd build
    
    # CMake配置
    cmake .. -DCMAKE_BUILD_TYPE=Release
    
    # 编译
    make -j$(nproc)
    
    echo "Linux构建完成"
    cd ..
fi

echo "构建脚本执行完成" 