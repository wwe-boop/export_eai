/**
 * @file eai_encoder_inference.h
 * @brief eAI编码器推理引擎接口定义
 * @details 提供eAI编码器推理的完整接口，包括初始化、推理执行和资源管理
 *
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * @copyright Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#ifndef EAI_ENCODER_INFERENCE_H
#define EAI_ENCODER_INFERENCE_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include "inference_config.h"
#include "eai/eai_vad_inference.h"
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// 前向声明
// ============================================================================

typedef struct EaiEncoderContext EaiEncoderContext;

// ============================================================================
// 核心数据结构
// ============================================================================

/**
 * @brief eAI编码器推理上下文结构体
 * 
 * 包含推理所需的所有状态信息，包括eAI上下文、缓冲区、配置参数等
 */
struct EaiEncoderContext {
    // eAI核心组件
    EaiVadContext* eai_context;         /**< eAI VAD推理上下文（复用） */
    
    // 配置参数
    EaiEncoderConfig config;            /**< 推理配置参数 */
    
    // 输入输出缓冲区
    float* input_buffer;                /**< 输入特征缓冲区 [time_steps, 400] */
    float* output_buffer;               /**< 输出特征缓冲区 [time_steps, 248] */
    float* batch_output_buffer;         /**< 批量推理输出缓冲区（大数据量） */
    int16_t* quantized_input_buffer;    /**< 量化输入缓冲区 */
    int16_t* quantized_output_buffer;   /**< 量化输出缓冲区 */
    
    // 缓冲区大小信息
    size_t input_buffer_size;           /**< 输入缓冲区大小（字节） */
    size_t output_buffer_size;          /**< 输出缓冲区大小（字节） */
    size_t quantized_input_size;        /**< 量化输入缓冲区大小（字节） */
    size_t quantized_output_size;       /**< 量化输出缓冲区大小（字节） */
    
    // 当前状态
    int current_input_frames;           /**< 当前输入帧数 */
    int current_output_frames;          /**< 当前输出帧数 */
    int is_initialized;                 /**< 初始化状态标志 */
    
    // 性能统计
    EaiEncoderPerfStats perf_stats;     /**< 性能统计信息 */
    
    // 调试信息
    char last_error_msg[256];           /**< 最后错误信息 */
    int debug_level;                    /**< 调试级别 */
};

/**
 * @brief 推理结果结构体
 */
typedef struct {
    float* encoder_output;              /**< 编码器输出特征 [time_steps, 248] */
    int time_steps;                     /**< 时间步数 */
    int feature_dim;                    /**< 特征维度 */
    EaiEncoderResult result_code;       /**< 结果状态码 */
    uint64_t inference_time_us;         /**< 推理耗时（微秒） */
} EaiEncoderInferenceResult;

// ============================================================================
// 核心接口函数
// ============================================================================

/**
 * @brief 初始化eAI编码器推理上下文
 * 
 * @param config 推理配置参数，包含模型路径等信息
 * @return 初始化成功的推理上下文指针，失败返回NULL
 * 
 * @note 调用者负责调用eai_encoder_destroy()释放资源
 * @warning 模型文件必须存在且可访问
 */
EaiEncoderContext* eai_encoder_init(const EaiEncoderConfig* config);

/**
 * @brief 执行eAI编码器推理
 * 
 * @param context 推理上下文
 * @param features 输入特征数据 [time_steps, 400]，float32类型
 * @param time_steps 输入时间步数
 * @param result 推理结果输出结构体
 * @return 推理结果状态码
 * 
 * @note 输入特征必须是400维的LFR特征
 * @note 输出结果的内存由context管理，调用者不需要释放
 * @warning 确保time_steps不超过max_batch_frames配置
 */
EaiEncoderResult eai_encoder_inference(EaiEncoderContext* context,
                                       const float* features,
                                       int time_steps,
                                       EaiEncoderInferenceResult* result);

/**
 * @brief 批量推理接口（支持大数据量处理）
 * 
 * @param context 推理上下文
 * @param features 输入特征数据 [time_steps, 400]
 * @param time_steps 输入时间步数
 * @param result 推理结果输出结构体
 * @return 推理结果状态码
 * 
 * @note 自动分批处理，适用于大量数据
 */
EaiEncoderResult eai_encoder_inference_batch(EaiEncoderContext* context,
                                             const float* features,
                                             int time_steps,
                                             EaiEncoderInferenceResult* result);

/**
 * @brief 释放eAI编码器推理上下文
 * 
 * @param context 要释放的推理上下文
 * 
 * @note 释放所有分配的内存和eAI资源
 */
void eai_encoder_destroy(EaiEncoderContext* context);

// ============================================================================
// 工具和调试接口
// ============================================================================

/**
 * @brief 获取性能统计信息
 * 
 * @param context 推理上下文
 * @return 性能统计信息指针，失败返回NULL
 */
const EaiEncoderPerfStats* eai_encoder_get_perf_stats(const EaiEncoderContext* context);

/**
 * @brief 重置性能统计信息
 * 
 * @param context 推理上下文
 * @return 操作结果状态码
 */
EaiEncoderResult eai_encoder_reset_perf_stats(EaiEncoderContext* context);

/**
 * @brief 获取最后错误信息
 * 
 * @param context 推理上下文
 * @return 错误信息字符串，失败返回NULL
 */
const char* eai_encoder_get_last_error(const EaiEncoderContext* context);

/**
 * @brief 设置调试级别
 * 
 * @param context 推理上下文
 * @param debug_level 调试级别 (0=关闭, 1=基本, 2=详细)
 * @return 操作结果状态码
 */
EaiEncoderResult eai_encoder_set_debug_level(EaiEncoderContext* context, int debug_level);

/**
 * @brief 打印推理上下文信息
 * 
 * @param context 推理上下文
 */
void eai_encoder_print_context_info(const EaiEncoderContext* context);

/**
 * @brief 验证推理结果与基准的一致性
 * 
 * @param result 推理结果
 * @param reference_file 基准文件路径（.npz格式）
 * @param tolerance 容差阈值
 * @return 验证结果状态码
 */
EaiEncoderResult eai_encoder_validate_result(const EaiEncoderInferenceResult* result,
                                             const char* reference_file,
                                             float tolerance);

/**
 * @brief 对VAD logits（前2维）应用Softmax
 * 
 * @param data 编码器输出数据 [time_steps, feature_dim]
 * @param time_steps 时间步数
 * @param feature_dim 特征维度 (必须 >= 2)
 */
void apply_softmax_to_vad_logits(float* data, int time_steps, int feature_dim);

#ifdef __cplusplus
}
#endif

#endif // EAI_ENCODER_INFERENCE_H
