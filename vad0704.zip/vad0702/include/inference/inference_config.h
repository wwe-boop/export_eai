/**
 * @file inference_config.h
 * @brief eAI编码器推理配置参数定义
 * @details 定义eAI编码器推理所需的配置参数、常量和数据结构
 *
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * @copyright Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#ifndef INFERENCE_CONFIG_H
#define INFERENCE_CONFIG_H

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// 编码器模型配置参数
// ============================================================================

/** 默认模型文件路径 */
#define EAI_ENCODER_DEFAULT_MODEL_PATH  "../../models/vad_encoder_eai.eai"

/** 输入特征维度 */
#define EAI_ENCODER_INPUT_DIM           400

/** 输出特征维度 */
#define EAI_ENCODER_OUTPUT_DIM          248

/** 上下文帧数 (简化推理模式，设置为1) */
#define EAI_ENCODER_CONTEXT_FRAMES      1

/** 最大批处理帧数 */
#define EAI_ENCODER_MAX_BATCH_FRAMES    128

/** 输入量化scale参数 */
#define EAI_ENCODER_INPUT_SCALE         0.0004765573082753644f

/** 输出量化scale参数（从张量信息获取） */
#define EAI_ENCODER_OUTPUT_SCALE        0.0004765573082753644f

// ============================================================================
// 内存配置参数
// ============================================================================

/** 内存对齐字节数 */
#define EAI_MEMORY_ALIGNMENT            256

/** 最大输入缓冲区大小（字节） */
#define EAI_MAX_INPUT_BUFFER_SIZE       (1024 * 1024)  // 1MB

/** 最大输出缓冲区大小（字节） */
#define EAI_MAX_OUTPUT_BUFFER_SIZE      (1024 * 1024)  // 1MB

// ============================================================================
// eAI运行时配置
// ============================================================================

/** eAI初始化标志 */
#define EAI_ENCODER_INIT_FLAGS          0x00000020  // 禁用异步处理

/** 内存类型 */
#define EAI_ENCODER_MEM_TYPE            EAI_MEM_TYPE_DDR

// ============================================================================
// 错误码定义
// ============================================================================

typedef enum {
    EAI_ENCODER_SUCCESS = 0,            /**< 成功 */
    EAI_ENCODER_ERROR_INVALID_PARAM,    /**< 无效参数 */
    EAI_ENCODER_ERROR_MEMORY_ALLOC,     /**< 内存分配失败 */
    EAI_ENCODER_ERROR_MODEL_LOAD,       /**< 模型加载失败 */
    EAI_ENCODER_ERROR_INIT_FAILED,      /**< 初始化失败 */
    EAI_ENCODER_ERROR_INFERENCE_FAILED, /**< 推理失败 */
    EAI_ENCODER_ERROR_NOT_INITIALIZED,  /**< 未初始化 */
    EAI_ENCODER_ERROR_BUFFER_OVERFLOW,  /**< 缓冲区溢出 */
    EAI_ENCODER_ERROR_QUANTIZATION,     /**< 量化/反量化错误 */
    EAI_ENCODER_ERROR_UNKNOWN           /**< 未知错误 */
} EaiEncoderResult;

// ============================================================================
// 推理配置结构体
// ============================================================================

/**
 * @brief eAI编码器推理配置参数
 */
typedef struct {
    const char* model_path;             /**< 模型文件路径 */
    int context_frames;                 /**< 上下文帧数 */
    int max_batch_frames;               /**< 最大批处理帧数 */
    float input_scale;                  /**< 输入量化scale */
    float output_scale;                 /**< 输出量化scale */
    int enable_debug;                   /**< 是否启用调试输出 */
    int enable_performance_log;         /**< 是否启用性能日志 */
} EaiEncoderConfig;

/**
 * @brief 默认配置初始化宏
 */
#define EAI_ENCODER_CONFIG_DEFAULT {                    \
    .model_path = EAI_ENCODER_DEFAULT_MODEL_PATH,       \
    .context_frames = EAI_ENCODER_CONTEXT_FRAMES,       \
    .max_batch_frames = EAI_ENCODER_MAX_BATCH_FRAMES,   \
    .input_scale = EAI_ENCODER_INPUT_SCALE,             \
    .output_scale = EAI_ENCODER_OUTPUT_SCALE,           \
    .enable_debug = 1,                                  \
    .enable_performance_log = 1                         \
}

// ============================================================================
// 性能统计结构体
// ============================================================================

/**
 * @brief 推理性能统计信息
 */
typedef struct {
    uint64_t total_inference_count;     /**< 总推理次数 */
    uint64_t total_inference_time_us;   /**< 总推理时间（微秒） */
    uint64_t total_frames_processed;    /**< 总处理帧数 */
    double avg_inference_time_ms;       /**< 平均推理时间（毫秒） */
    double frames_per_second;           /**< 每秒处理帧数 */
    uint64_t last_inference_time_us;    /**< 最近一次推理时间（微秒） */
} EaiEncoderPerfStats;

// 前向声明
typedef struct EaiEncoderContext EaiEncoderContext;

// ============================================================================
// 内部工具函数声明
// ============================================================================

/**
 * @brief 获取当前时间戳（微秒）
 * @return 当前时间戳
 */
uint64_t get_timestamp_us(void);

/**
 * @brief 量化float32数据到int16
 * @param input 输入float32数据
 * @param output 输出int16数据
 * @param size 数据元素个数
 * @param scale 量化scale参数
 * @return 量化结果状态码
 */
EaiEncoderResult quantize_float32_to_int16(const float* input, 
                                          int16_t* output, 
                                          size_t size, 
                                          float scale);

/**
 * @brief 反量化int16数据到float32
 * @param input 输入int16数据
 * @param output 输出float32数据
 * @param size 数据元素个数
 * @param scale 反量化scale参数
 * @return 反量化结果状态码
 */
EaiEncoderResult dequantize_int16_to_float32(const int16_t* input, 
                                            float* output, 
                                            size_t size, 
                                            float scale);

/**
 * @brief 分配对齐内存
 * @param size 内存大小
 * @param alignment 对齐字节数
 * @return 分配的内存指针，失败返回NULL
 */
void* aligned_malloc(size_t size, size_t alignment);

/**
 * @brief 释放对齐内存
 * @param ptr 要释放的内存指针
 */
void aligned_free(void* ptr);

/**
 * @brief 更新性能统计信息
 * @param stats 性能统计结构体
 * @param inference_time_us 本次推理耗时（微秒）
 * @param frames_processed 本次处理的帧数
 */
void update_perf_stats(EaiEncoderPerfStats* stats, 
                      uint64_t inference_time_us, 
                      int frames_processed);

/**
 * @brief 设置错误信息
 * @param context 推理上下文
 * @param error_code 错误码
 * @param format 错误信息格式字符串
 * @param ... 格式参数
 */
void set_error_message(EaiEncoderContext* context, 
                      EaiEncoderResult error_code, 
                      const char* format, ...);

/**
 * @brief 验证输入参数
 * @param features 输入特征
 * @param time_steps 时间步数
 * @param max_frames 最大帧数限制
 * @return 验证结果状态码
 */
EaiEncoderResult validate_input_params(const float* features, 
                                      int time_steps, 
                                      int max_frames);

/**
 * @brief 计算缓冲区大小
 * @param time_steps 时间步数
 * @param feature_dim 特征维度
 * @param data_type_size 数据类型大小
 * @return 缓冲区大小（字节）
 */
size_t calculate_buffer_size(int time_steps, int feature_dim, size_t data_type_size);

/**
 * @brief 验证特征数据有效性
 * @param features 特征数据
 * @param time_steps 时间步数
 * @param feature_dim 特征维度
 * @return 验证结果状态码
 */
EaiEncoderResult validate_feature_data(const float* features,
                                      int time_steps,
                                      int feature_dim);

/**
 * @brief 打印数组统计信息
 * @param name 数组名称
 * @param data 数组数据
 * @param size 数组大小
 */
void print_array_stats(const char* name, const float* data, size_t size);

/**
 * @brief 打印量化数组统计信息
 * @param name 数组名称
 * @param data 量化数组数据
 * @param size 数组大小
 */
void print_quantized_array_stats(const char* name, const int16_t* data, size_t size);

// ============================================================================
// 调试和日志宏
// ============================================================================

#define EAI_LOG_ERROR(ctx, fmt, ...) \
    do { \
        if ((ctx) && (ctx)->debug_level >= 1) { \
            printf("[ERROR] %s:%d " fmt "\n", __FUNCTION__, __LINE__, ##__VA_ARGS__); \
        } \
    } while(0)

#define EAI_LOG_WARN(ctx, fmt, ...) \
    do { \
        if ((ctx) && (ctx)->debug_level >= 1) { \
            printf("[WARN] %s:%d " fmt "\n", __FUNCTION__, __LINE__, ##__VA_ARGS__); \
        } \
    } while(0)

#define EAI_LOG_INFO(ctx, fmt, ...) \
    do { \
        if ((ctx) && (ctx)->debug_level >= 2) { \
            printf("[INFO] %s:%d " fmt "\n", __FUNCTION__, __LINE__, ##__VA_ARGS__); \
        } \
    } while(0)

#define EAI_LOG_DEBUG(ctx, fmt, ...) \
    do { \
        if ((ctx) && (ctx)->debug_level >= 3) { \
            printf("[DEBUG] %s:%d " fmt "\n", __FUNCTION__, __LINE__, ##__VA_ARGS__); \
        } \
    } while(0)

// ============================================================================
// 性能测量宏
// ============================================================================

#define EAI_PERF_START(start_time) \
    uint64_t start_time = get_timestamp_us()

#define EAI_PERF_END(start_time, ctx, frames) \
    do { \
        uint64_t end_time = get_timestamp_us(); \
        uint64_t elapsed = end_time - start_time; \
        if ((ctx) && (ctx)->config.enable_performance_log) { \
            printf("[PERF] Inference: %llu us, Frames: %d, FPS: %.2f\n", \
                   (unsigned long long)elapsed, frames, (frames * 1000000.0) / elapsed); \
        } \
        update_perf_stats(&(ctx)->perf_stats, elapsed, frames); \
    } while(0)

// ============================================================================
// 工具宏定义
// ============================================================================

/** 内存对齐宏 */
#define EAI_ALIGN_SIZE(size, alignment) \
    (((size) + (alignment) - 1) & ~((alignment) - 1))

/** 检查指针有效性 */
#define EAI_CHECK_PTR(ptr) \
    do { if (!(ptr)) return EAI_ENCODER_ERROR_INVALID_PARAM; } while(0)

/** 检查初始化状态 */
#define EAI_CHECK_INITIALIZED(ctx) \
    do { if (!(ctx) || !(ctx)->is_initialized) return EAI_ENCODER_ERROR_NOT_INITIALIZED; } while(0)

#ifdef __cplusplus
}
#endif

#endif // INFERENCE_CONFIG_H
