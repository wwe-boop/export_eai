/**
 * @file wav_frontend_online.h
 * @brief 在线音频前端处理组件接口定义（临时占位）
 * @details 为编译通过而创建的临时头文件，实际在线处理功能待后续实现
 *
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * @copyright Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#ifndef WAV_FRONTEND_ONLINE_H
#define WAV_FRONTEND_ONLINE_H

#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// 临时数据结构定义（用于编译通过）
// ============================================================================

/**
 * @brief 在线前端配置结构体
 */
typedef struct {
    int sample_rate;        /**< 采样率 */
    int frame_length_ms;    /**< 帧长（毫秒） */
    int frame_shift_ms;     /**< 帧移（毫秒） */
    int n_mels;             /**< Mel滤波器数量 */
    int lfr_m;              /**< LFR参数m */
    int lfr_n;              /**< LFR参数n */
    const char* cmvn_file;  /**< CMVN文件路径 */
} WavFrontendConfig;

/**
 * @brief 在线前端处理器结构体
 */
typedef struct {
    WavFrontendConfig config;   /**< 配置参数 */
    float* audio_buffer;        /**< 音频缓冲区 */
    float* feature_buffer;      /**< 特征缓冲区 */
    int buffer_size;            /**< 缓冲区大小 */
    int is_initialized;         /**< 初始化状态 */
} WavFrontendOnline;

// ============================================================================
// 返回码定义
// ============================================================================

#define WAV_FRONTEND_SUCCESS        0
#define WAV_FRONTEND_ERROR         -1
#define WAV_FRONTEND_BUFFER_FULL   -2
#define WAV_FRONTEND_NOT_READY     -3

// ============================================================================
// 临时函数声明（用于编译通过）
// ============================================================================

/**
 * @brief 创建在线前端处理器
 * @return 新创建的处理器指针
 */
WavFrontendOnline* WavFrontendOnline_Create(void);

/**
 * @brief 初始化在线前端处理器
 * @param frontend 前端处理器
 * @param config 配置参数
 * @return 0成功，非0失败
 */
int WavFrontendOnline_Init(WavFrontendOnline* frontend, const WavFrontendConfig* config);

/**
 * @brief 处理音频数据块
 * @param frontend 前端处理器
 * @param audio_data 音频数据
 * @param num_samples 样本数量
 * @param features 输出特征
 * @param num_features 输出特征数量
 * @return 0成功，非0失败
 */
int WavFrontendOnline_Process(WavFrontendOnline* frontend, 
                             const int16_t* audio_data, 
                             int num_samples,
                             float** features, 
                             int* num_features);

/**
 * @brief 重置前端处理器状态
 * @param frontend 前端处理器
 */
void WavFrontendOnline_Reset(WavFrontendOnline* frontend);

/**
 * @brief 销毁前端处理器
 * @param frontend 前端处理器
 */
void WavFrontendOnline_Destroy(WavFrontendOnline* frontend);

#ifdef __cplusplus
}
#endif

#endif // WAV_FRONTEND_ONLINE_H
