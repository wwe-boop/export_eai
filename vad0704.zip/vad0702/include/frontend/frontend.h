/**
 * @file frontend.h
 * @brief 音频前端处理模块头文件
 * @details 实现音频数据预处理、特征提取等功能
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#ifndef FRONTEND_H
#define FRONTEND_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "config/frontend_config.h"

/**
 * @brief 音频数据结构体
 */
typedef struct {
    float* waveform;       /**< 波形数据 */
    int length;            /**< 数据长度 */
} AudioData;

/**
 * @brief 处理结果结构体
 */
typedef struct {
    float* data;           /**< 数据指针 */
    int rows;              /**< 行数 */
    int cols;              /**< 列数 */
    float min_val;         /**< 最小值 */
    float max_val;         /**< 最大值 */
    float mean_val;        /**< 平均值 */
} ProcessResult;

// 函数声明

/**
 * @brief 初始化前端处理配置
 * @param[in] config 配置参数，如果为NULL则使用默认配置
 * @return 配置结构体指针，失败返回NULL
 */
FrontendConfig* frontend_config_init(const FrontendConfig* config);

/**
 * @brief 释放前端处理配置
 * @param[in] config 配置结构体指针
 */
void frontend_config_free(FrontendConfig* config);

/**
 * @brief 初始化前端处理通道
 * @param[in] config 配置参数
 * @return 通道结构体指针，失败返回NULL
 */
FrontendChannel* frontend_channel_init(const FrontendConfig* config);

/**
 * @brief 释放前端处理通道
 * @param[in] channel 通道结构体指针
 */
void frontend_channel_free(FrontendChannel* channel);

/**
 * @brief 提取Fbank特征
 * @param[in] channel 通道结构体指针
 * @param[in] audio 音频数据
 * @param[out] fbank_result 处理结果
 * @return 0成功，非0失败
 */
int extract_fbank(FrontendChannel* channel, const AudioData* audio, ProcessResult* fbank_result);

/**
 * @brief 处理音频数据
 * @param[in] channel 处理通道
 * @param[in] audio 音频数据
 * @param[out] features 输出特征
 * @return 0成功，非0失败
 */
int frontend_process(FrontendChannel* channel, AudioData* audio, float** features);

/**
 * @brief 音频数据预处理
 * @param[in] audio 输入音频数据
 * @param[out] input_result 输入波形的处理结果
 * @param[out] amplified_result 放大后的处理结果
 * @return 0成功，非0失败
 */
int preprocess_audio(const AudioData* audio, ProcessResult* input_result, ProcessResult* amplified_result);

/**
 * @brief 应用LFR处理
 * @param[in] channel 处理通道
 * @param[in] input 输入特征
 * @param[out] lfr_result LFR处理结果
 * @return 0成功，非0失败
 */
int apply_lfr(FrontendChannel* channel, const ProcessResult* input, ProcessResult* lfr_result);

/**
 * @brief 应用CMVN归一化
 * @param[in] channel 处理通道
 * @param[in] input 输入特征
 * @param[out] cmvn_result CMVN处理结果
 * @return 0成功，非0失败
 */
int apply_cmvn(FrontendChannel* channel, const ProcessResult* input, ProcessResult* cmvn_result);

/**
 * @brief 测试前端组件
 * @param[in] audio_path 音频文件路径
 * @return 0成功，非0失败
 */
int test_frontend(const char* audio_path);

/**
 * @brief Kaldi风格的分帧函数
 * @param[in] waveform 音频波形
 * @param[in] length 波形长度
 * @param[in] frame_length 帧长
 * @param[in] frame_shift 帧移
 * @param[in] snip_edges 是否裁剪边缘
 * @param[out] num_frames 输出帧数
 * @return 分帧后的数据
 */
float* kaldi_get_strided(const float* waveform, int length, int frame_length, int frame_shift, int snip_edges, int* num_frames);

/**
 * @brief Kaldi风格的完整窗口处理
 * @param[in,out] frames 分帧数据
 * @param[in] num_frames 帧数
 * @param[in] frame_length 帧长
 * @param[in] config 配置参数
 * @return 0成功，非0失败
 */
int kaldi_apply_window_processing(float* frames, int num_frames, int frame_length, const FrontendConfig* config);

/**
 * @brief 计算FFT和功率谱
 * @param[in] frames 分帧数据
 * @param[in] num_frames 帧数
 * @param[in] frame_length 帧长
 * @param[in] n_fft FFT点数
 * @param[out] power_spectrum 功率谱输出
 * @return 0成功，非0失败
 */
int compute_power_spectrum(const float* frames, int num_frames, int frame_length, int n_fft, float* power_spectrum);

/**
 * @brief 生成Mel滤波器组
 * @param[in] n_mels Mel滤波器数量
 * @param[in] n_fft FFT点数
 * @param[in] sample_rate 采样率
 * @param[in] fmin 最小频率
 * @param[in] fmax 最大频率
 * @param[out] mel_filters Mel滤波器组系数
 */
void create_mel_filterbank(int n_mels, int n_fft, int sample_rate, float fmin, float fmax, float* mel_filters);

/**
 * @brief 应用Mel滤波器组并计算对数能量
 * @param[in] power_spectrum 功率谱
 * @param[in] num_frames 帧数
 * @param[in] n_mels Mel滤波器数量
 * @param[in] n_fft FFT点数
 * @param[in] mel_filters Mel滤波器组系数
 * @param[out] fbank_features Fbank特征
 */
void apply_mel_filterbank(const float* power_spectrum, int num_frames, int n_mels, int n_fft, const float* mel_filters, float* fbank_features);

#ifdef __cplusplus
}
#endif

#endif // FRONTEND_H