/**
 * @file audio_utils.h
 * @brief 音频处理工具函数声明
 * @details 提供音频文件读取、写入等通用功能的接口
 *
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * @copyright Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#ifndef AUDIO_UTILS_H
#define AUDIO_UTILS_H

#include "frontend/frontend.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 读取WAV音频文件
 * @param[in] filename 文件路径
 * @param[out] audio_data 音频数据结构指针
 * @return 0成功，非0失败
 */
int read_wav_file(const char* filename, AudioData* audio_data);

/**
 * @brief 释放音频数据内存
 * @param[in] audio_data 音频数据结构指针
 */
void free_audio_data(AudioData* audio_data);

#ifdef __cplusplus
}
#endif

#endif // AUDIO_UTILS_H
