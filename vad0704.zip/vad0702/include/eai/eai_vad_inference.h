/**
 * @file eai_vad_inference.h
 * @brief eAI VAD inference engine interface
 * @details Core interface for VAD inference using eAI runtime
 *
 * @author l50011968
 * @date 2025.7.1
 * @version 1.0.0
 * @copyright Qualcomm Technologies, Inc.
 */

#ifndef EAI_VAD_INFERENCE_H
#define EAI_VAD_INFERENCE_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "eai.h"

// 简化版本：移除后处理相关依赖
// 临时类型定义，用于编译通过
typedef struct SpeechSegmentList SpeechSegmentList;

/**
 * @brief eAI VAD inference context structure
 *
 * Contains all necessary state and configuration for VAD inference
 * including model buffers, tensor information, and processing parameters.
 */
typedef struct {
    eaih_t eai_handle;
    void* model_buffer;
    size_t model_size;
    void* scratch_buffer;
    size_t scratch_size;
    void* persistent_buffer;
    size_t persistent_size;
    eai_tensor_info_t* input_tensors;
    eai_tensor_info_t* output_tensors;
    uint32_t num_inputs;
    uint32_t num_outputs;
    eai_batch_info_t batch_info;
    int input_feature_dim;
    int output_feature_dim;
    int context_frames;
    int max_batch_frames;
    float* context_cache;
    int cache_frames;
    int cache_capacity;
} EaiVadContext;

/**
 * @brief VAD inference result structure
 *
 * Contains encoder output, VAD probabilities, and detected speech segments.
 */
typedef struct {
    float* encoder_output;
    float* vad_probs;
    int time_steps;
    SpeechSegmentList* speech_segments;
} EaiVadResult;

// 函数声明


/**
 * @brief Initialize eAI VAD inference context
 *
 * @param model_path Path to eAI model file
 * @param context_frames Number of context frames for inference
 * @param max_batch_frames Maximum frames per batch
 *
 * @return Initialized context pointer on success, NULL on failure
 *
 * @note Model file must be accessible and valid
 * @warning Caller responsible for freeing returned context
 */
EaiVadContext* eai_vad_init(const char* model_path, int context_frames, int max_batch_frames);


/**
 * @brief Release eAI VAD inference context
 *
 * @param context Context to release
 *
 * @note Frees all allocated resources including model buffers
 */
void eai_vad_deinit(EaiVadContext* context);


/**
 * @brief Execute VAD inference on feature data
 *
 * @param context Initialized inference context
 * @param features Input feature matrix [time_steps x 400]
 * @param time_steps Number of time frames
 * @param vad_args VAD post-processing parameters (NULL for defaults)
 *
 * @return Inference results on success, NULL on failure
 *
 * @note Features must be 400-dimensional LFR features
 * @warning Caller must free returned result using eai_vad_free_result()
 */
EaiVadResult* eai_vad_inference(EaiVadContext* context,
                                const float* features,
                                int time_steps);


// 流式VAD推理函数已移除 - 依赖后处理组件

// 流式VAD处理器已移除 - 依赖后处理组件

// 流式VAD处理函数已移除 - 依赖后处理组件


/**
 * @brief Free VAD inference result
 *
 * @param result Result structure to free
 */
void eai_vad_free_result(EaiVadResult* result);

/**
 * @brief Destroy VAD inference context
 *
 * @param context Context to destroy
 */
void eai_vad_destroy(EaiVadContext* context);


int load_eai_model(const char* model_path, void** model_buffer, size_t* model_size);

/**
 * 打印推理结果
 * @param result 推理结果
 */
void print_eai_vad_result(const EaiVadResult* result);

/**
 * 将特征转换为eAI输入格式
 * @param features 输入特征 [time_steps, 400]
 * @param time_steps 时间步数
 * @param context_frames 上下文帧数
 * @param context_cache 上下文缓存
 * @param output_buffer 输出缓冲区 [time_steps, context_frames * 400]
 * @return 0成功，-1失败
 */
int prepare_eai_input(const float* features,
                      int time_steps,
                      int context_frames,
                      int feature_dim,
                      const float* context_cache,
                      float* output_buffer);

#endif // EAI_VAD_INFERENCE_H
