/*======================= COPYRIGHT NOTICE ==================================*]
[* Copyright (c) Qualcomm Technologies, Inc.                                 *]
[* All Rights Reserved.                                                      *]
[* Confidential and Proprietary - Qualcomm Technologies, Inc.                *]
[*===========================================================================*/

#ifndef __EAI_H__
#define __EAI_H__

#include <stdint.h>
#include <stdbool.h>
#include "eai_legacy.h"

#if EAI_BUILD_STATIC_RUNTIME == 0
  #ifdef _MSC_VER
    #define EAI_EXPORT __declspec(dllexport)
  #else
    #define EAI_EXPORT __attribute__((visibility("default")))
  #endif
#else
  #ifdef _MSC_VER
    #define EAI_EXPORT __declspec(dllimport)
  #else
    #define EAI_EXPORT
  #endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
 * eAI Result Codes
 *
 */
typedef enum EAI_RESULT {
    EAI_SUCCESS = 0,            /* Successful - No errors */
    EAI_FAIL,                   /* Failure - Generic */
    EAI_NEED_MORE,              /* Successful - Require more data to complete processing */
    EAI_INVALID_HANDLE,         /* Failure - Invalid eAI Handle Specified */
    EAI_UNSUPPORTED_PROP,       /* Failure - Unsupported Property ID Specified */
    EAI_INVALID_PARAMETER,      /* Failure - Invalid Parameter Specified : Generic - e.g. Function parameters,
                                                                                          Property parameters, etc */
    EAI_MLA_NOT_AVAILABLE,      /* Failure - ML Accelerator not available or not enabled */
    EAI_RESOURCE_FAILURE,       /* Failure - Insufficient resources available - e.g memory, BW, MIPS, etc */
    EAI_INVALID_MODEL_VERSION,  /* Failure - Unsupported Model version */
    EAI_INVALID_MODEL,          /* Failure - Invalid model definition or invalid model build type
                                                                              - e.g. Fixed point defintion using
                                                                                     floating point runtime */
    EAI_INVALID_ALIGNMENT,      /* Failure - Invalid memory alignments */
    EAI_PROHIBITED_LPI_REQUEST, /* Failure - Invalid call while LPI mode is active */
    EAI_HAS_MORE,               /* (deprecated) Successful - Containing more data than used during processing */
    EAI_DATA_CORRUPTION,        /* Failure - Invalid checksum result */
    EAI_LIB_LOAD_ERROR,         /* Failure - Unable to load symbols from lpi library*/
    EAI_RESULT_MAX = 0x3FFFFFFF
} EAI_RESULT;

/**
 * eAI Data Types
 *
 */
#define EAI_DATATYPE_FLOAT16        10      /* Float data - 16 bit  */
#define EAI_DATATYPE_FLOAT32        1       /* Float data - 32 bit  */
#define EAI_DATATYPE_FLOAT64        11      /* Float data - 64 bit  */
#define EAI_DATATYPE_INT4           14      /* Signed 4 bit data    */
#define EAI_DATATYPE_INT8           3       /* Signed 8 bit data    */
#define EAI_DATATYPE_INT16          5       /* Signed 16 bit data   */
#define EAI_DATATYPE_INT32          6       /* Signed 32 bit data   */
#define EAI_DATATYPE_INT64          7       /* Signed 64 bit data   */
#define EAI_DATATYPE_UINT4          15      /* Unsigned 4 bit data  */
#define EAI_DATATYPE_UINT8          2       /* Unsigned 8 bit data  */
#define EAI_DATATYPE_UINT16         4       /* Unsigned 16 bit data */
#define EAI_DATATYPE_UINT32         12      /* Unsigned 32 bit data */
#define EAI_DATATYPE_UINT64         13      /* Unsigned 64 bit data */

/**
 * eAI ML Accelerator Usage Types
 *
 */
typedef enum EAI_MLA_USAGE_TYPE {
    EAI_MLA_USAGE_TYPE_NO,                          /* Do not use : default */
    EAI_MLA_USAGE_TYPE_YES,                         /* Use - best effort : utiize MLA for as much processing as possible */
    EAI_MLS_USAGE_TYPE_MAX
} EAI_MLA_USAGE_TYPE;

/**
 * Handle for eAI instance
 */
typedef   void* eaih_t;

/**
 * eAI Property Types
 *
 * Included in the property type description is the type
 * associated with the property type.
 */
typedef enum EAI_PROP {
    EAI_PROP_SCRATCH_MEM,           /* Scratch memory size information : eai_memory_info_t */
    EAI_PROP_PERSISTENT_MEM,        /* Persistent memory size information : eai_memory_info_t */
    EAI_PROP_TENSOR_INFO,           /* Tensor information : eai_tensor_info_t */
    EAI_PROP_PORTS_NUM,             /* Number of inputs\outputs associated with the eAI graph  : eai_ports_info_t */
    EAI_PROP_EAIRT_INFO,            /* eAI runtimes Information-  e.g version, build type, etc.. : eai_rt_info_t */
    EAI_PROP_MODEL_ALIGNMENT,       /* Retreive model alignment requirement : uint32_t */
    EAI_PROP_MODEL_META_INFO,       /* Retreive model meta information : eai_model_meta_info */
    EAI_PROP_CLIENT_PERF_CFG,       /* Client's performance requirement for MLA Usage : eai_client_perf_config_t */
    EAI_PROP_MLA_CORE_INFO,         /* MLA core info: core id specified in eai_mla_core_info_t */
    EAI_PROP_MLA_NUM,               /* Number of MLA cores : uint32_t */
    EAI_PROP_MLA_AFFINITY,          /* MLA core affinity : eai_mla_affinity_t*/
    EAI_PROP_MAX = 0x3FFFFFFF
} EAI_PROP;


/**
 * eAI interface types.
 *
 * Interfaces can be used to define extra APIs for new functionalities (e.g., eai events) or new environments.
 */
typedef enum EAI_INTERFACE_ID {
    EAI_INTERFACE_DEFAULT,          /* Default interface that supports inference */
    EAI_INTERFACE_EVENT,            /* Interface for event handling */
    EAI_INTERFACE_COUNT
} EAI_INTERFACE_ID;

/**
 * Used to specify version information
 *
 */
typedef struct eai_version_t {
    uint32_t major;                 /* Major Version Info */
    uint32_t minor;                 /* Minor Version Info */
    uint32_t patch;                 /* Patch Version Info */
} eai_version_t;

#define EAI_RT_INFO_FLAG_FIXEDPOINT 0x00000001  /* If set, Fixed Point build, otherwise Floating Point Build*/
#define EAI_RT_INFO_FLAG_32BIT      0x00000002  /* If set, 32b build, otherwise 64b Build*/
#define EAI_RT_INFO_FLAG_MLA        0x00000004  /* If set, MLA Support is available*/

/**
 * Used to specify eAI Runtime Information
 *
 */
typedef struct eai_rt_info_t {
    eai_version_t version;      /* Version Info */
    uint32_t flags;             /* Various configuration\build flags */
} eai_rt_info_t;

#define MAX_NDIM    (5)

typedef enum EAI_TENSOR_IO_TYPE {
    EAI_TENSOR_IO_TYPE_INPUT = 0,           /* Identify input tensor (I/O tensor) */
    EAI_TENSOR_IO_TYPE_OUTPUT = 1,          /* Identify output tensor (I/O tensor) */
    EAI_TENSOR_IO_TYPE_INTERMEDIATE = 2     /* Intermediate tensor (input or output tensor of layers) */
} EAI_TENSOR_IO_TYPE;

typedef struct eai_tensor_info_t {
    uint32_t index;                 /* Index into the tensor list */
    uint32_t input_or_output;       /* Identifies input (0), output (1) or intermediate (2) tensor list */
    uint8_t* address;               /* Tensor buffer address */
    uint16_t element_type;          /* Element type : EAI_DATATYPE_XXX */
    uint16_t flags;                 /* Tensor flags populated from the eai tensor*/
    uint32_t num_dims;              /* Number of valid entries in the dim arrary */
    uint32_t dims[MAX_NDIM];        /* Dim array information, the dimensions are in NCHW order */
    uint32_t stride[MAX_NDIM];      /* Stride of each dimension in memory, the order of dimensions follows the dim array */
    uint32_t tensor_size;           /* Tensor size in bytes */
    uint32_t aligned_size;          /* Required tensor buffer size if allocated by client, this includes extra padding to make it aligned */
    uint32_t alignment;             /* Tensor buffer start address alignment requirement if allocated by client*/
    float scale;                    /* Quantization info: quantization scale */
    int16_t zero;                   /* Quantization info: zero point */
} eai_tensor_info_t;

typedef struct eai_ports_info_t {
    uint32_t input_or_output;       /* Identifies input (0) or output (1) ports list */
    uint32_t size;                  /* Number of ports */
} eai_ports_info_t;

/**
 * eAI eai_op_layer Reset flags : eai_layer_reset_t structure
 *
 */
#define EAI_LAYER_RESET_FLAGS_ALL       0x00000001  /* Resets the whole network */
#define EAI_LAYER_RESET_FLAGS_ONE       0x00000002  /* Resets a given recurrent (LSTM/GRU) layer */

typedef struct eai_layer_reset_t {
    uint32_t flags;                  /* Reset request types */
    uint32_t reset_layer_idx;        /* Given a layer index to reset */
} eai_layer_reset_t;

/**
 * eAI Memory Types
 *
 * Used to pass the information on which type of platform-specific memory the various buffers
 * (model, scratch and persistent) are located. Need to make sure eAI runtime and eNPU hardware
 * have access to the specified memory in the particular power mode. e.g., in low power island
 * mode, DDR memory is not available.
 *
 */
typedef enum EAI_MEM_TYPE {
    EAI_MEM_TYPE_UNKNOWN = 0,
    EAI_MEM_TYPE_DDR,               /* Main memory, only available in non-island mode */
    EAI_MEM_TYPE_LLC,               /* Last level cache */
    EAI_MEM_TYPE_TCM,               /* Tightly coupled memory for hardware */
    EAI_MEM_TYPE_COUNT
} EAI_MEM_TYPE;

typedef struct eai_memory_info_t {
    uint8_t* addr;                  /* Buffer address */
    uint32_t memory_size;           /* Buffer size in number of bytes */
    EAI_MEM_TYPE memory_type;       /* Memory type of the buffer */
} eai_memory_info_t;

typedef struct eai_buffer_info {
    uint32_t index;                 /* Identifies the port index the buffer is associated with */
    uint8_t* addr;                  /* Buffer address */
    uint32_t buffer_size;           /* buffer_size in bytes */
    uint32_t element_type;          /* (deprecated) Element type : EAI_DATATYPE_XXX */
    EAI_MEM_TYPE memory_type;       /* Memory type of the buffer : EAI_MEM_TYPE_XXX */
} eai_buffer_info_t;

typedef struct eai_batch_info_t {
    eai_buffer_info_t* inputs;      /* Pointer to array of input buffer descriptors */
    uint32_t num_inputs;            /* Indicates the number of input buffer descriptors */
    eai_buffer_info_t* outputs;     /* Pointer to array of output buffer descriptors */
    uint32_t num_outputs;           /* Indicates the number of output buffer descriptors */
} eai_batch_info_t;

typedef struct eai_model_meta_info_t {
    uint32_t model_type ;          /* float or fixed : fixed = 0, float = 1*/
    uint32_t target_type;          /* obtained from enum eai_model_target {EAI_MODEL_TARGET_X86, EAI_MODEL_TARGET_ARM, EAI_MODEL_TARGET_HEXAGON, EAI_MODEL_TARGET_TENSILICA} from eai_model.h*/
    uint32_t enpu_ver;             /* enpu version */
    uint32_t model_size;           /* total model size, including the header */
    uint32_t layer_count;          /* total number of layers */
    uint32_t compressed_model;     /* is the model compressed? */
    uint32_t fallback_enabled;     /* is fallback enabled? */
    uint32_t scratch_io;           /* Does the scratch memory contain the input or output*/
} eai_model_meta_info_t;

/** eai_client_priority_t
    Client priority levels, which affect prioritizing job execution
*/
typedef enum eai_client_priority {
    EAI_CLIENT_PRIORITY_DEFAULT  = 0,
    EAI_CLIENT_PRIORITY_VERY_LOW = 0,
    EAI_CLIENT_PRIORITY_LOW      = 1,
    EAI_CLIENT_PRIORITY_MEDIUM   = 2,
    EAI_CLIENT_PRIORITY_HIGH     = 3,
    EAI_CLIENT_PRIORITY_COUNT    = 4
} eai_client_priority;

/**
 * Used to define a client's processing config for MLA HW
 *
 */
#define EAI_CLIENT_PERF_FLAG_NON_REAL_TIME   0x00000001  /* Flag indicating a client is not real-time
                                                            For non real-time client, committed job will still
                                                            be accepted if requested frame rate can't be satisfied */
typedef struct eai_client_perf_config_t {
  uint32_t ftrt_ratio;            /* Faster than real time processing request : multiples of 0.1 factors,
                                       E.g 1.0 = 10, 2.3 = 23
                                       Multiplication factor applied to MLA's clock and HW votes */
  uint32_t fps;                   /* Number of frames to second to be processed */
  eai_client_priority priority;              /* client priority for MLA scheduling */
  uint32_t flags;
} eai_client_perf_config_t;

// Macro to initialize default eai_client_perf_config_t
#define EAI_CLIENT_PERF_CONFIG_INIT                 \
    {                                               \
        .fps = 1u,                                  \
        .ftrt_ratio = 10u,                          \
        .priority = EAI_CLIENT_PRIORITY_DEFAULT,    \
        .flags = 0x0                                \
    };

/**
 * Used to specify interface.
 */
typedef struct eai_interface_t {
    uint32_t interface_id;      /* interface_id should be one of the EAI_INTERFACE_ID */
    uint32_t flags;
} eai_interface_t;


/**
 * Used to set MLA core affinity
 *
 * core_selection: a bit mask for core selection. Each bit corresponds to a core, set the bit to use the core
 *                 Note that all zeros and all ones mean any core can be used for the eAI instance
 *
 * affinity: soft    - Default affinity. Scheduler will assign jobs to requested cores when feasible
 *           hard    - Scheduler will honour affinity requested by the client
 *
 *
 * Example for 2 MLA cores:
 * +--------+--------+---------------+-------------------------------------------------------------------------+
 * | bit 1  | bit 0  | affinity      |                 scheduler behavior                                      |
 * +--------+--------+---------------+-------------------------------------------------------------------------+
 * | 0      |      0 |      any      | Default affinity, scheduler will pick any core based on load            |
 * | 1      |      1 |      any      | Same as default affinity                                                |
 * | 0      |      1 |      hard     | All jobs will only be sent to core 0                                    |
 * | 1      |      0 |      hard     | All jobs will only be sent to core 1                                    |
 * | 0      |      1 |      soft     | Scheduler will attempt to send jobs to core 0                           |
 * | 1      |      0 |      soft     | Scheduler will attempt to send jobs to core 1                           |
 * +--------+--------+---------------+-------+-----------------------------------------------------------------+
 *
 */

typedef enum EAI_MLA_AFFINITY_TYPE {
    EAI_MLA_AFFINITY_SOFT    = 0,           // Default affinity
    EAI_MLA_AFFINITY_HARD    = 1
} EAI_MLA_AFFINITY_TYPE;

 typedef struct eai_mla_affinity_t {
    uint32_t core_selection;
    EAI_MLA_AFFINITY_TYPE affinity;
} eai_mla_affinity_t;

// Macro to initialize default eai_mla_affinity_t
#define EAI_MLA_AFFINITY_INIT                   \
    {                                           \
        .core_selection = 0u,                   \
        .affinity = EAI_MLA_AFFINITY_SOFT       \
    };

/**
 * @brief Used to store information related to a specific enpu core
 *
 */
typedef struct eai_mla_core_info_t {
    uint32_t id;
    uint32_t version;
    uint32_t mac;  // MAC/cycle
} eai_mla_core_info_t;

#define EAI_INIT_FLAGS_LPI          0x00000001  /* Low Power Island usage */

/**
 * Initializes\Loads instance of eAI runtime.
 *
 * @param[out] eaih
 *    Pointer to handle for this eAI runtime instance, valid
 *    when EAI_SUCCESS returned.
 *
 * @param[in] eai_model
 *    Pointer to a struct that contains eai model buffer, buffer size and memory type
 *    Need to query model buffer alignment requirement before preparing and loading
 *    the model
 *
 * @param[in] flags
 *     Indicator for various configurations
 *     Refer to EAI_INIT_FLAGS_xxx definitions
 *
 * @return EAI_RESULT
 */
EAI_EXPORT EAI_RESULT eai_init(eaih_t *eaih, eai_memory_info_t *eai_model, uint32_t flags);

/**
 * DeInitializes\UnLoads instance of eAI runtime.
 *
 * @param[in] eaih
 *    Handle for the eAI runtime instance.
 *
 * @return EAI_RESULT
 */
EAI_EXPORT EAI_RESULT eai_deinit(eaih_t eaih);

/**
 * Applies configuration settings.
 *
 * @param[in] eaih
 *    Handle for the eAI runtime instance.
 *
 * @return EAI_RESULT
 */
EAI_EXPORT EAI_RESULT eai_apply(eaih_t eaih);

/**
 * Performs the eAI graph execution.
 *
 * @param[in] eaih
 *    Handle for the eAI runtime instance.
 *
 * @param[in] batch_inputs
 *    Array of batch information structures describing the
 *    execution request.
 *
 * @param[in] num_batches
 *    Number of batch structures associated with the
 *    batch_inputs parameter.
 *
 * @return EAI_RESULT
 */
EAI_EXPORT EAI_RESULT eai_execute(eaih_t eaih, eai_batch_info_t* batch_inputs, uint32_t num_batches);

/**
 * Applys various settings.
 *
 * @param[in] eaih
 *    Handle for the eAI runtime instance.
 *
 * @param[in] prop
 *    Identifies the property type being applied
 *
 * @param[in] prop_info
 *    Identifies the property type information being applied.
 *
 * NOTE : Property information is EAI_PROP type specific, refer
 * to the EAI_PROP enumeration information to cross correlated
 * the required property information data types per property
 * types.
 *
 * @return EAI_RESULT
 */
EAI_EXPORT EAI_RESULT eai_set_property(eaih_t eaih, uint32_t prop, void* prop_info);

/**
 * Retrieves various settings.
 *
 * @param[in] eaih
 *    Handle for the eAI runtime instance.
 *
 * @param[in] prop
 *    Identifies the property type being retrieved
 *
 * @param[out] prop_info
 *    Identifies the property type information being retrieved.
 *
 * NOTE : Property information is EAI_PROP type specific, refer
 * to the EAI_PROP enumeration information to cross correlated
 * the required property information data types per property
 * types.
 *
 * @return EAI_RESULT
 */
EAI_EXPORT EAI_RESULT eai_get_property(eaih_t eaih, uint32_t prop, void* prop_info);

/**
 * Retrieves an interface of extensions.
 *
 * @param[in] eaih
 *      Handle for eAI runtime instance.
 *
 * @param[in] interface_id
 *      Identifier of the interface to get (e.g., EAI_INTERFACE_EVENT)
 *      Should be one of the EAI_INTERFACE_ID
 *
 * @return a pointer to the interface. If the interface with the specified identifier does not exist or is unsupported,
 *      NULL is returned.
 */
EAI_EXPORT eai_interface_t* eai_get_interface(eaih_t eaih, uint32_t interface_id);

/**
 * EAI_LAYER_RESET_FLAGS_ALL: reset all layers to initial state.
 * EAI_LAYER_RESET_FLAGS_ONE: reset specified LSTM/GRU hidden layer to initial state.
 *
 * @param[in] eaih
 *      Handle for eAI runtime instance.
 *
 * @param[in] info
 *      struct of reset information (eai_layer_reset_t) of RNN layer
 *
 * @return EAI_RESULT
 */
EAI_EXPORT EAI_RESULT eai_reset(eaih_t eaih, eai_layer_reset_t* info);

#ifdef __cplusplus
}
#endif

#endif //___EAI_H__
