/**
 * @file common_config.h
 * @brief 项目通用配置和定义
 * @details 包含项目中各模块共用的配置参数和宏定义
 *
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * @copyright Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#ifndef COMMON_CONFIG_H
#define COMMON_CONFIG_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// 项目版本信息
// ============================================================================

#define PROJECT_VERSION_MAJOR   1
#define PROJECT_VERSION_MINOR   0
#define PROJECT_VERSION_PATCH   0
#define PROJECT_VERSION_STRING  "1.0.0"

// ============================================================================
// 通用常量定义
// ============================================================================

#define MAX_PATH_LENGTH         1024
#define MAX_FILENAME_LENGTH     256
#define MAX_ERROR_MSG_LENGTH    512

// ============================================================================
// 内存对齐相关
// ============================================================================

#define MEMORY_ALIGNMENT        256
#define ALIGN_SIZE(size, alignment) \
    (((size) + (alignment) - 1) & ~((alignment) - 1))

// ============================================================================
// 调试和日志相关
// ============================================================================

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) \
    printf("[DEBUG] %s:%d " fmt "\n", __FUNCTION__, __LINE__, ##__VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...)
#endif

#define INFO_PRINT(fmt, ...) \
    printf("[INFO] " fmt "\n", ##__VA_ARGS__)

#define WARN_PRINT(fmt, ...) \
    printf("[WARN] " fmt "\n", ##__VA_ARGS__)

#define ERROR_PRINT(fmt, ...) \
    printf("[ERROR] %s:%d " fmt "\n", __FUNCTION__, __LINE__, ##__VA_ARGS__)

// ============================================================================
// 性能测量相关
// ============================================================================

#define PERF_TIMER_START(name) \
    struct timeval name##_start, name##_end; \
    gettimeofday(&name##_start, NULL)

#define PERF_TIMER_END(name) \
    gettimeofday(&name##_end, NULL); \
    double name##_elapsed = (name##_end.tv_sec - name##_start.tv_sec) * 1000.0 + \
                           (name##_end.tv_usec - name##_start.tv_usec) / 1000.0; \
    printf("[PERF] %s: %.2f ms\n", #name, name##_elapsed)

// ============================================================================
// 错误处理相关
// ============================================================================

#define CHECK_NULL_PTR(ptr, ret_val) \
    do { \
        if (!(ptr)) { \
            ERROR_PRINT("Null pointer: %s", #ptr); \
            return (ret_val); \
        } \
    } while(0)

#define CHECK_CONDITION(cond, ret_val, msg) \
    do { \
        if (!(cond)) { \
            ERROR_PRINT("Condition failed: %s - %s", #cond, msg); \
            return (ret_val); \
        } \
    } while(0)

// ============================================================================
// 数学相关
// ============================================================================

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#ifndef M_PI_2
#define M_PI_2 1.57079632679489661923
#endif

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define CLAMP(x, min_val, max_val) (MAX(min_val, MIN(x, max_val)))

// ============================================================================
// 音频处理相关常量
// ============================================================================

#define DEFAULT_SAMPLE_RATE     16000
#define DEFAULT_FRAME_LENGTH_MS 25
#define DEFAULT_FRAME_SHIFT_MS  10
#define DEFAULT_N_MELS          80
#define DEFAULT_LFR_M           5
#define DEFAULT_LFR_N           1

// ============================================================================
// 推理相关常量
// ============================================================================

#define DEFAULT_CONTEXT_FRAMES  7
#define DEFAULT_MAX_BATCH_FRAMES 64
#define DEFAULT_INPUT_DIM       400
#define DEFAULT_OUTPUT_DIM      248

#ifdef __cplusplus
}
#endif

#endif // COMMON_CONFIG_H
