/**
 * @file postprocess_types.h
 * @brief 后处理组件数据类型定义
 * @details 定义后处理组件使用的基础数据结构和枚举类型
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#ifndef POSTPROCESS_TYPES_H
#define POSTPROCESS_TYPES_H

#include <stdint.h>
#include <stdbool.h>

/**
 * @brief 帧状态枚举
 */
typedef enum {
    FRAME_STATE_SILENCE = 0,    // 静音帧
    FRAME_STATE_SPEECH = 1      // 语音帧
} FrameState;

/**
 * @brief 语音段结构体
 */
typedef struct {
    int start_ms;               // 开始时间(毫秒)
    int end_ms;                 // 结束时间(毫秒)
} SpeechSegment;

/**
 * @brief 语音段列表结构体
 */
typedef struct {
    SpeechSegment* segments;    // 语音段数组
    int count;                  // 语音段数量
    int capacity;               // 数组容量
} VADSpeechSegmentList;

/**
 * @brief VAD logits数据结构
 */
typedef struct {
    float* sil_probs;           // 静音概率数组
    float* speech_probs;        // 语音概率数组
    int num_frames;             // 帧数
} VADLogits;

/**
 * @brief 编码器输出数据结构
 */
typedef struct {
    float* data;                // 编码器输出数据 [num_frames, output_dim]
    int num_frames;             // 帧数
    int output_dim;             // 输出维度
} EncoderOutput;

/**
 * @brief 窗口平滑状态结构体
 */
typedef struct {
    FrameState* frame_states;   // 帧状态缓存
    int* window_buffer;         // 窗口缓存
    int window_pos;             // 窗口位置
    int speech_count;           // 窗口内语音帧计数
    bool initialized;           // 是否已初始化
} WindowSmoothState;

/**
 * @brief 状态机状态结构体
 */
typedef struct {
    FrameState current_state;   // 当前状态
    int state_duration;         // 当前状态持续帧数
    int speech_start_frame;     // 语音段开始帧
    int silence_count;          // 连续静音计数
    bool speech_confirmed;      // 语音是否已确认
} StateMachineState;

#endif // POSTPROCESS_TYPES_H 