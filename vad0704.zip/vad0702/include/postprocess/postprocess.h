/**
 * @file postprocess.h
 * @brief 后处理组件主接口
 * @details VAD后处理组件的主要接口定义，支持NPZ文件和编码器输出两种输入
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#ifndef POSTPROCESS_H
#define POSTPROCESS_H

#include "postprocess_types.h"
#include "postprocess_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 从NPZ文件进行VAD后处理
 * @param npz_file_path NPZ文件路径
 * @param config 后处理配置参数
 * @param output_segments 输出语音段列表
 * @return 0表示成功，非0表示失败
 */
int vad_postprocess_from_npz(const char* npz_file_path, 
                             const VADPostprocessConfig* config,
                             VADSpeechSegmentList* output_segments);

/**
 * @brief 从编码器输出进行VAD后处理
 * @param encoder_output 编码器输出数据
 * @param config 后处理配置参数
 * @param output_segments 输出语音段列表
 * @return 0表示成功，非0表示失败
 */
int vad_postprocess_from_encoder(const EncoderOutput* encoder_output,
                                 const VADPostprocessConfig* config,
                                 VADSpeechSegmentList* output_segments);

/**
 * @brief 初始化语音段列表
 * @param segments 语音段列表
 * @param initial_capacity 初始容量
 * @return 0表示成功，非0表示失败
 */
int speech_segment_list_init(VADSpeechSegmentList* segments, int initial_capacity);

/**
 * @brief 释放语音段列表
 * @param segments 语音段列表
 */
void speech_segment_list_free(VADSpeechSegmentList* segments);

/**
 * @brief 添加语音段到列表
 * @param segments 语音段列表
 * @param start_ms 开始时间(毫秒)
 * @param end_ms 结束时间(毫秒)
 * @return 0表示成功，非0表示失败
 */
int speech_segment_list_add(VADSpeechSegmentList* segments, int start_ms, int end_ms);

/**
 * @brief 打印语音段列表
 * @param segments 语音段列表
 * @param output_file 输出文件路径，NULL则输出到stdout
 */
void speech_segment_list_print(const VADSpeechSegmentList* segments, const char* output_file);

/**
 * @brief 核心VAD后处理算法
 * @param vad_logits VAD logits数据
 * @param config 配置参数
 * @param output_segments 输出语音段列表
 * @return 0表示成功，非0表示失败
 */
int vad_postprocess_core(const VADLogits* vad_logits,
                         const VADPostprocessConfig* config,
                         VADSpeechSegmentList* output_segments);

#ifdef __cplusplus
}
#endif

#endif // POSTPROCESS_H 