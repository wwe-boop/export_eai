/**
 * @file postprocess_config.h
 * @brief 后处理组件配置参数
 * @details 定义后处理算法的关键参数，与Python基准保持一致
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#ifndef POSTPROCESS_CONFIG_H
#define POSTPROCESS_CONFIG_H

/**
 * @brief VAD后处理配置参数结构体
 */
typedef struct {
    // 基础参数
    float speech_noise_thres;       // 语音噪声阈值，默认0.6
    float speech_2_noise_ratio;     // 语音噪声比例，默认1.0
    int frame_duration_ms;          // 每帧时长(毫秒)，默认10ms
    
    // 窗口平滑参数
    int window_size;                // 窗口大小(帧)，默认20帧(200ms)
    int sil_to_speech_thresh;       // 静音转语音阈值(帧)，默认15帧(150ms)
    int speech_to_sil_thresh;       // 语音转静音阈值(帧)，默认15帧(150ms)
    
    // 状态机参数
    int start_point_delay;          // 开始点延迟(帧)，默认40帧(400ms)
    int end_point_lookahead;        // 结束点前瞻(帧)，默认10帧(100ms)
    int max_end_silence_frames;     // 最大结束静音(帧)，默认65帧(650ms)
    
    // 音频参数
    int sample_rate;                // 采样率，默认16000
    
    // 输出参数
    bool enable_debug_output;       // 是否启用调试输出
    const char* output_file;        // 输出文件路径
} VADPostprocessConfig;

/**
 * @brief 获取默认VAD后处理配置
 * @return 默认配置结构体
 */
static inline VADPostprocessConfig get_default_vad_config(void) {
    VADPostprocessConfig config = {
        .speech_noise_thres = 0.6f,
        .speech_2_noise_ratio = 1.0f,
        .frame_duration_ms = 10,
        
        .window_size = 20,
        .sil_to_speech_thresh = 15,
        .speech_to_sil_thresh = 15,
        
        .start_point_delay = 40,
        .end_point_lookahead = 10,
        .max_end_silence_frames = 65,
        
        .sample_rate = 16000,
        
        .enable_debug_output = true,
        .output_file = "build/postprocess_test_output.txt"
    };
    return config;
}

#endif // POSTPROCESS_CONFIG_H 