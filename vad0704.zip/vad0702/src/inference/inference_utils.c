/**
 * @file inference_utils.c
 * @brief 推理组件工具函数实现
 * @details 提供推理组件所需的工具函数，包括量化、内存管理、性能统计等
 *
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * @copyright Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "inference/inference_config.h"
#include "../../include/inference/eai_encoder_inference.h"
#include <stdarg.h>

// ============================================================================
// 时间工具函数
// ============================================================================

uint64_t get_timestamp_us(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (uint64_t)tv.tv_sec * 1000000 + tv.tv_usec;
}

// ============================================================================
// 量化/反量化函数
// ============================================================================

EaiEncoderResult quantize_float32_to_int16(const float* input, 
                                          int16_t* output, 
                                          size_t size, 
                                          float scale) {
    if (!input || !output || size == 0 || scale <= 0.0f) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }
    
    for (size_t i = 0; i < size; i++) {
        float quantized = input[i] / scale;
        
        // 限制到int16范围
        if (quantized > 32767.0f) quantized = 32767.0f;
        if (quantized < -32768.0f) quantized = -32768.0f;
        
        output[i] = (int16_t)roundf(quantized);
    }
    
    return EAI_ENCODER_SUCCESS;
}

EaiEncoderResult dequantize_int16_to_float32(const int16_t* input, 
                                            float* output, 
                                            size_t size, 
                                            float scale) {
    if (!input || !output || size == 0 || scale <= 0.0f) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }
    
    for (size_t i = 0; i < size; i++) {
        output[i] = (float)input[i] * scale;
    }
    
    return EAI_ENCODER_SUCCESS;
}

// ============================================================================
// 内存管理函数
// ============================================================================

void* aligned_malloc(size_t size, size_t alignment) {
    if (size == 0 || alignment == 0) {
        return NULL;
    }
    
    // 确保对齐参数是2的幂
    if ((alignment & (alignment - 1)) != 0) {
        return NULL;
    }
    
    return aligned_alloc(alignment, EAI_ALIGN_SIZE(size, alignment));
}

void aligned_free(void* ptr) {
    if (ptr) {
        free(ptr);
    }
}

// ============================================================================
// 性能统计函数
// ============================================================================

void update_perf_stats(EaiEncoderPerfStats* stats, 
                      uint64_t inference_time_us, 
                      int frames_processed) {
    if (!stats || frames_processed <= 0) {
        return;
    }
    
    stats->total_inference_count++;
    stats->total_inference_time_us += inference_time_us;
    stats->total_frames_processed += frames_processed;
    stats->last_inference_time_us = inference_time_us;
    
    // 计算平均值
    if (stats->total_inference_count > 0) {
        stats->avg_inference_time_ms = 
            (double)stats->total_inference_time_us / (stats->total_inference_count * 1000.0);
    }
    
    if (stats->total_inference_time_us > 0) {
        stats->frames_per_second = 
            (double)stats->total_frames_processed * 1000000.0 / stats->total_inference_time_us;
    }
}

// ============================================================================
// 错误处理函数
// ============================================================================

void set_error_message(EaiEncoderContext* context, 
                      EaiEncoderResult error_code, 
                      const char* format, ...) {
    if (!context || !format) {
        return;
    }
    
    va_list args;
    va_start(args, format);
    vsnprintf(context->last_error_msg, sizeof(context->last_error_msg), format, args);
    va_end(args);
    
    EAI_LOG_ERROR(context, "Error %d: %s", error_code, context->last_error_msg);
}

// ============================================================================
// 参数验证函数
// ============================================================================

EaiEncoderResult validate_input_params(const float* features, 
                                      int time_steps, 
                                      int max_frames) {
    if (!features) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }
    
    if (time_steps <= 0) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }
    
    if (time_steps > max_frames) {
        return EAI_ENCODER_ERROR_BUFFER_OVERFLOW;
    }
    
    return EAI_ENCODER_SUCCESS;
}

// ============================================================================
// 缓冲区计算函数
// ============================================================================

size_t calculate_buffer_size(int time_steps, int feature_dim, size_t data_type_size) {
    if (time_steps <= 0 || feature_dim <= 0 || data_type_size == 0) {
        return 0;
    }
    
    size_t total_size = (size_t)time_steps * feature_dim * data_type_size;
    return EAI_ALIGN_SIZE(total_size, EAI_MEMORY_ALIGNMENT);
}

// ============================================================================
// 数据验证函数
// ============================================================================

static int is_valid_float_array(const float* data, size_t size) {
    if (!data || size == 0) {
        return 0;
    }
    
    for (size_t i = 0; i < size; i++) {
        if (isnan(data[i]) || isinf(data[i])) {
            return 0;
        }
    }
    
    return 1;
}

EaiEncoderResult validate_feature_data(const float* features, 
                                      int time_steps, 
                                      int feature_dim) {
    if (!features) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }
    
    size_t total_elements = (size_t)time_steps * feature_dim;
    if (!is_valid_float_array(features, total_elements)) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }
    
    return EAI_ENCODER_SUCCESS;
}

// ============================================================================
// 调试和打印函数
// ============================================================================

void print_array_stats(const char* name, const float* data, size_t size) {
    if (!name || !data || size == 0) {
        return;
    }
    
    float min_val = data[0];
    float max_val = data[0];
    double sum = 0.0;
    
    for (size_t i = 0; i < size; i++) {
        if (data[i] < min_val) min_val = data[i];
        if (data[i] > max_val) max_val = data[i];
        sum += data[i];
    }
    
    double mean = sum / size;
    
    printf("%s stats: min=%.6f, max=%.6f, mean=%.6f, size=%zu\n", 
           name, min_val, max_val, mean, size);
    
    // 打印前几个值
    printf("%s first 5 values: ", name);
    for (size_t i = 0; i < 5 && i < size; i++) {
        printf("%.6f ", data[i]);
    }
    printf("\n");
}

void print_quantized_array_stats(const char* name, const int16_t* data, size_t size) {
    if (!name || !data || size == 0) {
        return;
    }

    int16_t min_val = data[0];
    int16_t max_val = data[0];
    int64_t sum = 0;

    for (size_t i = 0; i < size; i++) {
        if (data[i] < min_val) min_val = data[i];
        if (data[i] > max_val) max_val = data[i];
        sum += data[i];
    }

    double mean = (double)sum / size;

    printf("%s stats: min=%d, max=%d, mean=%.2f, size=%zu\n",
           name, min_val, max_val, mean, size);

    // 打印前几个值
    printf("%s first 5 values: ", name);
    for (size_t i = 0; i < 5 && i < size; i++) {
        printf("%d ", data[i]);
    }
    printf("\n");
}

// 重复的函数定义已删除
