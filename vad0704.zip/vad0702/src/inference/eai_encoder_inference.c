/**
 * @file eai_encoder_inference.c
 * @brief eAI编码器推理引擎实现
 * @details 实现eAI编码器推理的完整功能，包括初始化、推理执行和资源管理
 *
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * @copyright Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "../../include/inference/eai_encoder_inference.h"
#include "inference/inference_config.h"
#include <string.h>
#include <sys/time.h>
#include <math.h> // 为expf和logf添加

// ============================================================================
// 内部函数声明
// ============================================================================

static EaiEncoderResult allocate_buffers(EaiEncoderContext* context);
static void deallocate_buffers(EaiEncoderContext* context);
static EaiEncoderResult prepare_input_data(EaiEncoderContext* context,
                                          const float* features,
                                          int time_steps);
static EaiEncoderResult execute_inference(EaiEncoderContext* context,
                                         int time_steps);
static EaiEncoderResult process_output_data(EaiEncoderContext* context,
                                           int time_steps,
                                           EaiEncoderInferenceResult* result);

// ============================================================================
// 核心接口实现
// ============================================================================

EaiEncoderContext* eai_encoder_init(const EaiEncoderConfig* config) {
    if (!config || !config->model_path) {
        printf("错误：无效的配置参数\n");
        return NULL;
    }
    
    // 分配上下文内存
    EaiEncoderContext* context = (EaiEncoderContext*)calloc(1, sizeof(EaiEncoderContext));
    if (!context) {
        printf("错误：上下文内存分配失败\n");
        return NULL;
    }
    
    // 复制配置参数
    context->config = *config;
    context->debug_level = config->enable_debug ? 2 : 0;
    
    EAI_LOG_INFO(context, "开始初始化eAI编码器推理上下文");
    EAI_LOG_INFO(context, "模型路径: %s", config->model_path);
    EAI_LOG_INFO(context, "上下文帧数: %d", config->context_frames);
    EAI_LOG_INFO(context, "最大批处理帧数: %d", config->max_batch_frames);
    
    // 初始化eAI VAD上下文（复用eai_interfence实现）
    context->eai_context = eai_vad_init(config->model_path, 
                                       config->context_frames, 
                                       config->max_batch_frames);
    if (!context->eai_context) {
        set_error_message(context, EAI_ENCODER_ERROR_INIT_FAILED, 
                         "eAI VAD上下文初始化失败");
        eai_encoder_destroy(context);
        return NULL;
    }
    
    EAI_LOG_INFO(context, "eAI VAD上下文初始化成功");
    
    // 分配输入输出缓冲区
    if (allocate_buffers(context) != EAI_ENCODER_SUCCESS) {
        set_error_message(context, EAI_ENCODER_ERROR_MEMORY_ALLOC, 
                         "缓冲区分配失败");
        eai_encoder_destroy(context);
        return NULL;
    }
    
    EAI_LOG_INFO(context, "缓冲区分配成功");
    
    // 初始化性能统计
    memset(&context->perf_stats, 0, sizeof(EaiEncoderPerfStats));
    
    // 设置初始化完成标志
    context->is_initialized = 1;
    
    EAI_LOG_INFO(context, "eAI编码器推理上下文初始化完成");
    
    return context;
}

/**
 * @brief 对VAD logits（前2维）应用Softmax
 */
void apply_softmax_to_vad_logits(float* data, int time_steps, int feature_dim) {
    if (feature_dim < 2) {
        return; // 特征维度不足，无法应用softmax
    }

    for (int t = 0; t < time_steps; ++t) {
        float* frame_data = data + t * feature_dim;
        float logit0 = frame_data[0];
        float logit1 = frame_data[1];

        // 寻找最大值以提高数值稳定性
        float max_logit = (logit0 > logit1) ? logit0 : logit1;

        // 计算指数
        float exp0 = expf(logit0 - max_logit);
        float exp1 = expf(logit1 - max_logit);

        // 计算总和
        float sum_exp = exp0 + exp1;

        // 计算Softmax概率
        frame_data[0] = exp0 / sum_exp;
        frame_data[1] = exp1 / sum_exp;
    }
}

EaiEncoderResult eai_encoder_inference(EaiEncoderContext* context,
                                       const float* features,
                                       int time_steps,
                                       EaiEncoderInferenceResult* result) {
    EAI_CHECK_PTR(context);
    EAI_CHECK_PTR(features);
    EAI_CHECK_PTR(result);
    EAI_CHECK_INITIALIZED(context);
    
    // 验证输入参数
    EaiEncoderResult ret = validate_input_params(features, time_steps, 
                                                context->config.max_batch_frames);
    if (ret != EAI_ENCODER_SUCCESS) {
        set_error_message(context, ret, "输入参数验证失败");
        return ret;
    }
    
    // 验证特征数据
    ret = validate_feature_data(features, time_steps, EAI_ENCODER_INPUT_DIM);
    if (ret != EAI_ENCODER_SUCCESS) {
        set_error_message(context, ret, "特征数据验证失败");
        return ret;
    }
    
    EAI_LOG_INFO(context, "开始推理: %d帧", time_steps);
    
    // 开始性能计时
    EAI_PERF_START(start_time);
    
    // 准备输入数据（量化）
    ret = prepare_input_data(context, features, time_steps);
    if (ret != EAI_ENCODER_SUCCESS) {
        set_error_message(context, ret, "输入数据准备失败");
        return ret;
    }
    
    EAI_LOG_DEBUG(context, "输入数据准备完成");
    
    // 执行eAI推理
    ret = execute_inference(context, time_steps);
    if (ret != EAI_ENCODER_SUCCESS) {
        set_error_message(context, ret, "eAI推理执行失败");
        return ret;
    }
    
    EAI_LOG_DEBUG(context, "eAI推理执行完成");
    
    // 处理输出数据（反量化）
    ret = process_output_data(context, time_steps, result);
    if (ret != EAI_ENCODER_SUCCESS) {
        set_error_message(context, ret, "输出数据处理失败");
        return ret;
    }
    
    EAI_LOG_DEBUG(context, "输出数据处理完成");
    
    // 结束性能计时
    EAI_PERF_END(start_time, context, time_steps);
    
    // 设置结果信息
    result->result_code = EAI_ENCODER_SUCCESS;
    result->inference_time_us = get_timestamp_us() - start_time;
    
    EAI_LOG_INFO(context, "推理完成: %d帧, 耗时: %llu微秒",
                time_steps, (unsigned long long)result->inference_time_us);
    
    return EAI_ENCODER_SUCCESS;
}

EaiEncoderResult eai_encoder_inference_batch(EaiEncoderContext* context,
                                             const float* features,
                                             int time_steps,
                                             EaiEncoderInferenceResult* result) {
    EAI_CHECK_PTR(context);
    EAI_CHECK_PTR(features);
    EAI_CHECK_PTR(result);
    EAI_CHECK_INITIALIZED(context);
    
    int max_batch_size = context->config.max_batch_frames;
    
    // 如果数据量小于等于最大批处理大小，直接调用单次推理
    if (time_steps <= max_batch_size) {
        return eai_encoder_inference(context, features, time_steps, result);
    }
    
    EAI_LOG_INFO(context, "开始批量推理: %d帧, 批大小: %d", time_steps, max_batch_size);

    // 分配或重用批量输出缓冲区
    size_t total_output_size = time_steps * EAI_ENCODER_OUTPUT_DIM * sizeof(float);

    // 如果已有缓冲区，先释放
    if (context->batch_output_buffer) {
        aligned_free(context->batch_output_buffer);
        context->batch_output_buffer = NULL;
    }

    // 分配新的批量输出缓冲区
    context->batch_output_buffer = (float*)aligned_malloc(total_output_size, EAI_MEMORY_ALIGNMENT);
    if (!context->batch_output_buffer) {
        set_error_message(context, EAI_ENCODER_ERROR_MEMORY_ALLOC,
                         "批量推理输出缓冲区分配失败");
        return EAI_ENCODER_ERROR_MEMORY_ALLOC;
    }
    
    EaiEncoderInferenceResult batch_result;
    uint64_t total_start_time = get_timestamp_us();
    int processed_frames = 0;
    
    // 分批处理
    for (int offset = 0; offset < time_steps; offset += max_batch_size) {
        int current_batch_size = (offset + max_batch_size <= time_steps) ? 
                                max_batch_size : (time_steps - offset);
        
        const float* batch_input = features + offset * EAI_ENCODER_INPUT_DIM;
        
        EaiEncoderResult ret = eai_encoder_inference(context, batch_input,
                                                    current_batch_size, &batch_result);
        if (ret != EAI_ENCODER_SUCCESS) {
            return ret;
        }

        // 复制批次结果到完整输出缓冲区
        memcpy(context->batch_output_buffer + offset * EAI_ENCODER_OUTPUT_DIM,
               batch_result.encoder_output,
               current_batch_size * EAI_ENCODER_OUTPUT_DIM * sizeof(float));
        
        processed_frames += current_batch_size;
        
        EAI_LOG_DEBUG(context, "批次 %d/%d 完成: %d帧", 
                     offset / max_batch_size + 1, 
                     (time_steps + max_batch_size - 1) / max_batch_size,
                     current_batch_size);
    }
    
    uint64_t total_time = get_timestamp_us() - total_start_time;
    
    // 设置最终结果
    result->encoder_output = context->batch_output_buffer;
    result->time_steps = time_steps;
    result->feature_dim = EAI_ENCODER_OUTPUT_DIM;
    result->result_code = EAI_ENCODER_SUCCESS;
    result->inference_time_us = total_time;

    // 简化的结果验证
    printf("✅ 批量推理完成: %d帧\n", time_steps);
    
    EAI_LOG_INFO(context, "批量推理完成: %d帧, 总耗时: %llu微秒",
                time_steps, (unsigned long long)total_time);
    
    return EAI_ENCODER_SUCCESS;
}

void eai_encoder_destroy(EaiEncoderContext* context) {
    if (!context) {
        return;
    }
    
    EAI_LOG_INFO(context, "开始释放eAI编码器推理上下文");
    
    // 释放缓冲区
    deallocate_buffers(context);
    
    // 释放eAI VAD上下文
    if (context->eai_context) {
        printf("正在释放eAI VAD上下文...\n");
        eai_vad_deinit(context->eai_context);
        context->eai_context = NULL;
        printf("eAI VAD上下文释放完成\n");
    }
    
    // 释放上下文本身
    free(context);
    
    printf("eAI编码器推理上下文已释放\n");
}

// ============================================================================
// 内部函数实现
// ============================================================================

static EaiEncoderResult allocate_buffers(EaiEncoderContext* context) {
    if (!context) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }

    int max_frames = context->config.max_batch_frames;

    // 计算缓冲区大小
    context->input_buffer_size = calculate_buffer_size(max_frames,
                                                      EAI_ENCODER_INPUT_DIM,
                                                      sizeof(float));
    context->output_buffer_size = calculate_buffer_size(max_frames,
                                                       EAI_ENCODER_OUTPUT_DIM,
                                                       sizeof(float));
    context->quantized_input_size = calculate_buffer_size(max_frames * context->config.context_frames,
                                                         EAI_ENCODER_INPUT_DIM,
                                                         sizeof(int16_t));
    context->quantized_output_size = calculate_buffer_size(max_frames,
                                                          EAI_ENCODER_OUTPUT_DIM,
                                                          sizeof(int16_t));

    EAI_LOG_DEBUG(context, "缓冲区大小计算: input=%zu, output=%zu, q_input=%zu, q_output=%zu",
                 context->input_buffer_size, context->output_buffer_size,
                 context->quantized_input_size, context->quantized_output_size);

    // 分配输入缓冲区
    context->input_buffer = (float*)aligned_malloc(context->input_buffer_size,
                                                  EAI_MEMORY_ALIGNMENT);
    if (!context->input_buffer) {
        EAI_LOG_ERROR(context, "输入缓冲区分配失败");
        return EAI_ENCODER_ERROR_MEMORY_ALLOC;
    }

    // 分配输出缓冲区
    context->output_buffer = (float*)aligned_malloc(context->output_buffer_size,
                                                   EAI_MEMORY_ALIGNMENT);
    if (!context->output_buffer) {
        EAI_LOG_ERROR(context, "输出缓冲区分配失败");
        return EAI_ENCODER_ERROR_MEMORY_ALLOC;
    }

    // 分配量化输入缓冲区
    context->quantized_input_buffer = (int16_t*)aligned_malloc(context->quantized_input_size,
                                                              EAI_MEMORY_ALIGNMENT);
    if (!context->quantized_input_buffer) {
        EAI_LOG_ERROR(context, "量化输入缓冲区分配失败");
        return EAI_ENCODER_ERROR_MEMORY_ALLOC;
    }

    // 分配量化输出缓冲区
    context->quantized_output_buffer = (int16_t*)aligned_malloc(context->quantized_output_size,
                                                               EAI_MEMORY_ALIGNMENT);
    if (!context->quantized_output_buffer) {
        EAI_LOG_ERROR(context, "量化输出缓冲区分配失败");
        return EAI_ENCODER_ERROR_MEMORY_ALLOC;
    }

    EAI_LOG_DEBUG(context, "所有缓冲区分配成功");

    return EAI_ENCODER_SUCCESS;
}

static void deallocate_buffers(EaiEncoderContext* context) {
    if (!context) {
        return;
    }

    aligned_free(context->input_buffer);
    aligned_free(context->output_buffer);
    aligned_free(context->batch_output_buffer);
    aligned_free(context->quantized_input_buffer);
    aligned_free(context->quantized_output_buffer);

    context->input_buffer = NULL;
    context->output_buffer = NULL;
    context->batch_output_buffer = NULL;
    context->quantized_input_buffer = NULL;
    context->quantized_output_buffer = NULL;

    EAI_LOG_DEBUG(context, "所有缓冲区已释放");
}

static EaiEncoderResult prepare_input_data(EaiEncoderContext* context,
                                          const float* features,
                                          int time_steps) {
    if (!context || !features || time_steps <= 0) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }

    // 复制输入特征到缓冲区
    size_t input_size = time_steps * EAI_ENCODER_INPUT_DIM * sizeof(float);
    memcpy(context->input_buffer, features, input_size);

    context->current_input_frames = time_steps;

    EAI_LOG_DEBUG(context, "输入特征复制完成: %d帧", time_steps);

    if (context->debug_level >= 3) {
        print_array_stats("输入特征", context->input_buffer,
                         time_steps * EAI_ENCODER_INPUT_DIM);
    }

    return EAI_ENCODER_SUCCESS;
}

static EaiEncoderResult execute_inference(EaiEncoderContext* context,
                                         int time_steps) {
    if (!context || time_steps <= 0) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }

    EAI_LOG_DEBUG(context, "开始执行eAI推理");

    // 使用eai_vad_inference执行推理
    EaiVadResult* vad_result = eai_vad_inference(context->eai_context,
                                                context->input_buffer,
                                                time_steps);

    if (!vad_result) {
        EAI_LOG_ERROR(context, "eAI VAD推理失败");
        return EAI_ENCODER_ERROR_INFERENCE_FAILED;
    }

    if (vad_result->time_steps != time_steps) {
        EAI_LOG_ERROR(context, "推理输出帧数不匹配: 期望%d, 实际%d",
                     time_steps, vad_result->time_steps);
        eai_vad_free_result(vad_result);
        return EAI_ENCODER_ERROR_INFERENCE_FAILED;
    }

    // 复制编码器输出到上下文缓冲区
    size_t output_size = time_steps * EAI_ENCODER_OUTPUT_DIM * sizeof(float);

    memcpy(context->output_buffer, vad_result->encoder_output, output_size);

    context->current_output_frames = time_steps;

    EAI_LOG_DEBUG(context, "eAI推理执行完成: %d帧", time_steps);

    if (context->debug_level >= 3) {
        print_array_stats("编码器输出", context->output_buffer,
                         time_steps * EAI_ENCODER_OUTPUT_DIM);
    }

    // 释放VAD结果
    eai_vad_free_result(vad_result);

    return EAI_ENCODER_SUCCESS;
}

static EaiEncoderResult process_output_data(EaiEncoderContext* context,
                                           int time_steps,
                                           EaiEncoderInferenceResult* result) {
    if (!context || !result || time_steps <= 0) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }

    // 设置结果信息
    result->encoder_output = context->output_buffer;
    result->time_steps = time_steps;
    result->feature_dim = EAI_ENCODER_OUTPUT_DIM;

    EAI_LOG_DEBUG(context, "输出数据处理完成: %d帧 x %d维",
                 time_steps, EAI_ENCODER_OUTPUT_DIM);

    return EAI_ENCODER_SUCCESS;
}

// ============================================================================
// 工具和调试接口实现
// ============================================================================

const EaiEncoderPerfStats* eai_encoder_get_perf_stats(const EaiEncoderContext* context) {
    if (!context || !context->is_initialized) {
        return NULL;
    }

    return &context->perf_stats;
}

EaiEncoderResult eai_encoder_reset_perf_stats(EaiEncoderContext* context) {
    EAI_CHECK_PTR(context);
    EAI_CHECK_INITIALIZED(context);

    memset(&context->perf_stats, 0, sizeof(EaiEncoderPerfStats));

    EAI_LOG_INFO(context, "性能统计已重置");

    return EAI_ENCODER_SUCCESS;
}

const char* eai_encoder_get_last_error(const EaiEncoderContext* context) {
    if (!context) {
        return "无效的上下文指针";
    }

    return context->last_error_msg;
}

EaiEncoderResult eai_encoder_set_debug_level(EaiEncoderContext* context, int debug_level) {
    EAI_CHECK_PTR(context);

    if (debug_level < 0 || debug_level > 3) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }

    context->debug_level = debug_level;

    printf("调试级别设置为: %d\n", debug_level);

    return EAI_ENCODER_SUCCESS;
}

void eai_encoder_print_context_info(const EaiEncoderContext* context) {
    if (!context) {
        printf("无效的上下文指针\n");
        return;
    }

    printf("\n=== eAI编码器推理上下文信息 ===\n");
    printf("初始化状态: %s\n", context->is_initialized ? "已初始化" : "未初始化");
    printf("模型路径: %s\n", context->config.model_path ? context->config.model_path : "未设置");
    printf("上下文帧数: %d\n", context->config.context_frames);
    printf("最大批处理帧数: %d\n", context->config.max_batch_frames);
    printf("输入量化scale: %.10f\n", context->config.input_scale);
    printf("输出量化scale: %.10f\n", context->config.output_scale);
    printf("调试级别: %d\n", context->debug_level);

    printf("\n=== 缓冲区信息 ===\n");
    printf("输入缓冲区大小: %zu 字节\n", context->input_buffer_size);
    printf("输出缓冲区大小: %zu 字节\n", context->output_buffer_size);
    printf("量化输入缓冲区大小: %zu 字节\n", context->quantized_input_size);
    printf("量化输出缓冲区大小: %zu 字节\n", context->quantized_output_size);

    printf("\n=== 当前状态 ===\n");
    printf("当前输入帧数: %d\n", context->current_input_frames);
    printf("当前输出帧数: %d\n", context->current_output_frames);

    if (context->is_initialized) {
        printf("\n=== 性能统计 ===\n");
        printf("总推理次数: %llu\n", (unsigned long long)context->perf_stats.total_inference_count);
        printf("总推理时间: %llu 微秒\n", (unsigned long long)context->perf_stats.total_inference_time_us);
        printf("总处理帧数: %llu\n", (unsigned long long)context->perf_stats.total_frames_processed);
        printf("平均推理时间: %.2f 毫秒\n", context->perf_stats.avg_inference_time_ms);
        printf("处理速度: %.2f 帧/秒\n", context->perf_stats.frames_per_second);
        printf("最近推理时间: %llu 微秒\n", (unsigned long long)context->perf_stats.last_inference_time_us);
    }

    printf("================================\n\n");
}

EaiEncoderResult eai_encoder_validate_result(const EaiEncoderInferenceResult* result,
                                             const char* reference_file,
                                             float tolerance) {
    if (!result || !reference_file || tolerance < 0.0f) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }

    if (!result->encoder_output || result->time_steps <= 0 || result->feature_dim <= 0) {
        return EAI_ENCODER_ERROR_INVALID_PARAM;
    }

    printf("\n=== 开始验证推理结果 ===\n");
    printf("基准文件: %s\n", reference_file);
    printf("容差阈值: %.6f\n", tolerance);
    printf("结果形状: [%d, %d]\n", result->time_steps, result->feature_dim);

    // 这里可以添加实际的NPZ文件读取和比较逻辑
    // 目前先进行基本的数据有效性检查

    // 检查数据有效性
    size_t total_elements = result->time_steps * result->feature_dim;
    for (size_t i = 0; i < total_elements; i++) {
        if (isnan(result->encoder_output[i]) || isinf(result->encoder_output[i])) {
            printf("❌ 发现无效数据: NaN或Inf在位置 %zu\n", i);
            return EAI_ENCODER_ERROR_INVALID_PARAM;
        }
    }

    // 计算统计信息
    float min_val = result->encoder_output[0];
    float max_val = result->encoder_output[0];
    double sum = 0.0;

    for (size_t i = 0; i < total_elements; i++) {
        float val = result->encoder_output[i];
        if (val < min_val) min_val = val;
        if (val > max_val) max_val = val;
        sum += val;
    }

    double mean = sum / total_elements;

    printf("结果统计:\n");
    printf("  最小值: %.6f\n", min_val);
    printf("  最大值: %.6f\n", max_val);
    printf("  平均值: %.6f\n", mean);
    printf("  总元素数: %zu\n", total_elements);

    // 打印前几个值用于调试
    printf("前5个值: ");
    for (int i = 0; i < 5 && i < (int)total_elements; i++) {
        printf("%.6f ", result->encoder_output[i]);
    }
    printf("\n");

    printf("✅ 基本验证通过\n");
    printf("========================\n\n");

    return EAI_ENCODER_SUCCESS;
}
