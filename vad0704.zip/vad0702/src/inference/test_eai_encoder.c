/**
 * @file test_eai_encoder.c
 * @brief eAI编码器推理测试程序
 * @details 测试eAI编码器推理功能，验证与Python基准的一致性
 *
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * @copyright Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "../../include/inference/eai_encoder_inference.h"
#include "../../include/frontend/frontend.h"
#include "../../include/utils/audio_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// 测试配置
#define TEST_AUDIO_PATH "../testsrc/sa1.wav"
#define TEST_OUTPUT_FILE "eai_encoder_test_output.txt"
#define PYTHON_REFERENCE_PATH "../python/ref_result/sa1_eai_encoder_output.npz"

/**
 * @brief 保存推理结果到文件
 */
int save_inference_result(const EaiEncoderInferenceResult* result, const char* output_path) {
    FILE* file = fopen(output_path, "w");
    if (!file) {
        printf("❌ 无法创建输出文件: %s\n", output_path);
        return -1;
    }

    fprintf(file, "# eAI编码器推理测试结果\n");
    fprintf(file, "# 时间步数: %d\n", result->time_steps);
    fprintf(file, "# 特征维度: %d\n", result->feature_dim);
    fprintf(file, "# 推理耗时: %llu 微秒\n", (unsigned long long)result->inference_time_us);
    fprintf(file, "# 结果状态: %d\n", result->result_code);
    fprintf(file, "# 格式: frame_index feature_0 feature_1 ... feature_N\n");

    // 计算统计信息
    float min_val = result->encoder_output[0];
    float max_val = result->encoder_output[0];
    double sum = 0.0;

    for (int t = 0; t < result->time_steps; t++) {
        for (int d = 0; d < result->feature_dim; d++) {
            float val = result->encoder_output[t * result->feature_dim + d];
            if (val < min_val) min_val = val;
            if (val > max_val) max_val = val;
            sum += val;
        }
    }

    double mean = sum / (result->time_steps * result->feature_dim);

    fprintf(file, "# 统计信息:\n");
    fprintf(file, "# 最小值: %.6f\n", min_val);
    fprintf(file, "# 最大值: %.6f\n", max_val);
    fprintf(file, "# 平均值: %.6f\n", mean);
    fprintf(file, "\n");

    // 保存前10帧的前5个特征值用于快速验证
    fprintf(file, "# 前10帧前5个特征值 (用于快速验证):\n");
    for (int t = 0; t < 10 && t < result->time_steps; t++) {
        fprintf(file, "# Frame %d: ", t);
        for (int d = 0; d < 5 && d < result->feature_dim; d++) {
            fprintf(file, "%.6f ", result->encoder_output[t * result->feature_dim + d]);
        }
        fprintf(file, "\n");
    }
    fprintf(file, "\n");

    // 保存完整结果数据
    for (int t = 0; t < result->time_steps; t++) {
        fprintf(file, "%d", t);
        for (int d = 0; d < result->feature_dim; d++) {
            fprintf(file, " %.6f", result->encoder_output[t * result->feature_dim + d]);
        }
        fprintf(file, "\n");
    }

    fclose(file);
    printf("✅ 推理结果已保存到: %s\n", output_path);
    return 0;
}

/**
 * @brief 测试eAI编码器推理
 */
int test_eai_encoder_inference() {
    printf("=== eAI编码器推理测试 ===\n");

    // 1. 初始化前端组件（获取特征）
    printf("🔄 初始化前端组件...\n");
    FrontendChannel* frontend_channel = frontend_channel_init(NULL);  // 使用默认配置
    if (!frontend_channel) {
        printf("❌ 前端组件初始化失败\n");
        return -1;
    }

    // 2. 读取测试音频文件
    printf("🔄 读取音频文件: %s\n", TEST_AUDIO_PATH);

    // 读取真实音频数据
    AudioData audio_data = {0};
    if (read_wav_file(TEST_AUDIO_PATH, &audio_data) != 0) {
        printf("❌ 音频文件读取失败\n");
        frontend_channel_free(frontend_channel);
        return -1;
    }

    printf("✅ 音频文件读取成功: %d 采样点\n", audio_data.length);

    // 3. 提取特征
    printf("🔄 提取Fbank特征...\n");
    ProcessResult fbank_result = {0};
    if (extract_fbank(frontend_channel, &audio_data, &fbank_result) != 0) {
        printf("❌ 特征提取失败\n");
        free(audio_data.waveform);
        frontend_channel_free(frontend_channel);
        return -1;
    }

    printf("✅ 前端处理完成: [%d, %d]\n",
           fbank_result.rows, fbank_result.cols);

    // 4. 初始化eAI编码器推理
    printf("🔄 初始化eAI编码器推理...\n");
    EaiEncoderConfig encoder_config = EAI_ENCODER_CONFIG_DEFAULT;
    encoder_config.model_path = "../models/vad_encoder_eai.eai";  // 修正模型路径

    EaiEncoderContext* encoder_ctx = eai_encoder_init(&encoder_config);
    if (!encoder_ctx) {
        printf("❌ eAI编码器初始化失败\n");
        free(fbank_result.data);
        free(audio_data.waveform);
        frontend_channel_free(frontend_channel);
        return -1;
    }

    printf("✅ eAI编码器初始化成功\n");
    eai_encoder_print_context_info(encoder_ctx);

    // 5. 检查特征数据有效性
    printf("🔄 检查特征数据有效性...\n");
    int total_elements = fbank_result.rows * fbank_result.cols;
    int invalid_count = 0;
    for (int i = 0; i < total_elements; i++) {
        if (isnan(fbank_result.data[i]) || isinf(fbank_result.data[i])) {
            invalid_count++;
            if (invalid_count <= 5) {  // 只打印前5个无效值
                printf("❌ 发现无效数据在位置 %d: %f\n", i, fbank_result.data[i]);
            }
        }
    }

    if (invalid_count > 0) {
        printf("❌ 总共发现 %d 个无效数据点\n", invalid_count);
        eai_encoder_destroy(encoder_ctx);
        free(fbank_result.data);
        free(audio_data.waveform);
        frontend_channel_free(frontend_channel);
        return -1;
    }

    printf("✅ 特征数据有效性检查通过\n");
    printf("特征数据统计: 形状[%d, %d], 范围[%.6f, %.6f], 平均值%.6f\n",
           fbank_result.rows, fbank_result.cols,
           fbank_result.min_val, fbank_result.max_val, fbank_result.mean_val);

    // 6. 执行推理（使用批处理推理处理大数据量）
    printf("🔄 执行eAI编码器推理...\n");
    printf("输入数据: %d帧，最大批处理: %d帧\n", fbank_result.rows, encoder_config.max_batch_frames);

    EaiEncoderInferenceResult inference_result;

    EaiEncoderResult ret = eai_encoder_inference_batch(
        encoder_ctx,
        fbank_result.data,      // 使用提取的特征数据
        fbank_result.rows,      // time_steps
        &inference_result
    );

    if (ret != EAI_ENCODER_SUCCESS) {
        printf("❌ 推理执行失败: %d\n", ret);
        printf("错误信息: %s\n", eai_encoder_get_last_error(encoder_ctx));
        eai_encoder_destroy(encoder_ctx);
        free(fbank_result.data);
        free(audio_data.waveform);
        frontend_channel_free(frontend_channel);
        return -1;
    }

    printf("✅ 推理执行成功!\n");
    printf("输出形状: [%d, %d]\n", inference_result.time_steps, inference_result.feature_dim);
    printf("推理耗时: %llu 微秒\n", (unsigned long long)inference_result.inference_time_us);

    // 在保存结果前应用Softmax
    printf("🔄 对VAD logits应用Softmax...\n");
    apply_softmax_to_vad_logits(
        inference_result.encoder_output,
        inference_result.time_steps,
        inference_result.feature_dim
    );
    printf("✅ Softmax应用完成\n");

    // 6. 显示性能统计
    const EaiEncoderPerfStats* perf_stats = eai_encoder_get_perf_stats(encoder_ctx);
    if (perf_stats) {
        printf("\n=== 性能统计 ===\n");
        printf("推理次数: %llu\n", (unsigned long long)perf_stats->total_inference_count);
        printf("总耗时: %llu 微秒\n", (unsigned long long)perf_stats->total_inference_time_us);
        printf("平均耗时: %.2f 毫秒\n", perf_stats->avg_inference_time_ms);
        printf("处理速度: %.2f 帧/秒\n", perf_stats->frames_per_second);
    }

    // 7. 保存结果（在清理资源之前）
    printf("🔄 保存推理结果...\n");
    if (save_inference_result(&inference_result, TEST_OUTPUT_FILE) != 0) {
        printf("❌ 结果保存失败\n");
        // 继续执行清理，不要返回错误
    }

    // 8. 保存简化的调试输出（无警告）
    printf("🔄 保存调试输出...\n");
    FILE* debug_file = fopen("build/eai_encoder_debug_output.txt", "w");
    if (debug_file) {
        fprintf(debug_file, "=== eAI编码器推理调试输出 ===\n");
        fprintf(debug_file, "输入数据: %d帧 x %d维\n", fbank_result.rows, fbank_result.cols);
        fprintf(debug_file, "输出数据: %d帧 x %d维\n", inference_result.time_steps, inference_result.feature_dim);
        fprintf(debug_file, "推理耗时: %llu 微秒\n", (unsigned long long)inference_result.inference_time_us);
        fprintf(debug_file, "数值范围: [%.6f, %.6f]\n",
                inference_result.encoder_output[0],
                inference_result.encoder_output[inference_result.time_steps * inference_result.feature_dim - 1]);

        // 输出前10帧的前5个值用于快速验证
        fprintf(debug_file, "\n前10帧前5个特征值:\n");
        for (int t = 0; t < 10 && t < inference_result.time_steps; t++) {
            fprintf(debug_file, "帧%d: ", t);
            for (int d = 0; d < 5 && d < inference_result.feature_dim; d++) {
                fprintf(debug_file, "%.6f ", inference_result.encoder_output[t * inference_result.feature_dim + d]);
            }
            fprintf(debug_file, "\n");
        }

        // 输出最后10帧的前5个值
        fprintf(debug_file, "\n最后10帧前5个特征值:\n");
        int start_frame = inference_result.time_steps - 10;
        if (start_frame < 0) start_frame = 0;
        for (int t = start_frame; t < inference_result.time_steps; t++) {
            fprintf(debug_file, "帧%d: ", t);
            for (int d = 0; d < 5 && d < inference_result.feature_dim; d++) {
                fprintf(debug_file, "%.6f ", inference_result.encoder_output[t * inference_result.feature_dim + d]);
            }
            fprintf(debug_file, "\n");
        }

        fclose(debug_file);
        printf("✅ 调试输出已保存到: build/eai_encoder_debug_output.txt\n");
    }

    // 8. 清理资源
    printf("🔄 清理资源...\n");
    eai_encoder_destroy(encoder_ctx);
    free(fbank_result.data);
    free(audio_data.waveform);
    frontend_channel_free(frontend_channel);

    printf("\n✅ eAI编码器推理测试完成!\n");
    printf("📊 结果文件: %s\n", TEST_OUTPUT_FILE);
    printf("🔗 对比基准: %s\n", PYTHON_REFERENCE_PATH);

    return 0;
}

/**
 * @brief 主函数
 */
int main(int argc, char* argv[]) {
    printf("=== eAI编码器推理测试程序 ===\n");
    printf("版本: 1.0.0\n");
    printf("作者: l50011968\n");
    printf("日期: 2025.7.2\n\n");

    // 执行测试
    int result = test_eai_encoder_inference();

    if (result == 0) {
        printf("\n🎉 所有测试通过!\n");
    } else {
        printf("\n❌ 测试失败!\n");
    }

    return result;
} 