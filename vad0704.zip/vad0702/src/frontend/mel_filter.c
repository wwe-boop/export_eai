/**
 * @file mel_filter.c
 * @brief Mel滤波器组模块
 * @details 负责Mel滤波器组的生成和应用
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "frontend/frontend.h"

/**
 * @brief 将频率转换为Mel刻度 (Kaldi标准实现)
 * @param[in] f 频率(Hz)
 * @return Mel刻度值
 */
static float hz2mel(float f) {
    return 1127.0f * logf(1.0f + f / 700.0f);  // 使用自然对数ln，与kaldi.py一致
}

/**
 * @brief 将Mel刻度转换为频率 (Kaldi标准实现)
 * @param[in] m Mel刻度值
 * @return 频率(Hz)
 */
static float mel2hz(float m) {
    return 700.0f * (expf(m / 1127.0f) - 1.0f);  // 使用指数函数exp，与kaldi.py一致
}

/**
 * @brief 生成Mel滤波器组 (Kaldi标准实现)
 * @param[in] n_mels Mel滤波器数量 (int类型)
 * @param[in] n_fft FFT点数 (int类型)
 * @param[in] sample_rate 采样率 (int类型)
 * @param[in] fmin 最小频率 (float类型，单位Hz)
 * @param[in] fmax 最大频率 (float类型，单位Hz)
 * @param[out] mel_filters Mel滤波器组系数 (float*类型，大小为n_mels*(n_fft/2))
 */
void create_mel_filterbank(int n_mels, int n_fft, int sample_rate, float fmin, float fmax, float* mel_filters) {
    // 计算Mel频率点
    float mel_min = hz2mel(fmin);
    float mel_max = hz2mel(fmax);
    float mel_step = (mel_max - mel_min) / (n_mels + 1);

    // 初始化滤波器组
    memset(mel_filters, 0, n_mels * (n_fft/2) * sizeof(float));

    // 使用完全的频域方法构建滤波器（与librosa/kaldi一致）
    for (int i = 0; i < n_mels; i++) {
        float left_mel = mel_min + i * mel_step;
        float center_mel = mel_min + (i + 1) * mel_step;
        float right_mel = mel_min + (i + 2) * mel_step;

        float* filter = mel_filters + i * (n_fft/2);

        // 对每个频率bin计算滤波器权重
        for (int j = 0; j < n_fft/2; j++) {
            float freq = (float)j * sample_rate / n_fft;
            float mel = hz2mel(freq);

            float weight = 0.0f;

            // 三角滤波器：上升沿
            if (mel >= left_mel && mel <= center_mel) {
                if (center_mel > left_mel) {
                    weight = (mel - left_mel) / (center_mel - left_mel);
                }
            }
            // 三角滤波器：下降沿
            else if (mel > center_mel && mel <= right_mel) {
                if (right_mel > center_mel) {
                    weight = (right_mel - mel) / (right_mel - center_mel);
                }
            }

            filter[j] = weight;
        }

        // 归一化滤波器（可选，根据标准决定）
        float filter_sum = 0.0f;
        for (int j = 0; j < n_fft/2; j++) {
            filter_sum += filter[j];
        }

        if (filter_sum > 0.0f) {
            for (int j = 0; j < n_fft/2; j++) {
                filter[j] /= filter_sum;
            }
        }
    }
    

}

/**
 * @brief 应用Mel滤波器组并计算对数能量
 * @param[in] power_spectrum 功率谱 (const float*类型，大小为num_frames*(n_fft/2))
 * @param[in] num_frames 帧数 (int类型)
 * @param[in] n_mels Mel滤波器数量 (int类型)
 * @param[in] n_fft FFT点数 (int类型)
 * @param[in] mel_filters Mel滤波器组系数 (const float*类型，大小为n_mels*(n_fft/2))
 * @param[out] fbank_features Fbank特征 (float*类型，大小为num_frames*n_mels)
 */
void apply_mel_filterbank(const float* power_spectrum, int num_frames, int n_mels, int n_fft, const float* mel_filters, float* fbank_features) {
    // 使用与torchaudio一致的epsilon值：torch.finfo(torch.float).eps
    const float epsilon_val = EPSILON;
    
    for (int i = 0; i < num_frames; i++) {
        const float* frame_power = power_spectrum + i * (n_fft/2);
        float* frame_fbank = fbank_features + i * n_mels;
        
        for (int j = 0; j < n_mels; j++) {
            float mel_energy = 0.0f;
            const float* filter = mel_filters + j * (n_fft/2);

            for (int k = 0; k < n_fft/2; k++) {
                mel_energy += frame_power[k] * filter[k];
            }
            
            mel_energy = mel_energy < epsilon_val ? epsilon_val : mel_energy;
            frame_fbank[j] = logf(mel_energy);  // 使用自然对数
        }
    }
}
