/**
 * @file window.c
 * @brief 窗函数处理模块
 * @details 负责各种窗函数的生成和应用
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "frontend/frontend.h"

/**
 * @brief 生成Povey窗
 * @param[out] window 窗函数数组
 * @param[in] length 窗长度
 */
static void generate_povey_window(float* window, int length) {
    const float PI = (float)M_PI;
    for (int i = 0; i < length; i++) {
        float x = (float)i / (length - 1);
        window[i] = powf(0.5f - 0.5f * cosf(2.0f * PI * x), 0.85f);
    }
}

/**
 * @brief 生成Hamming窗
 * @param[out] window 窗函数数组
 * @param[in] length 窗长度
 */
static void generate_hamming_window(float* window, int length) {
    const float PI = (float)M_PI;
    for (int i = 0; i < length; i++) {
        window[i] = 0.54f - 0.46f * cosf(2.0f * PI * i / (length - 1));
    }
}

/**
 * @brief 生成窗函数
 * @param[out] window 窗函数数组
 * @param[in] length 窗长度
 * @param[in] window_type 窗函数类型
 */
static void generate_window(float* window, int length, const char* window_type) {
    if (strcmp(window_type, "povey") == 0) {
        generate_povey_window(window, length);
    } else {
        generate_hamming_window(window, length);
    }
}

/**
 * @brief Kaldi风格的完整窗口处理
 * @param[in,out] frames 分帧数据
 * @param[in] num_frames 帧数
 * @param[in] frame_length 帧长
 * @param[in] config 配置参数
 * @return 0成功，非0失败
 */
int kaldi_apply_window_processing(float* frames, int num_frames, int frame_length, const FrontendConfig* config) {
    
    for (int i = 0; i < num_frames; i++) {
        float* frame = frames + i * frame_length;
        
        // 1. 抖动处理 (dither)
        if (config->dither > 0.0f) {
            for (int j = 0; j < frame_length; j++) {
                float u1 = (float)rand() / RAND_MAX;
                float u2 = (float)rand() / RAND_MAX;
                float noise = sqrtf(-2.0f * logf(u1)) * cosf(2.0f * M_PI * u2);
                frame[j] += config->dither * noise;
            }
        }
        
        // 2. 去直流分量 (remove_dc_offset)
        float sum = 0.0f;
        for (int j = 0; j < frame_length; j++) {
            sum += frame[j];
        }
        float mean = sum / frame_length;
        for (int j = 0; j < frame_length; j++) {
            frame[j] -= mean;
        }
        
        // 3. 预加重处理 (preemphasis) - 按照torchaudio实际行为
        // offset_strided_input = pad(strided_input, (1, 0), mode="replicate")
        // strided_input = strided_input - preemphasis_coefficient * offset_strided_input[:, :-1]
        if (PREEMPH_COEFF != 0.0f) {
            float first_val = frame[0];
            for (int j = frame_length - 1; j > 0; j--) {
                frame[j] = frame[j] - PREEMPH_COEFF * frame[j-1];
            }
            // 第一个元素: frame[0] - PREEMPH_COEFF * first_val (replicate模式)
            frame[0] = frame[0] - PREEMPH_COEFF * first_val;
        }
        
        // 4. 应用窗函数
        for (int j = 0; j < frame_length; j++) {
            float window_val;
            if (strcmp(config->window, "hamming") == 0) {
                window_val = 0.54f - 0.46f * cosf(2.0f * M_PI * j / (frame_length - 1));
            } else {  // povey window (default)
                float x = (float)j / (frame_length - 1);
                window_val = powf(0.5f - 0.5f * cosf(2.0f * M_PI * x), 0.85f);
            }
            frame[j] *= window_val;
        }
    }
    
    return 0;
}
