/**
 * @file fbank.c
 * @brief Fbank特征提取主模块
 * @details 整合各个模块实现完整的Fbank特征提取流程
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "frontend/frontend.h"
#include <common_config.h>

// 声明外部函数
extern int compute_power_spectrum(const float* frames, int num_frames, int frame_length, int n_fft, float* power_spectrum);
extern void create_mel_filterbank(int n_mels, int n_fft, int sample_rate, float fmin, float fmax, float* mel_filters);
extern void apply_mel_filterbank(const float* power_spectrum, int num_frames, int n_mels, int n_fft, const float* mel_filters, float* fbank_features);
extern int kaldi_apply_window_processing(float* frames, int num_frames, int frame_length, const FrontendConfig* config);

/**
 * @brief 提取Fbank特征
 * @param[in] channel 通道结构体指针 (FrontendChannel*类型，包含所有配置参数)
 * @param[in] audio 音频数据 (const AudioData*类型，包含波形数据和长度)
 * @param[out] fbank_result 处理结果 (ProcessResult*类型，输出完整的特征处理结果，包含Fbank+LFR+CMVN)
 * @return 0成功，非0失败 (int类型)
 */
int extract_fbank(FrontendChannel* channel, const AudioData* audio, ProcessResult* fbank_result) {
    if (!channel || !audio || !audio->waveform || !fbank_result) {
        return -1;
    }

    // 处理fmax参数（0表示使用nyquist频率）
    float fmax = channel->config.fmax;
    if (fmax <= 0.0f) {
        fmax = channel->config.fs / 2.0f;  // Nyquist频率
    }

    // 1. 进行分帧
    int num_frames = (audio->length - channel->config.frame_length) / channel->config.frame_shift + 1;
    if (num_frames <= 0) return -1;

    float* frames = (float*)malloc(num_frames * channel->config.frame_length * sizeof(float));
    if (!frames) return -1;

    // 手动分帧并应用音量放大
    for (int i = 0; i < num_frames; i++) {
        int start_idx = i * channel->config.frame_shift;
        float* frame = frames + i * channel->config.frame_length;

        for (int j = 0; j < channel->config.frame_length; j++) {
            if (start_idx + j < audio->length) {
                frame[j] = audio->waveform[start_idx + j] * (1 << 15); // 音量放大
            } else {
                frame[j] = 0.0f;
            }
        }
    }

    // 2. 应用窗函数处理
    for (int i = 0; i < num_frames; i++) {
        float* frame = frames + i * channel->config.frame_length;

        // 去直流分量
        float frame_sum = 0.0f;
        for (int j = 0; j < channel->config.frame_length; j++) {
            frame_sum += frame[j];
        }
        float frame_mean = frame_sum / channel->config.frame_length;
        for (int j = 0; j < channel->config.frame_length; j++) {
            frame[j] -= frame_mean;
        }

        // 预加重
        if (0.97f != 0.0f) {
            float first_val = frame[0];
            for (int j = channel->config.frame_length - 1; j > 0; j--) {
                frame[j] = frame[j] - 0.97f * frame[j-1];
            }
            frame[0] = frame[0] - 0.97f * first_val;
        }

        // 应用Hamming窗
        for (int j = 0; j < channel->config.frame_length; j++) {
            float window_val = 0.54f - 0.46f * cosf(2.0f * M_PI * j / (channel->config.frame_length - 1));
            frame[j] *= window_val;
        }
    }

    // 3. 计算FFT功率谱
    float* power_spectrum = (float*)malloc(num_frames * (channel->config.n_fft/2) * sizeof(float));
    if (!power_spectrum) {
        free(frames);
        return -1;
    }
    
    if (compute_power_spectrum(frames, num_frames, channel->config.frame_length, 
                             channel->config.n_fft, power_spectrum) != 0) {
        free(frames);
        free(power_spectrum);
        return -1;
    }
    free(frames);

    // 4. 创建Mel滤波器组
    float* mel_filters = (float*)malloc(channel->config.n_mels * (channel->config.n_fft/2) * sizeof(float));
    if (!mel_filters) {
        free(power_spectrum);
        return -1;
    }
    create_mel_filterbank(channel->config.n_mels, channel->config.n_fft, channel->config.fs, 
                         channel->config.fmin, fmax, mel_filters);

    // 5. 应用Mel滤波器组并取对数
    float* fbank_features = (float*)malloc(num_frames * channel->config.n_mels * sizeof(float));
    if (!fbank_features) {
        free(power_spectrum);
        free(mel_filters);
        return -1;
    }
    apply_mel_filterbank(power_spectrum, num_frames, channel->config.n_mels,
                        channel->config.n_fft, mel_filters, fbank_features);
    free(power_spectrum);
    free(mel_filters);

    // 6. 应用LFR处理
    ProcessResult temp_result = {0};
    temp_result.data = fbank_features;
    temp_result.rows = num_frames;
    temp_result.cols = channel->config.n_mels;
    
    ProcessResult lfr_result = {0};
    if (apply_lfr(channel, &temp_result, &lfr_result) != 0) {
        free(fbank_features);
        return -1;
    }
    free(fbank_features);

    // 7. 应用CMVN归一化
    if (apply_cmvn(channel, &lfr_result, fbank_result) != 0) {
        free(lfr_result.data);
        return -1;
    }
    free(lfr_result.data);

    return 0;
}
