/**
 * @file config.c
 * @brief 前端处理配置管理模块
 * @details 负责前端处理配置的初始化和管理
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "frontend/frontend.h"

/**
 * @brief 初始化前端处理配置
 * @param[in] config 配置参数，如果为NULL则使用默认配置
 * @return 配置结构体指针，失败返回NULL
 */
FrontendConfig* frontend_config_init(const FrontendConfig* config) {
    FrontendConfig* cfg = (FrontendConfig*)malloc(sizeof(FrontendConfig));
    if (!cfg) return NULL;
    
    // 设置默认值（严格按照frontend_core.py配置）
    cfg->fs = 16000;           // fs: int = 16000
    cfg->frame_length = 400;   // int(frame_length * fs / 1000) = int(25 * 16000 / 1000) = 400
    cfg->frame_shift = 160;    // int(frame_shift * fs / 1000) = int(10 * 16000 / 1000) = 160
    cfg->n_mels = 80;          // n_mels: int = 80
    cfg->n_fft = 400;          // n_fft = frame_length * fs / 1000 = 400
    strcpy(cfg->window, "hamming");  // window: str = "hamming"
    cfg->lfr_m = 5;            // 实际使用: lfr_m=5
    cfg->lfr_n = 1;            // 实际使用: lfr_n=1
    cfg->fmin = 0.0f;          // fmin = 0.0（与Python参考实现一致）
    cfg->fmax = 8000.0f;       // fmax = 8000.0（与Python参考实现一致）
    cfg->dither = 1.0f;        // dither: float = 0.0（与Python参考实现一致）
    cfg->snip_edges = 1;       // snip_edges: bool = True
    
    // 如果提供了配置，使用提供的值
    if (config) {
        if (config->fs > 0) {
            cfg->fs = config->fs;
            // 如果采样率改变，更新fmax默认值
            if (config->fmax <= 0.0f) {
                cfg->fmax = config->fs / 2.0f;
            }
        }
        if (config->frame_length > 0) cfg->frame_length = config->frame_length;
        if (config->frame_shift > 0) cfg->frame_shift = config->frame_shift;
        if (config->n_mels > 0) cfg->n_mels = config->n_mels;
        if (config->n_fft > 0) cfg->n_fft = config->n_fft;
        if (config->window[0] != '\0') strcpy(cfg->window, config->window);
        if (config->lfr_m > 0) cfg->lfr_m = config->lfr_m;
        if (config->lfr_n > 0) cfg->lfr_n = config->lfr_n;
        if (config->fmin >= 0.0f) cfg->fmin = config->fmin;
        if (config->fmax > 0.0f) cfg->fmax = config->fmax;
        if (config->dither >= 0.0f) cfg->dither = config->dither;
        cfg->snip_edges = config->snip_edges;
    }
    
    return cfg;
}

/**
 * @brief 释放前端处理配置
 * @param[in] config 配置结构体指针
 */
void frontend_config_free(FrontendConfig* config) {
    if (config) {
        free(config);
    }
}

/**
 * @brief 初始化前端处理通道
 * @param[in] config 配置参数，如果为NULL则使用默认配置
 * @return 通道结构体指针，失败返回NULL
 */
FrontendChannel* frontend_channel_init(const FrontendConfig* config) {
    FrontendChannel* channel = (FrontendChannel*)malloc(sizeof(FrontendChannel));
    if (!channel) return NULL;
    
    // 如果配置为空，使用默认配置
    if (config) {
        memcpy(&channel->config, config, sizeof(FrontendConfig));
    } else {
        FrontendConfig* default_config = frontend_config_init(NULL);
        if (!default_config) {
            free(channel);
            return NULL;
        }
        memcpy(&channel->config, default_config, sizeof(FrontendConfig));
        frontend_config_free(default_config);
    }
    
    return channel;
}

/**
 * @brief 释放前端处理通道
 * @param[in] channel 通道结构体指针
 */
void frontend_channel_free(FrontendChannel* channel) {
    if (channel) {
        free(channel);
    }
}
