/**
 * @file fft.c
 * @brief FFT和功率谱计算模块
 * @details 负责FFT变换和功率谱的计算
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "frontend/frontend.h"
#include <fftw3.h>

/**
 * @brief 计算FFT和功率谱
 * @param[in] frames 分帧数据 (const float*类型，大小为num_frames*frame_length)
 * @param[in] num_frames 帧数 (int类型)
 * @param[in] frame_length 帧长 (int类型，采样点数)
 * @param[in] n_fft FFT点数 (int类型)
 * @param[out] power_spectrum 功率谱输出 (float*类型，大小为num_frames*(n_fft/2))
 * @return 0成功，非0失败 (int类型)
 */
int compute_power_spectrum(const float* frames, int num_frames, int frame_length, int n_fft, float* power_spectrum) {
    float* fft_in = (float*)fftwf_malloc(n_fft * sizeof(float));
    fftwf_complex* fft_out = (fftwf_complex*)fftwf_malloc((n_fft/2 + 1) * sizeof(fftwf_complex));
    if (!fft_in || !fft_out) {
        if (fft_in) fftwf_free(fft_in);
        if (fft_out) fftwf_free(fft_out);
        return -1;
    }
    
    fftwf_plan plan = fftwf_plan_dft_r2c_1d(n_fft, fft_in, fft_out, FFTW_ESTIMATE);
    if (!plan) {
        fftwf_free(fft_in);
        fftwf_free(fft_out);
        return -1;
    }
    
    for (int i = 0; i < num_frames; i++) {
        memcpy(fft_in, frames + i * frame_length, frame_length * sizeof(float));
        memset(fft_in + frame_length, 0, (n_fft - frame_length) * sizeof(float));
        
        fftwf_execute(plan);
        
        float* frame_power = power_spectrum + i * (n_fft/2);
        for (int j = 0; j < n_fft/2; j++) {
            float real = fft_out[j][0];
            float imag = fft_out[j][1];
            frame_power[j] = real * real + imag * imag;  // Kaldi风格：不除以n_fft
            if (frame_power[j] < 1e-10f) frame_power[j] = 1e-10f;
        }
    }
    
    fftwf_destroy_plan(plan);
    fftwf_free(fft_in);
    fftwf_free(fft_out);
    
    return 0;
}
