/**
 * @file unified_test.c
 * @brief 统一的前端组件测试程序
 * @details 整合所有前端组件测试功能，包括配置测试、音频处理测试和验证测试
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sndfile.h>
#include <fftw3.h>
#include "frontend/frontend.h"

// 函数声明
static AudioData* read_wav_file(const char* filename);
static void free_audio_data(AudioData* audio);
static void print_process_result(const char* name, const ProcessResult* result);
static void save_results_to_file(const char* filename, const ProcessResult* result, const char* step_name);
static int test_config_initialization(void);
static int test_audio_preprocessing(const char* audio_path);
static int test_fbank_extraction(const char* audio_path);
static int validate_against_python(const char* audio_path);
static int debug_fbank_step_by_step(const char* audio_path);
static int extract_pure_fbank_features(FrontendChannel* channel, const AudioData* audio, ProcessResult* fbank_result);
static void compare_with_python_reference(const ProcessResult* result, const char* step_name,
                                        float expected_min, float expected_max, float expected_mean);

/**
 * @brief 读取WAV音频文件
 * @param[in] filename 文件路径
 * @return 音频数据结构指针，失败返回NULL
 */
static AudioData* read_wav_file(const char* filename) {
    SF_INFO sf_info = {0};
    SNDFILE* file = sf_open(filename, SFM_READ, &sf_info);
    if (!file) {
        printf("Error: Could not open file %s\n", filename);
        return NULL;
    }
    
    AudioData* audio = (AudioData*)malloc(sizeof(AudioData));
    if (!audio) {
        sf_close(file);
        return NULL;
    }
    
    audio->length = sf_info.frames;
    audio->waveform = (float*)malloc(audio->length * sizeof(float));
    if (!audio->waveform) {
        free(audio);
        sf_close(file);
        return NULL;
    }
    
    sf_count_t read_frames = sf_readf_float(file, audio->waveform, sf_info.frames);
    if (read_frames != sf_info.frames) {
        free(audio->waveform);
        free(audio);
        sf_close(file);
        return NULL;
    }
    
    sf_close(file);
    return audio;
}

/**
 * @brief 释放音频数据
 * @param[in] audio 音频数据指针
 */
static void free_audio_data(AudioData* audio) {
    if (audio) {
        if (audio->waveform) {
            free(audio->waveform);
        }
        free(audio);
    }
}

/**
 * @brief 打印处理结果
 * @param[in] name 结果名称
 * @param[in] result 处理结果
 */
static void print_process_result(const char* name, const ProcessResult* result) {
    if (!result || !result->data) {
        printf("%s: NULL\n", name);
        return;
    }
    
    printf("%s:\n", name);
    printf("  Shape: [%d, %d]\n", result->rows, result->cols);
    printf("  Range: [%.6f, %.6f]\n", result->min_val, result->max_val);
    printf("  Mean: %.6f\n", result->mean_val);
    
    // 打印前5个值（如果有的话）
    if (result->cols >= 5) {
        printf("  First 5 values: [");
        for (int i = 0; i < 5; i++) {
            printf("%.6f", result->data[i]);
            if (i < 4) printf(", ");
        }
        printf("]\n");
    }
}

/**
 * @brief 保存结果到文件
 * @param[in] filename 文件名
 * @param[in] result 处理结果
 * @param[in] step_name 步骤名称
 */
static void save_results_to_file(const char* filename, const ProcessResult* result, const char* step_name) {
    FILE* fp = fopen(filename, "a");
    if (!fp) return;
    
    fprintf(fp, "\n=== %s ===\n", step_name);
    fprintf(fp, "Shape: [%d, %d]\n", result->rows, result->cols);
    fprintf(fp, "Range: min=%.10f, max=%.10f, mean=%.10f\n", 
            result->min_val, result->max_val, result->mean_val);
    
    // 输出第一帧前5个数值
    if (result->rows > 0 && result->cols >= 5) {
        fprintf(fp, "First 5 values: ");
        for (int i = 0; i < 5; i++) {
            fprintf(fp, "%.10f", result->data[i]);
            if (i < 4) fprintf(fp, ", ");
        }
        fprintf(fp, "\n");
    }
    
    fclose(fp);
}

/**
 * @brief 测试配置初始化
 * @return 0成功，非0失败
 */
static int test_config_initialization(void) {
    printf("=== 测试配置初始化 ===\n");
    
    // 测试默认配置
    FrontendConfig* config = frontend_config_init(NULL);
    if (!config) {
        printf("Error: Failed to initialize default config\n");
        return -1;
    }
    
    printf("Default configuration:\n");
    printf("  Sample rate: %d Hz\n", config->fs);
    printf("  Frame length: %d samples (%.1f ms)\n", config->frame_length, 
           (float)config->frame_length * 1000 / config->fs);
    printf("  Frame shift: %d samples (%.1f ms)\n", config->frame_shift,
           (float)config->frame_shift * 1000 / config->fs);
    printf("  Mel filters: %d\n", config->n_mels);
    printf("  FFT size: %d\n", config->n_fft);
    printf("  Window: %s\n", config->window);
    printf("  Frequency range: %.1f - %.1f Hz\n", config->fmin, config->fmax);
    printf("  LFR: m=%d, n=%d\n", config->lfr_m, config->lfr_n);
    
    // 测试通道初始化
    FrontendChannel* channel = frontend_channel_init(config);
    if (!channel) {
        printf("Error: Failed to initialize channel\n");
        frontend_config_free(config);
        return -1;
    }
    
    printf("Channel initialized successfully\n");
    
    // 清理
    frontend_channel_free(channel);
    frontend_config_free(config);
    
    return 0;
}

/**
 * @brief 测试音频预处理
 * @param[in] audio_path 音频文件路径
 * @return 0成功，非0失败
 */
static int test_audio_preprocessing(const char* audio_path) {
    printf("\n=== 测试音频预处理 ===\n");

    // 读取音频文件
    AudioData* audio = read_wav_file(audio_path);
    if (!audio) {
        printf("Error: Failed to read audio file: %s\n", audio_path);
        return -1;
    }

    printf("Audio loaded: %d samples\n", audio->length);

    // 执行预处理
    ProcessResult input_result = {0};
    ProcessResult amplified_result = {0};

    if (preprocess_audio(audio, &input_result, &amplified_result) != 0) {
        printf("Error: Audio preprocessing failed\n");
        free_audio_data(audio);
        return -1;
    }

    // 打印结果
    print_process_result("Input waveform", &input_result);
    print_process_result("Amplified waveform", &amplified_result);

    // 清理
    free(amplified_result.data);
    free_audio_data(audio);

    return 0;
}

/**
 * @brief 测试Fbank特征提取
 * @param[in] audio_path 音频文件路径
 * @return 0成功，非0失败
 */
static int test_fbank_extraction(const char* audio_path) {
    printf("\n=== 测试Fbank特征提取 ===\n");

    // 读取音频文件
    AudioData* audio = read_wav_file(audio_path);
    if (!audio) {
        printf("Error: Failed to read audio file: %s\n", audio_path);
        return -1;
    }

    // 初始化前端处理器
    FrontendChannel* channel = frontend_channel_init(NULL);
    if (!channel) {
        printf("Error: Failed to initialize frontend channel\n");
        free_audio_data(audio);
        return -1;
    }

    // 提取特征
    ProcessResult fbank_result = {0};
    if (extract_fbank(channel, audio, &fbank_result) != 0) {
        printf("Error: Fbank extraction failed\n");
        frontend_channel_free(channel);
        free_audio_data(audio);
        return -1;
    }

    // 打印结果
    print_process_result("Fbank features (with LFR and CMVN)", &fbank_result);

    // 清理
    free(fbank_result.data);
    frontend_channel_free(channel);
    free_audio_data(audio);

    return 0;
}

/**
 * @brief 验证与Python结果的一致性
 * @param[in] audio_path 音频文件路径
 * @return 0成功，非0失败
 */
static int validate_against_python(const char* audio_path) {
    printf("\n=== 验证与Python结果一致性 ===\n");

    // 读取音频文件
    AudioData* audio = read_wav_file(audio_path);
    if (!audio) {
        printf("Error: Failed to read audio file: %s\n", audio_path);
        return -1;
    }

    // 初始化前端处理器（使用与Python一致的配置）
    FrontendConfig config = {0};
    config.fs = 16000;
    config.frame_length = 400;    // 25ms
    config.frame_shift = 160;     // 10ms
    config.n_mels = 80;
    config.n_fft = 400;
    strcpy(config.window, "hamming");
    config.lfr_m = 5;
    config.lfr_n = 1;
    config.fmin = 20.0f;
    config.fmax = 8000.0f;
    config.dither = 1.0f; 
    config.snip_edges = 1;

    FrontendChannel* channel = frontend_channel_init(&config);
    if (!channel) {
        printf("Error: Failed to initialize frontend channel\n");
        free_audio_data(audio);
        return -1;
    }

    // 清空结果文件
    FILE* fp = fopen("c_frontend_validation.txt", "w");
    if (fp) {
        fprintf(fp, "=== C Frontend Validation Results ===\n");
        fprintf(fp, "Test file: %s\n", audio_path);
        fprintf(fp, "Configuration:\n");
        fprintf(fp, "  Sample rate: %d Hz\n", config.fs);
        fprintf(fp, "  Frame length: %d samples (%.1f ms)\n", config.frame_length,
                (float)config.frame_length * 1000 / config.fs);
        fprintf(fp, "  Frame shift: %d samples (%.1f ms)\n", config.frame_shift,
                (float)config.frame_shift * 1000 / config.fs);
        fprintf(fp, "  Mel filters: %d\n", config.n_mels);
        fprintf(fp, "  FFT size: %d\n", config.n_fft);
        fprintf(fp, "  Window: %s\n", config.window);
        fprintf(fp, "  Frequency range: %.1f - %.1f Hz\n", config.fmin, config.fmax);
        fprintf(fp, "  LFR: m=%d, n=%d\n", config.lfr_m, config.lfr_n);
        fclose(fp);
    }

    // 执行预处理
    ProcessResult input_result = {0};
    ProcessResult amplified_result = {0};

    if (preprocess_audio(audio, &input_result, &amplified_result) != 0) {
        printf("Error: Audio preprocessing failed\n");
        frontend_channel_free(channel);
        free_audio_data(audio);
        return -1;
    }

    // 保存预处理结果
    save_results_to_file("c_frontend_validation.txt", &input_result, "1. Input Waveform");
    save_results_to_file("c_frontend_validation.txt", &amplified_result, "2. Amplified Waveform");

    // 提取Fbank特征
    ProcessResult fbank_result = {0};
    if (extract_fbank(channel, audio, &fbank_result) != 0) {
        printf("Error: Fbank extraction failed\n");
        free(amplified_result.data);
        frontend_channel_free(channel);
        free_audio_data(audio);
        return -1;
    }

    save_results_to_file("c_frontend_validation.txt", &fbank_result, "3. Final Output (Fbank+LFR+CMVN)");

    // 输出验证信息
    printf("Validation results:\n");
    printf("  Input audio: %d samples\n", audio->length);
    printf("  Amplified: [%d, %d], range: [%.3f, %.3f]\n",
           amplified_result.rows, amplified_result.cols,
           amplified_result.min_val, amplified_result.max_val);
    printf("  Final features: [%d, %d], range: [%.6f, %.6f]\n",
           fbank_result.rows, fbank_result.cols,
           fbank_result.min_val, fbank_result.max_val);

    printf("\nResults saved to: c_frontend_validation.txt\n");
    printf("Please compare with python/ref_result/sa1_frontend_steps.json\n");

    // 清理
    free(fbank_result.data);
    free(amplified_result.data);
    frontend_channel_free(channel);
    free_audio_data(audio);

    return 0;
}

/**
 * @brief 测试前端组件的主函数
 * @param[in] audio_path 音频文件路径
 * @return 0成功，非0失败
 */
int test_frontend(const char* audio_path) {
    if (!audio_path) {
        printf("Error: Audio path is NULL\n");
        return -1;
    }

    printf("=== Frontend Component Unified Test ===\n");
    printf("Audio file: %s\n", audio_path);

    // 执行所有测试
    if (test_config_initialization() != 0) {
        printf("Config initialization test failed\n");
        return -1;
    }

    if (test_audio_preprocessing(audio_path) != 0) {
        printf("Audio preprocessing test failed\n");
        return -1;
    }

    if (test_fbank_extraction(audio_path) != 0) {
        printf("Fbank extraction test failed\n");
        return -1;
    }

    if (validate_against_python(audio_path) != 0) {
        printf("Python validation test failed\n");
        return -1;
    }

    // 执行详细的逐步调试
    if (debug_fbank_step_by_step(audio_path) != 0) {
        printf("Step-by-step debug test failed\n");
        return -1;
    }

    printf("\n=== All tests completed successfully ===\n");
    return 0;
}

/**
 * @brief 与Python参考结果比较
 * @param[in] result 处理结果
 * @param[in] step_name 步骤名称
 * @param[in] expected_min 期望最小值
 * @param[in] expected_max 期望最大值
 * @param[in] expected_mean 期望平均值
 */
static void compare_with_python_reference(const ProcessResult* result, const char* step_name,
                                        float expected_min, float expected_max, float expected_mean) {
    if (!result || !result->data) {
        printf("❌ %s: 无效数据，无法比较\n", step_name);
        return;
    }

    printf("🔍 %s 与Python参考结果比较:\n", step_name);
    printf("   📐 形状: [%d, %d] (总计 %d 个元素)\n", result->rows, result->cols, result->rows * result->cols);

    // 比较最小值
    float min_diff = fabsf(result->min_val - expected_min);
    printf("   📉 最小值: C=%.10f, Python=%.10f, 差异=%.2e %s\n",
           result->min_val, expected_min, min_diff,
           min_diff < 1e-5 ? "✅" : (min_diff < 1e-3 ? "⚠️" : "❌"));

    // 比较最大值
    float max_diff = fabsf(result->max_val - expected_max);
    printf("   📈 最大值: C=%.10f, Python=%.10f, 差异=%.2e %s\n",
           result->max_val, expected_max, max_diff,
           max_diff < 1e-5 ? "✅" : (max_diff < 1e-3 ? "⚠️" : "❌"));

    // 比较平均值
    float mean_diff = fabsf(result->mean_val - expected_mean);
    printf("   📊 平均值: C=%.10f, Python=%.10f, 差异=%.2e %s\n",
           result->mean_val, expected_mean, mean_diff,
           mean_diff < 1e-5 ? "✅" : (mean_diff < 1e-3 ? "⚠️" : "❌"));

    // 总体评估
    if (min_diff < 1e-5 && max_diff < 1e-5 && mean_diff < 1e-5) {
        printf("   🎯 结果评估: 完全匹配 ✅\n");
    } else if (min_diff < 1e-3 && max_diff < 1e-3 && mean_diff < 1e-3) {
        printf("   🎯 结果评估: 基本匹配 ⚠️\n");
    } else {
        printf("   🎯 结果评估: 存在差异 ❌\n");
    }
}

/**
 * @brief 提取纯Fbank特征（不包含LFR和CMVN）
 * @param[in] channel 前端通道
 * @param[in] audio 音频数据
 * @param[out] fbank_result Fbank特征结果
 * @return 0成功，非0失败
 */
static int extract_pure_fbank_features(FrontendChannel* channel, const AudioData* audio, ProcessResult* fbank_result) {
    if (!channel || !audio || !audio->waveform || !fbank_result) {
        return -1;
    }

    // 处理fmax参数（0表示使用nyquist频率）
    float fmax = channel->config.fmax;
    if (fmax <= 0.0f) {
        fmax = channel->config.fs / 2.0f;  // Nyquist频率
    }

    // 1. 进行分帧
    int num_frames = (audio->length - channel->config.frame_length) / channel->config.frame_shift + 1;
    if (num_frames <= 0) return -1;

    float* frames = (float*)malloc(num_frames * channel->config.frame_length * sizeof(float));
    if (!frames) return -1;

    // 手动分帧
    for (int i = 0; i < num_frames; i++) {
        int start_idx = i * channel->config.frame_shift;
        float* frame = frames + i * channel->config.frame_length;

        for (int j = 0; j < channel->config.frame_length; j++) {
            if (start_idx + j < audio->length) {
                frame[j] = audio->waveform[start_idx + j];
            } else {
                frame[j] = 0.0f;
            }
        }
    }

    // 2. 应用窗函数处理
    for (int i = 0; i < num_frames; i++) {
        float* frame = frames + i * channel->config.frame_length;

        // 去直流分量
        float frame_sum = 0.0f;
        for (int j = 0; j < channel->config.frame_length; j++) {
            frame_sum += frame[j];
        }
        float frame_mean = frame_sum / channel->config.frame_length;
        for (int j = 0; j < channel->config.frame_length; j++) {
            frame[j] -= frame_mean;
        }

        // 预加重
        if (0.97f != 0.0f) {
            float first_val = frame[0];
            for (int j = channel->config.frame_length - 1; j > 0; j--) {
                frame[j] = frame[j] - 0.97f * frame[j-1];
            }
            frame[0] = frame[0] - 0.97f * first_val;
        }

        // 应用Hamming窗
        for (int j = 0; j < channel->config.frame_length; j++) {
            float window_val = 0.54f - 0.46f * cosf(2.0f * 3.14159265359f * j / (channel->config.frame_length - 1));
            frame[j] *= window_val;
        }
    }

    // 3. 计算FFT功率谱
    float* power_spectrum = (float*)malloc(num_frames * (channel->config.n_fft/2) * sizeof(float));
    if (!power_spectrum) {
        free(frames);
        return -1;
    }

    if (compute_power_spectrum(frames, num_frames, channel->config.frame_length,
                             channel->config.n_fft, power_spectrum) != 0) {
        free(frames);
        free(power_spectrum);
        return -1;
    }
    free(frames);

    // 4. 创建Mel滤波器组
    float* mel_filters = (float*)malloc(channel->config.n_mels * (channel->config.n_fft/2) * sizeof(float));
    if (!mel_filters) {
        free(power_spectrum);
        return -1;
    }
    create_mel_filterbank(channel->config.n_mels, channel->config.n_fft, channel->config.fs,
                         channel->config.fmin, fmax, mel_filters);

    // 5. 应用Mel滤波器组并取对数
    float* fbank_features = (float*)malloc(num_frames * channel->config.n_mels * sizeof(float));
    if (!fbank_features) {
        free(power_spectrum);
        free(mel_filters);
        return -1;
    }
    apply_mel_filterbank(power_spectrum, num_frames, channel->config.n_mels,
                        channel->config.n_fft/2, mel_filters, fbank_features);
    free(power_spectrum);
    free(mel_filters);

    // 记录结果（仅Fbank特征，不包含LFR和CMVN）
    fbank_result->data = fbank_features;
    fbank_result->rows = num_frames;
    fbank_result->cols = channel->config.n_mels;

    // 计算统计信息
    float min_val = fbank_features[0];
    float max_val = fbank_features[0];
    double sum = 0.0;
    int total_size = num_frames * channel->config.n_mels;

    for (int i = 0; i < total_size; i++) {
        if (fbank_features[i] < min_val) min_val = fbank_features[i];
        if (fbank_features[i] > max_val) max_val = fbank_features[i];
        sum += fbank_features[i];
    }

    fbank_result->min_val = min_val;
    fbank_result->max_val = max_val;
    fbank_result->mean_val = (float)(sum / total_size);

    return 0;
}

/**
 * @brief 逐步调试Fbank特征提取过程
 * @param[in] audio_path 音频文件路径
 * @return 0成功，非0失败
 */
static int debug_fbank_step_by_step(const char* audio_path) {
    printf("\n=== 逐步调试Fbank特征提取过程 ===\n");

    // 读取音频文件
    AudioData* audio = read_wav_file(audio_path);
    if (!audio) {
        printf("Error: Failed to read audio file: %s\n", audio_path);
        return -1;
    }

    printf("🔍 音频文件读取成功: %d 采样点\n", audio->length);

    // 初始化前端配置（使用与Python一致的参数）
    FrontendConfig config = {0};
    config.fs = 16000;
    config.frame_length = 400;    // 25ms
    config.frame_shift = 160;     // 10ms
    config.n_mels = 80;
    config.n_fft = 400;
    strcpy(config.window, "hamming");
    config.lfr_m = 5;
    config.lfr_n = 1;
    config.fmin = 0.0f;           // 与Python一致
    config.fmax = 8000.0f;        // 与Python一致
    config.dither = 0.0f;         // 与Python一致
    config.snip_edges = 1;

    FrontendChannel* channel = frontend_channel_init(&config);
    if (!channel) {
        printf("Error: Failed to initialize frontend channel\n");
        free_audio_data(audio);
        return -1;
    }

    printf("✅ 前端配置初始化成功\n");
    printf("📋 配置参数:\n");
    printf("   采样率: %d Hz\n", config.fs);
    printf("   帧长: %d 采样点 (%.1f ms)\n", config.frame_length,
           (float)config.frame_length * 1000.0f / config.fs);
    printf("   帧移: %d 采样点 (%.1f ms)\n", config.frame_shift,
           (float)config.frame_shift * 1000.0f / config.fs);
    printf("   Mel滤波器数: %d\n", config.n_mels);
    printf("   FFT点数: %d\n", config.n_fft);
    printf("   频率范围: %.1f - %.1f Hz\n", config.fmin, config.fmax);
    printf("   抖动系数: %.1f\n", config.dither);

    // 步骤1: 音频预处理
    printf("\n🔍 步骤1: 音频预处理\n");
    ProcessResult input_result = {0};
    ProcessResult amplified_result = {0};

    if (preprocess_audio(audio, &input_result, &amplified_result) != 0) {
        printf("❌ 音频预处理失败\n");
        frontend_channel_free(channel);
        free_audio_data(audio);
        return -1;
    }

    printf("✅ 音频预处理成功\n");
    print_process_result("输入波形", &input_result);
    compare_with_python_reference(&input_result, "输入波形",
                                -0.04058837890625f, 0.061614990234375f, 0.00022875524882692844f);

    print_process_result("音量放大", &amplified_result);
    compare_with_python_reference(&amplified_result, "音量放大",
                                -1330.0f, 2019.0f, 7.495851993560791f);

    // 步骤2: 纯Fbank特征提取
    printf("\n🔍 步骤2: 纯Fbank特征提取（不含LFR和CMVN）\n");

    // 使用放大后的音频数据
    AudioData amplified_audio = {
        .waveform = amplified_result.data,
        .length = amplified_result.cols
    };

    ProcessResult pure_fbank_result = {0};
    if (extract_pure_fbank_features(channel, &amplified_audio, &pure_fbank_result) != 0) {
        printf("❌ 纯Fbank特征提取失败\n");
        free(amplified_result.data);
        frontend_channel_free(channel);
        free_audio_data(audio);
        return -1;
    }

    printf("✅ 纯Fbank特征提取成功\n");
    print_process_result("纯Fbank特征", &pure_fbank_result);
    compare_with_python_reference(&pure_fbank_result, "纯Fbank特征",
                                2.934011459350586f, 21.91221809387207f, 13.650327682495117f);

    // 步骤3: LFR处理
    printf("\n🔍 步骤3: LFR处理\n");
    ProcessResult lfr_result = {0};
    if (apply_lfr(channel, &pure_fbank_result, &lfr_result) != 0) {
        printf("❌ LFR处理失败\n");
        free(pure_fbank_result.data);
        free(amplified_result.data);
        frontend_channel_free(channel);
        free_audio_data(audio);
        return -1;
    }

    printf("✅ LFR处理成功\n");
    print_process_result("LFR输出", &lfr_result);
    compare_with_python_reference(&lfr_result, "LFR输出",
                                2.934011459350586f, 21.91221809387207f, 13.648598670959473f);

    // 步骤4: CMVN归一化
    printf("\n🔍 步骤4: CMVN归一化\n");
    ProcessResult cmvn_result = {0};
    if (apply_cmvn(channel, &lfr_result, &cmvn_result) != 0) {
        printf("❌ CMVN归一化失败\n");
        free(lfr_result.data);
        free(pure_fbank_result.data);
        free(amplified_result.data);
        frontend_channel_free(channel);
        free_audio_data(audio);
        return -1;
    }

    printf("✅ CMVN归一化成功\n");
    print_process_result("CMVN输出", &cmvn_result);
    compare_with_python_reference(&cmvn_result, "CMVN输出",
                                -1.0382468700408936f, 1.0991052389144897f, 0.009595663286745548f);

    printf("\n🎉 所有步骤测试完成！\n");
    printf("📋 完整处理流程:\n");
    printf("   1. 输入波形 → 2. 音量放大 → 3. Fbank特征 → 4. LFR处理 → 5. CMVN归一化\n");

    // 清理资源
    free(cmvn_result.data);
    free(lfr_result.data);
    free(pure_fbank_result.data);
    free(amplified_result.data);
    frontend_channel_free(channel);
    free_audio_data(audio);

    return 0;
}

#ifndef MAIN_PROGRAM
int main(int argc, char* argv[]) {
    const char* audio_path = "../testsrc/sa1.wav";  // 默认音频文件路径

    // 如果提供了命令行参数，使用指定的音频文件路径
    if (argc > 1) {
        audio_path = argv[1];
    }

    return test_frontend(audio_path);
}
#endif
