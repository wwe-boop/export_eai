/**
 * @file audio_preprocess.c
 * @brief 音频预处理模块
 * @details 负责音频数据的预处理，包括音量放大、预加重、去直流等
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "frontend/frontend.h"

/**
 * @brief 计算数组的统计信息
 * @param[in] data 数据数组
 * @param[in] length 数组长度
 * @param[out] result 处理结果
 */
static void compute_stats(const float* data, int length, ProcessResult* result) {
    if (!data || length <= 0 || !result) return;
    
    result->min_val = data[0];
    result->max_val = data[0];
    result->mean_val = 0;
    
    for (int i = 0; i < length; i++) {
        if (data[i] < result->min_val) result->min_val = data[i];
        if (data[i] > result->max_val) result->max_val = data[i];
        result->mean_val += data[i];
    }
    
    result->mean_val /= length;
}

/**
 * @brief 预加重处理
 * @param[in,out] data 音频数据
 * @param[in] length 数据长度
 */
static void preemphasis(float* data, int length) {
    for (int i = length - 1; i > 0; i--) {
        data[i] -= PREEMPH_COEFF * data[i-1];
    }
    data[0] *= (1.0f - PREEMPH_COEFF);
}

/**
 * @brief 去直流分量
 * @param[in,out] data 音频数据
 * @param[in] length 数据长度
 */
static void remove_dc_offset(float* data, int length) {
    float sum = 0.0f;
    for (int i = 0; i < length; i++) {
        sum += data[i];
    }
    float mean = sum / length;
    for (int i = 0; i < length; i++) {
        data[i] -= mean;
    }
}

/**
 * @brief 抖动处理
 * @param[in,out] data 音频数据
 * @param[in] length 数据长度
 * @param[in] dither 抖动系数
 */
static void apply_dither(float* data, int length, float dither) {
    if (dither <= 0.0f) return;
    
    for (int i = 0; i < length; i++) {
        // 使用Box-Muller变换生成高斯噪声
        float u1 = (float)rand() / RAND_MAX;
        float u2 = (float)rand() / RAND_MAX;
        float noise = sqrtf(-2.0f * logf(u1)) * cosf(2.0f * M_PI * u2);
        data[i] += dither * noise;
    }
}

/**
 * @brief 音频数据预处理
 * @param[in] audio 输入音频数据
 * @param[out] input_result 输入波形的处理结果
 * @param[out] amplified_result 放大后的处理结果
 * @return 0成功，非0失败
 */
int preprocess_audio(const AudioData* audio, ProcessResult* input_result, ProcessResult* amplified_result) {
    if (!audio || !audio->waveform || audio->length <= 0) return -1;
    
    // 记录输入波形结果
    input_result->data = audio->waveform;
    input_result->rows = 1;
    input_result->cols = audio->length;
    compute_stats(audio->waveform, audio->length, input_result);
    
    // 音量放大
    float* amplified = (float*)malloc(audio->length * sizeof(float));
    if (!amplified) return -1;
    
    // 音量放大（与Python实现保持一致，只做音量放大）
    for (int i = 0; i < audio->length; i++) {
        amplified[i] = audio->waveform[i] * (1 << 15);  // 放大2^15倍
    }
    
    // 记录放大后结果
    amplified_result->data = amplified;
    amplified_result->rows = 1;
    amplified_result->cols = audio->length;
    compute_stats(amplified, audio->length, amplified_result);
    
    return 0;
}

/**
 * @brief Kaldi风格的分帧函数
 * @param[in] waveform 音频波形
 * @param[in] length 波形长度
 * @param[in] frame_length 帧长
 * @param[in] frame_shift 帧移
 * @param[in] snip_edges 是否裁剪边缘
 * @param[out] num_frames 输出帧数
 * @return 分帧后的数据
 */
float* kaldi_get_strided(const float* waveform, int length, int frame_length, int frame_shift, int snip_edges, int* num_frames) {
    if (snip_edges) {
        if (length < frame_length) {
            *num_frames = 0;
            return NULL;
        } else {
            *num_frames = 1 + (length - frame_length) / frame_shift;
        }
    } else {
        *num_frames = (length + (frame_shift / 2)) / frame_shift;
        // TODO: 实现边缘反射填充
    }
    
    if (*num_frames <= 0) return NULL;
    
    float* frames = (float*)malloc((*num_frames) * frame_length * sizeof(float));
    if (!frames) return NULL;
    
    // 分帧
    for (int i = 0; i < *num_frames; i++) {
        int start = i * frame_shift;
        for (int j = 0; j < frame_length; j++) {
            if (start + j < length) {
                frames[i * frame_length + j] = waveform[start + j];
            } else {
                frames[i * frame_length + j] = 0.0f;  // 零填充
            }
        }
    }
    
    return frames;
}
