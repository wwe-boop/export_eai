/**
 * @file cmvn.c
 * @brief CMVN(Cepstral Mean and Variance Normalization)处理模块
 * @details 负责CMVN归一化处理
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "frontend/frontend.h"

/**
 * @brief 计算数组的统计信息
 * @param[in] data 数据数组
 * @param[in] length 数组长度
 * @param[out] result 处理结果
 */
static void compute_stats(const float* data, int length, ProcessResult* result) {
    if (!data || length <= 0 || !result) return;
    
    result->min_val = data[0];
    result->max_val = data[0];
    result->mean_val = 0;
    
    for (int i = 0; i < length; i++) {
        if (data[i] < result->min_val) result->min_val = data[i];
        if (data[i] > result->max_val) result->max_val = data[i];
        result->mean_val += data[i];
    }
    
    result->mean_val /= length;
}

/**
 * @brief 加载CMVN参数
 * @param[in] cmvn_file CMVN文件路径
 * @param[out] means 均值数组
 * @param[out] vars 方差数组
 * @return 0成功，非0失败
 */
static int load_cmvn(const char* cmvn_file, float** means, float** vars) {
    FILE* fp = fopen(cmvn_file, "r");
    if (!fp) {
        return -1;
    }

    char line[MAX_LINE_LENGTH];
    float* means_data = (float*)malloc(400 * sizeof(float));
    float* vars_data = (float*)malloc(400 * sizeof(float));
    
    int means_count = 0;
    int vars_count = 0;
    int found_addshift = 0;
    int found_rescale = 0;
    
    while (fgets(line, MAX_LINE_LENGTH, fp)) {
        // 查找AddShift段（means）
        if (strstr(line, "<AddShift>")) {
            found_addshift = 1;
            continue;
        }
        
        // 查找Rescale段（vars）
        if (strstr(line, "<Rescale>")) {
            found_rescale = 1;
            continue;
        }
        
        // 解析AddShift后的LearnRateCoef行
        if (found_addshift && !found_rescale && strstr(line, "<LearnRateCoef>")) {

            char* token = strtok(line, " \t\n");
            int token_index = 0;
            
            while (token && means_count < 400) {
                // 跳过 "<LearnRateCoef>", "0", 和 "["
                if (token_index >= 3 && strcmp(token, "]") != 0) {
                    means_data[means_count++] = atof(token);
                }
                token = strtok(NULL, " \t\n");
                token_index++;
            }

            found_addshift = 0;  // 标记已处理
        }
        
        // 解析Rescale后的LearnRateCoef行
        if (found_rescale && strstr(line, "<LearnRateCoef>")) {

            char* token = strtok(line, " \t\n");
            int token_index = 0;
            
            while (token && vars_count < 400) {
                // 跳过 "<LearnRateCoef>", "0", 和 "["
                if (token_index >= 3 && strcmp(token, "]") != 0) {
                    vars_data[vars_count++] = atof(token);
                }
                token = strtok(NULL, " \t\n");
                token_index++;
            }

            found_rescale = 0;  // 标记已处理
        }
    }
    
    fclose(fp);
    
    if (means_count != 400 || vars_count != 400) {
        printf("错误: CMVN参数数量不正确，期望400个，实际 means=%d, vars=%d\n", means_count, vars_count);
        free(means_data);
        free(vars_data);
        return -1;
    }
    
    printf("成功加载CMVN参数: means=%d, vars=%d\n", means_count, vars_count);
    *means = means_data;
    *vars = vars_data;
    return 0;
}

/**
 * @brief 应用CMVN归一化
 * @param[in] channel 处理通道 (FrontendChannel*类型，包含配置信息)
 * @param[in] input 输入特征 (const ProcessResult*类型，包含待归一化的特征数据)
 * @param[out] cmvn_result CMVN处理结果 (ProcessResult*类型，输出归一化后的特征)
 * @return 0成功，非0失败 (int类型)
 */
int apply_cmvn(FrontendChannel* channel, const ProcessResult* input, ProcessResult* cmvn_result) {
    if (!channel || !input || !input->data || !cmvn_result) return -1;
    
    // 加载CMVN参数 - 尝试多个可能的路径
    float* means = NULL;
    float* vars = NULL;
    const char* cmvn_paths[] = {
        "../models/am.mvn",     // 从build目录运行时的路径
        "models/am.mvn",        // 从项目根目录运行时的路径
        "./models/am.mvn",      // 当前目录下的models文件夹
        NULL
    };

    int cmvn_loaded = 0;
    for (int i = 0; cmvn_paths[i] != NULL; i++) {
        if (load_cmvn(cmvn_paths[i], &means, &vars) == 0) {
            printf("✅ 成功加载CMVN参数: %s\n", cmvn_paths[i]);
            cmvn_loaded = 1;
            break;
        }
    }

    if (!cmvn_loaded) {
        printf("警告: 无法加载CMVN参数，跳过归一化\n");
        printf("尝试的路径:\n");
        for (int i = 0; cmvn_paths[i] != NULL; i++) {
            printf("  - %s\n", cmvn_paths[i]);
        }
        // 如果无法加载CMVN，直接复制原始特征
        float* output = (float*)malloc(input->rows * input->cols * sizeof(float));
        if (!output) return -1;
        memcpy(output, input->data, input->rows * input->cols * sizeof(float));
        cmvn_result->data = output;
        cmvn_result->rows = input->rows;
        cmvn_result->cols = input->cols;
        compute_stats(output, input->rows * input->cols, cmvn_result);
        return 0;
    }
    
    // 分配输出内存
    float* output = (float*)malloc(input->rows * input->cols * sizeof(float));
    if (!output) {
        free(means);
        free(vars);
        return -1;
    }
    
    // 应用CMVN归一化
    for (int i = 0; i < input->rows; i++) {
        for (int j = 0; j < input->cols; j++) {
            if (j < 400) {  // CMVN参数有400个
                output[i * input->cols + j] = input->data[i * input->cols + j] + means[j];
                output[i * input->cols + j] *= vars[j];
            } else {
                output[i * input->cols + j] = input->data[i * input->cols + j];
            }
        }
    }
    
    // 记录结果
    cmvn_result->data = output;
    cmvn_result->rows = input->rows;
    cmvn_result->cols = input->cols;
    compute_stats(output, input->rows * input->cols, cmvn_result);
    
    free(means);
    free(vars);
    return 0;
}
