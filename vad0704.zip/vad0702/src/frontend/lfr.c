/**
 * @file lfr.c
 * @brief LFR(Low Frame Rate)处理模块
 * @details 负责LFR特征处理
 * @author l50011968
 * @date 2025.7.2
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "frontend/frontend.h"

/**
 * @brief 计算数组的统计信息
 * @param[in] data 数据数组
 * @param[in] length 数组长度
 * @param[out] result 处理结果
 */
static void compute_stats(const float* data, int length, ProcessResult* result) {
    if (!data || length <= 0 || !result) return;
    
    result->min_val = data[0];
    result->max_val = data[0];
    result->mean_val = 0;
    
    for (int i = 0; i < length; i++) {
        if (data[i] < result->min_val) result->min_val = data[i];
        if (data[i] > result->max_val) result->max_val = data[i];
        result->mean_val += data[i];
    }
    
    result->mean_val /= length;
}

/**
 * @brief 应用LFR(Low Frame Rate)处理
 * @param[in] channel 通道结构体指针 (FrontendChannel*类型，包含LFR配置参数)
 * @param[in] input 输入特征 (const ProcessResult*类型，包含特征数据和维度信息)
 * @param[out] lfr_result 输出特征 (ProcessResult*类型，输出LFR处理后的特征)
 * @return 0成功，非0失败 (int类型)
 */
int apply_lfr(FrontendChannel* channel, const ProcessResult* input, ProcessResult* lfr_result) {
    if (!channel || !input || !input->data || !lfr_result) return -1;
    
    // 如果不需要LFR处理，直接复制原始特征
    if (channel->config.lfr_m == 1 && channel->config.lfr_n == 1) {
        float* output = (float*)malloc(input->rows * input->cols * sizeof(float));
        if (!output) return -1;
        memcpy(output, input->data, input->rows * input->cols * sizeof(float));
        lfr_result->data = output;
        lfr_result->rows = input->rows;
        lfr_result->cols = input->cols;
        compute_stats(output, input->rows * input->cols, lfr_result);
        return 0;
    }
    
    // 计算LFR后的帧数
    int lfr_num_frames = (input->rows + channel->config.lfr_n - 1) / channel->config.lfr_n;
    int lfr_feat_dim = channel->config.lfr_m * input->cols;
    
    // 分配输出内存
    float* output = (float*)malloc(lfr_num_frames * lfr_feat_dim * sizeof(float));
    if (!output) return -1;
    
    // 逐帧处理
    for (int i = 0; i < lfr_num_frames; i++) {
        int start_frame = i * channel->config.lfr_n;
        int end_frame = start_frame + channel->config.lfr_m;
        if (end_frame > input->rows) end_frame = input->rows;
        
        // 复制当前帧组的特征
        int valid_frames = end_frame - start_frame;
        memcpy(output + i * lfr_feat_dim, 
               input->data + start_frame * input->cols,
               valid_frames * input->cols * sizeof(float));
        
        // 如果需要填充，使用最后一帧的特征
        if (valid_frames < channel->config.lfr_m) {
            const float* last_frame = input->data + (input->rows - 1) * input->cols;
            for (int j = valid_frames; j < channel->config.lfr_m; j++) {
                memcpy(output + i * lfr_feat_dim + j * input->cols,
                       last_frame,
                       input->cols * sizeof(float));
            }
        }
    }
    
    // 记录结果
    lfr_result->data = output;
    lfr_result->rows = lfr_num_frames;
    lfr_result->cols = lfr_feat_dim;
    compute_stats(output, lfr_num_frames * lfr_feat_dim, lfr_result);
    
    return 0;
}
