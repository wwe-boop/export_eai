/**
 * @file audio_utils.c
 * @brief 音频处理工具函数实现
 * @details 提供音频文件读取、写入等通用功能
 *
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * @copyright Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include "utils/audio_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <sndfile.h>

/**
 * @brief 读取WAV音频文件
 * @param[in] filename 文件路径
 * @param[out] audio_data 音频数据结构指针
 * @return 0成功，非0失败
 */
int read_wav_file(const char* filename, AudioData* audio_data) {
    if (!filename || !audio_data) {
        printf("Error: Invalid parameters for read_wav_file\n");
        return -1;
    }

    SF_INFO sf_info = {0};
    SNDFILE* file = sf_open(filename, SFM_READ, &sf_info);
    if (!file) {
        printf("Error: Could not open file %s\n", filename);
        return -1;
    }
    
    audio_data->length = sf_info.frames;
    audio_data->waveform = (float*)malloc(audio_data->length * sizeof(float));
    if (!audio_data->waveform) {
        sf_close(file);
        return -1;
    }
    
    sf_count_t read_frames = sf_readf_float(file, audio_data->waveform, sf_info.frames);
    if (read_frames != sf_info.frames) {
        free(audio_data->waveform);
        audio_data->waveform = NULL;
        sf_close(file);
        return -1;
    }
    
    sf_close(file);
    return 0;
}

/**
 * @brief 释放音频数据内存
 * @param[in] audio_data 音频数据结构指针
 */
void free_audio_data(AudioData* audio_data) {
    if (audio_data && audio_data->waveform) {
        free(audio_data->waveform);
        audio_data->waveform = NULL;
        audio_data->length = 0;
    }
}
