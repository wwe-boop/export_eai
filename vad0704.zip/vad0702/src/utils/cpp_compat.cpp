/**
 * @file cpp_compat.cpp
 * @brief C++兼容性支持 - 为eAI库提供缺失的C++标准库符号
 * 
 * 这个文件提供了eAI库所需但系统C++标准库中缺失的符号的弱定义。
 * 这些符号通常在较新版本的libstdc++中提供，但为了兼容性，我们提供备用实现。
 */

#include <stdexcept>
#include <new>

/**
 * @brief 弱符号定义：当数组分配长度无效时抛出异常
 *
 * 这个函数在较新的libstdc++中定义，但在较老版本中可能缺失。
 * 我们提供一个弱符号定义作为备用。
 */
namespace std {
    __attribute__((weak))
    void __throw_bad_array_new_length() {
        throw std::bad_array_new_length();
    }
}
