/**
 * @file main.c
 * @brief VAD项目主程序入口 - 调试版本
 * @details 负责调用前端、推理和后处理三个核心组件，每一步都输出结果并与Python参考结果比较
 * @author l50011968
 * @date 2025.6.30
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "frontend/frontend.h"
#include "inference/eai_encoder_inference.h"
#include "postprocess/postprocess.h"
#include "postprocess/postprocess_types.h"
#include "postprocess/postprocess_config.h"
#include "utils/audio_utils.h"

// 前向声明
int test_inference_component(const char* audio_path, const char* model_path);
int debug_frontend_step_by_step(const char* audio_path);
int debug_extract_fbank_only(FrontendChannel* channel, const AudioData* audio, ProcessResult* fbank_result);
int debug_fbank_detailed(FrontendChannel* channel, const AudioData* audio, ProcessResult* fbank_result);

// 调试辅助函数
void debug_print_array_stats(const float* data, int size, const char* name);
void debug_print_first_n_values(const float* data, int n, const char* name);
void debug_compare_with_python_ref(const float* data, int rows, int cols, const char* step_name,
                           float expected_min, float expected_max, float expected_mean);
void print_separator(const char* title);

int main(int argc, char *argv[]) {
    print_separator("VAD项目调试版本启动");

    // 检查帮助参数
    if (argc > 1 && (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0)) {
        printf("用法: %s [音频文件路径] [模型文件路径] [--debug-frontend]\n", argv[0]);
        printf("参数:\n");
        printf("  音频文件路径: WAV音频文件路径 (默认: testsrc/sa1.wav)\n");
        printf("  模型文件路径: eAI模型文件路径 (默认: models/vad_encoder_eai.eai)\n");
        printf("  --debug-frontend: 启用前端逐步调试模式\n");
        printf("示例:\n");
        printf("  %s\n", argv[0]);
        printf("  %s testsrc/test.wav\n", argv[0]);
        printf("  %s testsrc/test.wav models/my_model.eai\n", argv[0]);
        printf("  %s testsrc/sa1.wav models/vad_encoder_eai.eai --debug-frontend\n", argv[0]);
        return 0;
    }

    // 解析命令行参数
    const char *audio_path = "testsrc/sa1.wav";  // 默认音频文件路径
    const char *model_path = "models/vad_encoder_eai.eai";  // 默认模型路径
    int debug_frontend = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--debug-frontend") == 0) {
            debug_frontend = 1;
        } else if (i == 1) {
            audio_path = argv[i];
        } else if (i == 2) {
            model_path = argv[i];
        }
    }

    printf("🔧 配置参数:\n");
    printf("  📁 音频文件: %s\n", audio_path);
    printf("  🤖 模型文件: %s\n", model_path);
    printf("  🐛 前端调试模式: %s\n", debug_frontend ? "启用" : "禁用");

    int ret = 0;

    if (debug_frontend) {
        // 1. 前端逐步调试模式
        print_separator("前端组件逐步调试");
        ret = debug_frontend_step_by_step(audio_path);
        if (ret != 0) {
            printf("❌ 前端逐步调试失败，错误代码: %d\n", ret);
            return -1;
        }
        printf("✅ 前端逐步调试完成\n");
    } else {
        // 1. 调用前端组件进行测试
        print_separator("前端组件测试");
        ret = test_frontend(audio_path);
        if (ret != 0) {
            printf("❌ 前端测试失败，错误代码: %d\n", ret);
            return -1;
        }
        printf("✅ 前端测试完成\n");
    }

    // 2. 推理组件测试
    print_separator("推理组件测试");
    ret = test_inference_component(audio_path, model_path);
    if (ret != 0) {
        printf("❌ 推理测试失败，错误代码: %d\n", ret);
        return -1;
    }
    printf("✅ 推理测试完成\n");

    print_separator("所有测试完成");
    printf("🎉 VAD项目调试版本运行成功！\n");
    return 0;
}

/**
 * @brief 打印分隔线和标题
 */
void print_separator(const char* title) {
    printf("\n");
    printf("============================================================\n");
    printf("🔍 %s\n", title);
    printf("============================================================\n");
}

/**
 * @brief 打印数组统计信息
 */
void debug_print_array_stats(const float* data, int size, const char* name) {
    if (!data || size <= 0) {
        printf("❌ %s: 无效数据\n", name);
        return;
    }

    float min_val = data[0];
    float max_val = data[0];
    double sum = 0.0;

    for (int i = 0; i < size; i++) {
        if (data[i] < min_val) min_val = data[i];
        if (data[i] > max_val) max_val = data[i];
        sum += data[i];
    }

    float mean_val = (float)(sum / size);

    printf("📊 %s 统计:\n", name);
    printf("   📏 大小: %d\n", size);
    printf("   📉 最小值: %.10f\n", min_val);
    printf("   📈 最大值: %.10f\n", max_val);
    printf("   📊 平均值: %.10f\n", mean_val);
}

/**
 * @brief 打印数组前N个值
 */
void debug_print_first_n_values(const float* data, int n, const char* name) {
    if (!data || n <= 0) {
        printf("❌ %s: 无效数据\n", name);
        return;
    }

    printf("🔢 %s 前%d个值: [", name, n);
    for (int i = 0; i < n; i++) {
        printf("%.10f", data[i]);
        if (i < n - 1) printf(", ");
    }
    printf("]\n");
}

/**
 * @brief 与Python参考结果比较
 */
void debug_compare_with_python_ref(const float* data, int rows, int cols, const char* step_name,
                           float expected_min, float expected_max, float expected_mean) {
    if (!data) {
        printf("❌ %s: 无效数据，无法比较\n", step_name);
        return;
    }

    int size = rows * cols;
    float min_val = data[0];
    float max_val = data[0];
    double sum = 0.0;

    for (int i = 0; i < size; i++) {
        if (data[i] < min_val) min_val = data[i];
        if (data[i] > max_val) max_val = data[i];
        sum += data[i];
    }

    float mean_val = (float)(sum / size);

    printf("🔍 %s 与Python参考结果比较:\n", step_name);
    printf("   📐 形状: [%d, %d] (总计 %d 个元素)\n", rows, cols, size);

    // 比较最小值
    float min_diff = fabsf(min_val - expected_min);
    printf("   📉 最小值: C=%.10f, Python=%.10f, 差异=%.2e %s\n",
           min_val, expected_min, min_diff,
           min_diff < 1e-5 ? "✅" : (min_diff < 1e-3 ? "⚠️" : "❌"));

    // 比较最大值
    float max_diff = fabsf(max_val - expected_max);
    printf("   📈 最大值: C=%.10f, Python=%.10f, 差异=%.2e %s\n",
           max_val, expected_max, max_diff,
           max_diff < 1e-5 ? "✅" : (max_diff < 1e-3 ? "⚠️" : "❌"));

    // 比较平均值
    float mean_diff = fabsf(mean_val - expected_mean);
    printf("   📊 平均值: C=%.10f, Python=%.10f, 差异=%.2e %s\n",
           mean_val, expected_mean, mean_diff,
           mean_diff < 1e-5 ? "✅" : (mean_diff < 1e-3 ? "⚠️" : "❌"));

    // 总体评估
    if (min_diff < 1e-5 && max_diff < 1e-5 && mean_diff < 1e-5) {
        printf("   🎯 结果评估: 完全匹配 ✅\n");
    } else if (min_diff < 1e-3 && max_diff < 1e-3 && mean_diff < 1e-3) {
        printf("   🎯 结果评估: 基本匹配 ⚠️\n");
    } else {
        printf("   🎯 结果评估: 存在差异 ❌\n");
    }
}

/**
 * @brief 前端组件逐步调试函数
 * @param audio_path 音频文件路径
 * @return 0成功，非0失败
 */
int debug_frontend_step_by_step(const char* audio_path) {
    printf("🔍 开始前端组件逐步调试...\n");
    printf("📁 音频文件: %s\n", audio_path);

    // 1. 读取音频文件
    print_separator("步骤1: 读取音频文件");
    AudioData audio_data = {0};
    if (read_wav_file(audio_path, &audio_data) != 0) {
        printf("❌ 音频文件读取失败\n");
        return -1;
    }
    printf("✅ 音频文件读取成功: %d 采样点\n", audio_data.length);

    // 2. 音频预处理（输入波形和音量放大）
    print_separator("步骤2: 音频预处理");
    ProcessResult input_result = {0};
    ProcessResult amplified_result = {0};

    if (preprocess_audio(&audio_data, &input_result, &amplified_result) != 0) {
        printf("❌ 音频预处理失败\n");
        free(audio_data.waveform);
        return -1;
    }

    // 2.1 输入波形分析
    printf("\n📊 步骤2.1: 输入波形分析\n");
    debug_print_array_stats(input_result.data, input_result.cols, "输入波形");
    debug_print_first_n_values(input_result.data, 5, "输入波形");

    // 与Python参考结果比较
    debug_compare_with_python_ref(input_result.data, input_result.rows, input_result.cols,
                          "输入波形", -0.04058837890625f, 0.061614990234375f, 0.00022875524882692844f);

    // 2.2 音量放大分析
    printf("\n📊 步骤2.2: 音量放大分析\n");
    debug_print_array_stats(amplified_result.data, amplified_result.cols, "音量放大");
    debug_print_first_n_values(amplified_result.data, 5, "音量放大");

    // 与Python参考结果比较
    debug_compare_with_python_ref(amplified_result.data, amplified_result.rows, amplified_result.cols,
                          "音量放大", -1330.0f, 2019.0f, 7.495851993560791f);

    // 3. 初始化前端配置和通道
    print_separator("步骤3: 初始化前端配置");
    FrontendConfig* config = frontend_config_init(NULL);
    if (!config) {
        printf("❌ 前端配置初始化失败\n");
        free(amplified_result.data);
        free(audio_data.waveform);
        return -1;
    }

    FrontendChannel* channel = frontend_channel_init(config);
    if (!channel) {
        printf("❌ 前端通道初始化失败\n");
        free(amplified_result.data);
        free(audio_data.waveform);
        frontend_config_free(config);
        return -1;
    }

    printf("✅ 前端配置和通道初始化成功\n");
    printf("📋 配置参数:\n");
    printf("   采样率: %d Hz\n", config->fs);
    printf("   Mel滤波器数: %d\n", config->n_mels);
    printf("   帧长: %d 采样点 (%.1f ms)\n", config->frame_length,
           (float)config->frame_length * 1000.0f / config->fs);
    printf("   帧移: %d 采样点 (%.1f ms)\n", config->frame_shift,
           (float)config->frame_shift * 1000.0f / config->fs);
    printf("   窗函数: %s\n", config->window);
    printf("   FFT点数: %d\n", config->n_fft);

    // 4. 调用现有的extract_fbank组件
    print_separator("步骤4: 调用extract_fbank组件");

    // 使用放大后的音频数据
    AudioData amplified_audio = {
        .waveform = amplified_result.data,
        .length = amplified_result.cols
    };

    ProcessResult fbank_result = {0};
    if (extract_fbank(channel, &amplified_audio, &fbank_result) != 0) {
        printf("❌ extract_fbank组件调用失败\n");
        free(amplified_result.data);
        free(audio_data.waveform);
        frontend_channel_free(channel);
        frontend_config_free(config);
        return -1;
    }

    printf("✅ extract_fbank组件调用成功\n");
    printf("📊 extract_fbank输出形状: [%d, %d]\n", fbank_result.rows, fbank_result.cols);
    debug_print_array_stats(fbank_result.data, fbank_result.rows * fbank_result.cols, "extract_fbank输出");
    debug_print_first_n_values(fbank_result.data, 5, "extract_fbank输出");

    // 与Python参考结果比较（这里是完整流程的最终输出）
    debug_compare_with_python_ref(fbank_result.data, fbank_result.rows, fbank_result.cols,
                          "extract_fbank输出", -1.0382468700408936f, 1.0991052389144897f, 0.009595663286745548f);

    // 5. 调用apply_lfr组件
    print_separator("步骤5: 调用apply_lfr组件");

    // 注意：extract_fbank已经包含了完整流程，我们需要单独测试LFR
    // 这里我们直接使用extract_fbank的输出作为演示
    printf("📊 extract_fbank输出（作为后续组件的输入参考）:\n");
    printf("   形状: [%d, %d]\n", fbank_result.rows, fbank_result.cols);
    debug_print_array_stats(fbank_result.data, fbank_result.rows * fbank_result.cols, "extract_fbank输出");
    debug_print_first_n_values(fbank_result.data, 5, "extract_fbank输出");

    printf("\n📝 说明: extract_fbank组件已经包含了Fbank+LFR+CMVN的完整流程\n");
    printf("   如需单独测试LFR组件，需要先获取纯Fbank特征作为输入\n");

    // 6. 推理组件测试
    print_separator("步骤6: 调用推理组件");

    printf("📊 前端输出（推理组件输入）:\n");
    printf("   形状: [%d, %d]\n", fbank_result.rows, fbank_result.cols);
    debug_print_array_stats(fbank_result.data, fbank_result.rows * fbank_result.cols, "前端输出");
    debug_print_first_n_values(fbank_result.data, 5, "前端输出");

    // 这里可以调用推理组件，但需要适配数据格式
    printf("\n📝 说明: 推理组件需要特定的数据格式，将在后续步骤中调用\n");

    // 7. 总结报告
    print_separator("调试总结报告");
    printf("🎯 组件调用完成情况:\n");
    printf("   ✅ 步骤1: 音频文件读取 - 成功\n");
    printf("   ✅ 步骤2: 音频预处理 - 成功\n");
    printf("   ✅ 步骤3: 前端配置初始化 - 成功\n");
    printf("   ✅ 步骤4: extract_fbank组件 - 成功\n");
    printf("   ✅ 步骤5: apply_lfr组件 - 已集成在extract_fbank中\n");
    printf("   ✅ 步骤6: 推理组件 - 待后续调用\n");

    printf("\n📊 数据流转统计:\n");
    printf("   📥 输入音频: [%d, %d] -> %d 采样点\n",
           input_result.rows, input_result.cols, input_result.cols);
    printf("   🔊 音量放大: [%d, %d] -> %d 采样点\n",
           amplified_result.rows, amplified_result.cols, amplified_result.cols);
    printf("   🎵 前端输出: [%d, %d] -> %d 特征\n",
           fbank_result.rows, fbank_result.cols, fbank_result.rows * fbank_result.cols);

    // 8. 清理资源
    printf("\n🧹 清理资源...\n");
    free(fbank_result.data);
    free(amplified_result.data);
    free(audio_data.waveform);
    frontend_channel_free(channel);
    frontend_config_free(config);

    printf("✅ 前端组件逐步调试完成！\n");
    return 0;
}

/**
 * @brief 仅提取Fbank特征（不包含LFR和CMVN）
 * @param channel 前端通道
 * @param audio 音频数据
 * @param fbank_result Fbank特征结果
 * @return 0成功，非0失败
 */
int debug_extract_fbank_only(FrontendChannel* channel, const AudioData* audio, ProcessResult* fbank_result) {
    if (!channel || !audio || !audio->waveform || !fbank_result) {
        return -1;
    }

    // 处理fmax参数（0表示使用nyquist频率）
    float fmax = channel->config.fmax;
    if (fmax <= 0.0f) {
        fmax = channel->config.fs / 2.0f;  // Nyquist频率
    }

    // 1. 进行分帧
    int num_frames = (audio->length - channel->config.frame_length) / channel->config.frame_shift + 1;
    if (num_frames <= 0) return -1;

    float* frames = (float*)malloc(num_frames * channel->config.frame_length * sizeof(float));
    if (!frames) return -1;

    // 手动分帧（不应用音量放大，因为输入已经是放大后的）
    for (int i = 0; i < num_frames; i++) {
        int start_idx = i * channel->config.frame_shift;
        float* frame = frames + i * channel->config.frame_length;

        for (int j = 0; j < channel->config.frame_length; j++) {
            if (start_idx + j < audio->length) {
                frame[j] = audio->waveform[start_idx + j];  // 不再次放大
            } else {
                frame[j] = 0.0f;
            }
        }
    }

    // 2. 应用窗函数处理
    for (int i = 0; i < num_frames; i++) {
        float* frame = frames + i * channel->config.frame_length;

        // 去直流分量
        float frame_sum = 0.0f;
        for (int j = 0; j < channel->config.frame_length; j++) {
            frame_sum += frame[j];
        }
        float frame_mean = frame_sum / channel->config.frame_length;
        for (int j = 0; j < channel->config.frame_length; j++) {
            frame[j] -= frame_mean;
        }

        // 预加重
        if (0.97f != 0.0f) {
            float first_val = frame[0];
            for (int j = channel->config.frame_length - 1; j > 0; j--) {
                frame[j] = frame[j] - 0.97f * frame[j-1];
            }
            frame[0] = frame[0] - 0.97f * first_val;
        }

        // 应用Hamming窗
        for (int j = 0; j < channel->config.frame_length; j++) {
            float window_val = 0.54f - 0.46f * cosf(2.0f * 3.14159265359f * j / (channel->config.frame_length - 1));
            frame[j] *= window_val;
        }
    }

    // 3. 计算FFT功率谱
    float* power_spectrum = (float*)malloc(num_frames * (channel->config.n_fft/2) * sizeof(float));
    if (!power_spectrum) {
        free(frames);
        return -1;
    }

    if (compute_power_spectrum(frames, num_frames, channel->config.frame_length,
                             channel->config.n_fft, power_spectrum) != 0) {
        free(frames);
        free(power_spectrum);
        return -1;
    }
    free(frames);

    // 4. 创建Mel滤波器组
    float* mel_filters = (float*)malloc(channel->config.n_mels * (channel->config.n_fft/2) * sizeof(float));
    if (!mel_filters) {
        free(power_spectrum);
        return -1;
    }
    create_mel_filterbank(channel->config.n_mels, channel->config.n_fft, channel->config.fs,
                         channel->config.fmin, fmax, mel_filters);

    // 5. 应用Mel滤波器组并取对数
    float* fbank_features = (float*)malloc(num_frames * channel->config.n_mels * sizeof(float));
    if (!fbank_features) {
        free(power_spectrum);
        free(mel_filters);
        return -1;
    }
    apply_mel_filterbank(power_spectrum, num_frames, channel->config.n_mels,
                        channel->config.n_fft, mel_filters, fbank_features);
    free(power_spectrum);
    free(mel_filters);

    // 记录结果（仅Fbank特征，不包含LFR和CMVN）
    fbank_result->data = fbank_features;
    fbank_result->rows = num_frames;
    fbank_result->cols = channel->config.n_mels;

    // 计算统计信息
    float min_val = fbank_features[0];
    float max_val = fbank_features[0];
    double sum = 0.0;
    int total_size = num_frames * channel->config.n_mels;

    for (int i = 0; i < total_size; i++) {
        if (fbank_features[i] < min_val) min_val = fbank_features[i];
        if (fbank_features[i] > max_val) max_val = fbank_features[i];
        sum += fbank_features[i];
    }

    fbank_result->min_val = min_val;
    fbank_result->max_val = max_val;
    fbank_result->mean_val = (float)(sum / total_size);

    return 0;
}

/**
 * @brief 详细调试Fbank特征提取的每个子步骤
 * @param channel 前端通道
 * @param audio 音频数据
 * @param fbank_result Fbank特征结果
 * @return 0成功，非0失败
 */
int debug_fbank_detailed(FrontendChannel* channel, const AudioData* audio, ProcessResult* fbank_result) {
    if (!channel || !audio || !audio->waveform || !fbank_result) {
        return -1;
    }

    printf("🔍 开始详细Fbank调试...\n");
    printf("📋 配置参数确认:\n");
    printf("   采样率: %d Hz\n", channel->config.fs);
    printf("   帧长: %d 采样点 (%.1f ms)\n", channel->config.frame_length,
           (float)channel->config.frame_length * 1000.0f / channel->config.fs);
    printf("   帧移: %d 采样点 (%.1f ms)\n", channel->config.frame_shift,
           (float)channel->config.frame_shift * 1000.0f / channel->config.fs);
    printf("   FFT点数: %d\n", channel->config.n_fft);
    printf("   Mel滤波器数: %d\n", channel->config.n_mels);
    printf("   频率范围: %.1f - %.1f Hz\n", channel->config.fmin, channel->config.fmax);
    printf("   抖动系数: %.1f\n", channel->config.dither);

    // 处理fmax参数
    float fmax = channel->config.fmax;
    if (fmax <= 0.0f) {
        fmax = channel->config.fs / 2.0f;
    }

    // 1. 分帧分析
    printf("\n🔍 步骤1: 分帧分析\n");
    int num_frames = (audio->length - channel->config.frame_length) / channel->config.frame_shift + 1;
    printf("   输入音频长度: %d 采样点\n", audio->length);
    printf("   计算帧数: %d 帧\n", num_frames);
    printf("   预期帧数 (Python): 644 帧\n");

    if (num_frames != 644) {
        printf("   ⚠️  帧数不匹配！C=%d, Python=644\n", num_frames);
    } else {
        printf("   ✅ 帧数匹配\n");
    }

    if (num_frames <= 0) return -1;

    float* frames = (float*)malloc(num_frames * channel->config.frame_length * sizeof(float));
    if (!frames) return -1;

    // 手动分帧（不再次放大，因为输入已经是放大后的）
    for (int i = 0; i < num_frames; i++) {
        int start_idx = i * channel->config.frame_shift;
        float* frame = frames + i * channel->config.frame_length;

        for (int j = 0; j < channel->config.frame_length; j++) {
            if (start_idx + j < audio->length) {
                frame[j] = audio->waveform[start_idx + j];
            } else {
                frame[j] = 0.0f;
            }
        }
    }

    // 分析第一帧的原始数据
    printf("\n🔍 步骤2: 第一帧原始数据分析\n");
    float* first_frame = frames;
    debug_print_array_stats(first_frame, channel->config.frame_length, "第一帧原始数据");
    debug_print_first_n_values(first_frame, 5, "第一帧原始数据");

    // 2. 应用窗函数处理
    printf("\n🔍 步骤3: 窗函数处理\n");
    for (int i = 0; i < num_frames; i++) {
        float* frame = frames + i * channel->config.frame_length;

        // 去直流分量
        float frame_sum = 0.0f;
        for (int j = 0; j < channel->config.frame_length; j++) {
            frame_sum += frame[j];
        }
        float frame_mean = frame_sum / channel->config.frame_length;
        for (int j = 0; j < channel->config.frame_length; j++) {
            frame[j] -= frame_mean;
        }

        // 预加重
        if (0.97f != 0.0f) {
            float first_val = frame[0];
            for (int j = channel->config.frame_length - 1; j > 0; j--) {
                frame[j] = frame[j] - 0.97f * frame[j-1];
            }
            frame[0] = frame[0] - 0.97f * first_val;
        }

        // 应用Hamming窗
        for (int j = 0; j < channel->config.frame_length; j++) {
            float window_val = 0.54f - 0.46f * cosf(2.0f * 3.14159265359f * j / (channel->config.frame_length - 1));
            frame[j] *= window_val;
        }
    }

    // 分析第一帧处理后的数据
    printf("   第一帧处理后数据分析:\n");
    debug_print_array_stats(first_frame, channel->config.frame_length, "第一帧处理后");
    debug_print_first_n_values(first_frame, 5, "第一帧处理后");

    // 3. 计算FFT功率谱
    printf("\n🔍 步骤4: FFT功率谱计算\n");
    float* power_spectrum = (float*)malloc(num_frames * (channel->config.n_fft/2) * sizeof(float));
    if (!power_spectrum) {
        free(frames);
        return -1;
    }

    if (compute_power_spectrum(frames, num_frames, channel->config.frame_length,
                             channel->config.n_fft, power_spectrum) != 0) {
        printf("   ❌ FFT功率谱计算失败\n");
        free(frames);
        free(power_spectrum);
        return -1;
    }

    printf("   ✅ FFT功率谱计算成功\n");
    printf("   功率谱形状: [%d, %d]\n", num_frames, channel->config.n_fft/2);

    // 分析第一帧的功率谱
    float* first_power_spectrum = power_spectrum;
    debug_print_array_stats(first_power_spectrum, channel->config.n_fft/2, "第一帧功率谱（原始）");
    debug_print_first_n_values(first_power_spectrum, 5, "第一帧功率谱（原始）");

    // 尝试不同的归一化方式
    printf("\n🔍 步骤5: 尝试功率谱归一化\n");

    // 方式1：除以FFT点数
    float* normalized_power1 = (float*)malloc(channel->config.n_fft/2 * sizeof(float));
    if (normalized_power1) {
        for (int i = 0; i < channel->config.n_fft/2; i++) {
            normalized_power1[i] = first_power_spectrum[i] / (float)channel->config.n_fft;
        }
        debug_print_array_stats(normalized_power1, channel->config.n_fft/2, "第一帧功率谱（除以n_fft）");
        debug_print_first_n_values(normalized_power1, 5, "第一帧功率谱（除以n_fft）");
        free(normalized_power1);
    }

    // 方式2：除以FFT点数的平方
    float* normalized_power2 = (float*)malloc(channel->config.n_fft/2 * sizeof(float));
    if (normalized_power2) {
        float norm_factor = (float)(channel->config.n_fft * channel->config.n_fft);
        for (int i = 0; i < channel->config.n_fft/2; i++) {
            normalized_power2[i] = first_power_spectrum[i] / norm_factor;
        }
        debug_print_array_stats(normalized_power2, channel->config.n_fft/2, "第一帧功率谱（除以n_fft²）");
        debug_print_first_n_values(normalized_power2, 5, "第一帧功率谱（除以n_fft²）");
        free(normalized_power2);
    }

    // 方式3：开平方根（幅度谱）
    float* amplitude_spectrum = (float*)malloc(channel->config.n_fft/2 * sizeof(float));
    if (amplitude_spectrum) {
        for (int i = 0; i < channel->config.n_fft/2; i++) {
            amplitude_spectrum[i] = sqrtf(first_power_spectrum[i]);
        }
        debug_print_array_stats(amplitude_spectrum, channel->config.n_fft/2, "第一帧幅度谱（开平方根）");
        debug_print_first_n_values(amplitude_spectrum, 5, "第一帧幅度谱（开平方根）");
        free(amplitude_spectrum);
    }

    free(frames);
    free(power_spectrum);
    return 0;  // 暂时返回，后续继续添加Mel滤波器调试
}

/**
 * @brief 测试推理组件
 * @param audio_path 音频文件路径
 * @param model_path 模型文件路径
 * @return 0成功，非0失败
 */
int test_inference_component(const char* audio_path, const char* model_path) {
    printf("=== eAI编码器推理组件测试 ===\n");

    // 1. 配置推理参数
    EaiEncoderConfig config = EAI_ENCODER_CONFIG_DEFAULT;
    config.model_path = model_path;
    config.enable_debug = 1;
    config.enable_performance_log = 1;

    printf("配置参数:\n");
    printf("  模型路径: %s\n", config.model_path);
    printf("  上下文帧数: %d\n", config.context_frames);
    printf("  最大批处理帧数: %d\n", config.max_batch_frames);
    printf("  输入量化scale: %.10f\n", config.input_scale);

    // 2. 初始化推理上下文
    printf("\n初始化推理上下文...\n");
    EaiEncoderContext* context = eai_encoder_init(&config);
    if (!context) {
        printf("❌ 推理上下文初始化失败\n");
        return -1;
    }

    printf("✅ 推理上下文初始化成功\n");

    // 3. 打印上下文信息
    eai_encoder_print_context_info(context);

    // 4. 读取真实音频并提取特征
    printf("读取真实音频文件: %s\n", audio_path);

    // 读取音频文件
    AudioData audio_data = {0};
    if (read_wav_file(audio_path, &audio_data) != 0) {
        printf("❌ 音频文件读取失败\n");
        eai_encoder_destroy(context);
        return -1;
    }

    printf("✅ 音频文件读取成功: %d 采样点\n", audio_data.length);

    // 初始化前端组件配置
    FrontendConfig* frontend_config = frontend_config_init(NULL);
    if (!frontend_config) {
        printf("❌ 前端配置初始化失败\n");
        free(audio_data.waveform);
        eai_encoder_destroy(context);
        return -1;
    }

    FrontendChannel* frontend_channel = frontend_channel_init(frontend_config);
    if (!frontend_channel) {
        printf("❌ 前端组件初始化失败\n");
        free(audio_data.waveform);
        frontend_config_free(frontend_config);
        eai_encoder_destroy(context);
        return -1;
    }

    // 提取Fbank特征
    printf("提取Fbank特征...\n");
    ProcessResult fbank_result = {0};
    if (extract_fbank(frontend_channel, &audio_data, &fbank_result) != 0) {
        printf("❌ 特征提取失败\n");
        free(audio_data.waveform);
        frontend_channel_free(frontend_channel);
        frontend_config_free(frontend_config);
        eai_encoder_destroy(context);
        return -1;
    }

    printf("✅ 特征提取完成: [%d, %d]\n", fbank_result.rows, fbank_result.cols);
    printf("特征数据统计: 范围[%.6f, %.6f], 平均值%.6f\n",
           fbank_result.min_val, fbank_result.max_val, fbank_result.mean_val);

    // 5. 执行推理（使用批量推理处理大数据量）
    printf("\n执行推理...\n");
    printf("输入数据: %d帧，最大批处理: %d帧\n", fbank_result.rows, config.max_batch_frames);

    EaiEncoderInferenceResult result;
    EaiEncoderResult ret;

    if (fbank_result.rows > config.max_batch_frames) {
        // 使用批量推理处理大数据量
        ret = eai_encoder_inference_batch(context, fbank_result.data, fbank_result.rows, &result);
    } else {
        // 使用普通推理处理小数据量
        ret = eai_encoder_inference(context, fbank_result.data, fbank_result.rows, &result);
    }

    if (ret != EAI_ENCODER_SUCCESS) {
        printf("❌ 推理执行失败: %s\n", eai_encoder_get_last_error(context));
        free(fbank_result.data);
        free(audio_data.waveform);
        frontend_channel_free(frontend_channel);
        eai_encoder_destroy(context);
        return -1;
    }

    printf("✅ 推理执行成功\n");

    // 6. 验证结果
    printf("\n验证推理结果...\n");
    printf("输出形状: [%d, %d]\n", result.time_steps, result.feature_dim);
    printf("推理耗时: %llu 微秒\n", (unsigned long long)result.inference_time_us);

    // 验证与基准的一致性
    ret = eai_encoder_validate_result(&result, "python/ref_result/sa1_eai_encoder_output.npz", 1e-5f);
    if (ret != EAI_ENCODER_SUCCESS) {
        printf("⚠️  结果验证警告，但继续执行\n");
    }

    // 7. 性能统计
    printf("\n性能统计信息:\n");
    const EaiEncoderPerfStats* stats = eai_encoder_get_perf_stats(context);
    if (stats) {
        printf("  总推理次数: %llu\n", (unsigned long long)stats->total_inference_count);
        printf("  平均推理时间: %.2f 毫秒\n", stats->avg_inference_time_ms);
        printf("  处理速度: %.2f 帧/秒\n", stats->frames_per_second);
    }

    // 8. 后处理：VAD语音段检测
    printf("\n执行后处理...\n");

    // 转换推理结果为后处理输入格式
    EncoderOutput encoder_output = {0};
    encoder_output.data = result.encoder_output;
    encoder_output.num_frames = result.time_steps;
    encoder_output.output_dim = result.feature_dim;

    printf("编码器输出转换: [%d, %d]\n", encoder_output.num_frames, encoder_output.output_dim);

    // 初始化后处理配置
    VADPostprocessConfig postprocess_config = get_default_vad_config();
    postprocess_config.output_file = "build/vad_segments.txt";  // 输出文件

    // 初始化语音段列表
    VADSpeechSegmentList speech_segments = {0};
    if (speech_segment_list_init(&speech_segments, 10) != 0) {
        printf("❌ 语音段列表初始化失败\n");
        free(fbank_result.data);
        free(audio_data.waveform);
        frontend_channel_free(frontend_channel);
        eai_encoder_destroy(context);
        return -1;
    }

    // 执行后处理
    if (vad_postprocess_from_encoder(&encoder_output, &postprocess_config, &speech_segments) == 0) {
        printf("✅ 后处理执行成功\n");
        printf("检测到语音段: %d 个\n", speech_segments.count);

        // 显示语音段信息
        for (int i = 0; i < speech_segments.count; i++) {
            const SpeechSegment* seg = &speech_segments.segments[i];
            printf("  语音段%d: %d-%d ms (时长: %d ms)\n",
                   i+1, seg->start_ms, seg->end_ms, seg->end_ms - seg->start_ms);
        }
    } else {
        printf("❌ 后处理执行失败\n");
    }

    // 清理后处理资源
    speech_segment_list_free(&speech_segments);

    // 8. 清理资源
    printf("\n清理资源...\n");
    free(fbank_result.data);
    free(audio_data.waveform);
    frontend_channel_free(frontend_channel);
    frontend_config_free(frontend_config);
    eai_encoder_destroy(context);

    printf("✅ 推理组件测试完成\n");
    printf("===============================\n");

    return 0;
}