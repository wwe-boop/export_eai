/**
 * @file npz_loader.c
 * @brief NPZ文件加载器实现
 * @details 实现从NPZ文件中读取编码器输出数据的功能
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "postprocess/postprocess.h"

/**
 * @brief 从原始二进制文件加载编码器输出数据
 * @param raw_file_path 原始二进制文件路径 
 * @param encoder_output 输出编码器数据结构
 * @return 0表示成功，非0表示失败
 */
int load_raw_encoder_output(const char* raw_file_path, EncoderOutput* encoder_output) {
    if (!raw_file_path || !encoder_output) {
        fprintf(stderr, "[ERROR] Loader: invalid parameters\n");
        return -1;
    }

    printf("🔄 加载原始二进制文件: %s\n", raw_file_path);

    // 打开文件
    FILE* file = fopen(raw_file_path, "rb");
    if (!file) {
        fprintf(stderr, "[ERROR] Cannot open file: %s (error: %s)\n", raw_file_path, strerror(errno));
        return -1;
    }

    // 获取文件大小
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);

    printf("  文件大小: %ld 字节\n", file_size);

    // 根据已知的形状 (1, 644, 248)
    const int expected_frames = 644;
    const int expected_dim = 248;
    const int expected_floats = expected_frames * expected_dim;
    const size_t expected_data_size = expected_floats * sizeof(float);

    printf("  期望数据: %d帧 × %d维 = %d个float32 (%zu字节)\n", 
           expected_frames, expected_dim, expected_floats, expected_data_size);

    if (file_size != expected_data_size) {
        fprintf(stderr, "[ERROR] File size mismatch, expected %zu bytes, actual %ld bytes\n", 
                expected_data_size, file_size);
        fclose(file);
        return -1;
    }

    // 分配内存
    encoder_output->data = (float*)malloc(expected_data_size);
    if (!encoder_output->data) {
        fprintf(stderr, "[ERROR] Memory allocation failed\n");
        fclose(file);
        return -1;
    }

    // 读取数据
    size_t read_bytes = fread(encoder_output->data, 1, expected_data_size, file);
    fclose(file);

    if (read_bytes != expected_data_size) {
        fprintf(stderr, "[ERROR] Incomplete data read, expected %zu bytes, actual read %zu bytes\n", 
                expected_data_size, read_bytes);
        free(encoder_output->data);
        encoder_output->data = NULL;
        return -1;
    }

    // 设置输出参数
    encoder_output->num_frames = expected_frames;
    encoder_output->output_dim = expected_dim;

    // 验证数据合理性
    float min_val = encoder_output->data[0];
    float max_val = encoder_output->data[0];
    double sum = 0.0;

    for (int i = 0; i < expected_floats; i++) {
        float val = encoder_output->data[i];
        if (val < min_val) min_val = val;
        if (val > max_val) max_val = val;
        sum += val;
    }

    float mean_val = (float)(sum / expected_floats);

    printf("[INFO] Data loaded successfully:\n");
    printf("  形状: [%d, %d]\n", encoder_output->num_frames, encoder_output->output_dim);
    printf("  数值范围: [%.6f, %.6f]\n", min_val, max_val);
    printf("  平均值: %.6f\n", mean_val);

    // 根据Python基准验证范围 [0.000000, 0.871077]
    if (min_val < -0.1f || max_val > 1.0f) {
        printf("⚠️  数值范围异常，请检查数据格式\n");
    }

    return 0;
}

/**
 * @brief NPZ文件加载器（通过转换为原始文件）
 * @param npz_file_path NPZ文件路径
 * @param encoder_output 输出编码器数据结构
 * @return 0表示成功，非0表示失败
 */
int load_npz_encoder_output(const char* npz_file_path, EncoderOutput* encoder_output) {
    // 检查是否存在对应的.raw文件
    char raw_file_path[1024];
    strncpy(raw_file_path, npz_file_path, sizeof(raw_file_path) - 1);
    raw_file_path[sizeof(raw_file_path) - 1] = '\0';
    
    // 将.npz替换为.raw
    char* ext = strstr(raw_file_path, ".npz");
    if (ext) {
        strcpy(ext, ".raw");
    } else {
        strcat(raw_file_path, ".raw");
    }
    
    printf("🔄 尝试加载对应的原始文件: %s\n", raw_file_path);
    
    // 检查.raw文件是否存在
    FILE* test_file = fopen(raw_file_path, "rb");
    if (test_file) {
        fclose(test_file);
        printf("[INFO] Found raw file, loading directly\n");
        return load_raw_encoder_output(raw_file_path, encoder_output);
    }
    
    // 如果.raw文件不存在，提示用户转换
    fprintf(stderr, "[ERROR] Raw file not found: %s\n", raw_file_path);
    fprintf(stderr, "请运行以下命令转换NPZ文件:\n");
    fprintf(stderr, "  python3 python/convert_npz_to_raw.py\n");
    
    return -1;
}

/**
 * @brief 释放编码器输出数据
 * @param encoder_output 编码器输出结构体
 */
void free_encoder_output(EncoderOutput* encoder_output) {
    if (encoder_output && encoder_output->data) {
        free(encoder_output->data);
        encoder_output->data = NULL;
        encoder_output->num_frames = 0;
        encoder_output->output_dim = 0;
    }
} 