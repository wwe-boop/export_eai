/**
 * @file window_smooth.c
 * @brief 窗口平滑算法实现
 * @details 实现基于滑动窗口的语音状态平滑处理
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "postprocess/postprocess.h"

/**
 * @brief 初始化窗口平滑状态
 * @param state 窗口状态结构体
 * @param num_frames 总帧数
 * @param window_size 窗口大小
 * @return 0表示成功，非0表示失败
 */
int window_smooth_init(WindowSmoothState* state, int num_frames, int window_size) {
    if (!state || num_frames <= 0 || window_size <= 0) {
        fprintf(stderr, "[ERROR] Window smoothing initialization: invalid parameters\n");
        return -1;
    }

    state->frame_states = (FrameState*)malloc(num_frames * sizeof(FrameState));
    state->window_buffer = (int*)malloc(window_size * sizeof(int));
    
    if (!state->frame_states || !state->window_buffer) {
        fprintf(stderr, "[ERROR] Failed to allocate window smoothing memory\n");
        if (state->frame_states) free(state->frame_states);
        if (state->window_buffer) free(state->window_buffer);
        return -1;
    }

    // 初始化状态
    memset(state->frame_states, FRAME_STATE_SILENCE, num_frames * sizeof(FrameState));
    memset(state->window_buffer, 0, window_size * sizeof(int));
    
    state->window_pos = 0;
    state->speech_count = 0;
    state->initialized = true;

    return 0;
}

/**
 * @brief 释放窗口平滑状态
 * @param state 窗口状态结构体
 */
void window_smooth_free(WindowSmoothState* state) {
    if (state) {
        if (state->frame_states) {
            free(state->frame_states);
            state->frame_states = NULL;
        }
        if (state->window_buffer) {
            free(state->window_buffer);
            state->window_buffer = NULL;
        }
        state->initialized = false;
    }
}

/**
 * @brief 应用窗口平滑算法
 * @param input_states 输入帧状态数组
 * @param num_frames 帧数
 * @param config 配置参数
 * @param output_states 输出平滑后的状态数组
 * @return 平滑后的语音帧数量
 */
int apply_window_smoothing(const FrameState* input_states,
                          int num_frames,
                          const VADPostprocessConfig* config,
                          FrameState* output_states) {
    if (!input_states || !output_states || !config) {
        fprintf(stderr, "[ERROR] Window smoothing: invalid parameters\n");
        return -1;
    }

    int window_size = config->window_size;
    int sil_to_speech_thresh = config->sil_to_speech_thresh;
    int speech_to_sil_thresh = config->speech_to_sil_thresh;

    printf("🔄 应用窗口平滑算法:\n");
    printf("  窗口大小: %d帧 (%dms)\n", window_size, window_size * config->frame_duration_ms);
    printf("  静音->语音阈值: %d帧 (%dms)\n", sil_to_speech_thresh, sil_to_speech_thresh * config->frame_duration_ms);
    printf("  语音->静音阈值: %d帧 (%dms)\n", speech_to_sil_thresh, speech_to_sil_thresh * config->frame_duration_ms);

    // 初始化窗口缓存
    int* window_buffer = (int*)calloc(window_size, sizeof(int));
    if (!window_buffer) {
        fprintf(stderr, "[ERROR] Failed to allocate window buffer memory\n");
        return -1;
    }

    int window_pos = 0;
    int speech_count_in_window = 0;
    int smoothed_speech_count = 0;

    // 初始化输出为静音
    for (int i = 0; i < num_frames; i++) {
        output_states[i] = FRAME_STATE_SILENCE;
    }

    for (int i = 0; i < num_frames; i++) {
        // 更新窗口缓存
        int old_val = window_buffer[window_pos];
        int new_val = (input_states[i] == FRAME_STATE_SPEECH) ? 1 : 0;
        
        window_buffer[window_pos] = new_val;
        speech_count_in_window = speech_count_in_window - old_val + new_val;
        window_pos = (window_pos + 1) % window_size;

        // 状态判断逻辑
        FrameState smoothed_state = FRAME_STATE_SILENCE;
        
        if (i >= window_size - 1) { // 窗口已满
            if (speech_count_in_window >= sil_to_speech_thresh) {
                smoothed_state = FRAME_STATE_SPEECH;
            } else if (speech_count_in_window <= window_size - speech_to_sil_thresh) {
                smoothed_state = FRAME_STATE_SILENCE;
            } else {
                // 保持前一帧状态（滞后效应）
                if (i > 0) {
                    smoothed_state = output_states[i - 1];
                }
            }
        }

        output_states[i] = smoothed_state;
        if (smoothed_state == FRAME_STATE_SPEECH) {
            smoothed_speech_count++;
        }
    }

    free(window_buffer);

    float smoothed_ratio = (float)smoothed_speech_count / num_frames;
    printf("  窗口平滑后语音帧: %d/%d (%.1f%%)\n", 
           smoothed_speech_count, num_frames, smoothed_ratio * 100.0f);

    return smoothed_speech_count;
} 