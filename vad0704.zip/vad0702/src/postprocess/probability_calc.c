/**
 * @file probability_calc.c
 * @brief 概率计算模块
 * @details 实现softmax计算和VAD概率提取功能
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "postprocess/postprocess.h"

/**
 * @brief 从编码器输出提取VAD概率 (第一维是静音概率)
 * @param encoder_output 编码器输出数据
 * @param vad_logits 输出VAD概率数据
 * @return 0表示成功，非0表示失败
 */
int extract_vad_logits(const EncoderOutput* encoder_output, VADLogits* vad_logits) {
    if (!encoder_output || !vad_logits || !encoder_output->data) {
        fprintf(stderr, "[ERROR] Extract VAD probability: invalid parameters\n");
        return -1;
    }

    if (encoder_output->output_dim < 2) {
        fprintf(stderr, "[ERROR] Encoder output dimension insufficient, requires at least 2 dimensions (VAD logits), actual: %d\n", encoder_output->output_dim);
        return -1;
    }

    int num_frames = encoder_output->num_frames;
    
    // 分配内存
    vad_logits->sil_probs = (float*)malloc(num_frames * sizeof(float));
    vad_logits->speech_probs = (float*)malloc(num_frames * sizeof(float));
    
    if (!vad_logits->sil_probs || !vad_logits->speech_probs) {
        fprintf(stderr, "[ERROR] Failed to allocate VAD probability memory\n");
        if (vad_logits->sil_probs) free(vad_logits->sil_probs);
        if (vad_logits->speech_probs) free(vad_logits->speech_probs);
        return -1;
    }

    vad_logits->num_frames = num_frames;

    // 前2维是VAD logits，应用softmax转换为概率（标准VAD方法）
    for (int i = 0; i < num_frames; i++) {
        float* frame_data = encoder_output->data + i * encoder_output->output_dim;
        float sil_logit = frame_data[0];    // 静音logit
        float speech_logit = frame_data[1]; // 语音logit

        // 计算softmax概率
        // softmax(x_i) = exp(x_i) / sum(exp(x_j))
        float exp_sil = expf(sil_logit);
        float exp_speech = expf(speech_logit);
        float sum_exp = exp_sil + exp_speech;

        float sil_prob = exp_sil / sum_exp;
        float speech_prob = exp_speech / sum_exp;

        vad_logits->sil_probs[i] = sil_prob;
        vad_logits->speech_probs[i] = speech_prob;
    }

    // 计算统计信息
    float sil_min = vad_logits->sil_probs[0];
    float sil_max = vad_logits->sil_probs[0];
    double sil_sum = 0.0;

    for (int i = 0; i < num_frames; i++) {
        float sil_val = vad_logits->sil_probs[i];
        if (sil_val < sil_min) sil_min = sil_val;
        if (sil_val > sil_max) sil_max = sil_val;
        sil_sum += sil_val;
    }

    float sil_mean = (float)(sil_sum / num_frames);

    printf("[INFO] VAD probability calculation completed:\n");
    printf("  帧数: %d\n", num_frames);
    printf("  静音概率范围: [%.6f, %.6f]\n", sil_min, sil_max);
    printf("  静音概率均值: %.6f\n", sil_mean);

    return 0;
}

/**
 * @brief 释放VAD logits数据
 * @param vad_logits VAD logits结构体
 */
void free_vad_logits(VADLogits* vad_logits) {
    if (vad_logits) {
        if (vad_logits->sil_probs) {
            free(vad_logits->sil_probs);
            vad_logits->sil_probs = NULL;
        }
        if (vad_logits->speech_probs) {
            free(vad_logits->speech_probs);
            vad_logits->speech_probs = NULL;
        }
        vad_logits->num_frames = 0;
    }
}

/**
 * @brief 基于阈值判断每帧的语音/静音状态
 * @param vad_logits VAD概率数据
 * @param config 配置参数
 * @param frame_states 输出每帧状态数组
 * @return 语音帧数量
 */
int classify_frames(const VADLogits* vad_logits, 
                   const VADPostprocessConfig* config,
                   FrameState* frame_states) {
    if (!vad_logits || !config || !frame_states) {
        fprintf(stderr, "[ERROR] Frame classification: invalid parameters\n");
        return -1;
    }

    int speech_count = 0;
    float threshold_base = config->speech_noise_thres;
    float ratio = config->speech_2_noise_ratio;

    printf("🔄 基于阈值判断帧状态:\n");
    printf("  参数: speech_noise_thres=%.1f, speech_2_noise_ratio=%.1f\n", 
           threshold_base, ratio);

    for (int i = 0; i < vad_logits->num_frames; i++) {
        float sil_prob = vad_logits->sil_probs[i];
        float speech_prob = vad_logits->speech_probs[i];
        
        // 标准VAD阈值计算: 直接比较语音概率与固定阈值
        float threshold = 0.4f;  // 基于测试结果的最优阈值

        // 判断逻辑: speech_prob > threshold 则为语音
        if (speech_prob > threshold) {
            frame_states[i] = FRAME_STATE_SPEECH;
            speech_count++;
        } else {
            frame_states[i] = FRAME_STATE_SILENCE;
        }

        // 输出前20帧和部分关键帧的详细信息
        if (i < 20 || i % 50 == 0) {
            printf("    帧%3d (%4dms): 静音=%.4f, 语音=%.4f, 阈值=%.4f, 判断=%s\n",
                   i, i * config->frame_duration_ms,
                   sil_prob, speech_prob, threshold,
                   frame_states[i] == FRAME_STATE_SPEECH ? "语音" : "静音");
        }
    }

    float speech_ratio = (float)speech_count / vad_logits->num_frames;
    printf("  检测到语音帧: %d/%d (%.1f%%)\n", 
           speech_count, vad_logits->num_frames, speech_ratio * 100.0f);

    return speech_count;
} 