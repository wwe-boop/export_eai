/**
 * @file test_postprocess.c
 * @brief 后处理模块测试程序
 * @details 独立测试后处理组件功能，从NPZ文件加载数据并进行VAD后处理
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "postprocess/postprocess.h"

int main(int argc, char* argv[]) {
    printf("[INFO] Starting VAD post-processing module test\n");
    printf("=====================================\n");

    // 1. 设置输入文件路径
    const char* npz_file_path = "python/ref_result/sa1_eai_encoder_output.npz";
    
    if (argc > 1) {
        npz_file_path = argv[1];
    }

    printf("输入NPZ文件: %s\n\n", npz_file_path);

    // 2. 获取默认配置
    VADPostprocessConfig config = get_default_vad_config();
    printf("配置参数:\n");
    printf("  speech_noise_thres: %.1f\n", config.speech_noise_thres);
    printf("  speech_2_noise_ratio: %.1f\n", config.speech_2_noise_ratio);
    printf("  frame_duration_ms: %d\n", config.frame_duration_ms);
    printf("  window_size: %d帧 (%dms)\n", config.window_size, config.window_size * config.frame_duration_ms);
    printf("  静音->语音阈值: %d帧 (%dms)\n", config.sil_to_speech_thresh, config.sil_to_speech_thresh * config.frame_duration_ms);
    printf("  语音->静音阈值: %d帧 (%dms)\n", config.speech_to_sil_thresh, config.speech_to_sil_thresh * config.frame_duration_ms);
    printf("  开始点延迟: %d帧 (%dms)\n", config.start_point_delay, config.start_point_delay * config.frame_duration_ms);
    printf("  结束点前瞻: %d帧 (%dms)\n", config.end_point_lookahead, config.end_point_lookahead * config.frame_duration_ms);
    printf("  最大结束静音: %d帧 (%dms)\n", config.max_end_silence_frames, config.max_end_silence_frames * config.frame_duration_ms);
    printf("  输出文件: %s\n\n", config.output_file);

    // 3. 初始化语音段列表
    VADSpeechSegmentList segments;
    if (speech_segment_list_init(&segments, 10) != 0) {
        fprintf(stderr, "[ERROR] Failed to initialize speech segment list\n");
        return -1;
    }

    // 4. 执行后处理
    int result = vad_postprocess_from_npz(npz_file_path, &config, &segments);
    
    if (result == 0) {
        printf("\n[INFO] Post-processing test completed successfully!\n");
        printf("============================\n");
        printf("最终结果摘要:\n");
        printf("  检测到 %d 个语音段\n", segments.count);
        
        for (int i = 0; i < segments.count; i++) {
            const SpeechSegment* seg = &segments.segments[i];
            int duration = seg->end_ms - seg->start_ms;
            printf("  段%d: %dms - %dms (时长: %dms)\n", 
                   i + 1, seg->start_ms, seg->end_ms, duration);
        }

        // 与Python基准对比
        printf("\n基准对比:\n");
        printf("  期望: 1个语音段 [780ms, 4470ms]\n");
        if (segments.count == 1) {
            const SpeechSegment* seg = &segments.segments[0];
            int start_diff = seg->start_ms - 780;
            int end_diff = seg->end_ms - 4470;
            printf("  实际: 1个语音段 [%dms, %dms]\n", seg->start_ms, seg->end_ms);
            printf("  差异: 开始%+dms, 结束%+dms\n", start_diff, end_diff);
            
            if (abs(start_diff) <= 10 && abs(end_diff) <= 20) {
                printf("[INFO] Accuracy verification passed!\n");
            } else {
                printf("  ⚠️  精度超出预期范围\n");
            }
        } else {
            printf("[ERROR] Segment count mismatch (expected: 1, actual: %d)\n", segments.count);
        }
    } else {
        printf("\n💥 后处理测试失败！\n");
    }

    // 5. 清理资源
    speech_segment_list_free(&segments);

    printf("\n测试程序结束\n");
    return result;
} 