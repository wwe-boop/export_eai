/**
 * @file postprocess_core.c
 * @brief 后处理核心模块
 * @details 整合所有后处理步骤，提供统一的处理接口
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include "postprocess/postprocess.h"

// 前向声明所有需要的函数
extern int load_npz_encoder_output(const char* npz_file_path, EncoderOutput* encoder_output);
extern void free_encoder_output(EncoderOutput* encoder_output);
extern int extract_vad_logits(const EncoderOutput* encoder_output, VADLogits* vad_logits);
extern void free_vad_logits(VADLogits* vad_logits);
extern int classify_frames(const VADLogits* vad_logits, const VADPostprocessConfig* config, FrameState* frame_states);
extern int apply_window_smoothing(const FrameState* input_states, int num_frames, const VADPostprocessConfig* config, FrameState* output_states);
extern int process_state_machine(const FrameState* smoothed_states, int num_frames, const VADPostprocessConfig* config, VADSpeechSegmentList* output_segments);
extern int merge_nearby_segments(VADSpeechSegmentList* segments, int merge_threshold_ms);

/**
 * @brief 核心VAD后处理算法
 * @param vad_logits VAD logits数据
 * @param config 配置参数
 * @param output_segments 输出语音段列表
 * @return 0表示成功，非0表示失败
 */
int vad_postprocess_core(const VADLogits* vad_logits,
                         const VADPostprocessConfig* config,
                         VADSpeechSegmentList* output_segments) {
    if (!vad_logits || !config || !output_segments) {
        fprintf(stderr, "❌ VAD后处理核心：无效参数\n");
        return -1;
    }

    int num_frames = vad_logits->num_frames;
    printf("\n🔄 开始VAD后处理 (帧数: %d)\n", num_frames);

    // 1. 分配临时数组
    FrameState* frame_states = (FrameState*)malloc(num_frames * sizeof(FrameState));
    FrameState* smoothed_states = (FrameState*)malloc(num_frames * sizeof(FrameState));
    
    if (!frame_states || !smoothed_states) {
        fprintf(stderr, "❌ 临时数组内存分配失败\n");
        if (frame_states) free(frame_states);
        if (smoothed_states) free(smoothed_states);
        return -1;
    }

    int result = 0;

    do {
        // 2. 基于阈值分类每帧
        printf("\n--- 步骤1: 阈值分类 ---\n");
        int speech_count = classify_frames(vad_logits, config, frame_states);
        if (speech_count < 0) {
            result = -1;
            break;
        }

        // 3. 窗口平滑
        printf("\n--- 步骤2: 窗口平滑 ---\n");
        int smoothed_count = apply_window_smoothing(frame_states, num_frames, config, smoothed_states);
        if (smoothed_count < 0) {
            result = -1;
            break;
        }

        // 4. 状态机处理
        printf("\n--- 步骤3: 状态机处理 ---\n");
        if (process_state_machine(smoothed_states, num_frames, config, output_segments) != 0) {
            result = -1;
            break;
        }

        // 5. 合并相近段
        printf("\n--- 步骤4: 合并优化 ---\n");
        int final_count = merge_nearby_segments(output_segments, 100); // 100ms合并阈值
        printf("最终语音段数: %d\n", final_count);

    } while (0);

    // 清理临时数组
    free(frame_states);
    free(smoothed_states);

    if (result == 0) {
        printf("\n✅ VAD后处理完成\n");
    } else {
        printf("\n❌ VAD后处理失败\n");
    }

    return result;
}

/**
 * @brief 从NPZ文件进行VAD后处理
 * @param npz_file_path NPZ文件路径
 * @param config 后处理配置参数
 * @param output_segments 输出语音段列表
 * @return 0表示成功，非0表示失败
 */
int vad_postprocess_from_npz(const char* npz_file_path, 
                             const VADPostprocessConfig* config,
                             VADSpeechSegmentList* output_segments) {
    if (!npz_file_path || !config || !output_segments) {
        fprintf(stderr, "❌ NPZ后处理：无效参数\n");
        return -1;
    }

    printf("🚀 开始从NPZ文件进行VAD后处理\n");
    printf("输入文件: %s\n", npz_file_path);

    EncoderOutput encoder_output = {0};
    VADLogits vad_logits = {0};
    int result = 0;

    do {
        // 1. 加载NPZ文件
        printf("\n=== 步骤1: 加载NPZ文件 ===\n");
        if (load_npz_encoder_output(npz_file_path, &encoder_output) != 0) {
            result = -1;
            break;
        }

        // 2. 提取VAD logits
        printf("\n=== 步骤2: 提取VAD Logits ===\n");
        if (extract_vad_logits(&encoder_output, &vad_logits) != 0) {
            result = -1;
            break;
        }

        // 3. 执行核心后处理算法
        printf("\n=== 步骤3: 核心后处理算法 ===\n");
        if (vad_postprocess_core(&vad_logits, config, output_segments) != 0) {
            result = -1;
            break;
        }

        // 4. 输出结果
        printf("\n=== 步骤4: 输出结果 ===\n");
        speech_segment_list_print(output_segments, config->output_file);

    } while (0);

    // 清理资源
    free_vad_logits(&vad_logits);
    free_encoder_output(&encoder_output);

    if (result == 0) {
        printf("\n🎉 NPZ后处理完成成功！\n");
    } else {
        printf("\n💥 NPZ后处理失败！\n");
    }

    return result;
}

/**
 * @brief 从编码器输出进行VAD后处理
 * @param encoder_output 编码器输出数据
 * @param config 后处理配置参数
 * @param output_segments 输出语音段列表
 * @return 0表示成功，非0表示失败
 */
int vad_postprocess_from_encoder(const EncoderOutput* encoder_output,
                                 const VADPostprocessConfig* config,
                                 VADSpeechSegmentList* output_segments) {
    if (!encoder_output || !config || !output_segments) {
        fprintf(stderr, "❌ 编码器后处理：无效参数\n");
        return -1;
    }

    printf("🚀 开始从编码器输出进行VAD后处理\n");
    printf("编码器输出: [%d, %d]\n", encoder_output->num_frames, encoder_output->output_dim);

    VADLogits vad_logits = {0};
    int result = 0;

    do {
        // 1. 提取VAD logits
        printf("\n=== 步骤1: 提取VAD Logits ===\n");
        if (extract_vad_logits(encoder_output, &vad_logits) != 0) {
            result = -1;
            break;
        }

        // 2. 执行核心后处理算法
        printf("\n=== 步骤2: 核心后处理算法 ===\n");
        if (vad_postprocess_core(&vad_logits, config, output_segments) != 0) {
            result = -1;
            break;
        }

        // 3. 输出结果
        printf("\n=== 步骤3: 输出结果 ===\n");
        speech_segment_list_print(output_segments, config->output_file);

    } while (0);

    // 清理资源
    free_vad_logits(&vad_logits);

    if (result == 0) {
        printf("\n🎉 编码器后处理完成成功！\n");
    } else {
        printf("\n💥 编码器后处理失败！\n");
    }

    return result;
} 