/**
 * @file state_machine.c
 * @brief 状态机模块实现
 * @details 实现基于状态机的语音段检测和边界确定逻辑
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "postprocess/postprocess.h"

/**
 * @brief 初始化状态机
 * @param state 状态机结构体
 * @return 0表示成功，非0表示失败
 */
int state_machine_init(StateMachineState* state) {
    if (!state) {
        fprintf(stderr, "[ERROR] State machine initialization: invalid parameters\n");
        return -1;
    }

    state->current_state = FRAME_STATE_SILENCE;
    state->state_duration = 0;
    state->speech_start_frame = -1;
    state->silence_count = 0;
    state->speech_confirmed = false;

    return 0;
}

/**
 * @brief 处理状态机转换并生成语音段
 * @param smoothed_states 平滑后的帧状态数组
 * @param num_frames 帧数
 * @param config 配置参数
 * @param output_segments 输出语音段列表
 * @return 0表示成功，非0表示失败
 */
int process_state_machine(const FrameState* smoothed_states,
                         int num_frames,
                         const VADPostprocessConfig* config,
                         VADSpeechSegmentList* output_segments) {
    if (!smoothed_states || !config || !output_segments) {
        fprintf(stderr, "[ERROR] State machine processing: invalid parameters\n");
        return -1;
    }

    StateMachineState state;
    state_machine_init(&state);

    int start_point_delay = config->start_point_delay;
    int end_point_lookahead = config->end_point_lookahead;
    int max_end_silence_frames = config->max_end_silence_frames;

    printf("🔄 状态机处理:\n");
    printf("  开始点延迟: %d帧 (%dms)\n", start_point_delay, start_point_delay * config->frame_duration_ms);
    printf("  结束点前瞻: %d帧 (%dms)\n", end_point_lookahead, end_point_lookahead * config->frame_duration_ms);
    printf("  最大结束静音: %d帧 (%dms)\n", max_end_silence_frames, max_end_silence_frames * config->frame_duration_ms);

    int segment_count = 0;

    for (int i = 0; i < num_frames; i++) {
        FrameState current_frame_state = smoothed_states[i];

        if (state.current_state == FRAME_STATE_SILENCE) {
            if (current_frame_state == FRAME_STATE_SPEECH) {
                // 静音 -> 语音转换
                if (state.speech_start_frame == -1) {
                    // 第一次检测到语音，应用回溯逻辑
                    int actual_start_frame = i - start_point_delay;
                    if (actual_start_frame < 0) {
                        actual_start_frame = 0;
                    }

                    state.speech_start_frame = actual_start_frame;
                    state.speech_confirmed = true;  // 简化：直接确认语音开始
                    printf("    帧%3d: 语音开始，回溯到帧%d (时间=%dms)\n",
                           i, state.speech_start_frame, state.speech_start_frame * config->frame_duration_ms);
                }

                state.current_state = FRAME_STATE_SPEECH;
                state.silence_count = 0;
                state.state_duration++;
            } else {
                // 继续静音状态
                state.state_duration++;
            }
        } else { // state.current_state == FRAME_STATE_SPEECH
            if (current_frame_state == FRAME_STATE_SILENCE) {
                // 语音 -> 静音转换
                state.silence_count++;
                printf("    帧%3d: 语音转静音，累积静音计数=%d帧\n", i, state.silence_count);

                // 检查是否超过最大静音阈值
                if (state.silence_count >= max_end_silence_frames) {
                    // 结束当前语音段
                    if (state.speech_confirmed) {
                        int start_frame = state.speech_start_frame;
                        int end_frame = i - state.silence_count + end_point_lookahead;
                        
                        // 确保结束帧不超出范围
                        if (end_frame >= num_frames) {
                            end_frame = num_frames - 1;
                        }

                        int start_ms = start_frame * config->frame_duration_ms;
                        int end_ms = end_frame * config->frame_duration_ms;
                        
                        printf("    帧%3d: 静音超过%dms，结束语音段\n", i, max_end_silence_frames * config->frame_duration_ms);
                        printf("      lookback_frame=%d帧, end_frame=%d\n", 
                               state.silence_count - end_point_lookahead, end_frame);
                        printf("      最终段: %d-%dms (时长%dms)\n", start_ms, end_ms, end_ms - start_ms);

                        // 添加语音段
                        speech_segment_list_add(output_segments, start_ms, end_ms);
                        segment_count++;
                    }

                    // 重置状态机
                    state.current_state = FRAME_STATE_SILENCE;
                    state.speech_start_frame = -1;
                    state.speech_confirmed = false;
                    state.silence_count = 0;
                    state.state_duration = 0;
                }
            } else {
                // 继续语音状态
                state.silence_count = 0;
                printf("    帧%3d: 语音段继续\n", i);
            }
        }
    }

    // 处理文件结束时未完成的语音段
    if (state.current_state == FRAME_STATE_SPEECH && state.speech_confirmed) {
        int start_frame = state.speech_start_frame;
        int end_frame = num_frames - 1;
        
        int start_ms = start_frame * config->frame_duration_ms;
        int end_ms = end_frame * config->frame_duration_ms;
        
        printf("    文件结束: 完成最后一个语音段 %d-%dms\n", start_ms, end_ms);
        speech_segment_list_add(output_segments, start_ms, end_ms);
        segment_count++;
    }

    printf("  状态机输出段: %d 个\n", segment_count);
    return 0;
} 