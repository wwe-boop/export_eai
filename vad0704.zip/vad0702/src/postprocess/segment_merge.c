/**
 * @file segment_merge.c
 * @brief 语音段管理模块
 * @details 实现语音段列表的管理、合并和输出功能
 * @author l50011968
 * @date 2025.7.3
 * @version 1.0.0
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "postprocess/postprocess.h"

/**
 * @brief 初始化语音段列表
 * @param segments 语音段列表
 * @param initial_capacity 初始容量
 * @return 0表示成功，非0表示失败
 */
int speech_segment_list_init(VADSpeechSegmentList* segments, int initial_capacity) {
    if (!segments || initial_capacity <= 0) {
        fprintf(stderr, "[ERROR] Speech segment list initialization: invalid parameters\n");
        return -1;
    }

    segments->segments = (SpeechSegment*)malloc(initial_capacity * sizeof(SpeechSegment));
    if (!segments->segments) {
        fprintf(stderr, "[ERROR] Failed to allocate speech segment list memory\n");
        return -1;
    }

    segments->count = 0;
    segments->capacity = initial_capacity;

    return 0;
}

/**
 * @brief 释放语音段列表
 * @param segments 语音段列表
 */
void speech_segment_list_free(VADSpeechSegmentList* segments) {
    if (segments) {
        if (segments->segments) {
            free(segments->segments);
            segments->segments = NULL;
        }
        segments->count = 0;
        segments->capacity = 0;
    }
}

/**
 * @brief 添加语音段到列表
 * @param segments 语音段列表
 * @param start_ms 开始时间(毫秒)
 * @param end_ms 结束时间(毫秒)
 * @return 0表示成功，非0表示失败
 */
int speech_segment_list_add(VADSpeechSegmentList* segments, int start_ms, int end_ms) {
    if (!segments || start_ms < 0 || end_ms <= start_ms) {
        fprintf(stderr, "[ERROR] Add speech segment: invalid parameters (start=%d, end=%d)\n", start_ms, end_ms);
        return -1;
    }

    // 检查容量，必要时扩展
    if (segments->count >= segments->capacity) {
        int new_capacity = segments->capacity * 2;
        SpeechSegment* new_segments = (SpeechSegment*)realloc(
            segments->segments, new_capacity * sizeof(SpeechSegment));
        
        if (!new_segments) {
            fprintf(stderr, "[ERROR] Failed to expand speech segment list\n");
            return -1;
        }

        segments->segments = new_segments;
        segments->capacity = new_capacity;
    }

    // 添加新段
    segments->segments[segments->count].start_ms = start_ms;
    segments->segments[segments->count].end_ms = end_ms;
    segments->count++;

    return 0;
}

/**
 * @brief 合并相近的语音段
 * @param segments 语音段列表
 * @param merge_threshold_ms 合并阈值(毫秒)
 * @return 合并后的段数
 */
int merge_nearby_segments(VADSpeechSegmentList* segments, int merge_threshold_ms) {
    if (!segments || segments->count <= 1) {
        return segments ? segments->count : 0;
    }

    printf("🔄 合并相近语音段 (阈值: %dms):\n", merge_threshold_ms);

    int write_pos = 0;
    
    for (int read_pos = 0; read_pos < segments->count; read_pos++) {
        if (write_pos == 0) {
            // 第一个段直接复制
            segments->segments[write_pos] = segments->segments[read_pos];
            write_pos++;
        } else {
            // 检查是否可以与前一段合并
            SpeechSegment* prev = &segments->segments[write_pos - 1];
            SpeechSegment* curr = &segments->segments[read_pos];
            
            int gap = curr->start_ms - prev->end_ms;
            
            if (gap <= merge_threshold_ms) {
                // 合并到前一段
                prev->end_ms = curr->end_ms;
                printf("  合并段: [%d,%d] + [%d,%d] -> [%d,%d] (间隔%dms)\n",
                       prev->start_ms, prev->end_ms - (curr->end_ms - prev->end_ms),
                       curr->start_ms, curr->end_ms,
                       prev->start_ms, prev->end_ms, gap);
            } else {
                // 作为新段添加
                segments->segments[write_pos] = *curr;
                write_pos++;
            }
        }
    }

    int original_count = segments->count;
    segments->count = write_pos;
    
    printf("  过滤合并后段: %d 个 (原来%d个)\n", segments->count, original_count);
    
    return segments->count;
}

/**
 * @brief 打印语音段列表
 * @param segments 语音段列表
 * @param output_file 输出文件路径，NULL则输出到stdout
 */
void speech_segment_list_print(const VADSpeechSegmentList* segments, const char* output_file) {
    if (!segments) {
        fprintf(stderr, "[ERROR] Print speech segment list: invalid parameters\n");
        return;
    }

    FILE* fp = stdout;
    if (output_file) {
        fp = fopen(output_file, "w");
        if (!fp) {
            fprintf(stderr, "[ERROR] Cannot open output file: %s\n", output_file);
            fp = stdout;
        }
    }

    fprintf(fp, "=== VAD后处理结果 ===\n");
    fprintf(fp, "检测到语音段: %d 个\n", segments->count);
    
    for (int i = 0; i < segments->count; i++) {
        const SpeechSegment* seg = &segments->segments[i];
        int duration = seg->end_ms - seg->start_ms;
        fprintf(fp, "    段%d: %dms - %dms (时长: %dms)\n", 
                i + 1, seg->start_ms, seg->end_ms, duration);
    }

    if (segments->count == 0) {
        fprintf(fp, "未检测到语音段\n");
    }

    fprintf(fp, "\n=== 与Python基准对比 ===\n");
    fprintf(fp, "期望结果: 1个语音段 [780ms, 4470ms]\n");
    
    if (segments->count == 1) {
        const SpeechSegment* seg = &segments->segments[0];
        int start_diff = seg->start_ms - 780;
        int end_diff = seg->end_ms - 4470;
        fprintf(fp, "实际结果: 1个语音段 [%dms, %dms]\n", seg->start_ms, seg->end_ms);
        fprintf(fp, "开始时间差异: %dms\n", start_diff);
        fprintf(fp, "结束时间差异: %dms\n", end_diff);
        
        if (abs(start_diff) <= 10 && abs(end_diff) <= 20) {
            fprintf(fp, "[INFO] Accuracy verification passed\n");
        } else {
            fprintf(fp, "[ERROR] Accuracy verification failed\n");
        }
    } else {
        fprintf(fp, "实际结果: %d个语音段\n", segments->count);
        fprintf(fp, "[ERROR] Segment count mismatch\n");
    }

    if (fp != stdout) {
        fclose(fp);
        printf("[INFO] Results written to file: %s\n", output_file);
    }
} 