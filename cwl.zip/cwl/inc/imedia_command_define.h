#ifndef IMEDIA_COMMAND_DEFINE_H
#define IMEDIA_COMMAND_DEFINE_H
#include "imedia_kwsnnse_struct.h"
#include "imedia_encoder_eai_define.h"
#include "imedia_decoder_eai_define.h"
#include "imedia_joiner_eai_define.h"
#include "imedia_vad_eai_define.h"
#include "imedia_command_api.h"

#define IMEDIA_COMMAND_FUSION_FRAME_NUM       4 // 音频缓存帧

#define DENOISE_PROCESS_Q                     15
#define IMEDIA_COMMAND_FRAMELAP_16K           160 // 1frame
#define IMEDIA_COMMAND_3FRAME_16K             480 // 1frame
#define IMEDIA_16K_SAMPLE_RATE                16000

#define IMEDIA_ASR_FRAMES_16K                 400 // 25ms
#define IMEDIA_ASR_FFT_OUT_16K                512 // FFT

#define IMEDIA_MAX_Q15                        32768
#define IMEDIA_MAX_Q15F                       32768.0

#define IMEDIA_FBANK_FEATURE_LEN              80 // fbank数目
#define IMEDIA_FBANK_FILTER_LEN               258 // fbank滤波器长度

#define IMEDIA_MAX_ACTIVE_PATH 10

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif
#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif
#ifndef ABS
#define ABS(x) ((x) < 0 ? -(x) : (x))
#endif


typedef struct {
    char key[MAX_HYP_SIZE];
    Hypothesis hyp;
} STRU_HYPS_DICT;

// 主结构体
typedef struct {
    STRU_ENCODER_EAI_CONTEXT stEncoderEai;
    STRU_DECODER_EAI_CONTEXT stDecoderEai;
    STRU_JOINER_EAI_CONTEXT stJoinerEai;
    STRU_VAD_EAI_CONTEXT stVadEai;


    unsigned int frameCnt;
    unsigned int fftFrameCnt;

    short resv;
    short frameLap;
    short dctOrder;
    short frameLen;

    const short *addWin;
    const short *delWin;
    const short *fftTab;
    const short *pResv;

    short sHistoryFrame[IMEDIA_COMMAND_FRAMELAP_16K * IMEDIA_COMMAND_FUSION_FRAME_NUM]; // 音频缓存4帧
    short sInData[IMEDIA_ASR_FRAMES_16K]; // 提取特征的长度25ms
    short sInDataWin[IMEDIA_ASR_FRAMES_16K]; // 提取特征的长度25ms
    int fftData[IMEDIA_ASR_FFT_OUT_16K+2];

    float powerBuf[IMEDIA_ASR_FFT_OUT_16K+2];
    float fBankOut[IMEDIA_FBANK_FEATURE_LEN];
    float* filterPointers[IMEDIA_FBANK_FEATURE_LEN];
    float filterWeights[IMEDIA_FBANK_FEATURE_LEN][IMEDIA_FBANK_FILTER_LEN];

    KwsDenoiseStruct *pKwsDenoiseParam;

    short readCacheBegin;
    short sEaiApplyFlag;
    short sEaiExecFlag;
    short sEaiInitFlag;

    int offset;

    short *encoderInBuf; // 
    short *shareEncoderInBuf; // 

    short cacheBegin;
    short* cacheBuf1; //
    short* cacheBuf2; //
    int* decoderInBuf;

    // 双线程相关
    short endEncoderExec;
    // 解码相关
    // StringIntPair sym2id[1300];
    StringIntPair *sym2id;
    STRU_HYPS_DICT prev[IMEDIA_MAX_ACTIVE_PATH];
    STRU_HYPS_DICT cur[IMEDIA_MAX_ACTIVE_PATH];
    int hypSize; // cur的路径数
    int time;
    // 解码图相关
    ContextGraph contextGraph;
    // token相关
    ImediaCommandInfo* commadInfo;

    char* eaiModel;
    char *eaiPacket;
    int eaiPacketSize;

    modelParam modelParam;  
    
}STRU_KDNR_CHAN, *PST_KDNR_CHAN;


#endif

