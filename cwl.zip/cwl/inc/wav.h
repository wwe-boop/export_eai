#ifndef WAV_H
#define WAV_H

#include <stdio.h>
#include <stdlib.h>

//定义一个默认8k单通道结构体
#define WAV_HEADER_8K_1CHAN  \
 { \
    {'R', 'I', 'F', 'F'},   \
    36, \
    {'W', 'A', 'V', 'E', 'f', 'm', 't', 0x20},  \
    0x00000010, \
    0x0001, \
    1,  \
    8000,   \
    16000,  \
    2,  \
    16, \
    {'d', 'a', 't', 'a'},   \
    0,  \
} \

//由于wav文件头有多种(44Bytes, 58Bytes, 60Bytes, 90Bytes)，这里只定义44Bytes的情况，不过它们的前
typedef struct tagSTR_WAV_HEADER
{
    //公共部分: 32Bytes
    signed char riff[4];   // "RIFF"
    int  filelen;   // fileLen-8
    signed char fmt[8];    // "WAVEfmt"
    int  size1;     // pcm:10 00 00 00， 即0x00000010
    short fmttag;   // 01 00
    short channel;  // channels num: 1/2
    int samplerate; // 8000 /16000
    int bytesrate; // 比特率: sampleRate*channel*1/2

    //以下信息不同wav格式大小不同，这里只列出了44Bytes的情况
    short block;    // 声道数*量化数/8
    short bitsample;// 量化数: 8/16
    char data[4];   //"data"
    int datalen;    //数据大小    
}STR_WAV_HEADER, *PST_WAV_HEADER;

//返回wav文件头数目, 及新的数据头
int read_wav(FILE *file_wav, PST_WAV_HEADER header);

#endif

