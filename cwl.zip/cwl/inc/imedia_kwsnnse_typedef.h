#ifndef _IMEDIA_KWSNNSE_TYPEDEF_
#define _IMEDIA_KWSNNSE_TYPEDEF_

#include <stdint.h>

// 内存保护检测宏定义
#define IMEDIA_VOICE_PROTECT_CODE32              0x5A5A5A5A
#define IMEDIA_VOICE_PROTECT_CODE16              0x5A5A
typedef unsigned char      QNNSEBOOL;
typedef long long          QNNSE_INT64;
typedef unsigned long long QNNSE_UINT64;
typedef uintptr_t          QNNSE_INTPTR;

#ifndef complex
    #define complex _Complex /**< complex type */
#endif
#define Q_ALIGN(num)
#define Q_ALIGN_ADDR(address, alignment) do { \
    (address) = (((address) + ((alignment) - 1)) & ~((alignment) - 1)); \
} while (0)

#endif

