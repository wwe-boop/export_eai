/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2021-2024. All rights reserved.
 * Description: imedia_aec_table.h
 * Author: jin
 * Create: 2024-06-27 19:35:11
 * 函数列表:
 *
 *****************************************************************************/

#ifndef _IMEDIA_HYPOTHESIS_H_
#define _IMEDIA_HYPOTHESIS_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "imedia_context_graph.h"
#include "math.h"

#define MAX_HYP_SIZE 200
#define MAX_RES_SIZE MAX_HYP_SIZE * 4
typedef struct {
    // The predicted tokens so far. Newly predicated tokens are appended.
    int ys[MAX_HYP_SIZE];

    // timestamps[i] contains the frame number after subsampling
    // on which ys[i] is decoded.
    int timestamps[MAX_HYP_SIZE];

    // The acoustic probability for each token in ys.
    // Used for keyword spotting task.
    // For transducer mofified beam-search and greedy-search,
    // this is filled with log_posterior scores.
    float ys_probs[MAX_HYP_SIZE];

    // contextScores[i] contains the context-graph score for each token in ys.
    // Used only in transducer mofified beam-search.
    // Elements filled only if `ContextGraph` is used.
    //float contextScores[MAX_HYP_SIZE];
    float contextScore;
    // The total score of ys in log space.
    // It contains only acoustic scores
    double logProb;
    ContextState* contextState;
    int numTailingBlanks;
    int ysSize;
    short phraseId;
} Hypothesis;


#ifdef __cplusplus
}
#endif

#endif // _IMEDIA_HYPOTHESIS_H_