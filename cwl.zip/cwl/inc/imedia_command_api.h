#ifndef IMEDIA_COMMAND_API_H
#define IMEDIA_COMMAND_API_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "imedia_kwsnnse_struct.h"
#define IMEDIA_COMMAND_SAMPLERATE_16K              (1)    // 16K
/*----------------------------------------------*
 * 接口返回码定义, todo                               *
 *----------------------------------------------*/
#define IMEDIA_COMMAND_EOK                         (0)        // 接口函数正常返回
#define IMEDIA_COMMAND_INV_HANDLE                  (1)        // 无效句柄(指针为空)
#define IMEDIA_COMMAND_INV_BASE                    (2)        // 无效的基地址
#define IMEDIA_COMMAND_INV_SAMPLERATE              (3)        // 无效的采样率
#define IMEDIA_COMMAND_INV_PDATA                   (4)        // 无效的输入输出数据流指针

#define IMEDIA_COMMAND_INV_EAI_PACKET               (101)
#define IMEDIA_COMMAND_INV_ENCODER_INIT             (102)
#define IMEDIA_COMMAND_INV_DECODER_INIT             (103)
#define IMEDIA_COMMAND_INV_JOINER_INIT              (104)
#define IMEDIA_COMMAND_INV_XXX                      (105)

#define MAX_FRAME_COUNT                 (0x7ffffffe) //   帧计数器最大值，防止溢出

#define ADD_END

// 命令词事件上报结构体,todo
typedef struct {
    int start;
    int end;
    uint32_t mask;
    float version;
} ImediaFreeWakeupEventInfo;

// 交互信息,todo
typedef struct {
    int activatePhaseId;
    int isNeedDecode;
    int isEnd;
    char result[MAX_RES_SIZE]; // 识别结果
    ImediaFreeWakeupEventInfo eventInfo; // 上报信息
} ImediaCommandInfo;

// 分配的内存,todo
typedef struct {
    char* tokenBuf;
    int tokenBufSize;
} ImediaCommandBuf;

// load eai model para
typedef struct _eaiModel {
    unsigned int modelAddr;
    unsigned int modelSize;
    unsigned int scratchAddr;
    unsigned int scratchSize;
    unsigned int persistentAddr;
    unsigned int persistentSize;
    unsigned int ioMemAddr;
    unsigned int ioMemSize;
    unsigned int cacheAddr;
    unsigned int cacheSize;
} eaiModel;

typedef struct _modelParam{
    unsigned int encoderInFrameBufSize; //39
    unsigned int encoderInFrameOffset;  //32
    unsigned int encoderCacheSize0; //15
    unsigned int encoderCacheSize1; //15*384
    unsigned int encoderOutDim; //512
    unsigned int encoderOutT; //8
    unsigned int decoderInDim; //2
    unsigned int decoderOutDim; //512
    unsigned int joinerInDim; //512
    float joinerScale; // 0.0021276867482811213
    unsigned int vocabSize;
} modelParam;
typedef struct _eaiHeader{
    unsigned int startMask;
    unsigned int version;
    unsigned int totalSize;
    unsigned int eaiVersionMajor;
    unsigned int eaiVersionMinor;
    unsigned int enpuVersion;
    unsigned int modelType;
    unsigned int quantType;
    modelParam param;
    eaiModel encoder;
    eaiModel decoder;
    eaiModel joiner;
    eaiModel vad;
    unsigned int tokensAddr;
    unsigned int tokensSize;
    unsigned int publicScratchAddr;
    unsigned int publicScratchSize;
    unsigned int publicContextScratchAddr;
    unsigned int publicContextScratchSize;
    unsigned int publicDecoderScratchAddr;
    unsigned int publicDecoderScratchSize;
    unsigned int reserved[100]; // 保证结尾256对齐
} eaiHeader;

/******************************************************************************
Function:      IMediaVoiceControlGetVersion
Description:   获取算法主调代码版本信息，包括详细版本号、发布日期
Return:        ret: 操作返回码
               IMEDIA_COMMAND_EOK表示成功，其他返回码表示失败
*******************************************************************************/
int IMediaVoiceControlGetVersion(void);

/******************************************************************************
Function:      IMediaVoiceControlReset
Description:   重置算法实例(通道变量)
Input:         pChanl: 算法通道结构体指针
               pParam: 参数指针
Return:        ret: 操作返回码
                    IMEDIA_COMMAND_EOK表示成功，其他返回码表示失败
*******************************************************************************/
int IMediaVoiceControlReset(void* pChanl);
/******************************************************************************
Function:      IMediaVoiceControlInit
Description:   初始化算法实例(通道变量)
Input:         pChanl: 算法通道结构体指针
               pParam: 参数指针
Return:        ret: 操作返回码
                    IMEDIA_COMMAND_EOK表示成功，其他返回码表示失败
*******************************************************************************/
int IMediaVoiceControlInit(void *pChanl, KwsDenoiseStruct * pParam, ImediaCommandBuf* commandBuf, ImediaCommandInfo* commandInfo, unsigned char *eaiPacket, int eaiPacketSize);

/******************************************************************************
Function:      IMediaVoiceControlGetPara
Description:   获取当前算法的参数配置
Input:         pChanl: 算法通道结构体指针
Output:        pParam:  参数指针
Return:        ret: 操作返回码
               IMEDIA_COMMAND_EOK表示成功，其他返回码表示失败
*******************************************************************************/
int IMediaVoiceControlGetPara(void *pChanl, void *pParam);

/******************************************************************************
Function:      IMediaVoiceControlSetPara
Description:   配置算法参数
Input:         pChanl: 算法通道结构体指针
Output:        pParam:  参数指针
Return:        ret: 操作返回码
               IMEDIA_COMMAND_EOK表示成功，其他返回码表示失败
*******************************************************************************/
int IMediaVoiceControlSetPara(void *pChanl, void *pParam, char *context_file);

/******************************************************************************
Function:      IMediaVoiceControlProcess
Description:   COMMAND算法处理
Input:         pChanl: 算法通道结构体指针
               x:输入数据
               pscratchBuf: 缓存区
Output:        pChanl: 对象句柄
Return:        ret: 操作返回码
               IMEDIA_COMMAND_EOK表示成功，其他返回码表示失败
*******************************************************************************/
int IMediaVoiceControlProcess(void* pChanl, short* x);
/******************************************************************************
Function:      IMediaVoiceControlDecode
Description:   模型推理
Input:         pChanl: 算法通道结构体指针
               x:输入数据
               pscratchBuf: 缓存区
Output:        pChanl: 对象句柄
Return:        ret: 操作返回码
               IMEDIA_COMMAND_EOK表示成功，其他返回码表示失败
*******************************************************************************/
int IMediaVoiceControlDecode(void *pChanl);

/******************************************************************************
Function:      IMediaVoiceControlDeinit
Description:   释放内存
Input:         pChanl: 算法通道结构体指针
Return:        ret: 操作返回码
               IMEDIA_COMMAND_EOK表示成功，其他返回码表示失败
*******************************************************************************/
int IMediaVoiceControlDeinit(void *pChanl);

#ifdef __cplusplus
}
#endif

#endif
