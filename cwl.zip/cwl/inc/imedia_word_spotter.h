/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2021-2024. All rights reserved.
 * Description: imedia_aec_table.h
 * Author: jin
 * Create: 2024-06-27 19:35:11
 * 函数列表:
 *
 *****************************************************************************/

#ifndef _IMEDIA_WORD_SPOTTER_H_
#define _IMEDIA_WORD_SPOTTER_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "imedia_kwsnnse_typedef.h"
#include "imedia_kwsnnse_struct.h"
#include "imedia_command_define.h"

int IMediaGetResult(STRU_KDNR_CHAN* pstKdnrChanl);

#ifdef __cplusplus
}
#endif

#endif