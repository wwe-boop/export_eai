/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2021-2024. All rights reserved.
 * Description: imedia_aec_table.h
 * Author: jin
 * Create: 2024-06-27 19:35:11
 * 函数列表:
 *
 *****************************************************************************/

#ifndef _IMEDIA_ENCODER_EAI_DEFINE_H_
#define _IMEDIA_ENCODER_EAI_DEFINE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "eai.h"

#define ENCODER_SCRATCH_BUFFER_MEM_TYPE            EAI_MEM_TYPE_DDR
#define ENCODER_PERSISTENT_BUFFER_MEM_TYPE         EAI_MEM_TYPE_DDR
#define ENCODER_MODEL_BUFFER_MEM_TYPE              EAI_MEM_TYPE_DDR

#define MAX_INPUT_NUM                      10
#define EAI_INIT_FLAGS_DISABLE_ASYNC       0x00000020 // Disable asynchronous processing in HAL


#define ENCODER_EAI_INPUT1_SCALE                0.0004865378141403198

// Memory processing
#define IS_ALIGNED(addr, alignment)     ((((size_t) addr) & (alignment - 1)) == 0)
#define PAD_TO_VALUE(addr, alignment)   ((((size_t) addr) + (alignment - 1)) & ~(alignment - 1))

typedef enum SAMPLE_APP_RESULT {
    SAMPLE_APP_SUCCESS = 0,
    SAMPLE_APP_FAIL
} SAMPLE_APP_RESULT;


typedef struct {
    eaih_t eai_handle;
    int tensor_count[2]; // 0: input tensor, 1: output tensor
    eai_tensor_info_t *tensors[2];
    eai_buffer_info_t *eai_buffers[2];
    eai_batch_info_t eai_batch;
} STRU_ENCODER_EAI_CONTEXT, *PST_ENCODER_EAI_CONTEXT;

#ifdef __cplusplus
}
#endif

#endif // _IMEDIA_AES_EAI_DEFINE_H_