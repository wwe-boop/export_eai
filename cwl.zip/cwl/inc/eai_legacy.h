/*======================= COPYRIGHT NOTICE ==================================*]
[* Copyright (c) Qualcomm Technologies, Inc.                                 *]
[* All Rights Reserved.                                                      *]
[* Confidential and Proprietary - Qualcomm Technologies, Inc.                *]
[*===========================================================================*/

#ifndef __EAI_LEGACY_H__
#define __EAI_LEGACY_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum EAI_PROP_LEGACY
{
    EAI_PROP_TENSOR_SIZE_INFO = 13,      /* (deprecated) Tensor Size : eai_tensor_size_info_t */
    EAI_PROP_REGISTER_BUFFER = 14,       /* (deprecated) Register buffer information to be used during eai_execute : eai_register_buffer_info_t */
    EAI_PROP_MLA_OFFLOAD_SUMMARY = 15    /* (deprecated) Retrieve MLA offload summary : eai_mla_offload_summary */
} EAI_PROP_LEGACY;

/**
 * Register buffer flags
 */
typedef enum EAI_REG_BUF_FLAGS
{
    EAI_REG_BUF_FLAGS_REGISTER,          /* Register a buffer */
    EAI_REG_BUF_FLAGS_DEREGISTER,        /* Deregister a buffer */
    EAI_REG_BUF_FLAGS_MAX = 0x3FFFFFFF
} EAI_REG_BUF_FLAGS;

/*
 * Buffer for EAI_PROP_REGISTER_BUFFER property call.
 * */
typedef struct eai_register_buffer_t {
    uint8_t*            buf;
    uint32_t            buf_size;
    EAI_REG_BUF_FLAGS   flags;                 /* Enum to specify flags for buffer */
} eai_register_buffer_t;

/*
 * Buffer info call for EAI_PROP_REGISTER_BUFFER property.
 * */
typedef struct eai_register_buffer_info_t {
    uint32_t     num_buffer;        /* Number of buffers being registered/deregistered */
    eai_register_buffer_t* buf;     /* Buffers */
} eai_register_buffer_info_t;

typedef struct eai_tensor_size_info_t {
    uint32_t index;                 /* Index into the tensor list */
    uint32_t input_or_output;       /* Identifies input (0) or output (1) ports list */
    uint32_t size;                  /* Tensor size in units of bytes */
} eai_tensor_size_info_t;

typedef struct eai_mla_offload_summary_t {
    uint32_t offload_cnt;    /* actual # of layers in the model that gets offloaded at runtime, some may get rejected due to hw resource */
    uint32_t reject_cnt;     /* # of layers in the model that get rejected by enpu due to resource constraints */
} eai_mla_offload_summary_t;

#ifdef __cplusplus
}
#endif

#endif //__EAI_LEGACY_H__