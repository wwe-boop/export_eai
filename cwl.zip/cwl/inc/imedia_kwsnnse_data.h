#ifndef _IMEDIA_KWSNNSE_DATA_H_
#define _IMEDIA_KWSNNSE_DATA_H_

#include "imedia_kwsnnse_typedef.h"
#include "imedia_kwsnnse_struct.h"
// ----------------------------------------------------------
#define IMEDIA_COMMON_TEXT_SECTION
#define IMEDIA_COMMON_TABLE_SECTION

// FFT parameters
#ifndef Q_CODE_NNSE_FFT
extern const short g_sFFT512CoefCommand[2 * 512];
#else
extern const short G_NNSE_COMMON_TWIDDLESPLIT[] Q_ALIGN(8);
extern const short G_NNSE_COMMON_FFT_TWD_R8[] Q_ALIGN(8);
extern const short G_NNSE_COMMON_IFFT_TWD_R8[] Q_ALIGN(8);
extern const iMedia_STRU_FFTDescr G_NNSE_COMMON_RFFT16_128;
extern const iMedia_STRU_FFTDescr G_NNSE_COMMON_RFFT16_256;
extern const iMedia_STRU_FFTDescr G_NNSE_COMMON_RFFT16_512;
extern const iMedia_STRU_FFTDescr G_NNSE_COMMON_RFFT16_1024;
extern const iMedia_STRU_FFTDescr G_NNSE_COMMON_RIFFT16_128;
extern const iMedia_STRU_FFTDescr G_NNSE_COMMON_RIFFT16_256;
extern const iMedia_STRU_FFTDescr G_NNSE_COMMON_RIFFT16_512;
extern const iMedia_STRU_FFTDescr G_NNSE_COMMON_RIFFT16_1024;
#endif

// ----------------------------------------------------------
// sigmoid parameters, delwind and iversewin
extern const short G_KWSNNSE_COMMON_ADDWINTAB30MS_16K[];
extern const short G_KWSNNSE_COMMON_DELWINTAB30MS_16K[];
extern const int G_KWSNNSE_COMMON_TAB_INVQ30[];
extern const int G_KWSNNSE_COMMON_LOG2TAB[];
extern const short G_KWSNNSE_COMMON_ADDWINTAB25MS_16K[];

// ----------------------------------------------------------

// parameters for NNSE model
#define IMEDIA_DNOISE_TABLE_SECTION

#define IMEDIA_MMHF_TEXT_SECTION
#define IMEDIA_MMHF_TABLE_SECTION

// for sigmoid
extern const int KwsNnse_MMHF_pow2_tab[];

// for get dct feature
extern const short IMEDIA_KDNR_DCT_16K_TAB[1024];

#endif
