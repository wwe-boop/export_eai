/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2021-2024. All rights reserved.
 * Description: imedia_aec_table.h
 * Author: jin
 * Create: 2024-06-27 19:35:11
 * 函数列表:
 *
 *****************************************************************************/

#ifndef _IMEDIA_CONTEXT_GRAPH_H_
#define _IMEDIA_CONTEXT_GRAPH_H_

#ifdef __cplusplus
extern "C" {
#endif
//
#define MAX_TOKEN 130
#define MAX_PHRASE_LEN 10
#define MAX_NODES 130*7  // 预定义最大节点数
#define MAX_PHRASES 130 // 预定义最大短语数

// ContextState structure
typedef struct ContextState {
    int id;
    int token;
    float tokenScore;
    float nodeScore;
    float outputScore;
    int isEnd;
    int level;
    short phrase;
    float acThreshold;
    struct ContextState* next[MAX_TOKEN];
    short nextNum;
    struct ContextState* fail;
    struct ContextState* output;
} ContextState;

// ContextGraph structure
typedef struct ContextGraph {
    float contextScore;
    float acThreshold;
    int numNodes;
    ContextState* root;
    ContextState* nodePool; // state池
} ContextGraph;


void IMediaInitContextGraph(ContextGraph* graph, float contextScore, float acThreshold);
int IMediaBuildContextGraph(ContextGraph* graph, int tokenIds[][MAX_PHRASE_LEN], int numPhrases, const short* phrases, float* scores, float* acThresholds);
void IMediaForwardOneStep(ContextState* root, ContextState* state, int token, int strictMode, float* score, ContextState** nextState, ContextState** matchedState);
void IMediaFinalize(ContextState* state, short* phraseId, float* score, ContextState** nextState);
int IMediaIsMatched(ContextState* state, ContextState** matchedState);

#ifdef __cplusplus
}
#endif

#endif // _IMEDIA_AES_EAI_DEFINE_H_