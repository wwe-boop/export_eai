/*========================================================================*/
/**
\file imedia_aes_eai_vec.cpp

    Copyright (c) Honor Device Co., Ltd. 2021-2024.
    All rights reserved.
\author honor
\date 2024-06-28 11:16:16
*/
/*========================================================================*/

#include <stdio.h>
#include <locale.h>
#include <string.h>
#include "imedia_symbol_table.h"

void ImediaSymbolTableInit(char* tokenfile, STRU_KDNR_CHAN* pstKdnrChanl)
{
    int i;
    int offset=0;
    int offset_tmp = 0;
    StringIntPair* sym2id = pstKdnrChanl->sym2id;

    for(i=0;i<pstKdnrChanl->modelParam.vocabSize;i++){
        sym2id[i].key = tokenfile + offset;
        offset_tmp = strlen(sym2id[i].key) + 1;
        if (offset_tmp % 8 != 0) {
            offset_tmp += (8 - offset_tmp % 8);
        }
        offset += offset_tmp;

        sym2id[i].val = *(int32_t *)(tokenfile + offset);
        offset += sizeof(int32_t);
    }
    return;
}