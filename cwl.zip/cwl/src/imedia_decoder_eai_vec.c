/*========================================================================*/
/**
\file imedia_aes_eai_vec.cpp

    Copyright (c) Honor Device Co., Ltd. 2021-2024.
    All rights reserved.
\author honor
\date 2024-06-28 11:16:16
*/
/*========================================================================*/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "imedia_decoder_eai_vec.h"
#include "imedia_decoder_eai_define.h"
#include "imedia_command_define.h"
#include "imedia_kwsnnse_typedef.h"
#include "imedia_common_basicop.h"

// Set eNPU core selection/affinity (optional)
// Below is an example for setting hard affinity on the most powerful core of the platform
EAI_RESULT ImediaDecoderSetMlaAffinity(STRU_DECODER_EAI_CONTEXT *context)
{
    int eai_ret;

    // Get the number of cores
    uint32_t num_cores = 0;
    eai_ret = eai_get_property(context->eai_handle, EAI_PROP_MLA_NUM, &num_cores);

    // Loop through all cores to find the big core based on MAC
    uint32_t big_core_mac = 0;
    uint32_t big_core_id = 0;
    for (int i = 0; i < num_cores; i++) {
        eai_mla_core_info_t core_info = {0};
        core_info.id = i;
        eai_ret = eai_get_property(context->eai_handle, EAI_PROP_MLA_CORE_INFO, &core_info);

        if (core_info.mac > big_core_mac) {
            big_core_mac = core_info.mac;
            big_core_id = core_info.id;
        }
    }

    // Initialize default values for core selection/affinity
    eai_mla_affinity_t client_affinity;
    client_affinity.core_selection = 0u;
    client_affinity.affinity = EAI_MLA_AFFINITY_SOFT;

    // Set big core & hard affinity
    client_affinity.core_selection = 1 << big_core_id;
    client_affinity.affinity = EAI_MLA_AFFINITY_HARD;
    eai_ret = eai_set_property(context->eai_handle, EAI_PROP_MLA_AFFINITY, &client_affinity);

    if (eai_ret != 0) {
        return EAI_FAIL;
    } else {
        return EAI_SUCCESS;
    }
}

// Perform EAI-INIT, EAI-APPLY
int IMediaDecoderEaiInit(STRU_KDNR_CHAN* pstKdnrChanl, unsigned char* baseAddr, eaiModel* pEaiModel)
{
    if (baseAddr == NULL) {
        return -1;
    }
    STRU_DECODER_EAI_CONTEXT *pstDecoderContext;
    pstDecoderContext = &pstKdnrChanl->stDecoderEai;
    EAI_RESULT eai_ret;

    unsigned int  eaiInitFlags;
    eai_memory_info_t scratchMemory;
    eai_memory_info_t persistentMemory;
    eai_memory_info_t modelBuffer = {0};
    eai_client_perf_config_t clientPerfConfig;

    unsigned char* decoderEnpuModelBuffer = baseAddr + pEaiModel->modelAddr;
    unsigned char* decoderEnpuScratchBuffer = baseAddr + pEaiModel->scratchAddr;
    unsigned char* decoderEnpuPersistentBuffer = baseAddr + pEaiModel->persistentAddr;
    unsigned char* decoderEnpuIOBuffer = baseAddr + pEaiModel->ioMemAddr;
    int enpuIOOffset = 0;

    // load model file into a model channel pointer, and align the model buffer to 256 byte.
    // perform EAI-INIT.
    eaiInitFlags            = EAI_INIT_FLAGS_DISABLE_ASYNC; // Disable Asynchronous processing by default.
    modelBuffer.addr        = decoderEnpuModelBuffer;  // model buffer
    modelBuffer.memory_size = pEaiModel->modelSize;;
    modelBuffer.memory_type = DECODER_MODEL_BUFFER_MEM_TYPE;

    eai_ret = eai_init(&pstDecoderContext->eai_handle, &modelBuffer, eaiInitFlags);
    pstKdnrChanl->sEaiInitFlag = eai_ret;
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }

    // get scratch buffer info and set scratch buffer for eai api.
    eai_ret = eai_get_property(pstDecoderContext->eai_handle, EAI_PROP_SCRATCH_MEM, &scratchMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    if (scratchMemory.memory_size > pEaiModel->scratchSize) {
        return -1;
    }
    scratchMemory.addr = decoderEnpuScratchBuffer;
    scratchMemory.memory_type = DECODER_SCRATCH_BUFFER_MEM_TYPE;
    eai_ret = eai_set_property(pstDecoderContext->eai_handle, EAI_PROP_SCRATCH_MEM, &scratchMemory);

    // get persistent buffer info, Set persistent buffer for eai api.
    eai_ret = eai_get_property(pstDecoderContext->eai_handle, EAI_PROP_PERSISTENT_MEM, &persistentMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    if (persistentMemory.memory_size > pEaiModel->persistentSize) {
        return -1;
    }
    persistentMemory.addr = decoderEnpuPersistentBuffer;
    persistentMemory.memory_type = DECODER_PERSISTENT_BUFFER_MEM_TYPE;
    eai_ret = eai_set_property(pstDecoderContext->eai_handle, EAI_PROP_PERSISTENT_MEM, &persistentMemory);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Set client perf config (optional), Initialize default values for client_perf_config.
    clientPerfConfig.fps = 1u;
    clientPerfConfig.ftrt_ratio = 10u;
    clientPerfConfig.priority = EAI_CLIENT_PRIORITY_DEFAULT;
    clientPerfConfig.flags = 0x0;
    eai_ret = eai_set_property(pstDecoderContext->eai_handle, EAI_PROP_CLIENT_PERF_CFG, &clientPerfConfig);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Set core selection/affinity (optional) ѡ��С��
    eai_ret = ImediaDecoderSetMlaAffinity(pstDecoderContext);
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // perform EAI-APPLY, Applies configuration settings.
    eai_ret = eai_apply(pstDecoderContext->eai_handle);
    pstKdnrChanl->sEaiApplyFlag = eai_ret;
    if (eai_ret != EAI_SUCCESS) {
        return -1;
    }
    // Get model I/O tensor information and allocate them.
    for (int i = 0; i < 2; i++) { // 2 index
        eai_ports_info_t ports_info;
        ports_info.input_or_output = i;
        eai_ret = eai_get_property(pstDecoderContext->eai_handle, EAI_PROP_PORTS_NUM, &ports_info);
        if (eai_ret != EAI_SUCCESS) {
            return -1;
        }
        pstDecoderContext->tensor_count[i] = ports_info.size;
        pstDecoderContext->tensors[i] = (eai_tensor_info_t *)(decoderEnpuIOBuffer + enpuIOOffset);
        enpuIOOffset += ports_info.size * sizeof(eai_tensor_info_t);
        if (enpuIOOffset > pEaiModel->ioMemSize) {
            return -1;
        }
        for (int j = 0; j < ports_info.size; j++) {
            pstDecoderContext->tensors[i][j].index = j;
            pstDecoderContext->tensors[i][j].input_or_output = i;
            eai_ret = eai_get_property(pstDecoderContext->eai_handle, EAI_PROP_TENSOR_INFO, &(pstDecoderContext->tensors[i][j]));
            if (eai_ret != EAI_SUCCESS) {
                return -1;
            }
        }
        pstDecoderContext->eai_buffers[i] = (eai_buffer_info_t *)(decoderEnpuIOBuffer + enpuIOOffset);
        enpuIOOffset += sizeof(eai_tensor_info_t) * pstDecoderContext->tensor_count[i];
        if (enpuIOOffset > pEaiModel->ioMemSize) {
            return -1;
        }
    }
    pstKdnrChanl->decoderInBuf = (int*)decoderEnpuIOBuffer + enpuIOOffset;
    enpuIOOffset += pstKdnrChanl->modelParam.decoderInDim * IMEDIA_FBANK_FEATURE_LEN;
    return eai_ret;
}

// Perform EAI-EXECUTE.
int IMediaDecoderEaiExec(STRU_KDNR_CHAN* pstKdnrChanl, int32_t* pIn, int16_t** pOut)
{
    STRU_DECODER_EAI_CONTEXT *pstDecoderContext;
    pstDecoderContext = &pstKdnrChanl->stDecoderEai;
    EAI_RESULT eai_ret;
    int i;
    int j;

    AudioCommonVecCopyUInt8((uint8_t*)pIn, (size_t)(pstDecoderContext->tensors[0]->tensor_size), pstDecoderContext->tensors[0]->address);

    for (i = 0; i < 2; i++) {
        for (j = 0; j < pstDecoderContext->tensor_count[i]; j++) {
            eai_tensor_info_t *tensor = &(pstDecoderContext->tensors[i][j]);
            pstDecoderContext->eai_buffers[i][j].index = j;
            pstDecoderContext->eai_buffers[i][j].element_type = tensor->element_type;
            pstDecoderContext->eai_buffers[i][j].addr = tensor->address;
            pstDecoderContext->eai_buffers[i][j].buffer_size = tensor->tensor_size;
            pstDecoderContext->eai_buffers[i][j].memory_type = DECODER_SCRATCH_BUFFER_MEM_TYPE;
        }
    }

    pstDecoderContext->eai_batch.num_inputs = pstDecoderContext->tensor_count[0];
    pstDecoderContext->eai_batch.num_outputs = pstDecoderContext->tensor_count[1];
    pstDecoderContext->eai_batch.inputs = &(pstDecoderContext->eai_buffers[0][0]);
    pstDecoderContext->eai_batch.outputs = &(pstDecoderContext->eai_buffers[1][0]);

    eai_ret = eai_execute(pstDecoderContext->eai_handle, &pstDecoderContext->eai_batch, 1);
    pstKdnrChanl->sEaiExecFlag = eai_ret;

    *pOut = (int16_t*)pstDecoderContext->tensors[1]->address;

    return eai_ret;
}

// Perform EAI-DEINIT and free allocated context memory
int IMediaDecoderEaiDeInit(STRU_KDNR_CHAN* pstKdnrChanl)
{
    int ret;
    STRU_DECODER_EAI_CONTEXT *pstDecoderContext;
    pstDecoderContext = &pstKdnrChanl->stDecoderEai;
    ret = eai_deinit(pstDecoderContext->eai_handle);

    return ret;
}
