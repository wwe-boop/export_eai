/*========================================================================*/
/**
\file imedia_aes_eai_vec.cpp

    Copyright (c) Honor Device Co., Ltd. 2021-2024.
    All rights reserved.
\author honor
\date 2024-06-28 11:16:16
*/
/*========================================================================*/
#include <stdint.h>
#include "imedia_greedy_search.h"
#include "imedia_decoder_eai_vec.h"
#include "imedia_joiner_eai_vec.h"
#include "imedia_command_define.h"


int IMediaGreedyDecode(STRU_KDNR_CHAN* pstKdnrChanl, int16_t* encoderOut, Hypothesis* hyp)
{
    int blankId = 0;
    int unkId = 0;
    int32_t* decoderInput = (int32_t*)pstKdnrChanl->decoderInBuf;
    int t = 0;

    int16_t* pDecoderOut;
    int16_t* pJoinerOut;

    pstKdnrChanl->hypSize = 1;

    while (t < pstKdnrChanl->modelParam.encoderOutT) {
        decoderInput[0] = hyp->ys[hyp->ysSize - 2];
        decoderInput[1] = hyp->ys[hyp->ysSize - 1];
        IMediaDecoderEaiExec(pstKdnrChanl, decoderInput, &pDecoderOut);
        IMediaJoinerEaiExec(pstKdnrChanl, encoderOut + t * pstKdnrChanl->modelParam.joinerInDim, pDecoderOut, &pJoinerOut);
        short max = -32767;
        short y = 0;

        for (int idx = 0; idx < pstKdnrChanl->modelParam.vocabSize; idx++) {
            if (pJoinerOut[idx] > max) {
                y = idx;
                max = pJoinerOut[idx];
            }
        }
        if (y != blankId && y != unkId) {

            hyp->ys[hyp->ysSize] = y;
            hyp->ysSize++;
            hyp->numTailingBlanks = 0;
            if(hyp->ysSize > MAX_HYP_SIZE){
                hyp->ysSize = 2;
            }
        }
        else {
            hyp->numTailingBlanks++;
        }
        t++;
    }
    return 0;
}
