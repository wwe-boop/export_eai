#include <stdio.h>
#include <string.h>
#include "imedia_command_api.h"
#include "imedia_context_graph.h"
#include "imedia_common_basicop.h"
#include "imedia_common_define.h"
#include "imedia_common_math.h"
#include "imedia_encoder_eai_vec.h"
#include "imedia_decoder_eai_vec.h"
#include "imedia_joiner_eai_vec.h"
#include "imedia_vad_eai_vec.h"
#include "imedia_greedy_search.h"
#include "imedia_word_spotter.h"
#include "imedia_symbol_table.h"
#include "imedia_common_process.h"

#define KWS_ASR_VERSION (25061616)

#define EAI_PACKET_END_MASK (0x41535230) // ASR0
#define EAI_PACKET_START_MASK (0x30525341) // 0RSA
#define NUM_TAILING_BLANKS_THREAD 15
#define CONTEXT_SCORE 1.5

int IMediaVoiceControlGetVersion(void)
{
    return KWS_ASR_VERSION;
}

int IMediaVoiceControlProcess(void* pChanl, short* x)
{
    STRU_KDNR_CHAN* pstKdnrChanl = NULL;
    if (NULL == pChanl) {
        return ((int)IMEDIA_COMMAND_INV_HANDLE);
    }
    if ((NULL == x)) {
        return ((int)IMEDIA_COMMAND_INV_PDATA);
    }

    pstKdnrChanl = (STRU_KDNR_CHAN*)pChanl;

    eaiHeader* pEaiheader = (eaiHeader *)pstKdnrChanl->eaiPacket;
    char* baseAddr = pstKdnrChanl->eaiPacket;

    char* pScratchBuf = baseAddr + pEaiheader->publicScratchAddr;
    int maxLen;
    uintptr_t address = (uintptr_t)pScratchBuf;
    Q_ALIGN_ADDR(address, 256);  // 256 HVX优化需要128字节对齐
    maxLen = IMEDIA_ASR_FFT_OUT_16K + 2; // 2 余量
    short* fftBufIn = (short*)pScratchBuf;
    pScratchBuf = pScratchBuf + maxLen;
    int i = 0;
    short* encoderInBuf = (short*)pstKdnrChanl->encoderInBuf;
    short* shareEncoderInBuf = (short*)pstKdnrChanl->shareEncoderInBuf;

    pstKdnrChanl->frameCnt++;
    if (pstKdnrChanl->frameCnt >= (unsigned int)MAX_FRAME_COUNT) {  // 帧计数溢出保护
        pstKdnrChanl->frameCnt = (unsigned int)MAX_FRAME_COUNT;
    }

    AudioCommonVecCopyInt16(x, pstKdnrChanl->frameLap, pstKdnrChanl->sHistoryFrame + pstKdnrChanl->cacheBegin);
    pstKdnrChanl->cacheBegin += pstKdnrChanl->frameLap;
    if (pstKdnrChanl->frameCnt < 2) {
        return 0;
    }
    AudioCommonPreProcFftKws1(pstKdnrChanl, x, 0, (int*)pScratchBuf);

    // input data to eai tensor.
    float ttmp;
    for (i = 0; i < IMEDIA_FBANK_FEATURE_LEN; i++) {
        ttmp = pstKdnrChanl->fBankOut[i] / ENCODER_EAI_INPUT1_SCALE;
        if (ttmp > IMEDIA_MAX_Q15F - 1) {
            ttmp = IMEDIA_MAX_Q15F - 1;
        }
        if (ttmp < -IMEDIA_MAX_Q15F) {
            ttmp = -IMEDIA_MAX_Q15F;
        }
        fftBufIn[i] = round(ttmp);
    }

    // 输入大小为3*512 后两帧前移，最新帧复制到数组末端
    AudioCommonVecCopyUInt8((uint8_t*)encoderInBuf + IMEDIA_FBANK_FEATURE_LEN * sizeof(int16_t),\
                           (pstKdnrChanl->modelParam.encoderInFrameBufSize - 1) * IMEDIA_FBANK_FEATURE_LEN * sizeof(int16_t),\
                           (uint8_t*)encoderInBuf);
    AudioCommonVecCopyUInt8((uint8_t*)fftBufIn,\
                            IMEDIA_FBANK_FEATURE_LEN * sizeof(int16_t),\
                            (uint8_t*)encoderInBuf + (pstKdnrChanl->modelParam.encoderInFrameBufSize - 1) * IMEDIA_FBANK_FEATURE_LEN * sizeof(int16_t));

    if (pstKdnrChanl->fftFrameCnt >= pstKdnrChanl->modelParam.encoderInFrameBufSize) {
        pstKdnrChanl->offset += 1;
    }
    if (pstKdnrChanl->fftFrameCnt < pstKdnrChanl->modelParam.encoderInFrameBufSize) {
        return 0;
    }
    if (pstKdnrChanl->fftFrameCnt != pstKdnrChanl->modelParam.encoderInFrameBufSize && pstKdnrChanl->offset != pstKdnrChanl->modelParam.encoderInFrameOffset) {
        return 0;
    }
    pstKdnrChanl->offset = 0;
    if (pstKdnrChanl->commadInfo->isNeedDecode == 0) {
        pstKdnrChanl->commadInfo->isNeedDecode = 1;
        if (pstKdnrChanl->endEncoderExec == 1) {
            pstKdnrChanl->endEncoderExec = 0;
            AudioCommonVecCopyUInt8((uint8_t*)encoderInBuf,\
                                    (IMEDIA_FBANK_FEATURE_LEN * pstKdnrChanl->modelParam.encoderInFrameBufSize) * sizeof(int16_t),\
                                    (uint8_t*)shareEncoderInBuf);
        }
    }

    return 0;
}

int ImediaCommandEaiForward(STRU_KDNR_CHAN* pstKdnrChanl, int* pScratchBuf)
{
    int iRet;
    int16_t *pEncoderOut;
    iRet = IMediaEncoderEaiExec(pstKdnrChanl, &pEncoderOut);
    if (iRet != 0) {
        return -1;
    }
    // IMediaGreedyDecode(pstKdnrChanl, pEncoderOut, &pstKdnrChanl->cur->hyp);
    IMediaBeamSearch(pstKdnrChanl, (int*)pScratchBuf, pEncoderOut);
#ifdef ADD_END
    STRU_HYPS_DICT* cur = pstKdnrChanl->cur;
    Hypothesis hyp;
    short count = 0;
    for (int i = 0; i < pstKdnrChanl->hypSize; i++) {
        hyp = (cur + i)->hyp;
        if (hyp.numTailingBlanks > NUM_TAILING_BLANKS_THREAD) {
            count++;
        }
    }
    if (count > pstKdnrChanl->hypSize / 2 || count > 1) {
        pstKdnrChanl->commadInfo->isEnd = 1;
        IMediaGetResult(pstKdnrChanl);
    }
#endif
    return 0;
}

int IsAligned256Byte(unsigned char *ptr)
{
    return ((uintptr_t)ptr % 256) == 0;
}

int IMediaVoiceControlReset(void* pChanl)
{
    int ret = 0;
    if (NULL == pChanl) {
        return ((int)IMEDIA_COMMAND_INV_HANDLE);
    }
    STRU_KDNR_CHAN* pstKdnrChanl;
    pstKdnrChanl = (STRU_KDNR_CHAN*)pChanl;
    // 推理reset
    STRU_ENCODER_EAI_CONTEXT* pstEncoderContext;
    pstEncoderContext = &pstKdnrChanl->stEncoderEai;
    AudioCommonVecSetInt8((signed char *)pstEncoderContext->tensors[0][1].address, (size_t)(pstEncoderContext->tensors[0][1].tensor_size), 0);
    AudioCommonVecSetInt8((signed char*)pstEncoderContext->tensors[0][2].address, (size_t)(pstEncoderContext->tensors[0][2].tensor_size), 0);
    AudioCommonVecSetInt8((signed char*)pstEncoderContext->tensors[1][1].address, (size_t)(pstEncoderContext->tensors[1][1].tensor_size), 0);
    AudioCommonVecSetInt8((signed char*)pstEncoderContext->tensors[1][2].address, (size_t)(pstEncoderContext->tensors[1][2].tensor_size), 0);

    // 解码reset
    AudioCommonVecSetInt8((signed char*)pstKdnrChanl->cur, sizeof(pstKdnrChanl->cur), 0);
    AudioCommonVecSetInt8((signed char*)pstKdnrChanl->prev, sizeof(pstKdnrChanl->prev), 0);
    for (int i = 0; i < IMEDIA_MAX_ACTIVE_PATH; i++) {
        pstKdnrChanl->cur[i].hyp.ysSize = 2;
        pstKdnrChanl->cur[i].hyp.phraseId = -1;
    }
    //pstKdnrChanl->time = 0;
    pstKdnrChanl->hypSize = 0;
    // framer reset
    ret = IMediaEncoderEaiReset(pstKdnrChanl);
    if (ret < 0) {
        return IMEDIA_COMMAND_INV_ENCODER_INIT;
    }

    //结果相关
    pstKdnrChanl->commadInfo->isEnd = 0;
    AudioCommonVecSetInt8((signed char*)pstKdnrChanl->commadInfo->result, sizeof(pstKdnrChanl->commadInfo->result), '\0');
    pstKdnrChanl->commadInfo->activatePhaseId = -1;
    return ((int)IMEDIA_COMMAND_EOK);
}

/******************************************************************************
Function:      IMediaVoiceControlInit
Description:   初始化算法实例，模型参数初始化，cnn1-cnn6+gru+dnn，分别初始化
Input:         pChanl: 算法通道结构体指针
               pkwsDenoiseParam: 参数指针
               cSampleRate:采样率
Output:        pChanl: 对象句柄
Return:        ret: 操作返回码
                    IMEDIA_KDNR_EOK表示成功，其他返回码表示失败
*******************************************************************************/

int IMediaVoiceControlInit(void *pChanl, KwsDenoiseStruct *pkwsDenoiseParam, ImediaCommandBuf* commandBuf, ImediaCommandInfo* commandInfo, unsigned char *eaiPacket, int eaiPacketSize)
{
    int ret = 0;
    STRU_KDNR_CHAN *pstKdnrChanl;
    if (NULL == pChanl || NULL == pkwsDenoiseParam || NULL == eaiPacket) {
        return ((int)IMEDIA_COMMAND_INV_HANDLE);
    }

    if (!IsAligned256Byte(eaiPacket)) {
        return IMEDIA_COMMAND_INV_EAI_PACKET;
    }

    eaiHeader* pEaiheader = (eaiHeader *)eaiPacket;

    if (pEaiheader->startMask != EAI_PACKET_START_MASK || eaiPacketSize != pEaiheader->totalSize) {
        return IMEDIA_COMMAND_INV_EAI_PACKET;
    }
    int endMask = *((int*)(eaiPacket + eaiPacketSize - sizeof(int)));
    if (endMask != EAI_PACKET_END_MASK) {
        return IMEDIA_COMMAND_INV_EAI_PACKET;
    }

    pstKdnrChanl = (STRU_KDNR_CHAN *)pChanl;
    AudioCommonVecSetInt8((signed char *)pChanl, sizeof(STRU_KDNR_CHAN), 0);
    AudioCommonVecSetInt8((signed char*)commandInfo, sizeof(ImediaCommandInfo), 0);

    pstKdnrChanl->eaiPacket = (char*) eaiPacket;
    pstKdnrChanl->pKwsDenoiseParam = pkwsDenoiseParam;
    pstKdnrChanl->commadInfo = commandInfo;

    pstKdnrChanl->frameLap = IMEDIA_FRAME_LAP_16K;
    pstKdnrChanl->dctOrder = IMEDIA_FFT_LEN_16K;
    pstKdnrChanl->frameLen = IMEDIA_FRAME_LEN_16K_25MS;
    pstKdnrChanl->addWin = pkwsDenoiseParam->pCommonTableSt.g_G_KWSNNSE_COMMON_ADDWINTAB25MS_16K;
    pstKdnrChanl->delWin = pkwsDenoiseParam->pCommonTableSt.g_G_KWSNNSE_COMMON_DELWINTAB30MS_16K;
    pstKdnrChanl->fftTab = (short*)pkwsDenoiseParam->pCommonFftTableSt.g_G_NNSE_sFFT512Coef;

    pstKdnrChanl->readCacheBegin = -120;

    pstKdnrChanl->modelParam = pEaiheader->param; //
    // mel初始化
    for (int i = 0; i < IMEDIA_FBANK_FEATURE_LEN; ++i) {
        pstKdnrChanl->filterPointers[i] = pstKdnrChanl->filterWeights[i];
    }
    AudioCommonCreateMelFilters(IMEDIA_FBANK_FEATURE_LEN, IMEDIA_FFT_LEN_16K, IMEDIA_16K_SAMPLE_RATE, pstKdnrChanl->filterPointers);

    ret = IMediaEncoderEaiInit(pstKdnrChanl, eaiPacket, &pEaiheader->encoder);
    if (ret < 0) {
        return IMEDIA_COMMAND_INV_ENCODER_INIT;
    }
    ret = IMediaDecoderEaiInit(pstKdnrChanl, eaiPacket, &pEaiheader->decoder);
    if (ret < 0) {
        return IMEDIA_COMMAND_INV_DECODER_INIT;
    }
    ret = IMediaJoinerEaiInit(pstKdnrChanl, eaiPacket, &pEaiheader->joiner);
    if (ret < 0) {
        return IMEDIA_COMMAND_INV_JOINER_INIT;
    }

    // 解码初始化
    for (int i = 0; i < IMEDIA_MAX_ACTIVE_PATH; i++) {
        pstKdnrChanl->cur[i].hyp.ysSize = 2;
        pstKdnrChanl->cur[i].hyp.phraseId = -1;
    }
    commandBuf->tokenBuf = (char*)eaiPacket + pEaiheader->tokensAddr;
    ImediaSymbolTableInit((char*)commandBuf->tokenBuf, pstKdnrChanl);

    IMediaVadEaiInit(pstKdnrChanl, eaiPacket, &pEaiheader->vad);

    // 结果初始化
    pstKdnrChanl->endEncoderExec = 1;
    pstKdnrChanl->commadInfo->activatePhaseId = -1;

    return ((int)IMEDIA_COMMAND_EOK);
}
/******************************************************************************
Function:      IMediaVoiceControlGetPara
Description:   获取配置参数
Input:         pChnVar: 算法通道结构体指针
Output:        pParam:  参数指针
Return:        ret: 操作返回码
               IMEDIA_KDNR_EOK表示成功，其他返回码表示失败
*******************************************************************************/
int IMediaVoiceControlGetPara(void *pChanl, void *pParam)
{
    return ((int)IMEDIA_COMMAND_EOK);
}
/******************************************************************************
Function:      IMediaVoiceControlSetPara
Description:   配置算法参数
Input:         pChnVar: 算法通道结构体指针
Output:        pParam:  参数指针
Return:        ret: 操作返回码
               IMEDIA_KDNR_EOK表示成功，其他返回码表示失败
*******************************************************************************/

char* ImediaStrtok(char* str, char* delimiters) {
    static char* last;
    if (str == NULL) {
        str = last;
    }
    if (str == NULL) {
        return NULL;
    }

    // 跳过前导分隔符
    str += strspn(str, delimiters);
    if (*str == '\0') {
        return NULL;
    }

    // 查找下一个分隔符
    char* token_end = strpbrk(str, delimiters);
    if (token_end != NULL) {
        *token_end = '\0';
        last = token_end + 1;
    }
    else {
        last = NULL;
    }

    return str;
}

int IMediaVoiceControlSetPara(void *pChanl, void *pParam, char *context_file)
{
    STRU_KDNR_CHAN* pstKdnrChanl;
    pstKdnrChanl = (STRU_KDNR_CHAN*)pChanl;
    if (context_file == NULL) {
        // printf("Failed get context_file");
        return -1;
    }
    eaiHeader* pEaiheader = (eaiHeader*)pstKdnrChanl->eaiPacket;
    char* baseAddr = pstKdnrChanl->eaiPacket;
    char* pScratchBuf = baseAddr + pEaiheader->publicContextScratchAddr;

    ContextGraph *contextGraph = &pstKdnrChanl->contextGraph;
    contextGraph->nodePool = (ContextState*)pScratchBuf;
    printf("wzc %p\n", pScratchBuf);
    pScratchBuf = pScratchBuf + MAX_NODES * sizeof(ContextState);
    printf("wzc %p\n", pScratchBuf);
    IMediaInitContextGraph(contextGraph, CONTEXT_SCORE, 1.0);
    // return -1;

    int tokenIds[MAX_PHRASES][MAX_PHRASE_LEN] = { 0 };
    int phrasesIndex = 0;
    int tokenIndex = 0;
    short phrases[MAX_PHRASES] = { 0 };
    float* scores = NULL;
    float* acThresholds = NULL;
    char* line = ImediaStrtok(context_file, "\n");
    printf("wzc context_file=%p, line=%p\n", context_file, line);
    
    // return -1;
    while(line != NULL) {
        tokenIndex = 0;
        line[strcspn(line, "\n")] = '\0'; // 去除换行符
        // 使用 strtok 根据空格切分字符串
        char* token = strtok(line, " ");
        if (token != NULL) {
            phrases[phrasesIndex] = atoi(token);
            token = strtok(NULL, " ");
        }
        while (token != NULL) {
            for (int j = 0; j < pstKdnrChanl->modelParam.vocabSize; j++) {
                if (strcmp(pstKdnrChanl->sym2id[j].key, token) == 0) {
                    tokenIds[phrasesIndex][tokenIndex] = pstKdnrChanl->sym2id[j].val;
                    break;
                }
            }
            tokenIndex++;
            if (tokenIndex > MAX_PHRASE_LEN) {
                return -1;
            }
            token = strtok(NULL, " ");
        }
        phrasesIndex++;
        if(phrasesIndex > MAX_PHRASES) {
            return -1;
        }
        line = ImediaStrtok(NULL, "\n");
    }
    printf("wzc context_file=%p, line=%p\n", context_file, line);

    int res = IMediaBuildContextGraph(contextGraph, tokenIds, phrasesIndex, phrases, scores, acThresholds);
    if (res != 0) {
        return -1;
    }
    return ((int)IMEDIA_COMMAND_EOK);
}
/******************************************************************************
Function:      IMediaCommandApply
Description:   KDNR算法处理
Input:         pChanl: 算法通道结构体指针
               cSampleRate:通道数
               x:输入数据
               y:处理输出数据
               pscratchBuf: 缓存区
Output:        pChanl: 对象句柄
Return:        ret: 操作返回码
               IMEDIA_KDNR_EOK表示成功，其他返回码表示失败
*******************************************************************************/
int IMediaVoiceControlDecode(void* pChanl)
{
    STRU_KDNR_CHAN *pstKdnrChanl = NULL;
    if (NULL == pChanl) {
        return ((int)IMEDIA_COMMAND_INV_HANDLE);
    }

    pstKdnrChanl = (STRU_KDNR_CHAN *)pChanl;
    eaiHeader* pEaiheader = (eaiHeader*)pstKdnrChanl->eaiPacket;
    char* baseAddr = pstKdnrChanl->eaiPacket;
    char* pScratchBuf = baseAddr + pEaiheader->publicDecoderScratchAddr;
    // NN 推理函数
    if (pstKdnrChanl->commadInfo->isNeedDecode == 1) {
        pstKdnrChanl->commadInfo->isNeedDecode = 0;
    }

    char *in;
    char **out;
    IMediaVadEaiExec(pstKdnrChanl,in,out);

    ImediaCommandEaiForward(pstKdnrChanl, (int*)pScratchBuf);
    return IMEDIA_COMMAND_EOK;

}
// 释放模型
int IMediaVoiceControlDeinit(void *pChanl)
{
    if (NULL == pChanl) {
        return ((int)IMEDIA_COMMAND_INV_HANDLE);
    }
    IMediaEncoderEaiDeInit((STRU_KDNR_CHAN*)pChanl);
    IMediaDecoderEaiDeInit((STRU_KDNR_CHAN*)pChanl);
    IMediaJoinerEaiDeInit((STRU_KDNR_CHAN*)pChanl);
    return ((int)IMEDIA_COMMAND_EOK);
}
