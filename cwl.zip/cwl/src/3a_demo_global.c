#include "stdio.h"
#include <string.h>
//#include "imedia_common_define.h"
#include "wav.h"
//#include <imedia_command_api.h>

#include "imedia_kwsnnse_data.h"
#include "imedia_kwsnnse_struct.h"
#include "imedia_command_api.h"
#include "imedia_command_define.h"

#include "imedia_word_spotter.h"
#include "imedia_context_graph.h"
#ifndef WIN32
#pragma clang diagnostic ignored "-Winvalid-source-encoding"
#endif

#ifdef TEST_MAX_MCPS
#include "hexagon_sim_timer.h"
unsigned long long start_time = 0, total_cycles = 0, max_mcps = 0, cycles = 0;
#endif

STR_WAV_HEADER nnWaveHead = WAV_HEADER_8K_1CHAN;
char cmdStringNN[1024];

void calc_scratchbuf_uesd(void* pScratchBuf, int size)
{
    unsigned char* scratchbuf = (unsigned char*)pScratchBuf;
    int i;

    for (i = size - 1; i >= 0; i--) {
        if (scratchbuf[i] != 0x5a) {
            break;
        }
    }
    printf("scratchbuf use %d, total %d\n", i + 1, size);
}


int TestCommand(const char *testfilePath, const char *waveFolderPath, const char* context_file, const char *eaifilePath, KwsDenoiseStruct *pkwsDenoiseParam)
{
    int cmdNum, frmCnt = 0;
    char testFileName[256], testFilePath[256];
    FILE *inFile;
    FILE *fpTestList = fopen(testfilePath, "r");
    void* handle = (void*)malloc(285128 * 10);
    int commandCount = 0;
	short datain[160] = { 0 };

    if (NULL == fpTestList) {
        printf("Open test list file %s Error\n", testfilePath);
        return -2;
    }

#if 1
    ImediaCommandInfo g_resultInfo;
    ImediaCommandBuf commandBuf;

    size_t model_size = 0;
    // read token
    FILE* fp1 = fopen(context_file, "rb");
    if (fp1 == NULL) {
        printf("Cannot open file: %s\n", context_file);
        fclose(fp1);
        return 0;
    }
    model_size = 0;
    fseek(fp1, 0, SEEK_END);
    model_size = ftell(fp1);
    fseek(fp1, 0, SEEK_SET);
    char* datBuf4 = NULL;
    datBuf4 = (char*)malloc(model_size + 256);
    uintptr_t address4 = (uintptr_t)datBuf4;
    Q_ALIGN_ADDR(address4, 256); // 256 align
    char* newAddr4 = (char*)address4;
    fread(newAddr4, sizeof(char), model_size, fp1);
    fclose(fp1);
    newAddr4[model_size] = '\0';
    printf("wzc cmdlist model_size=%d\n", model_size);


    // read decoder model and allocate memory
    FILE* fp = fopen(eaifilePath, "rb");
    if (fp == NULL) {
        printf("Cannot open file: %s\n", eaifilePath);
        fclose(fp);
        return 0;
    }
    model_size = 0;
    fseek(fp, 0, SEEK_END);
    model_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char *datBuf00 = (char*)malloc(model_size + 256);
    uintptr_t address00 = (uintptr_t)datBuf00;
    Q_ALIGN_ADDR(address00, 256); // 256 align
    unsigned char* eaiPacket = (unsigned char*)address00;
    fread(eaiPacket, sizeof(char), model_size, fp);
    fclose(fp);

    int ret = IMediaVoiceControlInit(handle, pkwsDenoiseParam, &commandBuf, &g_resultInfo, eaiPacket, model_size);
    printf("ret=%d, model_size=%d\n",ret,model_size);
    IMediaVoiceControlSetPara(handle, pkwsDenoiseParam, newAddr4);
#endif
    while (!feof(fpTestList)) {
        if (NULL == fgets(cmdStringNN, sizeof(cmdStringNN) - 1, fpTestList)) {
            break;
        }
        cmdNum = sscanf(cmdStringNN, "%s", testFileName);
        if (1 != cmdNum) {
            printf("testlist file para error!\n");
            continue;
        }
        printf("%s\n", testFileName);
        FILE* fp_res = fopen("./result_061916_debug.txt", "a"); // 结果保存
        fprintf(fp_res, "%s ", testFileName);
        strcpy(testFilePath, waveFolderPath);
        strcat(testFilePath, testFileName);
        
        inFile = fopen(testFilePath, "rb");
        if (NULL == inFile) {
            printf("Open Test file %s error...\n", testFilePath);
            return -1;
        }
        printf("Open file %s \n", testFilePath);

        frmCnt = 0;
        int version;
        version = IMediaVoiceControlGetVersion();
        printf("version:%d\n", version);
        while (1) {
            if (fread(datain, sizeof(short), 160, inFile) < 160) {
                break;
            }
            frmCnt += 1;
            //printf("%d %d %d %d %d %d %d %d %d %d\n", datain[0], datain[1], datain[2], datain[3], datain[4], datain[75], datain[76], datain[77], datain[78], datain[79]);
#ifdef TEST_MAX_MCPS
            start_time = hexagon_sim_read_pcycles();
#endif
            IMediaVoiceControlProcess(handle, datain);
            if (g_resultInfo.isNeedDecode) {
                IMediaVoiceControlDecode(handle);
            }
#ifdef TEST_MAX_MCPS
            cycles = hexagon_sim_read_pcycles() - start_time;
            total_cycles = total_cycles + cycles;
            if (cycles > max_mcps) {
                max_mcps = cycles;
            }
            printf(" max_mcps:%llu avg_mcps:%llu mcps:%llu\n", max_mcps / 10000, total_cycles / 10000 / frmCnt, cycles / 10000);
#endif
#ifdef ADD_END
            // 到达结尾，清空历史信息
            if (g_resultInfo.isEnd) {
                // 获取上报结果
                if (g_resultInfo.activatePhaseId != -1) {
                    commandCount++;
                }
                fprintf(fp_res, "%s %d\t", g_resultInfo.result, g_resultInfo.activatePhaseId);
                printf("%s %d\t", g_resultInfo.result, g_resultInfo.activatePhaseId);
                IMediaVoiceControlReset(handle);
            }
#endif
        }
		printf("frameCnt:%d\r\n", frmCnt);  //515

        // 如果有ADD_END，每句也最终识别下结果
        STRU_KDNR_CHAN* pstKdnrChanl = NULL;
        pstKdnrChanl = (STRU_KDNR_CHAN*)handle;
        IMediaGetResult(pstKdnrChanl);
        // 获取上报结果
        if (g_resultInfo.activatePhaseId != -1) {
            commandCount++;
        }
        fprintf(fp_res, "%s %d\t", g_resultInfo.result, g_resultInfo.activatePhaseId);
        printf("%s %d\t", g_resultInfo.result, g_resultInfo.activatePhaseId);
        //清空历史信息
        IMediaVoiceControlReset(handle);

        fprintf(fp_res, "\n");
        fclose(inFile);
        printf("commandCount:%d\t", commandCount);
        fclose(fp_res);
    }
    IMediaVoiceControlDeinit(handle);
    free(datBuf00);
    free(datBuf4);
    return 0;
}

int main(void)
{
    KwsDenoiseStruct pkwsDenoiseParam = {
#ifdef NN_DENOISE_USE_Q
        {
        .g_G_NNSE_COMMON_TWIDDLESPLIT = (void *)G_NNSE_COMMON_TWIDDLESPLIT,
        .g_G_NNSE_COMMON_FFT_TWD_R8 = (void *)G_NNSE_COMMON_FFT_TWD_R8,
        .g_G_NNSE_COMMON_IFFT_TWD_R8 = (void *)G_NNSE_COMMON_IFFT_TWD_R8,
        .g_G_NNSE_COMMON_RFFT16_128 = (void *)&G_NNSE_COMMON_RFFT16_128,
        .g_G_NNSE_COMMON_RFFT16_256 = (void *)&G_NNSE_COMMON_RFFT16_256,
        .g_G_NNSE_COMMON_RFFT16_512 = (void *)&G_NNSE_COMMON_RFFT16_512,
        .g_G_NNSE_COMMON_RFFT16_1024 = (void *)&G_NNSE_COMMON_RFFT16_1024,
        .g_G_NNSE_COMMON_RIFFT16_128 = (void *)&G_NNSE_COMMON_RIFFT16_128,
        .g_G_NNSE_COMMON_RIFFT16_256 = (void *)&G_NNSE_COMMON_RIFFT16_256,
        .g_G_NNSE_COMMON_RIFFT16_512 = (void *)&G_NNSE_COMMON_RIFFT16_512,
        .g_G_NNSE_COMMON_RIFFT16_1024 = (void *)&G_NNSE_COMMON_RIFFT16_1024,
        .g_G_NNSE_sFFT512Coef = NULL,
        },
#else
        {
        .g_G_NNSE_COMMON_FFT_TWD_R8 = NULL,
        .g_G_NNSE_COMMON_IFFT_TWD_R8 = NULL,
        .g_G_NNSE_COMMON_RFFT16_128 = NULL,
        .g_G_NNSE_COMMON_RFFT16_256 = NULL,
        .g_G_NNSE_COMMON_RFFT16_512 = NULL,
        .g_G_NNSE_COMMON_RFFT16_1024 = NULL,
        .g_G_NNSE_COMMON_RIFFT16_128 = NULL,
        .g_G_NNSE_COMMON_RIFFT16_256 = NULL,
        .g_G_NNSE_COMMON_RIFFT16_512 = NULL,
        .g_G_NNSE_COMMON_RIFFT16_1024 = NULL,
        .g_G_NNSE_sFFT512Coef = (iMedia_STRU_FFTDescr *)g_sFFT512CoefCommand,
        },
#endif
        {
        .g_G_KWSNNSE_COMMON_LOG2TAB = (void *)G_KWSNNSE_COMMON_LOG2TAB,
        .g_G_KWSNNSE_COMMON_TAB_INVQ30 = (void *)G_KWSNNSE_COMMON_TAB_INVQ30,
		.g_G_KWSNNSE_COMMON_ADDWINTAB25MS_16K = (void *)G_KWSNNSE_COMMON_ADDWINTAB25MS_16K,
        .g_G_KWSNNSE_COMMON_DELWINTAB30MS_16K = (void *)G_KWSNNSE_COMMON_DELWINTAB30MS_16K,

        },
        {
        .g_imedia_kdnr_dct_16k = (void *)IMEDIA_KDNR_DCT_16K_TAB,

		},
	};
	TestCommand("/data/c00032263/w00012255/prj/data/wavs.txt",
		        "/data/c00032263/w00012255/prj/data/wavs/",
                "/data/c00032263/w00012255/prj/cwl/cmd_pinyin_all.txt",
				"/data/c00032263/w00012255/prj/cwl/out_honor2_add_token_list.eai",
                &pkwsDenoiseParam);
    //TestCommand("/local/mnt/workspace/Qualcomm/Hexagon_SDK/6.2.0.1/addons/LPAI/eNPU6/5.7.1/data/test_nn_debug.txt",
    //    "/data3/workspace/g00014599/4th-model_packing/asr-osr-notebook-zipformer-enpu_v6_rel_1.0-patch/mozilla_16k/zh-CN/",
    //    "/local/mnt/workspace/Qualcomm/Hexagon_SDK/6.2.0.1/addons/LPAI/eNPU6/5.7.1/asr_eai8/pinyin_contexts.txt",
    //    "/local/mnt/workspace/Qualcomm/Hexagon_SDK/6.2.0.1/addons/LPAI/eNPU6/5.7.1/asr_eai8/out_add_token_list.eai",
    //    &pkwsDenoiseParam);
    //TestCommand("/local/mnt/workspace/Qualcomm/Hexagon_SDK/6.2.0.1/addons/LPAI/eNPU6/5.7.1/asr_eai8/test_cmd.txt",
    //"/local/mnt/workspace/Qualcomm/Hexagon_SDK/6.2.0.1/addons/LPAI/eNPU6/5.7.1/asr_eai8/",
    //"/local/mnt/workspace/Qualcomm/Hexagon_SDK/6.2.0.1/addons/LPAI/eNPU6/5.7.1/asr_eai8/cmd1_pinyin.txt",
    //"/local/mnt/workspace/Qualcomm/Hexagon_SDK/6.2.0.1/addons/LPAI/eNPU6/5.7.1/asr_eai8/out_add_token_list.eai",
    //&pkwsDenoiseParam);
	return 0;
}
