/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 * Description: imedia_common_ns_functon.c
 *****************************************************************************/
#include "imedia_kwsnnse_typedef.h"
#include "imedia_command_define.h"
#include "imedia_common_basicop.h"
#include "imedia_common_define.h"
#include "imedia_kwsnnse_struct.h"


#ifndef Q_CODE_NNSE_FFT
// C platform
static int aiFftInTempBuff[2 * 1026], aiFftOutTempBuff[2 * 1026] = { 0 };
// norm(x*y) Q15 0x4000 = 16384
#define MPY16X32R(x, y) \
    (((int)((short)(x) * (unsigned short)(y) + 0x4000) >> 15) + \
    ((int)((short)(x) * (short)((y) >> 16)) << 1))

// diagonal matrix for computing in FFT
#define DIG_REV(i, m, j) \
    do {                                                                \
    unsigned _ = (i);                                                   \
    _ = ((_ & 0x33333333) <<  2) | ((_ & ~0x33333333) >>  2);           \
    _ = ((_ & 0x0F0F0F0F) <<  4) | ((_ & ~0x0F0F0F0F) >>  4);           \
    _ = ((_ & 0x00FF00FF) <<  8) | ((_ & ~0x00FF00FF) >>  8);           \
    _ = ((_ & 0x0000FFFF) << 16) | ((_ & ~0x0000FFFF) >> 16);           \
    (j) = _ >> (m);                                                     \
    } while (0)

void Audiofft16x32(const short * ptrW, int npoints, int * ptrX, int * ptrY)
{
    int i = 0, j = 0, l1 = 0, l2 = 0, h2 = 0, predj = 0, twOffset = 0, stride = 0, fftJmp = 0;
    int xt0_0 = 0, yt0_0 = 0, xt1_0 = 0, yt1_0 = 0, xt2_0 = 0, yt2_0 = 0;
    int xt0_1 = 0, yt0_1 = 0, xt1_1 = 0, yt1_1 = 0, xt2_1 = 0, yt2_1 = 0;
    int xh0_0 = 0, xh1_0 = 0, xh20_0 = 0, xh21_0 = 0, xl0_0 = 0, xl1_0 = 0, xl20_0 = 0, xl21_0 = 0;
    int xh0_1 = 0, xh1_1 = 0, xh20_1 = 0, xh21_1 = 0, xl0_1 = 0, xl1_1 = 0, xl20_1 = 0, xl21_1 = 0;
    int x_0 = 0, x_1 = 0, x_2 = 0, x_3 = 0, x_l1_0 = 0, x_l1_1 = 0, x_l1_2 = 0, x_l1_3 = 0, x_l2_0 = 0, x_l2_1 = 0;
    int xh0_2 = 0, xh1_2 = 0, xl0_2 = 0, xl1_2 = 0, xh0_3 = 0, xh1_3 = 0, xl0_3 = 0, xl1_3 = 0;
    int x_4 = 0, x_5 = 0, x_6 = 0, x_7 = 0, x_l2_2 = 0, x_l2_3 = 0, x_h2_0 = 0, x_h2_1 = 0, x_h2_2 = 0, x_h2_3 = 0;
    int x_8 = 0, x_9 = 0, x_a = 0, x_b = 0, x_c = 0, x_d = 0, x_e = 0, x_f = 0;

    short si10 = 0, si20 = 0, si30 = 0, co10 = 0, co20 = 0, co30 = 0;
    short si11 = 0, si21 = 0, si31 = 0, co11 = 0, co21 = 0, co31 = 0;

    const short *w = NULL;
    int *x = NULL, *x2 = NULL, *x0 = NULL;
    int *y0 = NULL, *y1 = NULL, *y2 = NULL, *y3 = NULL;
    int n00 = 0, n10 = 0, n20 = 0, n30 = 0, n01 = 0, n11 = 0, n21 = 0, n31 = 0;
    int n02 = 0, n12 = 0, n22 = 0, n32 = 0, n03 = 0, n13 = 0, n23 = 0, n33 = 0;
    int n0 = 0, j0;
    int radix = 0, m = 0;
    int y0r = 0, y0i = 0, y4r = 0, y4i = 0;
    int norm = 0;

    // split into 4 pieces to compute fft param
    for (i = 31, m = 1; (npoints & (1 << i)) == 0; i--, m++) {}
    radix = (m & 1) ? 2 : 4; // 2 4
    norm = m - 2; // 2

    stride = npoints;
    twOffset = 0;
    fftJmp = 6 * stride; // 6
    // ood 1 3 5 7 9 11  and  even 0 2 4 6 8 10 compute, respectively
    // into 3 stages
    while (stride > 4) {
        j = 0;
        fftJmp >>= 2; // 2
        h2 = stride >> 1;
        l1 = stride;
        l2 = stride + (stride >> 1);

        x = ptrX;
        w = ptrW + twOffset;
        twOffset += fftJmp;

        stride >>= 2; // 2

        for (i = 0; i <(npoints >> 3); i++) {
            co10 = w[j + 1];    si10 = w[j + 0]; // 0 1
            co20 = w[j + 3];    si20 = w[j + 2]; // 2 3
            co30 = w[j + 5];    si30 = w[j + 4]; // 4 5

            co11 = w[j + 7];    si11 = w[j + 6]; // 6 7
            co21 = w[j + 9];    si21 = w[j + 8]; // 8 9
            co31 = w[j + 11];   si31 = w[j + 10]; // 10 11
            x_0 = x[0];       x_1 = x[1];  // 0 1
            x_2 = x[2];       x_3 = x[3]; // 2 3

            x_l1_0 = x[l1]; x_l1_1 = x[l1 + 1];
            x_l1_2 = x[l1 + 2]; x_l1_3 = x[l1 + 3]; // 2 3

            x_l2_0 = x[l2]; x_l2_1 = x[l2 + 1];
            x_l2_2 = x[l2 + 2]; x_l2_3 = x[l2 + 3]; // 2 3

            x_h2_0 = x[h2]; x_h2_1 = x[h2 + 1];
            x_h2_2 = x[h2 + 2]; x_h2_3 = x[h2 + 3]; // 2  3

            xh0_0 = x_0 + x_l1_0;        xh1_0 = x_1 + x_l1_1;
            xh0_1 = x_2 + x_l1_2;        xh1_1 = x_3 + x_l1_3;

            xl0_0 = x_0 - x_l1_0;        xl1_0 = x_1 - x_l1_1;
            xl0_1 = x_2 - x_l1_2;        xl1_1 = x_3 - x_l1_3;

            xh20_0 = x_h2_0 + x_l2_0;        xh21_0 = x_h2_1 + x_l2_1;
            xh20_1 = x_h2_2 + x_l2_2;        xh21_1 = x_h2_3 + x_l2_3;

            xl20_0 = x_h2_0 - x_l2_0;        xl21_0 = x_h2_1 - x_l2_1;
            xl20_1 = x_h2_2 - x_l2_2;        xl21_1 = x_h2_3 - x_l2_3;
            x0 = x;
            x2 = x0;
            x += 4;  // step 4
            j += 12; // step 12

            predj = (j - fftJmp);
            if (!predj) {
                x += fftJmp;
            }
            if (!predj) {
                j = 0;
            }

            y0r = xh0_0 + xh20_0;  y0i = xh1_0 + xh21_0;
            xt0_0 = xh0_0 - xh20_0;  yt0_0 = xh1_0 - xh21_0;

            y4r = xh0_1 + xh20_1;  y4i = xh1_1 + xh21_1;
            xt0_1 = xh0_1 - xh20_1;  yt0_1 = xh1_1 - xh21_1;

            xt1_0 = xl0_0 + xl21_0;  yt2_0 = xl1_0 + xl20_0;
            xt1_1 = xl0_1 + xl21_1;  yt2_1 = xl1_1 + xl20_1;

            xt2_0 = xl0_0 - xl21_0;  yt1_0 = xl1_0 - xl20_0;
            xt2_1 = xl0_1 - xl21_1;  yt1_1 = xl1_1 - xl20_1;

            x2[0] = y0r;             x2[1] = y0i; // 0 1
            x2[2] = y4r;             x2[3] = y4i; // 2 3

            x2[h2] = MPY16X32R(si10, yt1_0) + MPY16X32R(co10, xt1_0);
            x2[h2 + 2] = MPY16X32R(si11, yt1_1) + MPY16X32R(co11, xt1_1); // 2

            x2[h2 + 1] = MPY16X32R(co10, yt1_0) - MPY16X32R(si10, xt1_0); // 1
            x2[h2 + 3] = MPY16X32R(co11, yt1_1) - MPY16X32R(si11, xt1_1); // 3

            x2[l1] = MPY16X32R(si20, yt0_0) + MPY16X32R(co20, xt0_0);
            x2[l1 + 1] = MPY16X32R(co20, yt0_0) - MPY16X32R(si20, xt0_0);

            x2[l1 + 2] = MPY16X32R(si21, yt0_1) + MPY16X32R(co21, xt0_1); // 2
            x2[l1 + 3] = MPY16X32R(co21, yt0_1) - MPY16X32R(si21, xt0_1); // 3

            x2[l2] = MPY16X32R(si30, yt2_0) + MPY16X32R(co30, xt2_0);
            x2[l2 + 1] = MPY16X32R(co30, yt2_0) - MPY16X32R(si30, xt2_0);

            x2[l2 + 2] = MPY16X32R(si31, yt2_1) + MPY16X32R(co31, xt2_1); // 2
            x2[l2 + 3] = MPY16X32R(co31, yt2_1) - MPY16X32R(si31, xt2_1); // 3
        }
    }

    y0 = ptrY;
    y2 = ptrY + (int)npoints;
    x0 = ptrX;
    x2 = ptrX + (int)(npoints >> 1);

    if (radix == 2) {
        y1 = y0 + (int)(npoints >> 2); // 2
        y3 = y2 + (int)(npoints >> 2); // 2
        l1 = norm + 1;
        j0 = 8; // 8
        n0 = npoints >> 1;
    } else {
        y1 = y0 + (int)(npoints >> 1);
        y3 = y2 + (int)(npoints >> 1);
        l1 = norm + 2; // 2
        j0 = 4; // 4
        n0 = npoints >> 2; // 2
    }
    j = 0;

    for (i = 0; i < npoints; i += 8) {
        DIG_REV(j, l1, h2);
        x_0 = x0[0]; x_1 = x0[1];  // 0 1
        x_2 = x0[2]; x_3 = x0[3];  // 2 3
        x_4 = x0[4]; x_5 = x0[5];   // 4 5
        x_6 = x0[6]; x_7 = x0[7];  // 6 7
        x0 += 8;  // 8

        if (radix == 2) {
            n00 = x_0 + x_2;     n01 = x_1 + x_3;
            n10 = x_4 + x_6;     n11 = x_5 + x_7;

            n20 = x_0 - x_2;     n21 = x_1 - x_3;
            n30 = x_4 - x_6;     n31 = x_5 - x_7;
        } else {
            xh0_0 = x_0 + x_4; xh1_0 = x_1 + x_5;
            xh0_1 = x_2 + x_6; xh1_1 = x_3 + x_7;

            xl0_0 = x_0 - x_4; xl1_0 = x_1 - x_5;
            xl0_1 = x_2 - x_6; xl1_1 = x_3 - x_7;

            n00 = xh0_0 + xh0_1; n01 = xh1_0 + xh1_1;
            n10 = xl0_0 + xl1_1; n11 = xl1_0 - xl0_1;

            n20 = xh0_0 - xh0_1; n21 = xh1_0 - xh1_1;
            n30 = xl0_0 - xl1_1; n31 = xl1_0 + xl0_1;
        }
        /* 2 is split ood and even  */
        y0[2 * h2] = n00;   y0[2 * h2 + 1] = n01;
        y1[2 * h2] = n10;   y1[2 * h2 + 1] = n11;
        y2[2 * h2] = n20;   y2[2 * h2 + 1] = n21;
        y3[2 * h2] = n30;   y3[2 * h2 + 1] = n31;
        /* 0 2 4 6 is even and 1 3 5 7 even  */
        x_8 = x2[0]; x_9 = x2[1];
        x_a = x2[2]; x_b = x2[3];
        x_c = x2[4]; x_d = x2[5];
        x_e = x2[6]; x_f = x2[7];
        x2 += 8; // 8 step

        if (radix == 2) {
            n02 = x_8 + x_a;     n03 = x_9 + x_b;
            n22 = x_8 - x_a;     n23 = x_9 - x_b;
            n12 = x_c + x_e;     n13 = x_d + x_f;
            n32 = x_c - x_e;     n33 = x_d - x_f;
        } else {
            xh0_2 = x_8 + x_c; xh1_2 = x_9 + x_d;
            xl0_2 = x_8 - x_c; xl1_2 = x_9 - x_d;
            xh0_3 = x_a + x_e; xh1_3 = x_b + x_f;
            xl0_3 = x_a - x_e; xl1_3 = x_b - x_f;

            n02 = xh0_2 + xh0_3; n03 = xh1_2 + xh1_3;
            n12 = xl0_2 + xl1_3; n13 = xl1_2 - xl0_3;
            n22 = xh0_2 - xh0_3; n23 = xh1_2 - xh1_3;
            n32 = xl0_2 - xl1_3; n33 = xl1_2 + xl0_3;
        }
        /*  2  3 */
        y0[2 * h2 + 2] = n02;   y0[2 * h2 + 3] = n03;
        y1[2 * h2 + 2] = n12;   y1[2 * h2 + 3] = n13;
        y2[2 * h2 + 2] = n22;   y2[2 * h2 + 3] = n23;
        y3[2 * h2 + 2] = n32;   y3[2 * h2 + 3] = n33;

        j += j0;
        if (j == n0) {
            j += n0;
            x0 += (int)npoints >> 1;
            x2 += (int)npoints >> 1;
        }
    }
}

void Audioifft16x32(const short * ptrW, int npoints, int * ptrX, int * ptrY)
{
    int i = 0, j = 0, l1 = 0, l2 = 0, h2 = 0, predj = 0, twOffset = 0, stride = 0, fftJmp = 0;
    int xt0_0 = 0, yt0_0 = 0, xt1_0 = 0, yt1_0 = 0, xt2_0 = 0, yt2_0 = 0;
    int xt0_1 = 0, yt0_1 = 0, xt1_1 = 0, yt1_1 = 0, xt2_1 = 0, yt2_1 = 0;
    int xh0_0 = 0, xh1_0 = 0, xh20_0 = 0, xh21_0 = 0, xl0_0 = 0, xl1_0 = 0, xl20_0 = 0, xl21_0 = 0;
    int xh0_1 = 0, xh1_1 = 0, xh20_1 = 0, xh21_1 = 0, xl0_1 = 0, xl1_1 = 0, xl20_1 = 0, xl21_1 = 0;
    int x_0 = 0, x_1 = 0, x_2 = 0, x_3 = 0, x_l1_0 = 0, x_l1_1 = 0, x_l1_2 = 0, x_l1_3 = 0, x_l2_0 = 0, x_l2_1 = 0;
    int xh0_2 = 0, xh1_2 = 0, xl0_2 = 0, xl1_2 = 0, xh0_3 = 0, xh1_3 = 0, xl0_3 = 0, xl1_3 = 0;
    int x_4 = 0, x_5 = 0, x_6 = 0, x_7 = 0, x_l2_2 = 0, x_l2_3 = 0, x_h2_0 = 0, x_h2_1 = 0, x_h2_2 = 0, x_h2_3 = 0;
    int x_8 = 0, x_9 = 0, x_a = 0, x_b = 0, x_c = 0, x_d = 0, x_e = 0, x_f = 0;
    short si10 = 0, si20 = 0, si30 = 0, co10 = 0, co20 = 0, co30 = 0;
    short si11 = 0, si21 = 0, si31 = 0, co11 = 0, co21 = 0, co31 = 0;
    const short *w = NULL;
    int *x = NULL, *x2 = NULL, *x0 = NULL;
    int * y0 = NULL, *y1 = NULL, *y2 = NULL, *y3 = NULL;
    int n00 = 0, n10 = 0, n20 = 0, n30 = 0, n01 = 0, n11 = 0, n21 = 0, n31 = 0,
        n02 = 0, n12 = 0, n22 = 0, n32 = 0, n03 = 0, n13 = 0, n23 = 0, n33 = 0;
    int n0 = 0, j0 = 0;
    int radix = 0, m = 0, y0r = 0, y0i = 0, y4r = 0, y4i = 0;
    int norm = 0;
    for (i = 31, m = 1; (npoints & (1 << i)) == 0; i--, m++) {}
    radix = (m & 1) ? 2 : 4;  // 2 4
    norm = m - 2; // 2
    stride = npoints;
    twOffset = 0;
    fftJmp = 6 * stride;  // stride 6
    // ood 1 3 5 7 9 11  and  even 0 2 4 6 8 10 compute, respectively
    // into 3 stages
    while (stride > 4) {
        j = 0;
        fftJmp >>= 2; // right mv 2

        h2 = stride >> 1;
        l1 = stride;
        l2 = stride + (stride >> 1);

        x = ptrX;
        w = ptrW + twOffset;
        twOffset += fftJmp;

        stride >>= 2; // right mv 2

        for (i = 0; i < (npoints >> 3); i++) {
            /* odd is 1 3 5 7 9 11 even is 0 2 4 6 8 10 */
            co10 = w[j + 1];    si10 = w[j + 0];
            co20 = w[j + 3];    si20 = w[j + 2];
            co30 = w[j + 5];    si30 = w[j + 4];
            co11 = w[j + 7];    si11 = w[j + 6];
            co21 = w[j + 9];    si21 = w[j + 8];
            co31 = w[j + 11];   si31 = w[j + 10];
            x_0 = x[0];       x_1 = x[1];
            x_2 = x[2];       x_3 = x[3]; // 2 3

            x_l1_0 = x[l1]; x_l1_1 = x[l1 + 1];
            x_l1_2 = x[l1 + 2]; x_l1_3 = x[l1 + 3]; // 2 3

            x_l2_0 = x[l2]; x_l2_1 = x[l2 + 1];
            x_l2_2 = x[l2 + 2]; x_l2_3 = x[l2 + 3]; // 2 3

            x_h2_0 = x[h2]; x_h2_1 = x[h2 + 1];
            x_h2_2 = x[h2 + 2]; x_h2_3 = x[h2 + 3]; // 2 3

            xh0_0 = x_0 + x_l1_0;        xh1_0 = x_1 + x_l1_1;
            xh0_1 = x_2 + x_l1_2;        xh1_1 = x_3 + x_l1_3;

            xl0_0 = x_0 - x_l1_0;        xl1_0 = x_1 - x_l1_1;
            xl0_1 = x_2 - x_l1_2;        xl1_1 = x_3 - x_l1_3;

            xh20_0 = x_h2_0 + x_l2_0;        xh21_0 = x_h2_1 + x_l2_1;
            xh20_1 = x_h2_2 + x_l2_2;        xh21_1 = x_h2_3 + x_l2_3;

            xl20_0 = x_h2_0 - x_l2_0;        xl21_0 = x_h2_1 - x_l2_1;
            xl20_1 = x_h2_2 - x_l2_2;        xl21_1 = x_h2_3 - x_l2_3;

            x0 = x;
            x2 = x0;

            j += 12; // 12 step
            x += 4;  // 4 step

            predj = (j - fftJmp);
            if (!predj) {
                x += fftJmp;
            }
            if (!predj) {
                j = 0;
            }

            y0r = xh0_0 + xh20_0; y0i = xh1_0 + xh21_0;
            y4r = xh0_1 + xh20_1; y4i = xh1_1 + xh21_1;

            xt0_0 = xh0_0 - xh20_0; yt0_0 = xh1_0 - xh21_0;
            xt0_1 = xh0_1 - xh20_1; yt0_1 = xh1_1 - xh21_1;

            xt2_0 = xl0_0 + xl21_0; yt2_0 = xl1_0 - xl20_0;
            xt1_0 = xl0_0 - xl21_0; yt1_0 = xl1_0 + xl20_0;

            xt2_1 = xl0_1 + xl21_1; yt2_1 = xl1_1 - xl20_1;
            xt1_1 = xl0_1 - xl21_1; yt1_1 = xl1_1 + xl20_1;

            x2[0] = y0r;             x2[1] = y0i;
            x2[2] = y4r;             x2[3] = y4i; // 2  3

            x2[h2] = MPY16X32R(co10, xt1_0) - MPY16X32R(si10, yt1_0);
            x2[h2 + 1] = MPY16X32R(co10, yt1_0) + MPY16X32R(si10, xt1_0);

            x2[h2 + 2] = MPY16X32R(co11, xt1_1) - MPY16X32R(si11, yt1_1); // 2
            x2[h2 + 3] = MPY16X32R(co11, yt1_1) + MPY16X32R(si11, xt1_1); // 3

            x2[l1] = MPY16X32R(co20, xt0_0) - MPY16X32R(si20, yt0_0);
            x2[l1 + 1] = MPY16X32R(co20, yt0_0) + MPY16X32R(si20, xt0_0);

            x2[l1 + 2] = MPY16X32R(co21, xt0_1) - MPY16X32R(si21, yt0_1); // 2
            x2[l1 + 3] = MPY16X32R(co21, yt0_1) + MPY16X32R(si21, xt0_1); // 3

            x2[l2] = MPY16X32R(co30, xt2_0) - MPY16X32R(si30, yt2_0);
            x2[l2 + 1] = MPY16X32R(co30, yt2_0) + MPY16X32R(si30, xt2_0);

            x2[l2 + 2] = MPY16X32R(co31, xt2_1) - MPY16X32R(si31, yt2_1); // 2
            x2[l2 + 3] = MPY16X32R(co31, yt2_1) + MPY16X32R(si31, xt2_1); // 3
        }
    }

    y0 = ptrY;
    y2 = ptrY + (int)npoints;
    x0 = ptrX;
    x2 = ptrX + (int)(npoints >> 1);

    if (radix == 2) {
        y1 = y0 + (int)(npoints >> 2);  // 2
        y3 = y2 + (int)(npoints >> 2);  // 2
        l1 = norm + 1;
        j0 = 8;  // 8
        n0 = npoints >> 1;
    } else {
        y1 = y0 + (int)(npoints >> 1);
        y3 = y2 + (int)(npoints >> 1);
        l1 = norm + 2;  // 2
        j0 = 4;  // 4
        n0 = npoints >> 2;  // 2
    }
    j = 0;

    for (i = 0; i < npoints; i += 8) {
        DIG_REV(j, l1, h2);
        /* ood is 1 3 5 7  even is 2 4 6 8 */
        x_0 = x0[0]; x_1 = x0[1];
        x_2 = x0[2]; x_3 = x0[3];
        x_4 = x0[4]; x_5 = x0[5];
        x_6 = x0[6]; x_7 = x0[7];

        if (radix == 2) {
            n00 = x_0 + x_2;     n01 = x_1 + x_3;
            n10 = x_4 + x_6;     n11 = x_5 + x_7;

            n20 = x_0 - x_2;     n21 = x_1 - x_3;
            n30 = x_4 - x_6;     n31 = x_5 - x_7;
        } else {
            xh0_0 = x_0 + x_4; xh1_0 = x_1 + x_5;
            xh0_1 = x_2 + x_6; xh1_1 = x_3 + x_7;

            xl0_0 = x_0 - x_4; xl1_0 = x_1 - x_5;
            xl0_1 = x_2 - x_6; xl1_1 = x_3 - x_7;

            n00 = xh0_0 + xh0_1; n01 = xh1_0 + xh1_1;
            n30 = xl0_0 + xl1_1; n11 = xl1_0 + xl0_1;

            n20 = xh0_0 - xh0_1; n21 = xh1_0 - xh1_1;
            n10 = xl0_0 - xl1_1; n31 = xl1_0 - xl0_1;
        }
        x0 += 8;

        y0[2 * h2] = n00;   y0[2 * h2 + 1] = n01;
        y1[2 * h2] = n10;   y1[2 * h2 + 1] = n11;
        y2[2 * h2] = n20;   y2[2 * h2 + 1] = n21;
        y3[2 * h2] = n30;   y3[2 * h2 + 1] = n31;

        x_8 = x2[0]; x_9 = x2[1];
        x_a = x2[2]; x_b = x2[3];
        x_c = x2[4]; x_d = x2[5];
        x_e = x2[6]; x_f = x2[7];

        if (radix == 2) {
            n02 = x_8 + x_a;     n03 = x_9 + x_b;
            n12 = x_c + x_e;     n13 = x_d + x_f;

            n22 = x_8 - x_a;     n23 = x_9 - x_b;
            n32 = x_c - x_e;     n33 = x_d - x_f;
        } else {
            xh0_2 = x_8 + x_c; xh1_2 = x_9 + x_d;
            xh0_3 = x_a + x_e; xh1_3 = x_b + x_f;

            xl0_2 = x_8 - x_c; xl1_2 = x_9 - x_d;
            xl0_3 = x_a - x_e; xl1_3 = x_b - x_f;

            n02 = xh0_2 + xh0_3; n03 = xh1_2 + xh1_3;
            n32 = xl0_2 + xl1_3; n13 = xl1_2 + xl0_3;

            n22 = xh0_2 - xh0_3; n23 = xh1_2 - xh1_3;
            n12 = xl0_2 - xl1_3; n33 = xl1_2 - xl0_3;
        }
        x2 += 8; // step 8
        y0[2 * h2 + 2] = n02;   y0[2 * h2 + 3] = n03;  // 2 3
        y1[2 * h2 + 2] = n12;   y1[2 * h2 + 3] = n13;  // 2  3
        y2[2 * h2 + 2] = n22;   y2[2 * h2 + 3] = n23;  // 2  3
        y3[2 * h2 + 2] = n32;   y3[2 * h2 + 3] = n33;  // 2  3

        j += j0;
        if (j == n0) {
            j += n0;
            x0 += (int)npoints >> 1;
            x2 += (int)npoints >> 1;
        }
    }
}

short AudioCommonFftKws1(short sFftOrder, int* fftInBuf, int* fftOutBuf, signed char* pScratchBuf, const short* sFFT512Coef)
{
    int* aiFftIn = aiFftInTempBuff;
    int i;
    int sNormShift2, sNormShift2Tmp;
    int sNormBack;
    int iMax, iData;
    const short* sFFTCoef;
    short butterOpCnt;
    // Perform FFT on the data buffer
    iMax = 0;
    for (i = 0; i < sFftOrder; i++) {
        aiFftIn[2 * i] = 0;
        aiFftIn[2 * i + 1] = 0;
        iData = LAbs(fftInBuf[i]);
        if (iData > iMax) {
            iMax = iData;
        }
    }

    sNormShift2 = NormL(iMax);
    butterOpCnt = 30 - NormL(sFftOrder);
    sNormShift2 = sNormShift2 - butterOpCnt;

    if (sNormShift2 >= 0) {
        for (i = 0; i < sFftOrder; i++) {
            aiFftIn[2 * i] = fftInBuf[i] << sNormShift2;
        }
    } else {
        sNormShift2Tmp = -sNormShift2;
        for (i = 0; i < sFftOrder; i++) {
            aiFftIn[2 * i] = fftInBuf[i] >> sNormShift2Tmp;
        }
    }
    // FFT系数表格
    if (512 == sFftOrder) {
        sFFTCoef = sFFT512Coef;
    } else {
        sFFTCoef = sFFT512Coef;
    }
    Audiofft16x32(sFFTCoef, sFftOrder, aiFftIn, fftOutBuf);
    sNormBack = sNormShift2; // FFT的Q值
    return sNormBack;
}

/*****************************************************************************
 函 数 名  : KwsNnseCommonFft
 功能描述  : FFT处理函数
 输入参数  : short sFftOrder     -- FFT点数, 256/512/1024
             int *fftInBuf     -- FFT输入数据，sFftOrder+2
             IMEDIA_VOID *pScratchBuf   -- ScratchBuf空间，用于存放fftInBuf的norm后数据，
                                           若不在乎fftInBuf被改写，可直接传入fftInBuf或NULL
 输出参数  : int *fftOutBuf    -- FFT输出数据，sFftOrder
             int *pScratchBuf
 返 回 值  : short               -- norm
*****************************************************************************/

short KwsNnseCommonFft(short sFftOrder, int *fftInBuf, int *fftOutBuf, signed char *pScratchBuf, CommonFftTableStruct *pCommonFftTableSt)
{
    int *aiFftIn = aiFftInTempBuff;
    int i = 0;
    int sNormShift2 = 0, sNormShift2Tmp = 0;
    int sNormBack = 0;
    int iMax = 0, iData = 0;
    const short *sFFTCoef = NULL;
    short butterOpCnt = 0;
    // Perform FFT on the data buffer
    iMax = 0;
    for (i = 0; i < sFftOrder; i++) {
        // 2 split ood and even
        aiFftIn[2 * i] = 0;
        aiFftIn[2 * i + 1] = 0;
        iData = LAbs(fftInBuf[i]);
        if (iData > iMax) {
            iMax = iData;
        }
    }

    sNormShift2 = NormL(iMax);
    butterOpCnt = 30 - NormL(sFftOrder); // 30 norm
    sNormShift2 = sNormShift2 - butterOpCnt;

    if (sNormShift2 >= 0) {
        for (i = 0; i < sFftOrder; i++) {
            aiFftIn[2 * i] = fftInBuf[i] << sNormShift2;  // 2
        }
    } else {
        sNormShift2Tmp = -sNormShift2;
        for (i = 0; i < sFftOrder; i++) {
            aiFftIn[2 * i] = fftInBuf[i] >> sNormShift2Tmp;  // 2
        }
    }
    // FFT系数表格

    if (512 == sFftOrder) {  // 512 points
        sFFTCoef = (const short *)pCommonFftTableSt->g_G_NNSE_sFFT512Coef;
    } else {
        return 0;
    }

    Audiofft16x32(sFFTCoef, sFftOrder, aiFftIn, fftOutBuf);
    sNormBack = sNormShift2; // FFT的Q值
    return sNormBack;
}

short KwsNnseCommonIfft(short sFftOrder, int *ifftInBuf, int *ifftOutBuf, signed char *pScratchBuf, CommonFftTableStruct *pCommonFftTableSt)
{
    int *aiFftIn = aiFftInTempBuff, *aiFftOut = aiFftOutTempBuff;
    int i = 0;
    short sNormShift2 = 0, sNormShift2Tmp = 0;
    short butterOpCnt = 0;
    short sNormBack = 0;
    int iMax = 0, iData = 0;
    int *piPtr = NULL;
    const short *sFFTCoef = NULL;

    // ==========================================================================
    // 128  512 256 1024 points
    if ((sFftOrder != 128) && (sFftOrder != 256) && (sFftOrder != 512) && (sFftOrder != 1024)) {
        return 0;
    }
    iMax = ifftInBuf[0];
    for (i = 0; i < sFftOrder; i++) {
        aiFftOut[2 * i] = 0;
        aiFftOut[2 * i + 1] = 0;
    }

    for (i = sFftOrder + 2 - 1; i != 0; i--) {
        iData = LAbs(ifftInBuf[i]);
        if (iData > iMax) {
            iMax = iData;
        }
    }
    sNormShift2 = NormL(iMax);
    butterOpCnt = 30 - NormL(sFftOrder); // norm 30
    sNormShift2 = sNormShift2 - butterOpCnt;

    if (sNormShift2 > 0) {
        for (i = 0; i < sFftOrder + 2; i++) { // 2
            aiFftIn[i] = ifftInBuf[i] << sNormShift2;
        }
    } else {
        sNormShift2Tmp = -sNormShift2;
        for (i = 0; i < sFftOrder + 2; i++) {  // 2
            aiFftIn[i] = ifftInBuf[i] >> sNormShift2Tmp;
        }
    }

    // 扩展右半部分
    piPtr = &aiFftIn[sFftOrder * 2 - 1]; // ood 2-1
    for (i = 2; i < sFftOrder; i += 2) { // 2
        *(piPtr--) = -aiFftIn[i + 1]; // 虚部
        *(piPtr--) = aiFftIn[i];    // 实部
    }
    sNormBack = sNormShift2 + butterOpCnt + 1;

    if (sFftOrder == 512) { // 512 point
        sFFTCoef = (const short *)pCommonFftTableSt->g_G_NNSE_sFFT512Coef;
    }
    else {
        return 0;
    }

    Audioifft16x32(sFFTCoef, sFftOrder, aiFftIn, aiFftOut);
    for (i = 0; i < sFftOrder; i++) {
        ifftOutBuf[i] = aiFftOut[2 * i]; // even 2
    }
    return sNormBack;
}

/*****************************************************************************
 函 数 名  : iMedia_anr_fft_norm
 功能描述  : FFT与IFFT前数据归整操作
 输入参数  : int *buf      : 输入缓冲区 (8字节对齐)
             int iLoop     : buf长度
 输出参数  : int *buf      : 输出缓冲区 (8字节对齐)
 返 回 值  : short
*****************************************************************************/
short KwsNnseCommonFftNorm(int *buf, int iBufLen)
{
    int i = 0;
    short sNorm = 0;
    int data32x2 = 0;
    int max32x2 = 0;
    int *pld = (int *)buf;

    // Norm
    for (i = 0; i < iBufLen; i++) { // 2
        data32x2 = pld[i];
        max32x2 = MAX(ABS(data32x2), ABS(max32x2));
    }
    sNorm = NormL(max32x2);
    return sNorm;
}


//   ==============================================================================
//    功能描述: FFT/IFFT后Norm结果向量移位
//    输入参数:x            -- 要Norm的数据向量
//        Norm         -- 需要移位的量，正数表示左移，负数表示右移
//        Len          -- 数据长度
//    输出参数:pstTrace     -- y移位后的向量结果
//    返回参数:无
//   ==============================================================================
void KwsNnseFftVecShift32x32(int *__restrict y, const int *__restrict x, int norm, int len)
{
    int n = 0;
    int  vxw = 0, vyw = 0;
    const int *__restrict px = (const int *)x;
    int *__restrict py = (int *)y;
    vxw = 0;
    if (norm > 31) { // 31 Q
        norm = 31; // 31 Q
    } else if (norm < -31) { // 31 Q
        norm = -31; // 31 Q
    }
    for (n = 0; n < len; n++) { // 2
        vxw = px[n];
        vyw = LShlNnse(vxw, norm);
        py[n] = vyw;
    }
}


#else
// Q platform
#define FIRST_STAGE_SCALE 3
#define FFT_BUTTERFLY_S3(_step) do {  \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2); \
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);  \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);  \
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);  \
        vC1 = Q6_P_vsubw_PP_sat(vB0, vB1);  \
        vA0 = pAndx0[1];  \
        vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);  \
        vC2 = Q6_P_vxsubaddw_PP_sat(vB2, vB3); \
        vA1 = pAndx1[1];  \
        vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[1]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[1]));  \
        vC3 = Q6_P_vxaddsubw_PP_sat(vB2, vB3);  \
        vA2 = pAndx2[1]; \
        vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[2]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[2]));  \
        vC0 = Q6_P_vasrw_PR(vC0, rsa);  \
        vA3 = pAndx3[1]; \
        vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[0]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3,  pTwd[0]));  \
        vC1 = Q6_P_vasrw_PR(vC1, rsa);  \
        pAndx0[0] = vC0;  \
        pAndx0++;  \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);  \
        vC2 = Q6_P_vasrw_PR(vC2, rsa);  \
        pAndx1[0] = vC1;  \
        pAndx1++;  \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);  \
        vC3 = Q6_P_vasrw_PR(vC3, rsa);  \
        pAndx3[0] = vC2;  \
        pAndx3++;  \
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);  \
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);  \
        pAndx2[0] = vC3;  \
        pAndx2++; \
        vC1 = Q6_P_vsubw_PP_sat(vB0, vB1); \
        vA0 = pAndx0[_step];  \
        vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);  \
        vC2 = Q6_P_vxsubaddw_PP_sat(vB2, vB3); \
        vA1 = pAndx1[_step]; \
        vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[4]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[4])); \
        vC3 = Q6_P_vxaddsubw_PP_sat(vB2, vB3); \
        vA2 = pAndx2[_step]; \
        vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[5]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[5])); \
        vC0 = Q6_P_vasrw_PR(vC0, rsa); \
        vA3 = pAndx3[_step]; \
        vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[3]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3, pTwd[3])); \
        vC1 = Q6_P_vasrw_PR(vC1, rsa); \
        pAndx0[0] = vC0; \
        pAndx0 += _step; \
        vC2 = Q6_P_vasrw_PR(vC2, rsa); \
        pAndx1[0] = vC1; \
        pAndx1 += _step; \
        vC3 = Q6_P_vasrw_PR(vC3, rsa); \
        pAndx3[0] = vC2; \
        pAndx3 += _step; \
        pAndx2[0] = vC3; \
        pAndx2 += _step; \
        pTwd += 6; \
    } while (0)
 /* 6 */
#define IFFT_BUTTERFLY_S3(_step) do {  \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2); \
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);  \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);  \
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);  \
        vC1 = Q6_P_vsubw_PP_sat(vB0, vB1);  \
        vA0 = pAndx0[1];  \
        vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);  \
        vC2 = Q6_P_vxaddsubw_PP_sat(vB2, vB3); \
        vA1 = pAndx1[1];  \
        vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[1]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[1]));  \
        vC3 = Q6_P_vxsubaddw_PP_sat(vB2, vB3);  \
        vA2 = pAndx2[1]; \
        vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[2]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[2]));  \
        vC0 = Q6_P_vasrw_PR(vC0, rsa);  \
        vA3 = pAndx3[1]; \
        vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[0]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3,  pTwd[0]));  \
        vC1 = Q6_P_vasrw_PR(vC1, rsa);  \
        pAndx0[0] = vC0;  \
        pAndx0++;  \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);  \
        vC2 = Q6_P_vasrw_PR(vC2, rsa);  \
        pAndx1[0] = vC1;  \
        pAndx1++;  \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);  \
        vC3 = Q6_P_vasrw_PR(vC3, rsa);  \
        pAndx3[0] = vC2;  \
        pAndx3++;  \
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);  \
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);  \
        pAndx2[0] = vC3;  \
        pAndx2++; \
        vC1 = Q6_P_vsubw_PP_sat(vB0, vB1); \
        vA0 = pAndx0[_step];  \
        vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);  \
        vC2 = Q6_P_vxaddsubw_PP_sat(vB2, vB3); \
        vA1 = pAndx1[_step]; \
        vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[4]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[4])); \
        vC3 = Q6_P_vxsubaddw_PP_sat(vB2, vB3); \
        vA2 = pAndx2[_step]; \
        vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[5]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[5])); \
        vC0 = Q6_P_vasrw_PR(vC0, rsa); \
        vA3 = pAndx3[_step]; \
        vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[3]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3, pTwd[3])); \
        vC1 = Q6_P_vasrw_PR(vC1, rsa); \
        pAndx0[0] = vC0; \
        pAndx0 += _step; \
        vC2 = Q6_P_vasrw_PR(vC2, rsa); \
        pAndx1[0] = vC1; \
        pAndx1 += _step; \
        vC3 = Q6_P_vasrw_PR(vC3, rsa); \
        pAndx3[0] = vC2; \
        pAndx3 += _step; \
        pAndx2[0] = vC3; \
        pAndx2 += _step; \
        pTwd += 6; \
    } while (0)


#define FFT_BUTTERFLY_S3_T3F(_step) do {    \
        vA0 = pAndx0[1];  \
        vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);  \
        vC2 = Q6_P_vxsubaddw_PP_sat(vB2, vB3); \
        vA1 = pAndx1[1];  \
        vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[1]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[1]));  \
        vC3 = Q6_P_vxaddsubw_PP_sat(vB2, vB3);  \
        vA2 = pAndx2[1]; \
        vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[2]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[2]));  \
        vC0 = Q6_P_vasrw_PR(vC0, rsa);  \
        vA3 = pAndx3[1]; \
        vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[0]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3,  pTwd[0]));  \
        vC1 = Q6_P_vasrw_PR(vC1, rsa);  \
        pAndx0[0] = vC0;  \
        pAndx0++;  \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);  \
        vC2 = Q6_P_vasrw_PR(vC2, rsa);  \
        pAndx1[0] = vC1;  \
        pAndx1++;  \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);  \
        vC3 = Q6_P_vasrw_PR(vC3, rsa);  \
        pAndx3[0] = vC2;  \
        pAndx3++;  \
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);  \
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);  \
        pAndx2[0] = vC3;  \
        pAndx2++; \
        vC1 = Q6_P_vsubw_PP_sat(vB0, vB1); \
        vA0 = pAndx0[_step];  \
        vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);  \
        vC2 = Q6_P_vxsubaddw_PP_sat(vB2, vB3); \
        vA1 = pAndx1[_step]; \
        vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[4]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[4])); \
        vC3 = Q6_P_vxaddsubw_PP_sat(vB2, vB3); \
        vA2 = pAndx2[_step]; \
        vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[5]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[5])); \
        vC0 = Q6_P_vasrw_PR(vC0, rsa); \
        vA3 = pAndx3[_step]; \
        vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[3]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3, pTwd[3])); \
        vC1 = Q6_P_vasrw_PR(vC1, rsa); \
        pAndx0[0] = vC0; \
        pAndx0 += _step; \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2); \
        vC2 = Q6_P_vasrw_PR(vC2, rsa); \
        pAndx1[0] = vC1; \
        pAndx1 += _step; \
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);  \
        vC3 = Q6_P_vasrw_PR(vC3, rsa); \
        pAndx3[0] = vC2; \
        pAndx3 += _step; \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);           \
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);           \
        pAndx2[0] = vC3; \
        pAndx2 += _step; \
        vC1 = Q6_P_vsubw_PP_sat(vB0, vB1);           \
    } while (0)

#define IFFT_BUTTERFLY_S3_T3F(_step) do {    \
        vA0 = pAndx0[1];  \
        vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);  \
        vC2 = Q6_P_vxaddsubw_PP_sat(vB2, vB3); \
        vA1 = pAndx1[1];  \
        vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[1]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[1]));  \
        vC3 = Q6_P_vxsubaddw_PP_sat(vB2, vB3);  \
        vA2 = pAndx2[1]; \
        vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[2]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[2]));  \
        vC0 = Q6_P_vasrw_PR(vC0, rsa);  \
        vA3 = pAndx3[1]; \
        vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[0]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3,  pTwd[0]));  \
        vC1 = Q6_P_vasrw_PR(vC1, rsa);  \
        pAndx0[0] = vC0;  \
        pAndx0++;  \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);  \
        vC2 = Q6_P_vasrw_PR(vC2, rsa);  \
        pAndx1[0] = vC1;  \
        pAndx1++;  \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);  \
        vC3 = Q6_P_vasrw_PR(vC3, rsa);  \
        pAndx3[0] = vC2;  \
        pAndx3++;  \
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);  \
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);  \
        pAndx2[0] = vC3;  \
        pAndx2++; \
        vC1 = Q6_P_vsubw_PP_sat(vB0, vB1); \
        vA0 = pAndx0[_step];  \
        vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);  \
        vC2 = Q6_P_vxaddsubw_PP_sat(vB2, vB3); \
        vA1 = pAndx1[_step]; \
        vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[4]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[4])); \
        vC3 = Q6_P_vxsubaddw_PP_sat(vB2, vB3); \
        vA2 = pAndx2[_step]; \
        vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[5]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[5])); \
        vC0 = Q6_P_vasrw_PR(vC0, rsa); \
        vA3 = pAndx3[_step]; \
        vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[3]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3, pTwd[3])); \
        vC1 = Q6_P_vasrw_PR(vC1, rsa); \
        pAndx0[0] = vC0; \
        pAndx0 += _step; \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2); \
        vC2 = Q6_P_vasrw_PR(vC2, rsa); \
        pAndx1[0] = vC1; \
        pAndx1 += _step; \
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);  \
        vC3 = Q6_P_vasrw_PR(vC3, rsa); \
        pAndx3[0] = vC2; \
        pAndx3 += _step; \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);           \
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);           \
        pAndx2[0] = vC3; \
        pAndx2 += _step; \
        vC1 = Q6_P_vsubw_PP_sat(vB0, vB1);           \
    } while (0)
/* 0 1 2 3 4 */
#define FFT_BUTTERFLY_R2(idx) do {      \
        vA1 = pAndx0[1];    \
        vA2 = pAndx0[2];   \
        vA3 = pAndx0[3];   \
        vA0 = pAndx0[0];   \
        pAndx0 += 4; \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA1);    \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA1);    \
        vB1 = Q6_P_vaddw_PP_sat(vA2, vA3);    \
        vB3 = Q6_P_vsubw_PP_sat(vA2, vA3);    \
        p_y0[idx] = vB0;   \
        p_y1[idx] = vB1;   \
        p_y2[idx] = vB2;   \
        p_y3[idx] = vB3;   \
    } while (0)
/* 0 1 2 3 4 */
#define IFFT_BUTTERFLY_R2(idx) do {      \
        vA1 = pAndx0[1];    \
        vA2 = pAndx0[2];   \
        vA3 = pAndx0[3];   \
        vA0 = pAndx0[0];   \
        pAndx0 += 4; \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA1);    \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA1);    \
        vB1 = Q6_P_vaddw_PP_sat(vA2, vA3);    \
        vB3 = Q6_P_vsubw_PP_sat(vA2, vA3);    \
        p_y0[idx] = vB0;   \
        p_y1[idx] = vB1;   \
        p_y2[idx] = vB2;   \
        p_y3[idx] = vB3;   \
    } while (0)
/* 0 1 2 3 4 */
#define FFT_BUTTERFLY_R4(idx) do {      \
        vA1 = pAndx0[1];                \
        vA2 = pAndx0[2];                \
        vA3 = pAndx0[3];                \
        vA0 = pAndx0[0];                \
        pAndx0 += 4;                    \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);        \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);        \
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);        \
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);        \
        vA0 = Q6_P_vaddw_PP_sat(vB0, vB1);        \
        vA2 = Q6_P_vsubw_PP_sat(vB0, vB1);        \
        vA1 = Q6_P_vxaddsubw_PP_sat(vB2, vB3);        \
        vA3 = Q6_P_vxsubaddw_PP_sat(vB2, vB3);        \
        p_y0[idx] = vA0;            \
        p_y1[idx] = vA1;            \
        p_y2[idx] = vA2;            \
        p_y3[idx] = vA3;            \
    } while (0)
/* 0 1 2 3 4 */
#define IFFT_BUTTERFLY_R4(idx) do {      \
        vA1 = pAndx0[1];                \
        vA2 = pAndx0[2];                \
        vA3 = pAndx0[3];                \
        vA0 = pAndx0[0];                \
        pAndx0 += 4;                    \
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);        \
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);        \
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);        \
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);        \
        vA0 = Q6_P_vaddw_PP_sat(vB0, vB1);        \
        vA2 = Q6_P_vsubw_PP_sat(vB0, vB1);        \
        vA1 = Q6_P_vxsubaddw_PP_sat(vB2, vB3);        \
        vA3 = Q6_P_vxaddsubw_PP_sat(vB2, vB3);        \
        p_y0[idx] = vA0;            \
        p_y1[idx] = vA1;            \
        p_y2[idx] = vA2;            \
        p_y3[idx] = vA3;            \
    } while (0)

IMEDIA_COMMON_TEXT_SECTION
static int AudioFftCores3(int *y, int *x, const iMedia_STRU_FFTDescr *pDescr, CommonFftTableStruct *pCommonFftTableSt)
{
    QNNSE_INT64 *__restrict pAndx0 = NULL;
    QNNSE_INT64 *__restrict pAndx1 = NULL;
    QNNSE_INT64 *__restrict pAndx2 = NULL;
    QNNSE_INT64 *__restrict pAndx3 = NULL;
    QNNSE_INT64 vA0, vA1, vA2, vA3, vB0, vB1, vB2, vB3, vC0, vC1, vC2, vC3;
    int scale = 0;
    int m = pDescr->m;
    const short *__restrict pInc = pDescr->inc;
    const int **seq = (const int **)pDescr->twd;
    const int *__restrict pTwd = (const int *)*seq++;
    int stride = m; //    The stride is quartered with every iteration of the outer loop.
    int rsa = 2;   // 2
    if (stride > 4) { // 4
        int lc = m >> 3; // 3
        //   -----------------------------------------------------------------
        //    Set up pointers to access "m/4", "m/2", "3N/4" complex point or
        //    "m/2", "m", "3N/2" half word
        //   -----------------------------------------------------------------
        pAndx0 = (QNNSE_INT64 *)x;
        pAndx1 = pAndx0 + (stride >> 2); // 2
        pAndx2 = pAndx1 + (stride >> 2); // 2
        pAndx3 = pAndx2 + (stride >> 2); // 2

        vA0 = Q6_P_vasrw_PI(*pAndx0, FIRST_STAGE_SCALE);
        vA1 = Q6_P_vasrw_PI(*pAndx1, FIRST_STAGE_SCALE);
        vA2 = Q6_P_vasrw_PI(*pAndx2, FIRST_STAGE_SCALE);
        vA3 = Q6_P_vasrw_PI(*pAndx3, FIRST_STAGE_SCALE);

        if (stride == 8) { rsa >>= 1; } // 8

        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);


        vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);

        do {

            vC1 = Q6_P_vsubw_PP_sat(vB0, vB1);
            vC2 = Q6_P_vxsubaddw_PP_sat(vB2, vB3);

            vA0 = pAndx0[1]; // offset 8

            vC3 = Q6_P_vxaddsubw_PP_sat(vB2, vB3);;
            vC0 = Q6_P_vasrw_PR(vC0, rsa);
            vA2 = pAndx2[1];
            vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[1]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[1]));
            vA0 = Q6_P_vasrw_PI(vA0, FIRST_STAGE_SCALE);
            vA1 = pAndx1[1]; // 8
            vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[2]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[2]));
            vA2 = Q6_P_vasrw_PI(vA2, FIRST_STAGE_SCALE);
            vA3 = pAndx3[1]; // 8
            vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[0]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3, pTwd[0]));
            vA1 = Q6_P_vasrw_PI(vA1, FIRST_STAGE_SCALE);
            vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);
            vA3 = Q6_P_vasrw_PI(vA3, FIRST_STAGE_SCALE);
            pAndx0[0] = vC0;
            pAndx0++;
            vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);
            vC1 = Q6_P_vasrw_PR(vC1, rsa);
            *pAndx1 = vC1; // offset 8
            pAndx1++;
            vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);
            vC2 = Q6_P_vasrw_PR(vC2, rsa);
            pAndx3[0] = vC2; // offset 8
            pAndx3++;
            vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);
            vC3 = Q6_P_vasrw_PR(vC3, rsa);
            pAndx2[0] = vC3; // offset 8
            pAndx2++;
            vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);
            vA0 = pAndx0[1];        // offset 8
            vC1 = Q6_P_vsubw_PP_sat(vB0, vB1);
            vC0 = Q6_P_vasrw_PR(vC0, rsa);
            vA1 = pAndx1[1]; // offset 8

            vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[4]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[4]));
            vC2 = Q6_P_vxsubaddw_PP_sat(vB2, vB3);

            vA0 = Q6_P_vasrw_PI(vA0, FIRST_STAGE_SCALE);
            vA2 = pAndx2[1]; // offset 8
            vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[5]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[5]));

            vC3 = Q6_P_vxaddsubw_PP_sat(vB2, vB3);
            vA1 = Q6_P_vasrw_PI(vA1, FIRST_STAGE_SCALE);
            vA3 = pAndx3[1]; // offset 8
            vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[3]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3, pTwd[3]));
            vA2 = Q6_P_vasrw_PI(vA2, FIRST_STAGE_SCALE);
            pAndx0[0] = vC0; // offset 8
            pAndx0++;
            vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);
            vC1 = Q6_P_vasrw_PR(vC1, rsa);
            pAndx1[0] = vC1; // offset 8
            pAndx1++;
            vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);
            vA3 = Q6_P_vasrw_PI(vA3, FIRST_STAGE_SCALE);
            vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);
            vC2 = Q6_P_vasrw_PR(vC2, rsa);
            pAndx3[0] = vC2; // offset 8
            pAndx3++;
            vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);
            vC3 = Q6_P_vasrw_PR(vC3, rsa);
            pAndx2[0] = vC3; // offset 8
            pAndx2++;
            vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);
            pTwd += 6;
        } while (--lc);

        scale += (stride != 8) ? 2 : 1; // 8, 2
        stride >>= 2; // 2
    }
    while (stride > 16) { // 16
        int lc = m >> 4; // 4
        int step;
        int icount = 0;
        int shiftNum = (stride >> 2); // right mv 2
        //   -----------------------------------------------------------------
        //    Set up pointers to access "m/4", "m/2", "3N/4" complex point or
        //    "m/2", "m", "3N/2" half word
        //   -----------------------------------------------------------------
        pAndx0 = (QNNSE_INT64 *)x;
        pAndx1 = pAndx0 + shiftNum; // 2
        pAndx2 = pAndx1 + shiftNum; // 2
        pAndx3 = pAndx2 + shiftNum; // 2

        vA0 = *pAndx0;
        vA1 = *pAndx1;
        vA2 = *pAndx2;
        vA3 = *pAndx3;

        pTwd = (const int *)*seq++;

        do {
            step = (*pInc) >> 1;
            pInc++;
            FFT_BUTTERFLY_S3(1);
            FFT_BUTTERFLY_S3(step);
            icount += 16; // 16
            if (icount == stride) {
                pTwd = (const int *)(*(seq - 1));
                icount = 0;
            }
        } while (--lc);
        scale += 2; // 2
        stride >>= 2; // 2
    }
    if (stride == 16) { // 16
        int lc = m >> 4; // 4
        int shiftNum = (stride >> 2);
        //   -----------------------------------------------------------------
        //    Set up pointers to access "m/4", "m/2", "3N/4" complex point or
        //    "m/2", "m", "3N/2" half word
        //   -----------------------------------------------------------------
        pAndx0 = (QNNSE_INT64 *)x;
        pAndx1 = pAndx0 + shiftNum; // 2
        pAndx2 = pAndx1 + shiftNum; // 2
        pAndx3 = pAndx2 + shiftNum; // 2

        vA0 = *pAndx0;
        vA1 = *pAndx1;
        vA2 = *pAndx2;
        vA3 = *pAndx3;

        pTwd = (const int *)*seq++;
        do {
            FFT_BUTTERFLY_S3(1); // 8
            FFT_BUTTERFLY_S3(13); // 13
            pTwd = (const int *)(*(seq - 1));
        } while (--lc);

        scale += 2; // 2
        stride >>= 2; // 2
    }

    if (stride == 8) { // 8
        int lc = m >> 3; // 3
        //   -----------------------------------------------------------------
        //    Set up pointers to access "m/4", "m/2", "3N/4" complex point or
        //    "m/2", "m", "3N/2" half word
        //   -----------------------------------------------------------------
        pAndx0 = (QNNSE_INT64 *)x;
        pAndx1 = pAndx0 + (stride >> 2); // 2
        pAndx2 = pAndx1 + (stride >> 2); // 2
        pAndx3 = pAndx2 + (stride >> 2); // 2

        vA0 = *pAndx0;
        vA1 = *pAndx1;
        vA2 = *pAndx2;
        vA3 = *pAndx3;

        rsa >>= 1;
        pTwd = (const int *)pCommonFftTableSt->g_G_NNSE_COMMON_FFT_TWD_R8;

        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);
        vC1 = Q6_P_vsubw_PP_sat(vB0, vB1);
        do {
            FFT_BUTTERFLY_S3_T3F(7); // 7
        } while (--lc);

        scale += 1;
        stride >>= 2; // 2
    }
    {
        int i, i0, i1, i2, i3, ai;
        QNNSE_INT64 *p_y0 = (QNNSE_INT64 *)(y);
        QNNSE_INT64 *p_y1 = (p_y0 + (m >> 2)); // 2
        QNNSE_INT64 *p_y2 = (p_y1 + (m >> 2)); // 2
        QNNSE_INT64 *p_y3 = (p_y2 + (m >> 2)); // 2
        pAndx0 = (QNNSE_INT64 *)(x);

        i = Q6_R_normamt_R(m) + 1;
        ai = Q6_R_asl_RR_sat(1, i);
        i0 = 0;

        if (stride == 2) { // 2
            //   ------------------------------------------------------------------
            //    last stage is RADIX2 !!!
            //   ------------------------------------------------------------------
            for (i = 0; i < Q6_R_asr_RR_sat(m, 4); i++) { // 4

                i1 = Q6_R_brev_R(i0);
                i1 = Q6_R_add_RR_sat(i1, ai);
                i1 = Q6_R_brev_R(i1);

                i2 = Q6_R_brev_R(i1);
                i2 = Q6_R_add_RR_sat(i2, ai);
                i2 = Q6_R_brev_R(i2);

                i3 = Q6_R_brev_R(i2);
                i3 = Q6_R_add_RR_sat(i3, ai);
                i3 = Q6_R_brev_R(i3);
                FFT_BUTTERFLY_R2(Q6_R_asr_RR_sat(i0, 3)); // 3
                FFT_BUTTERFLY_R2(Q6_R_asr_RR_sat(i1, 3)); // 3
                FFT_BUTTERFLY_R2(Q6_R_asr_RR_sat(i2, 3)); // 3
                FFT_BUTTERFLY_R2(Q6_R_asr_RR_sat(i3, 3)); // 3

                i0 = Q6_R_brev_R(i3);
                i0 = Q6_R_add_RR_sat(i0, ai);
                i0 = Q6_R_brev_R(i0);
            }
        } else {
            //   ------------------------------------------------------------------
            //    last stage is RADIX4 !!!
            //   ------------------------------------------------------------------
            for (i = 0; i < Q6_R_asr_RR_sat(m, 4); i++) { // 4

                i1 = Q6_R_brev_R(i0);
                i1 = Q6_R_add_RR_sat(i1, ai);
                i1 = Q6_R_brev_R(i1);

                i2 = Q6_R_brev_R(i1);
                i2 = Q6_R_add_RR_sat(i2, ai);
                i2 = Q6_R_brev_R(i2);

                i3 = Q6_R_brev_R(i2);
                i3 = Q6_R_add_RR_sat(i3, ai);
                i3 = Q6_R_brev_R(i3);
                //   --------------------------------------------------------------
                //    Read eight inputs, and perform radix4 decomposition
                //   --------------------------------------------------------------
                FFT_BUTTERFLY_R4(Q6_R_asr_RR_sat(i0, 3)); // 3
                FFT_BUTTERFLY_R4(Q6_R_asr_RR_sat(i1, 3)); // 3
                FFT_BUTTERFLY_R4(Q6_R_asr_RR_sat(i2, 3)); // 3
                FFT_BUTTERFLY_R4(Q6_R_asr_RR_sat(i3, 3)); // 3
                i0 = Q6_R_brev_R(i3);
                i0 = Q6_R_add_RR_sat(i0, ai);
                i0 = Q6_R_brev_R(i0);
            }
        }

    }
    return scale;
}


IMEDIA_COMMON_TEXT_SECTION
static int AudioFftCplx32x16(int *y, int *x, const iMedia_STRU_FFTDescr *h, CommonFftTableStruct *pCommonFftTableSt)
{
    int scale = FIRST_STAGE_SCALE;
    scale += AudioFftCores3(y, x, h, pCommonFftTableSt);
    return scale;
}

IMEDIA_COMMON_TEXT_SECTION
void KwsNnseSplitPartx2(int *x, int m, CommonFftTableStruct *pCommonFftTableSt)
{
    int i;
    QNNSE_INT64 *__restrict pAndx0 = NULL;
    QNNSE_INT64 *__restrict pAndx1 = NULL;
    const int *__restrict pTwd = NULL;
    QNNSE_INT64 vA0, vA1, vB0, vB1, vC0, vC1, vF0;
    QNNSE_INT64 vR = Q6_P_combine_RR(1, 1);
    int tempTwd, vB1L;
    int step = 1;
    if (m == 512) { // 512 point
        step = 2; // step 2
    } else if (m == 256) { // 256 point
        step = 4; // step 4
    } else if (m == 128) { // 128 point
        step = 8; // step 8
    }

    pAndx0 = (QNNSE_INT64 *)x;
    pAndx1 = (QNNSE_INT64 *)(x + m);
    pTwd = (const int *)pCommonFftTableSt->g_G_NNSE_COMMON_TWIDDLESPLIT;
    //    load data and prepare pointers for pre-increment
    //    first and last samples
    vA0 = pAndx0[0];
    vB0 = Q6_P_vxsubaddw_PP_sat(vA0, vA0);
    *pAndx0 = Q6_P_combine_RR(0, HEXAGON_V_GET_W1(vB0));
    *pAndx1 = Q6_P_combine_RR(0, HEXAGON_V_GET_W0(vB0));
    pAndx0++;
    pAndx1--;
    vA0 = *pAndx0;
    vA1 = *pAndx1;

    for (i = 1; i <(m >> 2); i++) { // 2
        //    load twiddle
        tempTwd = *(pTwd + i * step);
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA1);
        vB1 = Q6_P_vsubw_PP_sat(vA0, vA1);
        vA0 = Q6_P_combine_RR(HEXAGON_V_GET_W1(vB0), HEXAGON_V_GET_W0(vB1));
        vB1 = Q6_P_combine_RR(HEXAGON_V_GET_W1(vB1), HEXAGON_V_GET_W0(vB0));
        vF0 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vA0, tempTwd), Q6_R_cmpyrwh_PR_s1_rnd_sat(vA0, tempTwd));

        vA0 = pAndx0[1];
        vA1 = pAndx1[-1];
        vB0 = Q6_P_vasrw_PI(Q6_P_vaddw_PP_sat(vF0, vR), 1);
        vB1 = Q6_P_vasrw_PI(Q6_P_vaddw_PP_sat(vB1, vR), 1);
        //    SUM/DIFF
        vC0 = Q6_P_vsubw_PP_sat(vB1, vB0);
        vC1 = Q6_P_vaddw_PP_sat(vB1, vB0);
        vB1L = Q6_R_neg_R_sat(HEXAGON_V_GET_W1(vC1));
        vC1 = Q6_P_combine_RR(vB1L, HEXAGON_V_GET_W0(vC1));
        *pAndx0 = vC0;
        *pAndx1 = vC1;
        pAndx0++;
        pAndx1--;
    }
    //    middle sample
    vB1L = Q6_R_neg_R_sat(HEXAGON_V_GET_W1(vA0));
    vC0 = Q6_P_combine_RR(vB1L, HEXAGON_V_GET_W0(vA0));
    *pAndx0 = vC0;
}

IMEDIA_COMMON_TEXT_SECTION
static int AudioFftReal32x16(int *y, int *x, int fftOrder, CommonFftTableStruct *pCommonFftTableSt)
{
    int scale;
    const iMedia_STRU_FFTDescr *hIfft = NULL;
    if (fftOrder == 512) { // 512
        hIfft = pCommonFftTableSt->g_G_NNSE_COMMON_RFFT16_512;
    } else {
        return 0;
    }
    scale = AudioFftCplx32x16(y, x, hIfft, pCommonFftTableSt);    // fft of half-size

    KwsNnseSplitPartx2(y, fftOrder, pCommonFftTableSt);
    return scale;
}

/*
 * fftInBuf: 需要8字节对齐
 * fftOutBuf：8字节对齐
 */
short KwsNnseCommonFft(short sFftOrder, int *fftInBuf, int *fftOutBuf, signed char *pScratchBuf, CommonFftTableStruct *pCommonFftTableSt)
{
    int i, iNormBack, iNormShift2, iButterOpCnt;
    int iMax;
    QNNSE_INT64 *pt64tmp = (QNNSE_INT64 *)fftInBuf;
    QNNSE_INT64 *pt64Norm = NULL;
    QNNSE_INT64 lmax = 0;
    int *fftNormBuf = NULL;
    if (pScratchBuf == NULL) {
        fftNormBuf = fftInBuf;
    } else {
        QNNSE_INTPTR address = (QNNSE_INTPTR)pScratchBuf;
        Q_ALIGN_ADDR(address, 8); // 8 字节对齐
        fftNormBuf = (int *)address;
    }
    for (i = 0; i <(sFftOrder >> 1); i++) {
        lmax = Q6_P_vmaxw_PP(Q6_P_vabsw_P(pt64tmp[i]), lmax);
    }
    iMax = Q6_R_max_RR(((int *)&lmax)[0], ((int *)&lmax)[1]);
    iNormShift2 = Q6_R_normamt_R(iMax);

    pt64Norm = (QNNSE_INT64 *)fftNormBuf;
    for (i = 0; i <(sFftOrder >> 1); i++) {
        pt64Norm[i] = Q6_P_vaslw_PR(pt64tmp[i], iNormShift2);
    }
    fftOutBuf[0] = 0;
    iButterOpCnt = AudioFftReal32x16(fftOutBuf, fftNormBuf, sFftOrder, pCommonFftTableSt);
    iNormBack = iNormShift2 - iButterOpCnt;     //    FFT的Q值
    return iNormBack;
}

/*
 * fftInBuf: 需要8字节对齐
 * fftOutBuf：8字节对齐
 */
short AudioCommonFftKws1(short sFftOrder, int* fftInBuf, int* fftOutBuf, signed char* pScratchBuf, CommonFftTableStruct* pCommonFftTableSt)
{
    int i, iNormBack, iNormShift2, iButterOpCnt;
    int iMax;
    Q3A_INT64* pt64tmp = (Q3A_INT64*)fftInBuf;
    Q3A_INT64* pt64Norm = NULL;
    Q3A_INT64 lmax = 0;
    int* fftNormBuf = NULL;
    if (pScratchBuf == NULL) {
        fftNormBuf = fftInBuf;
    } else {
        Q3A_INTPTR address = (Q3A_INTPTR)pScratchBuf;
        Q_ALIGN_ADDR(address, 8);
        fftNormBuf = (int*)address;
    }
    for (i = 0; i <(sFftOrder >> 1); i++) {
        lmax = Q6_P_vmaxw_PP(Q6_P_vabsw_P(pt64tmp[i]), lmax);
    }
    iMax = Q6_R_max_RR(((int*)&lmax)[0], ((int*)&lmax)[1]);
    iNormShift2 = Q6_R_normamt_R(iMax);

    pt64Norm = (Q3A_INT64*)fftNormBuf;
    for (i = 0; i <(sFftOrder >> 1); i++) {
        pt64Norm[i] = Q6_P_vaslw_PR(pt64tmp[i], iNormShift2);
    }
    fftOutBuf[0] = 0;
    iButterOpCnt = AudioFftReal32x16(fftOutBuf, fftNormBuf, sFftOrder, pHandleCommon);
    iNormBack = iNormShift2 - iButterOpCnt;     //    FFT的Q值
    return iNormBack;
}

//   ==============================================================================
//    函数名称: AudioIsplitPartx2
//    功能描述: 实数IFFT的反split函数
//    输入参数:X        --  复数功率谱
//             m        --  点数
//    输出参数: X        --  将复数功率谱组合成实数IFFT所需的复数谱
//    返回参数: 无
//   ==============================================================================
IMEDIA_COMMON_TEXT_SECTION
static void AudioIsplitPartx2(int *x, int m, CommonFftTableStruct *pCommonFftTableSt)
{
    int i;
    QNNSE_INT64 *__restrict pAndx0 = NULL;
    QNNSE_INT64 *__restrict pAndx1 = NULL;
    QNNSE_INT64  vA0, vA1, vB0, vB1, vC0, vC1, vF0;
    QNNSE_INT64 vR = Q6_P_combine_RR(1, 1);
    int vA0H, vA1H, tempTwd, vB1L;
    const int *__restrict pTwd = (const int *)pCommonFftTableSt->g_G_NNSE_COMMON_TWIDDLESPLIT;
    int step = 1;
    if (m == 512) { // 512 point
        step = 2; // step 2
    } else if (m == 256) { // 256 point
        step = 4; // step 4
    } else if (m == 128) { // 128 point
        step = 8; // step 8
    }
    pAndx0 = (QNNSE_INT64 *)x;
    pAndx1 = (QNNSE_INT64 *)(x + m);
    //    first point
    vA0 = *pAndx0;
    vA1 = *pAndx1;
    vA0H = HEXAGON_V_GET_W0(vA0);
    vA1H = HEXAGON_V_GET_W0(vA1);
    vB0 = Q6_P_combine_RR(Q6_R_sub_RR_sat(vA0H, vA1H), Q6_R_add_RR_sat(vA0H, vA1H));
    vB0 = Q6_P_vasrw_PI(Q6_P_vaddw_PP_sat(vB0, vR), 1);
    *pAndx0 = vB0;
    *pAndx1 = 0;
    pAndx0++;
    pAndx1--;
    vA0 = *pAndx0;
    vA1 = *pAndx1;

    for (i = 1; i <(m >> 2); i++) { // 2
        //    load twiddle
        tempTwd = *(pTwd + i * step);
        //    ADD/SUBB
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA1);
        vB1 = Q6_P_vsubw_PP_sat(vA0, vA1);

        vA0 = Q6_P_combine_RR(HEXAGON_V_GET_W0(vB1), HEXAGON_V_GET_W1(vB0));
        vB1 = Q6_P_combine_RR(HEXAGON_V_GET_W1(vB1), HEXAGON_V_GET_W0(vB0));
        // do rotation
        vF0 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vA0, tempTwd), Q6_R_cmpyrwh_PR_s1_rnd_sat(vA0, tempTwd));
        vB0 = Q6_P_combine_RR(Q6_R_neg_R_sat(HEXAGON_V_GET_W0(vF0)), Q6_R_neg_R_sat(HEXAGON_V_GET_W1(vF0)));
        vA0 = pAndx0[1];
        vA1 = pAndx1[-1];
        // load next data
        vB0 = Q6_P_vasrw_PI(Q6_P_vaddw_PP_sat(vB0, vR), 1);
        vB1 = Q6_P_vasrw_PI(Q6_P_vaddw_PP_sat(vB1, vR), 1);
        //    SUM/DIFF
        vC0 = Q6_P_vaddw_PP_sat(vB1, vB0);
        vC1 = Q6_P_vsubw_PP_sat(vB1, vB0);
        vB1L = Q6_R_neg_R_sat(HEXAGON_V_GET_W1(vC1));
        vC1 = Q6_P_combine_RR(vB1L, HEXAGON_V_GET_W0(vC1));
        *pAndx0 = vC0;
        *pAndx1 = vC1;
        pAndx0++;
        pAndx1--;
    }
    // middle sample
    vB1L = Q6_R_neg_R_sat(HEXAGON_V_GET_W1(vA0));
    vC0 = Q6_P_combine_RR(vB1L, HEXAGON_V_GET_W0(vA0));
    *pAndx0 = vC0;
}

//   ==============================================================================
//    函数名称: AudioIfftCores3
//    功能描述: 复数IFFT核心函数
//    输入参数: x        --  需要做IFFT的复数谱
//              pDescr   --  IFFT的表格数据指针
//    输出参数: y        --  IFFT后的复数信号
//    返回参数: int    --  IFFT过程中的Norm值,均为正数,表示右移
//   ==============================================================================
IMEDIA_COMMON_TEXT_SECTION
static int AudioIfftCores3(int *y, int *x, const iMedia_STRU_FFTDescr *pDescr, CommonFftTableStruct *pCommonFftTableSt)
{
    QNNSE_INT64 *__restrict pAndx0 = NULL;
    QNNSE_INT64 *__restrict pAndx1 = NULL;
    QNNSE_INT64 *__restrict pAndx2 = NULL;
    QNNSE_INT64 *__restrict pAndx3 = NULL;
    QNNSE_INT64 vA0, vA1, vA2, vA3, vB0, vB1, vB2, vB3, vC0, vC1, vC2, vC3;
    int scale = 0;
    int m = pDescr->m;
    const short *__restrict pInc = pDescr->inc;
    const int **seq = (const int **)pDescr->twd;
    const int *__restrict pTwd = (const int *)*seq++;
    int stride = m; //    The stride is quartered with every iteration of the outer loop.
    int rsa = 2;   // 2
    if (stride > 4) { // 4
        int lc = m >> 3; // 3
        //   -----------------------------------------------------------------
        //    Set up pointers to access "m/4", "m/2", "3N/4" complex point or
        //    "m/2", "m", "3N/2" half word
        //   -----------------------------------------------------------------
        pAndx0 = (QNNSE_INT64 *)x;
        pAndx1 = pAndx0 + (stride >> 2); // 2
        pAndx2 = pAndx1 + (stride >> 2); // 2
        pAndx3 = pAndx2 + (stride >> 2); // 2

        vA0 = Q6_P_vasrw_PI(*pAndx0, FIRST_STAGE_SCALE);
        vA1 = Q6_P_vasrw_PI(*pAndx1, FIRST_STAGE_SCALE);
        vA2 = Q6_P_vasrw_PI(*pAndx2, FIRST_STAGE_SCALE);
        vA3 = Q6_P_vasrw_PI(*pAndx3, FIRST_STAGE_SCALE);

        if (stride == 8) { rsa >>= 1; } // 8

        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);
        vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);

        do {
            vC1 = Q6_P_vsubw_PP_sat(vB0, vB1);
            vC2 = Q6_P_vxaddsubw_PP_sat(vB2, vB3);
            vA0 = pAndx0[1]; // offset 8
            vC3 = Q6_P_vxsubaddw_PP_sat(vB2, vB3);

            vC0 = Q6_P_vasrw_PR(vC0, rsa);
            vA2 = pAndx2[1];
            vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[1]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[1]));
            vA0 = Q6_P_vasrw_PI(vA0, FIRST_STAGE_SCALE);
            vA1 = pAndx1[1]; // 8
            vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[2]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[2]));
            vA2 = Q6_P_vasrw_PI(vA2, FIRST_STAGE_SCALE);
            vA3 = pAndx3[1]; // 8
            vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[0]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3, pTwd[0]));
            vA1 = Q6_P_vasrw_PI(vA1, FIRST_STAGE_SCALE);
            vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);
            vA3 = Q6_P_vasrw_PI(vA3, FIRST_STAGE_SCALE);

            pAndx0[0] = vC0;
            pAndx0++;
            vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);
            vC1 = Q6_P_vasrw_PR(vC1, rsa);
            *pAndx1 = vC1; // offset 8
            pAndx1++;
            vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);
            vC2 = Q6_P_vasrw_PR(vC2, rsa);
            pAndx3[0] = vC2; // offset 8
            pAndx3++;
            vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);
            vC3 = Q6_P_vasrw_PR(vC3, rsa);
            pAndx2[0] = vC3; // offset 8
            pAndx2++;
            vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);
            vA0 = pAndx0[1];        // offset 8
            vC1 = Q6_P_vsubw_PP_sat(vB0, vB1);
            vC0 = Q6_P_vasrw_PR(vC0, rsa);
            vA1 = pAndx1[1]; // offset 8
            vC1 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC1, pTwd[4]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC1, pTwd[4]));
            vC2 = Q6_P_vxaddsubw_PP_sat(vB2, vB3);

            vA0 = Q6_P_vasrw_PI(vA0, FIRST_STAGE_SCALE);
            vA2 = pAndx2[1]; // offset 8
            vC2 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC2, pTwd[5]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC2, pTwd[5]));

            vC3 = Q6_P_vxsubaddw_PP_sat(vB2, vB3);
            vA1 = Q6_P_vasrw_PI(vA1, FIRST_STAGE_SCALE);
            vA3 = pAndx3[1]; // offset 8
            vC3 = Q6_P_combine_RR(Q6_R_cmpyiwh_PR_s1_rnd_sat(vC3, pTwd[3]), Q6_R_cmpyrwh_PR_s1_rnd_sat(vC3, pTwd[3]));
            vA2 = Q6_P_vasrw_PI(vA2, FIRST_STAGE_SCALE);
            pAndx0[0] = vC0; // offset 8
            pAndx0++;
            vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);
            vC1 = Q6_P_vasrw_PR(vC1, rsa);
            pAndx1[0] = vC1; // offset 8
            pAndx1++;
            vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);
            vA3 = Q6_P_vasrw_PI(vA3, FIRST_STAGE_SCALE);
            vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);
            vC2 = Q6_P_vasrw_PR(vC2, rsa);
            pAndx3[0] = vC2; // offset 8
            pAndx3++;
            vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);
            vC3 = Q6_P_vasrw_PR(vC3, rsa);

            pAndx2[0] = vC3; // offset 8
            pAndx2++;
            vC0 = Q6_P_vaddw_PP_sat(vB0, vB1);
            pTwd += 6; // 6
        } while (--lc);

        scale += (stride != 8) ? 2 : 1; // 8, 2
        stride >>= 2; // 2
    }

    while (stride > 16) { // 16
        int lc = m >> 4; // 4
        int step;
        int icount = 0;
        int shiftNum = (stride >> 2); // 2
        //   -----------------------------------------------------------------
        //    Set up pointers to access "m/4", "m/2", "3N/4" complex point or
        //    "m/2", "m", "3N/2" half word
        //   -----------------------------------------------------------------
        pAndx0 = (QNNSE_INT64 *)x;
        pAndx1 = pAndx0 + shiftNum; // 2
        pAndx2 = pAndx1 + shiftNum; // 2
        pAndx3 = pAndx2 + shiftNum; // 2

        vA0 = *pAndx0;
        vA1 = *pAndx1;
        vA2 = *pAndx2;
        vA3 = *pAndx3;

        pTwd = (const int *)*seq++;
        do {
            step = (*pInc) >> 1;
            pInc++;
            IFFT_BUTTERFLY_S3(1);
            IFFT_BUTTERFLY_S3(step);
            icount += 16; // 16
            if (icount == stride) {
                pTwd = (const int *)(*(seq - 1));
                icount = 0;
            }
        } while (--lc);
        scale += 2; // 2
        stride >>= 2; // 2
    }
    if (stride == 16) { // 16
        int lc = m >> 4; // 4
        int shiftNum = (stride >> 2); // 2
        //   -----------------------------------------------------------------
        //    Set up pointers to access "m/4", "m/2", "3N/4" complex point or
        //    "m/2", "m", "3N/2" half word
        //   -----------------------------------------------------------------
        pAndx0 = (QNNSE_INT64 *)x;
        pAndx1 = pAndx0 + shiftNum; // 2
        pAndx2 = pAndx1 + shiftNum; // 2
        pAndx3 = pAndx2 + shiftNum; // 2

        vA0 = *pAndx0;
        vA1 = *pAndx1;
        vA2 = *pAndx2;
        vA3 = *pAndx3;

        pTwd = (const int *)*seq++;
        do {
            IFFT_BUTTERFLY_S3(1); // 8
            IFFT_BUTTERFLY_S3(13); // 13
            pTwd = (const int *)(*(seq - 1));
        } while (--lc);

        scale += 2; // 2
        stride >>= 2; // 2
    }

    if (stride == 8) { // 8
        int lc = m >> 3; // 3
        //   -----------------------------------------------------------------
        //    Set up pointers to access "m/4", "m/2", "3N/4" complex point or
        //    "m/2", "m", "3N/2" half word
        //   -----------------------------------------------------------------
        pAndx0 = (QNNSE_INT64 *)x;
        pAndx1 = pAndx0 + (stride >> 2); // 2
        pAndx2 = pAndx1 + (stride >> 2); // 2
        pAndx3 = pAndx2 + (stride >> 2); // 2

        vA0 = *pAndx0;
        vA1 = *pAndx1;
        vA2 = *pAndx2;
        vA3 = *pAndx3;

        rsa >>= 1;
        pTwd = (const int *)pCommonFftTableSt->g_G_NNSE_COMMON_IFFT_TWD_R8;
        vB0 = Q6_P_vaddw_PP_sat(vA0, vA2);
        vB3 = Q6_P_vsubw_PP_sat(vA1, vA3);
        vB2 = Q6_P_vsubw_PP_sat(vA0, vA2);
        vB1 = Q6_P_vaddw_PP_sat(vA1, vA3);
        vC1 = Q6_P_vsubw_PP_sat(vB0, vB1);
        do {
            IFFT_BUTTERFLY_S3_T3F(7); // 7
        } while (--lc);

        scale += 1;
        stride >>= 2; // 2
    }
    {
        int i, i0, i1, i2, i3, ai;
        QNNSE_INT64 *p_y0 = (QNNSE_INT64 *)(y);
        QNNSE_INT64 *p_y1 = (p_y0 + (m >> 2)); // 2
        QNNSE_INT64 *p_y2 = (p_y1 + (m >> 2)); // 2
        QNNSE_INT64 *p_y3 = (p_y2 + (m >> 2)); // 2
        pAndx0 = (QNNSE_INT64 *)(x);

        i = Q6_R_normamt_R(m) + 1;
        ai = Q6_R_asl_RR_sat(1, i);
        i0 = 0;

        if (stride == 2) { // 2
            //   ------------------------------------------------------------------
            //    last stage is RADIX2 !!!
            //   ------------------------------------------------------------------
            for (i = 0; i < Q6_R_asr_RR_sat(m, 4); i++) { // 4
                i1 = Q6_R_brev_R(i0);
                i1 = Q6_R_add_RR_sat(i1, ai);
                i1 = Q6_R_brev_R(i1);
                i2 = Q6_R_brev_R(i1);
                i2 = Q6_R_add_RR_sat(i2, ai);
                i2 = Q6_R_brev_R(i2);
                i3 = Q6_R_brev_R(i2);
                i3 = Q6_R_add_RR_sat(i3, ai);
                i3 = Q6_R_brev_R(i3);
                IFFT_BUTTERFLY_R2(Q6_R_asr_RR_sat(i0, 3)); // 3
                IFFT_BUTTERFLY_R2(Q6_R_asr_RR_sat(i1, 3)); // 3
                IFFT_BUTTERFLY_R2(Q6_R_asr_RR_sat(i2, 3)); // 3
                IFFT_BUTTERFLY_R2(Q6_R_asr_RR_sat(i3, 3)); // 3
                i0 = Q6_R_brev_R(i3);
                i0 = Q6_R_add_RR_sat(i0, ai);
                i0 = Q6_R_brev_R(i0);
            }
        } else {
            //   ------------------------------------------------------------------
            //    last stage is RADIX4 !!!
            //   ------------------------------------------------------------------
            for (i = 0; i < Q6_R_asr_RR_sat(m, 4); i++) { // 4
                i1 = Q6_R_brev_R(i0);
                i1 = Q6_R_add_RR_sat(i1, ai);
                i1 = Q6_R_brev_R(i1);
                i2 = Q6_R_brev_R(i1);
                i2 = Q6_R_add_RR_sat(i2, ai);
                i2 = Q6_R_brev_R(i2);
                i3 = Q6_R_brev_R(i2);
                i3 = Q6_R_add_RR_sat(i3, ai);
                i3 = Q6_R_brev_R(i3);
                //   --------------------------------------------------------------
                //    Read eight inputs, and perform radix4 decomposition
                //   --------------------------------------------------------------
                IFFT_BUTTERFLY_R4(Q6_R_asr_RR_sat(i0, 3)); // 3
                IFFT_BUTTERFLY_R4(Q6_R_asr_RR_sat(i1, 3)); // 3
                IFFT_BUTTERFLY_R4(Q6_R_asr_RR_sat(i2, 3)); // 3
                IFFT_BUTTERFLY_R4(Q6_R_asr_RR_sat(i3, 3)); // 3
                i0 = Q6_R_brev_R(i3);
                i0 = Q6_R_add_RR_sat(i0, ai);
                i0 = Q6_R_brev_R(i0);
            }
        }
    }
    return scale;
}

//   ==============================================================================
//    函数名称: AudioIfftCplx32x16
//    功能描述: 复数IFFT入口函数
//    输入参数: x        --  需要做IFFT的复数谱
//             h        --  IFFT所需的表格数据句柄
//    输出参数: y        --  IFFT后的复数信号
//    返回参数: int    --  IFFT过程中的Norm值,均为正数,表示右移
//   ==============================================================================
IMEDIA_COMMON_TEXT_SECTION
static int AudioIfftCplx32x16(int *y, int *x, const iMedia_STRU_FFTDescr *h, CommonFftTableStruct *pCommonFftTableSt)
{

    int scale = FIRST_STAGE_SCALE;
    scale += AudioIfftCores3(y, x, h, pCommonFftTableSt);
    return scale;
}
//   ==============================================================================
//    功能描述: 实数IFFT运算
//    输入参数: x           -- 输入复数频谱，总共为(fftOrder/2+1)个频点，fftOrder+2个数
//        fftOrder    -- IFFT点数，支持128点、256点和512点
//    输出参数:y           -- IFFT变换后的复数序列，总共为fftOrder实数
//    返回参数:int         -- Norm值，在变换过程中为提高进度，会对结果进行Norm，
//                       正数表示右移，负数表示左右，仅与ftOrder有交
//                       fftOrder    norm
//                        128         7
//                        256         8
//                        512         9
//   ==============================================================================
IMEDIA_COMMON_TEXT_SECTION
int KwsNnseIfftReal32x16(int *y, int *x, int fftOrder, CommonFftTableStruct *pCommonFftTableSt)
{
    int scale;
    const iMedia_STRU_FFTDescr *hFft = NULL;

    if (fftOrder == 128) { // 128
        hFft = (pCommonFftTableSt->g_G_NNSE_COMMON_RIFFT16_128);
    } else if (fftOrder == 256) { // 256
        hFft = (pCommonFftTableSt->g_G_NNSE_COMMON_RIFFT16_256);
    } else if (fftOrder == 512) { // 512
        hFft = (pCommonFftTableSt->g_G_NNSE_COMMON_RIFFT16_512);
    } else {  // 1024 == fftOrder
        hFft = (pCommonFftTableSt->g_G_NNSE_COMMON_RIFFT16_1024);
    }

    AudioIsplitPartx2(x, fftOrder, pCommonFftTableSt);
    scale = AudioIfftCplx32x16(y, x, hFft, pCommonFftTableSt);

    return scale;
}

short KwsNnseCommonIfft(short sFftOrder, int *ifftInBuf, int *ifftOutBuf, signed char *pScratchBuf, CommonFftTableStruct *pCommonFftTableSt)
{
    int i;
    int iMax;
    int sNorm;
    int iLoop = (sFftOrder + 2) >> 1; // 2
    QNNSE_INT64 *pt64tmp = (QNNSE_INT64 *)ifftInBuf;
    QNNSE_INT64 *pt64Norm = NULL;
    QNNSE_INT64 lmax = 0;
    int *ifftNormBuf = NULL;
    if (pScratchBuf == NULL) {
        ifftNormBuf = ifftInBuf;
    } else {
        QNNSE_INTPTR address = (QNNSE_INTPTR)pScratchBuf;
        Q_ALIGN_ADDR(address, 8); // 8bit 对齐
        ifftNormBuf = (int *)address;
    }
    for (i = 0; i < iLoop; i++) {
        lmax = Q6_P_vmaxw_PP(Q6_P_vabsw_P(pt64tmp[i]), lmax);
    }
    iMax = Q6_R_max_RR(((int *)&lmax)[0], ((int *)&lmax)[1]);
    sNorm = Q6_R_normamt_R(iMax) - 1;
    pt64Norm = (QNNSE_INT64 *)ifftNormBuf;
    for (i = 0; i < iLoop; i++) {
        pt64Norm[i] = Q6_P_vaslw_PR(pt64tmp[i], sNorm);
    }
    KwsNnseIfftReal32x16(ifftOutBuf, ifftNormBuf, sFftOrder, pCommonFftTableSt);
    return sNorm;
}

short KwsNnseCommonFftNorm(int *buf, int iBufLen)
{
    int i;
    int iMax;
    short sNorm;
    QNNSE_INT64 lmax = 0;
    const QNNSE_INT64 *__restrict pt64tmp = (const QNNSE_INT64 *)buf;
    for (i = 0; i <(iBufLen >> 1); i++) {
        lmax = Q6_P_vmaxw_PP(Q6_P_vabsw_P(pt64tmp[i]), lmax);
    }
    iMax = Q6_R_max_RR(((int *)&lmax)[0], ((int *)&lmax)[1]);
    sNorm = Q6_R_normamt_R(iMax);
    return sNorm;
}

//   ==============================================================================
//    功能描述: FFT/IFFT后Norm结果向量移位
//    输入参数:x            -- 要Norm的数据向量
//        Norm         -- 需要移位的量，正数表示左移，负数表示右移
//        Len          -- 数据长度
//    输出参数:pstTrace     -- y移位后的向量结果
//    返回参数:无
//   ==============================================================================
void KwsNnseFftVecShift32x32(int *__restrict y, const int *__restrict x, int norm, int len)
{
    int i;
    if (norm > 31) { // 31
        norm = 31; // 31
    } else if (norm < -31) { // 31
        norm = -31; // 31
    }
    for (i = 0; i < len - 1; i = i + 2) { // 2
        y[i] = Q6_R_asl_RR_sat(x[i], norm);
        y[i + 1] = Q6_R_asl_RR_sat(x[i + 1], norm);
    }
    if (len & 1) {
        y[len - 1] = Q6_R_asl_RR_sat(x[len - 1], norm);
    }
}

#endif
