/* *****************************************************************************
 * Copyright (c) Honor Device Co., Ltd. 2016-2016. All rights reserved.
 * Description: imedia_common_ns_functon.c
 * Author: wq
 * Create: 2016-2-14 14:27:1
 * 函数列表:
 * AudioCommonLdivideQ
 *****************************************************************************/
#include "imedia_common_basicop.h"
#include "imedia_common_define.h"
#include "imedia_common_math.h"
#include "imedia_command_define.h"
#include "imedia_kwsnnse_typedef.h"
#include <stdint.h>

#include <stdio.h>

#ifdef WIN32
#include "trace_config.h"
#include "debug.h"
#endif

/*****************************************************************************
 函 数 名  : AudioCommonWindowPreKws1
 功能描述  : FFT前的加窗、清零操作
 输入参数  : short *spBuf            封帧后的语音
             const short *psWin      窗表格
             short frameLen          帧长
             short fftBufLen         fftInBuf的长度
 输出参数  : int *fftInBuf         FFT输入缓冲区
 返 回 值  : IMEDIA_VOID
*****************************************************************************/
IMEDIA_COMMON_TEXT_SECTION
void AudioCommonWindowPreKws1( short *spBuf, const short *psWin, short frameLen, short fftBufLen, int *fftInBuf)
{
#ifndef Q_CODE_NNSE_FFT
    int i;

    for (i = 0; i < frameLen; i++) { // 4
        fftInBuf[i] = LShrNnse((int)spBuf[i] * (int)psWin[i], DENOISE_PROCESS_Q);  // 15 Q15
    }
    // 后面清0
    AudioCommonVecSetInt32(&fftInBuf[frameLen], fftBufLen - frameLen, 0);
#else
    int i;
    int *spBufInt, *psWinInt;
    Q3A_INT64 *fftInBufLL;
    spBufInt = (int *)spBuf;
    psWinInt = (int *)psWin;
    fftInBufLL = (Q3A_INT64 *)fftInBuf;

    for (j = 0; j < (pChnal->frameLen >> 1); j++) {
        fftInBufLL[j] = Q6_P_vasrw_PI(Q6_P_vmpyh_RR_sat(spBufInt[j], psWinInt[j]), DENOISE_PROCESS_Q); // Q15
    }
    //后面清0
    AudioCommonVecSetInt32(&fftInBuf[frameLen], fftBufLen - frameLen, 0);
#endif
}

void AudioCommonCreateMelFilters(int numFilters, int fftSize, int sampleRate, float** filters)
{
    float melMax = 1127.0 * logf(1.0 + IMEDIA_MEL_HIGH_FREQ / 700.0);
    float melMin = 1127.0 * logf(1.0 + IMEDIA_MEL_LOW_FREQ / 700.0);
    float deltaMel = (melMax - melMin) / (numFilters + 1);

    float leftMel, centerMel, rightMel;
    // 创建三角形滤波器
    for (int i = 0; i < numFilters; i++) {
        leftMel= melMin + i * deltaMel;
        centerMel = melMin + (i + 1) * deltaMel;
        rightMel = melMin + (i + 2) * deltaMel;
        for (int j = 0; j < fftSize / 2 + 1; j++) {
            float freq = 1.0 * j * sampleRate / fftSize;
            float mel = 1127.0 * logf(1.0 + freq / 700.0);
            if (mel > leftMel && mel <= centerMel) {
                filters[i][j] = (mel - leftMel) / (centerMel - leftMel);
            } else if (mel > centerMel && mel < rightMel) {
                filters[i][j] = (rightMel - mel) / (rightMel - centerMel);
            }
        }
    }

}

void AudioCommonEnergyComp(STRU_KDNR_CHAN* pChnal, int* fftOut, float* power)
{
    int i;
    float tmp1, tmp2;
    for (i = 0; i < IMEDIA_FFT_OUT; i++) {
        tmp1 = fftOut[2 * i] / IMEDIA_MAX_Q15F;
        tmp2 = fftOut[2 * i + 1] / IMEDIA_MAX_Q15F;
        power[i] = tmp1 * tmp1 + tmp2 * tmp2;
    }
}

void AudioCommonComputeFbank(float** filters, float* spectrum, int numFilters, float* fbank)
{
    float tmp;
    float fmax;
    for (int i = 0; i < numFilters; i++) {
        fbank[i] = 0.0;
        tmp = 0.0;
        for (int j = 0; j < 512 / 2 + 1; j++) {
            tmp += spectrum[j] * filters[i][j];
        }
        fmax = MAX(tmp, IMEDIA_EPSILON);
        tmp = logf(fmax); // 对数变换避免数值问题
        fbank[i] = tmp;
    }
}

void AudioCommonPreEmphasis(short* input, short* output, int size)
{
    output[0] = input[0] - LShrNnse(IMEDIA_EMPHASIS * input[0], DENOISE_PROCESS_Q);
    for (int i = size - 1; i > 0; i--) {
        output[i] = input[i] - LShrNnse((long long)IMEDIA_EMPHASIS * (long long)input[i - 1], DENOISE_PROCESS_Q);
    }
}

void AudioRemoveDC(short* input, short* output, int size)
{
    int i;
    long long tmp = 0;
    for (i = 0; i < size; i++) {
        tmp += input[i];
    }
    tmp = tmp / size;
    for (i = 0; i < size; i++) {
        output[i] = input[i] - tmp;
    }
}

/*****************************************************************************
 函 数 名  : AudioCommonPreProcFftKws1
 功能描述  : 频域预处理： 分帧、加窗、FFT
             short *x
             short sSampleRate
             short gainDB
             short delay
             short *psDelayBuf
 输出参数  : 无
 返 回 值  : static IMEDIA_VOID
*****************************************************************************/
IMEDIA_COMMON_TEXT_SECTION
int AudioCommonPreProcFftKws1(STRU_KDNR_CHAN* pChnal, short* x, short dnFlg, int* piScratchBuf)
{
    short frameLap, frameLen, fftLen, sFftNorm;
    const short *psWin = NULL;

    // 以下变量使用ScratchBuf
    int *fftInBuf = NULL;
    int *fftOutBuf = NULL;
    // 保证piScratchBuf 8字节对齐
    uintptr_t address = (uintptr_t)piScratchBuf;
    Q_ALIGN_ADDR(address, 8);
    piScratchBuf = (int *)address;

    frameLap = pChnal->frameLap;
    fftLen   = pChnal->dctOrder;
    frameLen = pChnal->frameLen;
    psWin    = pChnal->addWin;

    //   ScratchBuf使用量:
    fftInBuf    = (int *)(piScratchBuf); // 4
    fftOutBuf   = fftInBuf + (fftLen + 4); // 4

    //    分帧
    if (pChnal->readCacheBegin >= 0) {
        AudioCommonVecCopyInt16(pChnal->sHistoryFrame+ pChnal->readCacheBegin, IMEDIA_ASR_FRAMES_16K, pChnal->sInData);
    } else {
        for (int i = 0; i < IMEDIA_ASR_FRAMES_16K; i++) {
            int index = i + pChnal->readCacheBegin;
            while (index < 0) {
                index = -1 * index - 1;
            }
            pChnal->sInData[i] = pChnal->sHistoryFrame[index];
        }
    }
    if (pChnal->frameCnt >= 3) {
        AudioCommonVecCopyInt16(pChnal->sHistoryFrame + frameLap, IMEDIA_COMMAND_3FRAME_16K, pChnal->sHistoryFrame);
        pChnal->cacheBegin -= frameLap;
    }
    if (pChnal->readCacheBegin < 0) {
        pChnal->readCacheBegin += IMEDIA_COMMAND_FRAMELAP_16K;
    }

    // 去直流
    AudioRemoveDC(pChnal->sInData, pChnal->sInData, IMEDIA_ASR_FRAMES_16K);
    AudioCommonPreEmphasis(pChnal->sInData, pChnal->sInDataWin, IMEDIA_ASR_FRAMES_16K);
    AudioCommonWindowPreKws1(pChnal->sInDataWin, psWin, frameLen, fftLen + 2, fftInBuf); // 2
    //    FFT变换
    sFftNorm = AudioCommonFftKws1(fftLen, fftInBuf, fftOutBuf, NULL, pChnal->fftTab);
    for (int i = 0; i < fftLen+2; i++) {
        pChnal->fftData[i] = LShrNnse(fftOutBuf[i], sFftNorm);  // ??Q15
    }
    AudioCommonEnergyComp(pChnal, pChnal->fftData, pChnal->powerBuf);
    AudioCommonComputeFbank(pChnal->filterPointers, pChnal->powerBuf, 80, pChnal->fBankOut);

    pChnal->fftFrameCnt += 1;
    if (pChnal->fftFrameCnt >= (unsigned int)MAX_FRAME_COUNT) {  // 帧计数溢出保护
        pChnal->fftFrameCnt = (unsigned int)MAX_FRAME_COUNT;
    }
    return 0;
}
